//! Declarative command-line interface powered by `clap`.
//!
//! The public command model stays separate from the presentation library. Clap
//! owns syntax, typed values, contextual diagnostics and generated help; this
//! module only maps its typed parse tree to the command model used by the
//! composition root.

use std::path::{Path, PathBuf};

use clap::{CommandFactory, Parser, ValueEnum};

use caly_config::loader::{ConfigFileError, load_config_file};

mod grammar;

use grammar::{ClapCli, ClapCommand, ClapConfigCmd, ClapCoreCmd, ClapSubCmd, ClapSysCmd};

/// A leaf action inside the `core` family.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CoreCmd {
    Start,
    Stop,
    Restart,
    /// Switch the active core (mihomo <-> sing-box) at runtime.
    Switch(String),
    /// Select a node by its 32-hex ID or (resolved via snapshot) display name.
    Select {
        node: Option<String>,
        delay: bool,
    },
    CloseConnections,
    Mode(String),
    ProxyGroups,
    ListConnections,
    /// List registered nodes with their IDs, names and protocols.
    ListNodes,
    Traffic,
    Delay {
        all: bool,
        name: Option<String>,
        url: Option<String>,
    },
    /// List the configured routing rules (offline).
    Rules,
    /// Show which configured rule a host or IP matches (offline diagnostic).
    RuleMatch(String),
}

/// A leaf action inside the `sub` family.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SubCmd {
    Refresh,
    List,
    Check {
        path: PathBuf,
        userinfo: Option<String>,
    },
    Import {
        path: Option<PathBuf>,
        clipboard: bool,
    },
}

/// A leaf action inside the `sys` family.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SysCmd {
    Proxy(bool),
    Tun(bool),
}

/// A leaf action inside the `config` family.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ConfigCmd {
    Apply,
    Generate,
    Default,
    /// Validate the merged base/profile/fragment configuration.
    Validate,
    /// Validate a single YAML or JSON configuration file.
    Check(PathBuf),
    /// Print the active XDG config root.
    Path,
    /// List the active config tree and profiles.
    Files,
    Edit(Editor),
}

/// Supported terminal editors for the configuration directory.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Editor {
    Vim,
    Nvim,
}

/// Parsed application command, decoupled from clap's derive types.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Command {
    Help,
    Version,
    Daemon,
    Status,
    /// Run offline diagnostics; `--fix` grants missing TUN capabilities.
    Doctor(bool),
    Tui,
    Dns(Option<String>),
    Core(CoreCmd),
    Sub(SubCmd),
    Sys(SysCmd),
    Config(ConfigCmd),
    Completions(CompletionShell),
}

/// Global options shared across commands after typed validation.
#[derive(Clone, Debug, Eq, PartialEq, Default)]
pub struct CliOptions {
    pub socket: Option<PathBuf>,
    pub json: bool,
    pub core: Option<String>,
    pub mihomo_bin: Option<PathBuf>,
    pub sing_box_bin: Option<PathBuf>,
}

/// Parsed command plus global options.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Invocation {
    pub command: Command,
    pub options: CliOptions,
}

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub enum CompletionShell {
    Bash,
    Elvish,
    Fish,
    #[value(name = "powershell")]
    PowerShell,
    Zsh,
}

/// Parses CLI arguments with clap. Grammar, help output and value checks are
/// fully declarative; there is exactly one spelling per command.
pub fn parse_args(args: impl IntoIterator<Item = String>) -> Result<Invocation, clap::Error> {
    ClapCli::try_parse_from(std::iter::once("caly".to_owned()).chain(args)).map(Into::into)
}

impl From<ClapCli> for Invocation {
    fn from(cli: ClapCli) -> Self {
        let options = CliOptions {
            socket: cli.global.socket,
            json: cli.global.json,
            core: cli.global.core.map(|value| value.as_str().to_owned()),
            mihomo_bin: cli.global.mihomo_bin,
            sing_box_bin: cli.global.sing_box_bin,
        };
        let command = match cli.command {
            ClapCommand::Help => Command::Help,
            ClapCommand::Version => Command::Version,
            ClapCommand::Daemon => Command::Daemon,
            ClapCommand::Status => Command::Status,
            ClapCommand::Doctor { fix } => Command::Doctor(fix),
            ClapCommand::Tui => Command::Tui,
            ClapCommand::Dns { domain } => Command::Dns(domain),
            ClapCommand::Core { command } => Command::Core(command.into()),
            ClapCommand::Sub { command } => Command::Sub(command.into()),
            ClapCommand::Sys { command } => Command::Sys(command.into()),
            ClapCommand::Config { command } => Command::Config(command.into()),
            ClapCommand::Completions { shell } => Command::Completions(shell),
        };
        Self { command, options }
    }
}

impl From<ClapCoreCmd> for CoreCmd {
    fn from(value: ClapCoreCmd) -> Self {
        match value {
            ClapCoreCmd::Start => Self::Start,
            ClapCoreCmd::Stop => Self::Stop,
            ClapCoreCmd::Restart => Self::Restart,
            ClapCoreCmd::Switch { core } => Self::Switch(core.as_str().to_owned()),
            ClapCoreCmd::Select { node, delay } => Self::Select { node, delay },
            ClapCoreCmd::CloseConnections => Self::CloseConnections,
            ClapCoreCmd::Mode { mode } => Self::Mode(mode.as_str().to_owned()),
            ClapCoreCmd::ProxyGroups => Self::ProxyGroups,
            ClapCoreCmd::ListConnections => Self::ListConnections,
            ClapCoreCmd::ListNodes => Self::ListNodes,
            ClapCoreCmd::Traffic => Self::Traffic,
            ClapCoreCmd::Delay { all, name, url } => Self::Delay { all, name, url },
            ClapCoreCmd::Rules => Self::Rules,
            ClapCoreCmd::RuleMatch { target } => Self::RuleMatch(target),
        }
    }
}

impl From<ClapSubCmd> for SubCmd {
    fn from(value: ClapSubCmd) -> Self {
        match value {
            ClapSubCmd::Refresh => Self::Refresh,
            ClapSubCmd::List => Self::List,
            ClapSubCmd::Check { path, userinfo } => Self::Check { path, userinfo },
            ClapSubCmd::Import { path, clipboard } => Self::Import { path, clipboard },
        }
    }
}

impl From<ClapSysCmd> for SysCmd {
    fn from(value: ClapSysCmd) -> Self {
        match value {
            ClapSysCmd::Proxy { state } => Self::Proxy(state.enabled()),
            ClapSysCmd::Tun { state } => Self::Tun(state.enabled()),
        }
    }
}

impl From<ClapConfigCmd> for ConfigCmd {
    fn from(value: ClapConfigCmd) -> Self {
        match value {
            ClapConfigCmd::Apply => Self::Apply,
            ClapConfigCmd::Generate => Self::Generate,
            ClapConfigCmd::Validate => Self::Validate,
            ClapConfigCmd::Check { path } => Self::Check(path),
            ClapConfigCmd::Path => Self::Path,
            ClapConfigCmd::Files => Self::Files,
            ClapConfigCmd::Default => Self::Default,
            ClapConfigCmd::Vim => Self::Edit(Editor::Vim),
            ClapConfigCmd::Nvim => Self::Edit(Editor::Nvim),
        }
    }
}

/// Writes a completion script for the requested shell to stdout.
pub fn generate_completions(shell: CompletionShell) {
    let shell = match shell {
        CompletionShell::Bash => clap_complete::Shell::Bash,
        CompletionShell::Elvish => clap_complete::Shell::Elvish,
        CompletionShell::Fish => clap_complete::Shell::Fish,
        CompletionShell::PowerShell => clap_complete::Shell::PowerShell,
        CompletionShell::Zsh => clap_complete::Shell::Zsh,
    };
    let mut command = ClapCli::command();
    clap_complete::generate(shell, &mut command, "caly", &mut std::io::stdout());
}

pub fn check_config_file(path: &Path) -> Result<(), ConfigFileError> {
    load_config_file(path).map(|_| ())
}

#[cfg(test)]
mod cli_tests;
