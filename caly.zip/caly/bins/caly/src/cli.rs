//! Public command model decoupled from clap derive types.

use std::path::{Path, PathBuf};

use clap::{CommandFactory, Parser};

use caly_config::loader::{ConfigFileError, load_config_file};

mod grammar;

use grammar::{
    ClapCli, ClapCommand, ClapSetCmd, ClapSetCoreCmd, ClapSetConfigCmd, ClapSetDaemonCmd,
    ClapSetProfileCmd, ClapSetProxyCmd, ClapSetRuleProviderCmd, ClapSetSubCmd, ClapShowCmd,
    ClapShowConfigCmd, ClapShowCoreCmd, ClapShowProfileCmd, ClapShowProxyCmd, ClapShowSubCmd,
    ClapToolCmd, CompletionShell,
};
pub use grammar::Editor;

// Round 16: the legacy enums (`CoreCmd` / `SubCmd` /
// `SysCmd` / `ConfigCmd` / `ProfileCmd`) used to live
// here as the internal input shape of
// `commands::bridge::old_*`. Round 16 moved them to
// `client::legacy` (private client RPC types). The public
// surface of this module is now only the 5-namespace
// grammar (`Tool` / `Show` / `Set` / `Completions` /
// `Daemon`).

// ── Public enums (one variant per leaf the runtime cares about) ──

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ToolCmd {
    Help(Option<String>),
    Version,
    Doctor { fix: bool },
    Tui { readonly: bool },
    Dns(Option<String>),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ShowCmd {
    Status,
    Core(ShowCoreCmd),
    Sub(ShowSubCmd),
    Profile(ShowProfileCmd),
    Proxy(ShowProxyCmd),
    Config(ShowConfigCmd),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ShowCoreCmd {
    Nodes, Groups, Connections, Traffic, Mode, Rules { r#match: Option<String> }, Health,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ShowSubCmd {
    Providers,
    Parse { path: PathBuf, userinfo: Option<String> },
    Import { path: Option<PathBuf>, clipboard: bool },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ShowProfileCmd { List, Show { id: String } }

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ShowProxyCmd { List, Show { id: String }, Groups }

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ShowConfigCmd {
    Path, Files,
    Validate { file: Option<PathBuf> },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetCmd {
    Core(SetCoreCmd),
    Proxy(SetProxyCmd),
    Tun(bool),
    Sub(SetSubCmd),
    Profile(SetProfileCmd),
    Config(SetConfigCmd),
    Daemon(SetDaemonCmd),
    /// Round 12: declarative `rule_providers:` CRUD + refresh,
    /// the third "remote source" resource alongside `sub` and
    /// `profile`. See `commands::rule_provider::dispatch`.
    RuleProvider(SetRuleProviderCmd),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetCoreCmd {
    Start, Stop, Restart,
    Switch(String),
    Select { node: Option<String>, delay: bool, group: Option<String> },
    Mode(String),
    CloseConnections,
    Delay {
        name: Option<String>,
        all: bool,
        url: Option<String>,
        /// Per-URL sample count (1..=5); `None`
        /// means "use the default". Surfaced in
        /// the offline `Query::UrlTest` path.
        samples: Option<u32>,
    },
    UrlTest {
        name: String,
        url: Option<String>,
        timeout: Option<u32>,
        /// Per-URL sample count (1..=5); `None`
        /// means "use the default". Forwarded
        /// through the typed client command so
        /// the offline path applies it.
        samples: Option<u32>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetProxyCmd {
    Add { uri: String, group: Option<String>, apply: bool, dry_run: bool },
    Edit { id: String, apply: bool, dry_run: bool },
    Remove { id: String, apply: bool, dry_run: bool },
    Import { path: PathBuf, apply: bool, dry_run: bool },
    On, Off,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetSubCmd {
    Refresh,
    Add { url: String, name: Option<String>, apply: bool, dry_run: bool },
    Remove { url: String, apply: bool, dry_run: bool },
    Enable { url: String, apply: bool, dry_run: bool },
    Disable { url: String, apply: bool, dry_run: bool },
    Import { path: Option<PathBuf>, clipboard: bool, apply: bool, dry_run: bool },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetProfileCmd {
    Add { id: String, source: String, apply: bool, dry_run: bool },
    Remove { id: String, apply: bool, dry_run: bool },
    Edit { id: String, apply: bool, dry_run: bool },
    /// Round 12: refresh always writes the body (the body IS the
    /// cache). A `NotModified` outcome (HTTP 304) is a real
    /// outcome, not a dry-run. The `--apply` / `--dry-run` flags
    /// were removed from `set profile refresh` because the
    /// distinction was meaningless.
    Refresh { id: Option<String> },
    Export { id: String, out: PathBuf },
    Enable { id: String, apply: bool, dry_run: bool },
    Disable { id: String, apply: bool, dry_run: bool },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetConfigCmd {
    Apply, Generate, Default,
    Diff { file: Option<PathBuf> },
    Edit(Editor),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetDaemonCmd { Stop, Reload, Restart, Status }

/// Round 12: declarative CRUD for `rule_providers:`. Each
/// variant is a separate grammar leaf so the help text can name
/// the resource being acted on. `--apply` / `--dry-run` policy
/// is the same as the other `set` resources (default dry-run,
/// explicit `--apply` writes, mutually exclusive).
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SetRuleProviderCmd {
    /// Add a new provider to `rule_providers:`. Source kind is
    /// one of `http <url>`, `file <path>`, or `inline --payload <body>`.
    Add {
        name: String,
        source: RuleProviderSourceSpec,
        apply: bool,
        dry_run: bool,
    },
    /// Remove a provider from `rule_providers:`.
    Remove {
        name: String,
        apply: bool,
        dry_run: bool,
    },
    /// Enable a disabled provider.
    Enable {
        name: String,
        apply: bool,
        dry_run: bool,
    },
    /// Disable a provider (the daemon boot skips it).
    Disable {
        name: String,
        apply: bool,
        dry_run: bool,
    },
    /// Refresh the provider's materialised body under
    /// `<workdir>/rule-providers/<name>.yaml`. Always writes
    /// (the materialised file IS the body the kernel reads);
    /// `--apply` / `--dry-run` are not exposed here for the
    /// same reason as `set profile refresh`.
    Refresh { name: Option<String> },
    /// List all declared rule providers (and their enable
    /// state). Pure read; the JSON output is the source of
    /// truth for scripts.
    List,
}

/// Round 12: public source-kind spec for the `set rule-provider
/// add` leaf. Mirrors the `type: http | file | inline` shape
/// of `caly_config::schema::RuleProviderSourceConfig` but
/// erases the bounded text (the CLI does not enforce size
/// diagnostics at the grammar level).
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuleProviderSourceSpec {
    Http { url: String, interval_ms: u64 },
    File { path: PathBuf },
    Inline { payload: String },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Command {
    Daemon,
    // New (Round 11)
    Tool(ToolCmd),
    Show(ShowCmd),
    Set(SetCmd),
    Completions(CompletionShell),
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct CliOptions {
    pub socket: Option<PathBuf>,
    pub json: bool,
    pub core: Option<String>,
    pub mihomo_bin: Option<PathBuf>,
    pub sing_box_bin: Option<PathBuf>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Invocation {
    pub command: Command,
    pub options: CliOptions,
}

// ── Parsing ──

pub fn parse_args(args: impl IntoIterator<Item = String>) -> Result<Invocation, clap::Error> {
    ClapCli::try_parse_from(std::iter::once("caly".to_owned()).chain(args)).map(Into::into)
}

impl From<ClapCli> for Invocation {
    fn from(cli: ClapCli) -> Self {
        let options = CliOptions {
            socket: cli.global.socket,
            json: cli.global.json,
            core: cli.global.core.map(|v| v.as_str().to_owned()),
            mihomo_bin: cli.global.mihomo_bin,
            sing_box_bin: cli.global.sing_box_bin,
        };
        let command = match cli.command {
            ClapCommand::Daemon => Command::Daemon,
            ClapCommand::Tool { command } => Command::Tool(command.into()),
            ClapCommand::Show { command } => Command::Show(command.into()),
            ClapCommand::Set { command } => Command::Set(command.into()),
            ClapCommand::Completions { shell } => Command::Completions(shell),
        };
        Self { command, options }
    }
}

// ── From impls: clap grammar → public enums ──

impl From<ClapToolCmd> for ToolCmd {
    fn from(c: ClapToolCmd) -> Self {
        match c {
            ClapToolCmd::Help { command } => Self::Help(command),
            ClapToolCmd::Version => Self::Version,
            ClapToolCmd::Doctor { fix } => Self::Doctor { fix },
            ClapToolCmd::Tui { readonly } => Self::Tui { readonly },
            ClapToolCmd::Dns { domain } => Self::Dns(domain),
        }
    }
}

impl From<ClapShowCmd> for ShowCmd {
    fn from(c: ClapShowCmd) -> Self {
        match c {
            ClapShowCmd::Status => Self::Status,
            ClapShowCmd::Core { command } => Self::Core(command.into()),
            ClapShowCmd::Sub { command } => Self::Sub(command.into()),
            ClapShowCmd::Profile { command } => Self::Profile(command.into()),
            ClapShowCmd::Proxy { command } => Self::Proxy(command.into()),
            ClapShowCmd::Config { command } => Self::Config(command.into()),
        }
    }
}

impl From<ClapShowCoreCmd> for ShowCoreCmd {
    fn from(c: ClapShowCoreCmd) -> Self {
        match c {
            ClapShowCoreCmd::Nodes => Self::Nodes,
            ClapShowCoreCmd::Groups => Self::Groups,
            ClapShowCoreCmd::Connections => Self::Connections,
            ClapShowCoreCmd::Traffic => Self::Traffic,
            ClapShowCoreCmd::Mode => Self::Mode,
            ClapShowCoreCmd::Rules { r#match } => Self::Rules { r#match },
            ClapShowCoreCmd::Health => Self::Health,
        }
    }
}

impl From<ClapShowSubCmd> for ShowSubCmd {
    fn from(c: ClapShowSubCmd) -> Self {
        match c {
            ClapShowSubCmd::Providers => Self::Providers,
            ClapShowSubCmd::Parse { path, userinfo } => Self::Parse { path, userinfo },
            ClapShowSubCmd::Import { path, clipboard } => Self::Import { path, clipboard },
        }
    }
}

impl From<ClapShowProfileCmd> for ShowProfileCmd {
    fn from(c: ClapShowProfileCmd) -> Self {
        match c {
            ClapShowProfileCmd::List => Self::List,
            ClapShowProfileCmd::Show { id } => Self::Show { id },
        }
    }
}

impl From<ClapShowProxyCmd> for ShowProxyCmd {
    fn from(c: ClapShowProxyCmd) -> Self {
        match c {
            ClapShowProxyCmd::List => Self::List,
            ClapShowProxyCmd::Show { id } => Self::Show { id },
            ClapShowProxyCmd::Groups => Self::Groups,
        }
    }
}

impl From<ClapShowConfigCmd> for ShowConfigCmd {
    fn from(c: ClapShowConfigCmd) -> Self {
        match c {
            ClapShowConfigCmd::Path => Self::Path,
            ClapShowConfigCmd::Files => Self::Files,
            ClapShowConfigCmd::Validate { file } => Self::Validate { file },
        }
    }
}

impl From<ClapSetCmd> for SetCmd {
    fn from(c: ClapSetCmd) -> Self {
        match c {
            ClapSetCmd::Core { command } => Self::Core(command.into()),
            ClapSetCmd::Proxy { command } => Self::Proxy(command.into()),
            ClapSetCmd::Tun { state } => Self::Tun(state.enabled()),
            ClapSetCmd::Sub { command } => Self::Sub(command.into()),
            ClapSetCmd::Profile { command } => Self::Profile(command.into()),
            ClapSetCmd::Config { command } => Self::Config(command.into()),
            ClapSetCmd::Daemon { command } => Self::Daemon(command.into()),
            ClapSetCmd::RuleProvider { command } => Self::RuleProvider(command.into()),
        }
    }
}

impl From<ClapSetCoreCmd> for SetCoreCmd {
    fn from(c: ClapSetCoreCmd) -> Self {
        match c {
            ClapSetCoreCmd::Start => Self::Start,
            ClapSetCoreCmd::Stop => Self::Stop,
            ClapSetCoreCmd::Restart => Self::Restart,
            ClapSetCoreCmd::Switch { core } => Self::Switch(core.as_str().to_owned()),
            ClapSetCoreCmd::Select { node, delay, group } => Self::Select { node, delay, group },
            ClapSetCoreCmd::Mode { mode } => Self::Mode(mode.as_str().to_owned()),
            ClapSetCoreCmd::CloseConnections => Self::CloseConnections,
            ClapSetCoreCmd::Delay { name, all, url, samples } => {
                Self::Delay { name, all, url, samples }
            }
            ClapSetCoreCmd::UrlTest { name, url, timeout, samples } => {
                Self::UrlTest { name, url, timeout, samples }
            }
        }
    }
}

impl From<ClapSetProxyCmd> for SetProxyCmd {
    fn from(c: ClapSetProxyCmd) -> Self {
        match c {
            ClapSetProxyCmd::Add { uri, group, apply, dry_run } =>
                Self::Add { uri, group, apply, dry_run },
            ClapSetProxyCmd::Edit { id, apply, dry_run } => Self::Edit { id, apply, dry_run },
            ClapSetProxyCmd::Remove { id, apply, dry_run } => Self::Remove { id, apply, dry_run },
            ClapSetProxyCmd::Import { path, apply, dry_run } => Self::Import { path, apply, dry_run },
            ClapSetProxyCmd::On => Self::On,
            ClapSetProxyCmd::Off => Self::Off,
        }
    }
}

impl From<ClapSetSubCmd> for SetSubCmd {
    fn from(c: ClapSetSubCmd) -> Self {
        match c {
            ClapSetSubCmd::Refresh => Self::Refresh,
            ClapSetSubCmd::Add { url, name, apply, dry_run } => Self::Add { url, name, apply, dry_run },
            ClapSetSubCmd::Remove { url, apply, dry_run } => Self::Remove { url, apply, dry_run },
            ClapSetSubCmd::Enable { url, apply, dry_run } => Self::Enable { url, apply, dry_run },
            ClapSetSubCmd::Disable { url, apply, dry_run } => Self::Disable { url, apply, dry_run },
            ClapSetSubCmd::Import { path, clipboard, apply, dry_run } =>
                Self::Import { path, clipboard, apply, dry_run },
        }
    }
}

impl From<ClapSetProfileCmd> for SetProfileCmd {
    fn from(c: ClapSetProfileCmd) -> Self {
        match c {
            ClapSetProfileCmd::Add { id, source, apply, dry_run } =>
                Self::Add { id, source, apply, dry_run },
            ClapSetProfileCmd::Remove { id, apply, dry_run } => Self::Remove { id, apply, dry_run },
            ClapSetProfileCmd::Edit { id, apply, dry_run } => Self::Edit { id, apply, dry_run },
            ClapSetProfileCmd::Refresh { id } => Self::Refresh { id },
            ClapSetProfileCmd::Export { id, out } => Self::Export { id, out },
            ClapSetProfileCmd::Enable { id, apply, dry_run } => Self::Enable { id, apply, dry_run },
            ClapSetProfileCmd::Disable { id, apply, dry_run } => Self::Disable { id, apply, dry_run },
        }
    }
}

impl From<ClapSetConfigCmd> for SetConfigCmd {
    fn from(c: ClapSetConfigCmd) -> Self {
        match c {
            ClapSetConfigCmd::Apply => Self::Apply,
            ClapSetConfigCmd::Generate => Self::Generate,
            ClapSetConfigCmd::Default => Self::Default,
            ClapSetConfigCmd::Diff { file } => Self::Diff { file },
            ClapSetConfigCmd::Edit { editor } => Self::Edit(match editor {
                grammar::Editor::Vim => Editor::Vim,
                grammar::Editor::Nvim => Editor::Nvim,
            }),
        }
    }
}

impl From<ClapSetDaemonCmd> for SetDaemonCmd {
    fn from(c: ClapSetDaemonCmd) -> Self {
        match c {
            ClapSetDaemonCmd::Stop => Self::Stop,
            ClapSetDaemonCmd::Reload => Self::Reload,
            ClapSetDaemonCmd::Restart => Self::Restart,
            ClapSetDaemonCmd::Status => Self::Status,
        }
    }
}

impl From<ClapSetRuleProviderCmd> for SetRuleProviderCmd {
    fn from(c: ClapSetRuleProviderCmd) -> Self {
        match c {
            ClapSetRuleProviderCmd::AddHttp { name, url, interval_ms, apply, dry_run } => Self::Add {
                name,
                source: RuleProviderSourceSpec::Http { url, interval_ms },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::AddFile { name, path, apply, dry_run } => Self::Add {
                name,
                source: RuleProviderSourceSpec::File { path },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::AddInline { name, payload, apply, dry_run } => Self::Add {
                name,
                source: RuleProviderSourceSpec::Inline { payload },
                apply,
                dry_run,
            },
            ClapSetRuleProviderCmd::Remove { name, apply, dry_run } => Self::Remove { name, apply, dry_run },
            ClapSetRuleProviderCmd::Enable { name, apply, dry_run } => Self::Enable { name, apply, dry_run },
            ClapSetRuleProviderCmd::Disable { name, apply, dry_run } => Self::Disable { name, apply, dry_run },
            ClapSetRuleProviderCmd::Refresh { name } => Self::Refresh { name },
            ClapSetRuleProviderCmd::List => Self::List,
        }
    }
}

pub fn check_config_file(path: &Path) -> Result<(), ConfigFileError> {
    load_config_file(path).map(|_| ())
}

pub fn generate_completions(shell: CompletionShell) {
    let shell = match shell {
        CompletionShell::Bash => clap_complete::Shell::Bash,
        CompletionShell::Elvish => clap_complete::Shell::Elvish,
        CompletionShell::Fish => clap_complete::Shell::Fish,
        CompletionShell::PowerShell => clap_complete::Shell::PowerShell,
        CompletionShell::Zsh => clap_complete::Shell::Zsh,
    };
    let mut command = ClapCli::command();
    clap_complete::generate(shell, &mut command, "caly", &mut std::io::stdout());
}

#[cfg(test)]
mod cli_tests;
