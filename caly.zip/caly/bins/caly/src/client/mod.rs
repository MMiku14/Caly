//! CLI-side UDS client commands.

mod config_generate;
mod control;
mod execute;
mod output;
mod output_capabilities;
mod query;
mod rules;

pub use config_generate::{
    config_files, config_path, edit_config, generate_config, reset_default_config,
    validate_active_config,
};
pub use control::run_control_action;
pub use query::{Query, run_query};

use std::{path::PathBuf, process::ExitCode};

use crate::{ClientCommand, cli::ConfigCmd};
use caly_protocol::client::{ClientContract, UdsClient};

/// Best-effort daemon snapshot read for the currently active core label
/// (`mihomo`/`sing-box`). Falls back to `None` when the daemon is unreachable
/// or reports no core, keeping offline queries usable without a daemon.
pub(super) fn active_core_kind_label() -> Option<String> {
    use caly_protocol::protocol::v2::WireCoreKind;
    let socket = std::env::var_os("CALY_SOCKET").map_or_else(
        || caly_platform::paths::AppPaths::from_env().socket_path(),
        std::path::PathBuf::from,
    );
    let mut client = UdsClient::connect(socket).ok()?;
    execute::handshake(&mut client).ok()?;
    let snapshot = client.snapshot().ok()?;
    WireCoreKind::from_wire(snapshot.applied.core_kind?).map(|kind| {
        match kind {
            WireCoreKind::Mihomo => "mihomo",
            WireCoreKind::SingBox => "sing-box",
            WireCoreKind::Xray => "xray",
        }
        .to_owned()
    })
}

/// Executes one bounded client command against the configured UDS.
pub fn run_client(command: ClientCommand, options: crate::cli::CliOptions) -> ExitCode {
    // Reject an invalid `--core` target before any daemon connection, so a
    // typo fails fast and clearly instead of silently mapping to mihomo.
    if let Some(core) = options.core.as_deref()
        && core != "mihomo"
        && core != "sing-box"
    {
        return output::report_invalid_core(core, options.json);
    }
    // Read-only Clash API queries run offline against the controller, so they
    // do not require a daemon connection or a mutation operation.
    if let ClientCommand::Core(core_cmd) = &command {
        if let Some(query) = execute::core_query(core_cmd) {
            let core = match options.core.as_deref() {
                Some(core) => core.to_owned(),
                None => std::env::var("CALY_CORE").unwrap_or_else(|_| {
                    // Follow the daemon's runtime active core so offline
                    // queries (delay, proxy-groups, ...) hit the kernel the
                    // user actually switched to, not a hardcoded mihomo.
                    active_core_kind_label().unwrap_or_else(|| "mihomo".to_owned())
                }),
            };
            return run_query(&core, query, options.json);
        }
        // Routing-rule commands run fully offline against the configured rules.
        if matches!(
            core_cmd,
            crate::cli::CoreCmd::Rules | crate::cli::CoreCmd::RuleMatch(_)
        ) {
            return rules::run_rules(core_cmd, options.json);
        }
    }
    // `config` leaves that never need a daemon connection run offline.
    if let ClientCommand::Config(config_cmd) = &command {
        match config_cmd {
            ConfigCmd::Generate => return generate_config(options.json),
            ConfigCmd::Default => return reset_default_config(options.json),
            ConfigCmd::Validate => return validate_active_config(options.json),
            ConfigCmd::Check(path) => return execute::check_single_config_file(path, options.json),
            ConfigCmd::Path => return config_path(options.json),
            ConfigCmd::Files => return config_files(options.json),
            ConfigCmd::Edit(editor) => return edit_config(*editor, options.json),
            ConfigCmd::Apply => {}
        }
    }
    let socket = options.socket.unwrap_or_else(|| {
        std::env::var_os("CALY_SOCKET").map_or_else(
            || caly_platform::paths::AppPaths::from_env().socket_path(),
            PathBuf::from,
        )
    });
    let mut client = match execute::connect_with_retry(&socket) {
        Ok(client) => client,
        Err(error) => return output::report_error(error, options.json),
    };
    if let Err(error) = execute::handshake(&mut client) {
        return output::report_error(error, options.json);
    }
    let core = options.core.as_deref();
    match command {
        ClientCommand::Status => output::print_status(&mut client, options.json),
        ClientCommand::Core(core_cmd) => {
            execute::execute_core_cmd(&mut client, core_cmd, core, options.json)
        }
        ClientCommand::RefreshSubscription => {
            execute::execute_refresh_subscription(&mut client, options.json)
        }
        ClientCommand::Sys(sys_cmd) => execute::execute_sys_cmd(&mut client, sys_cmd, options.json),
        ClientCommand::Config(config_cmd) => {
            execute::execute_config_cmd(&mut client, config_cmd, options.json)
        }
    }
}

/// Generates a random 128-bit operation id.
///
/// Operation ids only need uniqueness (they are not security tokens): 128
/// random bits from the platform CSPRNG give negligible collision probability
/// and carry no time/pid structure, so adjacent operations are never related.
pub(crate) fn operation_id() -> [u8; 16] {
    caly_platform::entropy::random_bytes::<16>()
}

/// Hex-encodes a 128-bit identity for display and wire JSON.
pub(crate) fn hex(value: [u8; 16]) -> String {
    caly_domain::to_hex(value)
}

#[cfg(test)]
mod client_tests;
