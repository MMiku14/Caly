//! Offline Clash API queries against the running core's controller.
//!
//! These are read-only queries (proxy groups, connections, traffic) that the
//! CLI executes directly against the controller address, without going through
//! a daemon mutation operation. The core kind is resolved from `--core` or
//! `CALY_CORE`, and the controller address from `CALY_MIHOMO_CONTROLLER` /
//! `CALY_SINGBOX_CONTROLLER` (defaulting to the standard loopback ports).

use std::process::ExitCode;

use caly_kernel::ports::{ConnectionSummary, KernelControl, ProxyGroup};

/// The controller timeout for read-only queries.
const QUERY_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(5);

/// Probe targets for latency estimation, ordered by reachability of a clean
/// 204 across egresses. The kernel dials each node through the proxy, so a
/// node that cannot reach one target may reach another (different egress /
/// anycast); the first URL that answers wins, double-sampled for stability.
///
/// Cloudflare's anycast CDN leads: it is reachable from most egresses even
/// where the Google endpoints are blocked or constrained (e.g. a CN exit),
/// so the common case answers on the first URL rather than stalling the whole
/// failover across the blocked Google targets.
pub const PROBE_URLS: [&str; 3] = [
    "https://cp.cloudflare.com/generate_204",
    "https://www.google.com/generate_204",
    "https://www.gstatic.com/generate_204",
];

/// Probes one node through the active core controller with URL failover and
/// a confirmatory second sample.
///
/// * URLs are tried in order; the first URL the node can reach wins.
/// * A reachable first sample is confirmed with a second sample on the same
///   URL and the minimum of the two is returned (a single-sample spike is
///   common on hot/loaded egress, and the minimum is a stabler estimate).
/// * All URLs unreachable maps to `Ok(None)`; a controller transport error
///   (connect failure, kernel gone) stays `Err` so callers can distinguish
///   an unreachable node from a probe infrastructure fault.
pub(super) fn probe_delay_best(
    control: &mut dyn KernelControl,
    name: &str,
    url: Option<&str>,
    timeout: std::time::Duration,
) -> Result<Option<u32>, caly_kernel::ports::KernelFailure> {
    let urls: Vec<&str> = match url {
        Some(value) => vec![value],
        None => PROBE_URLS.to_vec(),
    };
    for probe_url in urls {
        match control.test_delay_url(name, probe_url, timeout) {
            Ok(Some(first)) => {
                // Second sample on the same URL; a transient hiccup on the
                // first sample is common, keep the minimum.
                let second = control.test_delay_url(name, probe_url, timeout).ok().flatten();
                let ms = second.map_or(first, |second| first.min(second));
                return Ok(Some(ms));
            }
            Ok(None) => {}
            Err(error) if error.kind == caly_kernel::ports::KernelFailureKind::DeadlineExceeded => {
                // The probe stalled on this particular target (e.g. a
                // network-constrained URL). That is a property of the *target*, not
                // of the node, so fail over to the next probe URL instead of
                // aborting the whole sweep on a single blocked endpoint.
            }
            Err(error) => return Err(error),
        }
    }
    Ok(None)
}
/// Executes a read-only Clash API query against the resolved core controller.
pub fn run_query(core: &str, query: Query, json: bool) -> ExitCode {
    let mut control = match build_control(core) {
        Ok(control) => control,
        Err(error) => {
            return crate::client::output::report_failure(&format!("query failed: {error}"), json);
        }
    };
    match query {
        Query::ProxyGroups => match control.proxy_groups(QUERY_TIMEOUT) {
            Ok(groups) => print_groups(&groups, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
        Query::Connections => match control.connections(QUERY_TIMEOUT) {
            Ok(summary) => print_connections(&summary, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
        Query::Traffic => match control.traffic(QUERY_TIMEOUT) {
            Ok((download, upload)) => print_traffic(download, upload, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
        Query::UrlTest { name, url } => match probe_delay_best(&mut *control, &name, url.as_deref(), QUERY_TIMEOUT) {
            Ok(delay) => print_delay(&name, delay, json),
            Err(error) => report_query_error(&format!("{error}"), json),
        },
    }
}

/// A read-only Clash API query.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Query {
    ProxyGroups,
    Connections,
    Traffic,
    /// Latency test for a named proxy (`GET /proxies/{name}/delay`).
    UrlTest {
        name: String,
        /// Probe target URL override (default: Google generate_204).
        url: Option<String>,
    },
}

/// Builds the core controller from the resolved core kind.
pub(super) fn build_control(core: &str) -> Result<Box<dyn KernelControl + Send>, String> {
    // The daemon persists its generated controller secret to an owner-only file
    // so offline queries authenticate; `CALY_CONTROLLER_SECRET` overrides it.
    let secret = std::env::var("CALY_CONTROLLER_SECRET")
        .ok()
        .or_else(read_daemon_secret)
        .and_then(|value| caly_domain::BoundedText::new(value).ok());
    // Controller endpoints come from the config file (then env, then defaults).
    let controllers = crate::daemon_config::controllers().map_err(|e| format!("{e:?}"))?;
    match core {
        "mihomo" => caly_kernel::mihomo::MihomoHttpControl::new(controllers.mihomo, secret)
            .map(|control| Box::new(control) as Box<dyn KernelControl + Send>)
            .map_err(|error| format!("{error:?}")),
        "sing-box" => caly_kernel::sing_box::SingBoxHttpControl::new(controllers.sing_box, secret)
            .map(|control| Box::new(control) as Box<dyn KernelControl + Send>)
            .map_err(|error| format!("{error:?}")),
        other => Err(format!("unknown core `{other}`; use mihomo or sing-box")),
    }
}

/// Reads the controller secret the daemon persisted under the XDG runtime root.
fn read_daemon_secret() -> Option<String> {
    let path = caly_platform::paths::AppPaths::from_env().controller_secret_path();
    std::fs::read_to_string(&path)
        .ok()
        .map(|value| value.trim().to_owned())
        .filter(|value| !value.is_empty())
}

fn print_groups(groups: &[ProxyGroup], json: bool) -> ExitCode {
    if json {
        let value: Vec<serde_json::Value> = groups
            .iter()
            .map(|group| {
                serde_json::json!({
                    "name": group.name,
                    "selected": group.selected,
                })
            })
            .collect();
        println!("{}", serde_json::json!({ "proxy_groups": value }));
    } else {
        println!("proxy groups:");
        for group in groups {
            let selected = group.selected.as_deref().unwrap_or("-");
            println!("  {} (selected: {selected})", group.name);
        }
    }
    ExitCode::SUCCESS
}

fn print_connections(summary: &ConnectionSummary, json: bool) -> ExitCode {
    if json {
        println!(
            "{}",
            serde_json::json!({
                "active": summary.active,
                "download_bytes": summary.download_bytes,
                "upload_bytes": summary.upload_bytes,
            })
        );
    } else {
        println!(
            "connections: {} active | download {} B | upload {} B",
            summary.active, summary.download_bytes, summary.upload_bytes
        );
    }
    ExitCode::SUCCESS
}

fn print_traffic(download: u64, upload: u64, json: bool) -> ExitCode {
    if json {
        println!(
            "{}",
            serde_json::json!({ "download_bytes": download, "upload_bytes": upload })
        );
    } else {
        println!("traffic: download {download} B | upload {upload} B");
    }
    ExitCode::SUCCESS
}

fn print_delay(name: &str, delay: Option<u32>, json: bool) -> ExitCode {
    if json {
        println!("{}", serde_json::json!({ "name": name, "delay_ms": delay }));
    } else {
        match delay {
            Some(ms) => println!("{name}: {ms} ms"),
            None => println!("{name}: unreachable / no latency"),
        }
    }
    ExitCode::SUCCESS
}

fn report_query_error(message: &str, json: bool) -> ExitCode {
    crate::client::output::report_failure(&format!("query failed: {message}"), json)
}
