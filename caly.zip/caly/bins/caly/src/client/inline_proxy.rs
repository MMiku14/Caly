//! Round 16: offline inline-proxy writer for the
//! `set proxy …` leaves.
//!
//! The 4 CRUD leaves (`add` / `edit` / `remove` / `import`)
//! round-trip inline proxy URIs as JSON files under
//! `<state>/inline-proxies/<id>.json`. The on-disk shape
//! is intentionally minimal — `{ "uri": "...", "group":
//! optional, "added_at_ms": u64 }` — so the kernel's
//! own URI parser is the only source of truth for the
//! node structure (a single proxy URI maps to one node).
//!
//! # Why a separate module (not inside `subscription.rs`)
//!
//! `subscription` is for *fetched* content (subscription
//! sources refresh over the network). Inline proxies are
//! operator-typed content: the URI is the body, the
//! identity is a hash of the URI, and the file lifetime
//! matches the operator's `set proxy add/remove` flow.
//! Splitting the two resources keeps the writer
//! invariants simple (no daemon refresh, no `Merge`
//! recursion, no source-name de-duplication).

use std::path::{Path, PathBuf};

use caly_platform::paths::AppPaths;

const INLINE_PROXY_DIR: &str = "inline-proxies";

/// Round 16: convenience re-export so the dispatch in
/// `commands::set::proxy` doesn't have to reach into
/// `caly_platform::paths` directly.
pub fn resolve_paths_pub() -> AppPaths {
    AppPaths::from_env()
}

/// Single inline proxy entry. The URI is the operator's
/// raw input; the kernel's URI parser is the source of
/// truth for the structured node.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct InlineProxy {
    /// The operator-typed proxy URI (`vmess://...`,
    /// `ss://...`, `trojan://...`, etc.). Stored as
    /// received — round-trip through `serde_json` is
    /// faithful.
    pub uri: String,
    /// Optional proxy group the inline node belongs to.
    /// Round 16: advisory; the kernel reads it on the
    /// `config apply` path.
    pub group: Option<String>,
    /// Wall-clock ms when the entry was added. Used as
    /// a stable ordering hint for the kernel.
    pub added_at_ms: u64,
}

/// Single error type for the 4 CRUD writers. The CLI maps
/// each variant to a stable `code:` so the operator gets
/// a consistent envelope across writers.
#[derive(Debug)]
pub enum InlineProxyError {
    /// The URI is empty or fails basic shape validation
    /// (`scheme://...`). The kernel's parser is the
    /// source of truth for full validation, but a
    /// trivially-malformed URI never reaches disk.
    InvalidUri(String),
    /// `add` / `import` on a URI whose hash is already
    /// present in `<state>/inline-proxies/`.
    AlreadyDeclared(String),
    /// `remove` / `edit` on a URI whose hash isn't in
    /// the directory.
    NotDeclared(String),
    /// The proxy file is unreadable / unwriteable.
    Io(String),
}

impl core::fmt::Display for InlineProxyError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUri(reason) => write!(formatter, "invalid proxy URI: {reason}"),
            Self::AlreadyDeclared(id) =>
                write!(formatter, "inline proxy `{id}` is already declared"),
            Self::NotDeclared(id) => write!(formatter, "inline proxy `{id}` is not declared"),
            Self::Io(reason) => write!(formatter, "inline proxy I/O failed: {reason}"),
        }
    }
}

impl std::error::Error for InlineProxyError {}

/// What an `add` / `remove` / `import` call did.
/// `DryRun` is what `--dry-run` (the default) returns when
/// the call would have written.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InlineProxyOutcome {
    Applied,
    DryRun,
}

fn inline_dir(paths: &AppPaths) -> PathBuf {
    paths.state.join(INLINE_PROXY_DIR)
}

fn validate_uri(uri: &str) -> Result<(), InlineProxyError> {
    let uri = uri.trim();
    if uri.is_empty() {
        return Err(InlineProxyError::InvalidUri("URI is empty".to_owned()));
    }
    if !(uri.starts_with("vmess://")
        || uri.starts_with("ss://")
        || uri.starts_with("trojan://")
        || uri.starts_with("vless://")
        || uri.starts_with("hysteria://")
        || uri.starts_with("hysteria2://")
        || uri.starts_with("tuic://")
        || uri.starts_with("wireguard://"))
    {
        return Err(InlineProxyError::InvalidUri(format!(
            "URI must start with a known proxy scheme (vmess, ss, trojan, vless, hysteria, hysteria2, tuic, wireguard); got `{}`",
            &uri[..uri.len().min(20)]
        )));
    }
    Ok(())
}

/// Stable id derived from the URI. SHA-256 hex of the
/// URI bytes, truncated to 16 hex chars (64 bits — same
/// convention as `NodeId`).
fn id_for_uri(uri: &str) -> String {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};
    let mut hasher = DefaultHasher::new();
    uri.hash(&mut hasher);
    let h = hasher.finish();
    format!("{h:016x}")
}

/// Returns the on-disk path for `id` *without* touching
/// the filesystem. The dry-run writers use this so a
/// `set proxy add` dry-run is truly read-only: the parent
/// directory is not created, the file is not opened,
/// the inline-proxies dir is left untouched if it
/// didn't already exist. Apply mode still uses
/// [`path_for_id_and_ensure_dir`] below.
fn path_for_id(paths: &AppPaths, id: &str) -> PathBuf {
    inline_dir(paths).join(format!("{id}.json"))
}

/// Returns the on-disk path for `id`, creating the
/// inline-proxies directory if it doesn't exist. Used
/// by the apply path and the read-back helpers
/// (`list_proxies`, `read_entry`).
fn path_for_id_and_ensure_dir(
    paths: &AppPaths,
    id: &str,
) -> Result<PathBuf, InlineProxyError> {
    let dir = inline_dir(paths);
    std::fs::create_dir_all(&dir).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    Ok(dir.join(format!("{id}.json")))
}

fn read_entry(path: &Path) -> Result<InlineProxy, InlineProxyError> {
    let bytes = std::fs::read(path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    serde_json::from_slice::<InlineProxyEntry>(&bytes)
        .map(InlineProxy::from)
        .map_err(|e| InlineProxyError::Io(format!("parse {}: {e}", path.display())))
}

fn write_entry(path: &Path, entry: &InlineProxy) -> Result<(), InlineProxyError> {
    let serialized =
        serde_json::to_vec_pretty(&InlineProxyEntry::from(entry.clone()))
            .map_err(|e| InlineProxyError::Io(e.to_string()))?;
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, &serialized).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    std::fs::rename(&tmp, path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    Ok(())
}

#[derive(serde::Serialize, serde::Deserialize)]
struct InlineProxyEntry {
    uri: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    group: Option<String>,
    added_at_ms: u64,
}

impl From<InlineProxy> for InlineProxyEntry {
    fn from(p: InlineProxy) -> Self {
        Self {
            uri: p.uri,
            group: p.group,
            added_at_ms: p.added_at_ms,
        }
    }
}

impl From<InlineProxyEntry> for InlineProxy {
    fn from(e: InlineProxyEntry) -> Self {
        Self {
            uri: e.uri,
            group: e.group,
            added_at_ms: e.added_at_ms,
        }
    }
}

fn current_unix_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| u64::try_from(d.as_millis().min(u128::from(u64::MAX))).unwrap_or(u64::MAX))
}

/// `set proxy add <uri> [--group G] [--apply]`.
///
/// Default: dry-run. `--apply` is the only thing that
/// actually writes `<state>/inline-proxies/<id>.json`.
pub fn add_proxy(
    paths: &AppPaths,
    uri: &str,
    group: Option<&str>,
    apply: bool,
) -> Result<(InlineProxyOutcome, String), InlineProxyError> {
    validate_uri(uri)?;
    let id = id_for_uri(uri);
    // Round 19: dry-run uses the read-only path
    // helper (no `create_dir_all` side-effect), so
    // `set proxy add --dry-run` against a fresh
    // state root is truly side-effect-free. Apply
    // mode uses the ensure-dir helper.
    let path = path_for_id(paths, &id);
    if path.exists() {
        return Err(InlineProxyError::AlreadyDeclared(id));
    }
    if !apply {
        return Ok((InlineProxyOutcome::DryRun, id));
    }
    let path = path_for_id_and_ensure_dir(paths, &id)?;
    let entry = InlineProxy {
        uri: uri.trim().to_owned(),
        group: group.map(str::to_owned),
        added_at_ms: current_unix_ms(),
    };
    write_entry(&path, &entry)?;
    Ok((InlineProxyOutcome::Applied, id))
}

/// `set proxy remove <id>` (id is the 16-hex id from
/// `list` or the URI itself).
pub fn remove_proxy(
    paths: &AppPaths,
    id: &str,
    apply: bool,
) -> Result<InlineProxyOutcome, InlineProxyError> {
    let resolved = resolve_id(paths, id)?;
    if !apply {
        return Ok(InlineProxyOutcome::DryRun);
    }
    let path = path_for_id(paths, &resolved);
    if !path.exists() {
        return Err(InlineProxyError::NotDeclared(resolved));
    }
    std::fs::remove_file(&path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    Ok(InlineProxyOutcome::Applied)
}

/// `set proxy edit <id>` — spawn `$EDITOR` (or `vi`) with
/// the current URI line, write the result back.
pub fn edit_proxy(
    paths: &AppPaths,
    id: &str,
    apply: bool,
) -> Result<InlineProxyOutcome, InlineProxyError> {
    let resolved = resolve_id(paths, id)?;
    let path = path_for_id_and_ensure_dir(paths, &resolved)?;
    let entry = read_entry(&path)?;
    if !apply {
        return Ok(InlineProxyOutcome::DryRun);
    }
    let editor = std::env::var("EDITOR").unwrap_or_else(|_| "vi".to_owned());
    let tmp = std::env::temp_dir().join(format!("caly-inline-proxy-{resolved}.json"));
    // The body shown to the editor is the JSON form
    // (operator-friendly: the comment line is the URI
    // for reference). Round 17 can move to a plain-text
    // form if operators prefer it.
    let editor_body = format!(
        "# Edit the URI line below; one URI per file.\n# group (optional): {}\n# id: {resolved}\n{}\n",
        entry.group.as_deref().unwrap_or(""),
        entry.uri,
    );
    std::fs::write(&tmp, editor_body).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    let status = std::process::Command::new(&editor)
        .arg(&tmp)
        .status()
        .map_err(|error| InlineProxyError::Io(format!("cannot spawn `{editor}`: {error}")))?;
    if !status.success() {
        let _ = std::fs::remove_file(&tmp);
        return Err(InlineProxyError::Io(format!(
            "editor `{editor}` exited with {status}"
        )));
    }
    let edited = std::fs::read_to_string(&tmp).map_err(|e| InlineProxyError::Io(e.to_string()))?;
    let _ = std::fs::remove_file(&tmp);
    let new_uri = edited
        .lines()
        .find(|line| !line.starts_with('#') && !line.trim().is_empty())
        .ok_or_else(|| InlineProxyError::InvalidUri(
            "editor left the body empty; aborting".to_owned(),
        ))?
        .trim()
        .to_owned();
    validate_uri(&new_uri)?;
    let new_id = id_for_uri(&new_uri);
    if new_id == resolved {
        // Same URI, no-op edit; preserve the original
        // file (a write would churn the mtime).
    } else {
        // The URI changed; remove the old entry and
        // create a new one at the new id.
        std::fs::remove_file(&path).map_err(|e| InlineProxyError::Io(e.to_string()))?;
        let new_path = path_for_id_and_ensure_dir(paths, &new_id)?;
        let new_entry = InlineProxy {
            uri: new_uri,
            group: entry.group,
            added_at_ms: current_unix_ms(),
        };
        write_entry(&new_path, &new_entry)?;
    }
    Ok(InlineProxyOutcome::Applied)
}

/// `set proxy import --file <path>` — bulk-add URIs from
/// a file (one URI per line, `#` comments, blank lines
/// skipped). Already-declared URIs are reported but not
/// re-added; the run is atomic per-URI.
///
/// The outcome distinguishes three shapes so the
/// dispatch can report a meaningful envelope:
/// - `Applied(count)` — at least one entry was written
///   in apply mode.
/// - `DryRun(count)` — at least one entry *would* be
///   written in apply mode, but the dry-run short-
///   circuits before any I/O.
/// - `NoOp(reason)` — nothing would change (file
///   empty, all entries already declared, or apply
///   mode running against a state with no new
///   entries). This case still counts as a successful
///   idempotent operation; the dispatch can decide
///   whether to report `dry_run:true` based on
///   `apply`.
pub fn import_proxy(
    paths: &AppPaths,
    file: &Path,
    apply: bool,
) -> Result<ImportOutcome, InlineProxyError> {
    let body = std::fs::read_to_string(file)
        .map_err(|e| InlineProxyError::Io(format!("cannot read {}: {e}", file.display())))?;
    let mut count = 0_usize;
    for line in body.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        validate_uri(line)?;
        let id = id_for_uri(line);
        // Round 19: dry-run uses the read-only path
        // helper. The apply path uses the ensure-dir
        // helper only when it actually needs to
        // create the file. This way a dry-run
        // import against a fresh state root is
        // side-effect-free.
        let path = path_for_id(paths, &id);
        if path.exists() {
            continue;
        }
        if !apply {
            count += 1;
            continue;
        }
        let path = path_for_id_and_ensure_dir(paths, &id)?;
        let entry = InlineProxy {
            uri: line.to_owned(),
            group: None,
            added_at_ms: current_unix_ms(),
        };
        write_entry(&path, &entry)?;
        count += 1;
    }
    if count == 0 {
        // Round 19: the apply path is no-op idempotent
        // (file empty / all dupes), the dry-run path
        // is "nothing to do". The dispatch maps the
        // `apply` flag onto `dry_run` in the envelope;
        // here we just report the count.
        return Ok(ImportOutcome::NoOp);
    }
    Ok(if apply {
        ImportOutcome::Applied(count)
    } else {
        ImportOutcome::DryRun(count)
    })
}

/// `import_proxy` outcome with the count of entries that
/// were (or would have been) written. The dispatch in
/// `commands::set::proxy` reports `count` and
/// `dry_run` in the JSON envelope so scripts know how
/// many inline proxies the import touched.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ImportOutcome {
    /// Apply mode wrote `count` new entries.
    Applied(usize),
    /// Dry-run: `count` entries would be written.
    DryRun(usize),
    /// Apply or dry-run: no new entries. Reported
    /// with `dry_run:false` in apply mode (idempotent
    /// success) or `dry_run:true` in dry-run mode.
    NoOp,
}

/// Resolves a user-supplied id (16-hex hash or the URI
/// itself) to the canonical 16-hex id. Returns
/// `NotDeclared` if the resolved file doesn't exist.
fn resolve_id(paths: &AppPaths, id_or_uri: &str) -> Result<String, InlineProxyError> {
    let candidate = if id_or_uri.contains("://") {
        // operator supplied the raw URI; hash it.
        id_for_uri(id_or_uri)
    } else {
        id_or_uri.to_owned()
    };
    let path = path_for_id(paths, &candidate);
    if path.exists() {
        Ok(candidate)
    } else {
        Err(InlineProxyError::NotDeclared(candidate))
    }
}

/// Lists all inline proxies (for `show proxy list` /
/// `set proxy list`). Round 16: returns `Vec<(id, uri)>`.
/// The future `show proxy list` will use this.
#[allow(dead_code)]
pub fn list_proxies(paths: &AppPaths) -> Vec<(String, String)> {
    let dir = inline_dir(paths);
    let mut out = Vec::new();
    // Round 19: if the inline-proxies directory
    // doesn't exist yet (no inline proxies added),
    // report an empty list instead of erroring.
    let Ok(entries) = std::fs::read_dir(&dir) else {
        return out;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        let Some(stem) = path.file_stem().and_then(|s| s.to_str()) else {
            continue;
        };
        if let Ok(entry) = read_entry(&path) {
            out.push((stem.to_owned(), entry.uri));
        }
    }
    out.sort_by(|a, b| a.0.cmp(&b.0));
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::ffi::OsString;

    fn hermetic_paths(dir: &std::path::Path) -> AppPaths {
        let env = |key: &str| -> Option<OsString> {
            match key {
                "HOME" => Some(OsString::from("/home/test")),
                "XDG_RUNTIME_DIR" => Some(OsString::from("/run/user/1000")),
                "XDG_STATE_HOME" => Some(OsString::from(dir.as_os_str())),
                "XDG_CONFIG_HOME" => Some(OsString::from(dir.as_os_str())),
                _ => None,
            }
        };
        AppPaths::from_env_vars(&env)
    }

    fn temp_root(name: &str) -> PathBuf {
        static COUNTER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
        let n = COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let pid = std::process::id();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos());
        let path = std::env::temp_dir()
            .join(format!("caly-ip-{name}-{pid}-{n}-{nanos}"));
        std::fs::create_dir_all(&path).unwrap_or_else(|_| std::process::abort());
        path
    }

    #[test]
    fn validate_uri_rejects_unknown_schemes() {
        assert!(matches!(validate_uri(""), Err(InlineProxyError::InvalidUri(_))));
        assert!(matches!(validate_uri("file:///etc/passwd"), Err(InlineProxyError::InvalidUri(_))));
        assert!(validate_uri("vmess://abc").is_ok());
        assert!(validate_uri("ss://YWVz").is_ok());
    }

    #[test]
    fn add_proxy_dry_run_does_not_write() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let (outcome, _id) = add_proxy(&paths, "ss://YWVz", None, false)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::DryRun);
        let list = list_proxies(&paths);
        assert!(list.is_empty());
    }

    #[test]
    fn add_proxy_apply_persists_an_entry() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let (outcome, id) = add_proxy(&paths, "ss://YWVz", Some("auto"), true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::Applied);
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 1);
        assert_eq!(list[0].0, id);
        assert_eq!(list[0].1, "ss://YWVz");
        // Re-adding the same URI is a no-op error.
        let result = add_proxy(&paths, "ss://YWVz", None, true);
        assert!(matches!(result, Err(InlineProxyError::AlreadyDeclared(_))));
    }

    #[test]
    fn remove_proxy_filters_a_matching_id() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let (_, id) = add_proxy(&paths, "ss://a", None, true)
            .unwrap_or_else(|_| std::process::abort());
        let (_, _) = add_proxy(&paths, "ss://b", None, true)
            .unwrap_or_else(|_| std::process::abort());
        let outcome = remove_proxy(&paths, &id, true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::Applied);
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 1);
    }

    #[test]
    fn remove_proxy_rejects_unknown_id() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let result = remove_proxy(&paths, "deadbeef", true);
        assert!(matches!(result, Err(InlineProxyError::NotDeclared(_))));
    }

    #[test]
    fn remove_proxy_accepts_a_raw_uri() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        add_proxy(&paths, "vmess://abc", None, true)
            .unwrap_or_else(|_| std::process::abort());
        let outcome = remove_proxy(&paths, "vmess://abc", true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::Applied);
    }

    #[test]
    fn import_proxy_bulk_reads_a_file() {
        let dir = temp_root("__FUNC__");
        let paths = hermetic_paths(dir.as_path());
        let list_path = dir.join("list.txt");
        std::fs::write(
            &list_path,
            "# comment\n\nss://a\nvmess://b\nss://a\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        let outcome = import_proxy(&paths, &list_path, true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, ImportOutcome::Applied(2));
        let list = list_proxies(&paths);
        assert_eq!(list.len(), 2, "duplicate `ss://a` must be skipped");
    }
}
