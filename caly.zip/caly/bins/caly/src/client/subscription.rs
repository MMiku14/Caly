//! Round 14: offline subscription writer for the
//! `set sub …` leaves.
//!
//! Round 16: also owns the offline subscription
//! **inspection** surface (`list` / `check` / `import`)
//! that `show sub …` and the legacy `set sub import`
//! preview path go through. The previous home
//! (`commands::bridge`) is being retired; the helpers
//! below are the source of truth.
//!
//! The `subscriptions.sources: Vec<SubscriptionSource>` (and
//! the `providers:` list when an `import` writes inline
//! nodes) are owned by the operator's `config.yaml`. The
//! `Refreshable` trait now drives `set sub refresh` (via the
//! new typed `client::run_client_collect`); this module owns
//! the 5 CRUD writers that round-trip the `config.yaml` and
//! the layered-merge result.
//!
//! # Why a separate module (not inside `profile.rs`)
//!
//! `client::profile` is a 620-line file with its own error
//! type, its own `mutate_profiles_in_config` helper, and
//! its own SSRF-safe fetch pipeline. The subscription
//! writers don't share any of that surface — they touch
//! `subscriptions.sources` (a different key), they use a
//! different error type, and they delegate the fetch
//! pipeline to the daemon. Putting them in their own file
//! keeps the Round 11/12/13 profile code untouched and
//! gives the subscription path its own diagnostic shape.
//!
//! # Round 14 error model
//!
//! Every writer returns `Result<_, SubCmdError>`. The
//! CLI dispatch in `commands::set::sub` maps each variant
//! to a stable `code:` in the JSON envelope:
//!
//! | variant                | code                  |
//! |------------------------|-----------------------|
//! | `InvalidUrl`           | `sub.invalid_url`     |
//! | `AlreadyDeclared`      | `sub.already_declared`|
//! | `NotDeclared`          | `sub.not_declared`    |
//! | `InvalidName`          | `sub.invalid_name`    |
//! | `Write`                | `sub.write_failed`    |
//! | `Parse`                | `sub.parse_failed`    |
//! | `Validate`             | `sub.validate_failed` |
//! | `Mutator`              | `sub.mutator_failed`  |
//!
//! The `Write` / `Parse` / `Validate` / `Mutator` variants
//! carry the underlying `ConfigWriteError` message so the
//! operator can `cat config.yaml.bak` and recover without
//! a debug log.

use std::path::PathBuf;

use caly_config::schema::{ProviderConfig, ProviderKind, SubscriptionSource};
use caly_platform::paths::AppPaths;

use super::config_writer::{ConfigWriteError, backup_config_yaml};

/// Where the writer should land. `set sub import` and
/// `set sub add` differ: import is a one-shot `InlineNodes`
/// provider under a fresh name; add is an append to the
/// existing `subscriptions.sources` list. (Round 14: the
/// actual writers are flat functions; the enum is reserved
/// for a future round that unifies them.)
#[allow(dead_code)]
#[derive(Debug, Clone)]
pub enum SubWriteTarget {
    /// `set sub add <name> <url>`: append `{ url, enabled: true }`
    /// to `subscriptions.sources`.
    Source { url: String },
    /// `set sub import --name <name>`: write a fresh
    /// `providers: [{ name, kind: InlineNodes([…]) }]` entry.
    /// The list of nodes is the operator's clipboard /
    /// file content.
    Inline { provider: String, nodes: Vec<String> },
    /// `set sub remove|enable|disable <url>`: act on the
    /// source whose `url` matches.
    Toggle { url: String },
}

/// Single error type for the 5 CRUD writers. The CLI maps
/// each variant to a stable `code:` so the operator gets
/// a consistent envelope across writers.
#[allow(dead_code)] // `InvalidName` / `Mutator` / `Parse` are
                   // reserved for the `set sub import` `--save`
                   // path (Round 15+) which will surface inline
                   // provider failures through the same enum.
#[derive(Debug)]
pub enum SubCmdError {
    /// The URL is empty, missing a scheme, or points at a
    /// non-HTTP(S) scheme (the SSRF guard refuses
    /// `file://` and `data://`).
    InvalidUrl(String),
    /// `add` on a URL that's already in
    /// `subscriptions.sources`.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a URL that's
    /// not in `subscriptions.sources`.
    NotDeclared(String),
    /// `import --name` is not a path-safe ASCII id.
    InvalidName(String),
    /// A `ConfigWriteError` from the generic writer.
    Write(String),
    /// A `ConfigWriteError::Parse` shorthand (kept as a
    /// separate variant so the CLI can branch on it
    /// without re-matching the display string).
    Parse(String),
    /// A `ConfigWriteError::Validate` shorthand.
    Validate(String),
    /// A `ConfigWriteError::Mutator` shorthand.
    Mutator(String),
}

impl core::fmt::Display for SubCmdError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidUrl(reason) => write!(formatter, "invalid subscription URL: {reason}"),
            Self::AlreadyDeclared(url) => {
                write!(formatter, "subscription source `{url}` is already declared")
            }
            Self::NotDeclared(url) => {
                write!(formatter, "subscription source `{url}` is not declared")
            }
            Self::InvalidName(name) => {
                write!(formatter, "provider name `{name}` is not path-safe ASCII")
            }
            Self::Write(reason)
            | Self::Parse(reason)
            | Self::Validate(reason)
            | Self::Mutator(reason) => write!(formatter, "{reason}"),
        }
    }
}

impl std::error::Error for SubCmdError {}

impl From<ConfigWriteError> for SubCmdError {
    fn from(value: ConfigWriteError) -> Self {
        match &value {
            ConfigWriteError::Read { .. } | ConfigWriteError::Write { .. } => {
                SubCmdError::Write(value.to_string())
            }
            ConfigWriteError::Parse { .. } => Self::Parse(value.to_string()),
            ConfigWriteError::Validate { .. } => Self::Validate(value.to_string()),
            ConfigWriteError::Mutator(_) => Self::Mutator(value.to_string()),
        }
    }
}

/// Resolves the operator's XDG roots. Mirrors
/// `client::profile::resolve_paths` so the test
/// fixtures can inject a custom `HOME` / `XDG_*` and the
/// behaviour is identical across writers.
pub fn resolve_paths() -> AppPaths {
    AppPaths::from_env()
}

/// Loads the active `AppConfig` from `paths` (so the
/// tests can inject a hermetic root via
/// `AppPaths::from_env_vars(&test_env())`).
pub fn load_declared_with(
    paths: &AppPaths,
) -> Result<caly_config::schema::AppConfig, SubCmdError> {
    let limits = caly_config::loader::LoaderLimits::secure_default();
    let layered = caly_config::loader::LayeredConfigPaths::new(paths.config.clone(), None);
    caly_config::loader::load_layered_yaml_with(
        &layered,
        limits,
        &caly_config::loader::InMemoryProfileResolver::lenient(),
    )
    .map_err(|error| SubCmdError::Write(format!("load layered config: {error}")))
}

/// Convenience: `load_declared` for production callers
/// that don't inject a path.
#[allow(dead_code)]
pub fn load_declared() -> Result<caly_config::schema::AppConfig, SubCmdError> {
    load_declared_with(&resolve_paths())
}

/// What an `add` / `remove` / `enable` / `disable` /
/// `import` call did. `DryRun` is what `--dry-run` (the
/// default) returns when the call would have written.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SubWriteOutcome {
    Applied,
    DryRun,
}

fn config_yaml_path(paths: &AppPaths) -> PathBuf {
    paths.config.join("config.yaml")
}

/// `set sub add <name> <url> [--apply]`.
///
/// Default: dry-run. `--apply` is the only thing that
/// actually mutates `config.yaml`. The dry-run path
/// runs every check (URL shape, already-declared,
/// post-write schema validation) and reports "would
/// have added subscription source `<url>`" without
/// touching the operator's file.
///
/// Note: `subscriptions:` is a struct in the schema
/// (with `sources`, `url`, `connect_timeout_ms`, …),
/// not a `Vec<_>` — so this writer goes through the
/// struct-typed path (`write_subscriptions`) rather
/// than the `mutate_yaml_key::<Vec<T>>` helper that
/// `set profile` uses. The two paths share
/// `backup_config_yaml` + `parse_and_validate_yaml` so
/// the operator's safety net is the same.
pub fn add_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    validate_url(url)?;
    let config = load_declared_with(paths)?;
    if config.subscriptions.sources.iter().any(|s| s.url == url) {
        return Err(SubCmdError::AlreadyDeclared(url.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    let path = config_yaml_path(paths);
    backup_config_yaml(&path).map_err(SubCmdError::from)?;
    let mut next = config.subscriptions.clone();
    next.sources.push(SubscriptionSource { url: url.to_owned(), enabled: true });
    write_subscriptions(&path, &next)?;
    Ok(SubWriteOutcome::Applied)
}

/// `set sub remove <url> [--apply]`. Filters the
/// `sources` list by URL. Returns
/// `SubCmdError::NotDeclared` if the URL is not in the
/// list.
pub fn remove_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    validate_url(url)?;
    let config = load_declared_with(paths)?;
    let before = config.subscriptions.sources.len();
    let after_estimate = config.subscriptions.sources.iter().filter(|s| s.url != url).count();
    if after_estimate == before {
        return Err(SubCmdError::NotDeclared(url.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    let path = config_yaml_path(paths);
    backup_config_yaml(&path).map_err(SubCmdError::from)?;
    let mut next = config.subscriptions.clone();
    next.sources.retain(|s| s.url != url);
    write_subscriptions(&path, &next)?;
    Ok(SubWriteOutcome::Applied)
}

/// `set sub enable <url> [--apply]`. Flips
/// `enabled: true` on the matching source. (All sources
/// are enabled by default, so this is a no-op when the
/// source is already enabled — but the writer accepts
/// it for symmetry with `disable`.)
pub fn enable_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    set_source_enabled(paths, url, true, apply)
}

/// `set sub disable <url> [--apply]`. Flips
/// `enabled: false` on the matching source.
pub fn disable_source(
    paths: &AppPaths,
    url: &str,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    set_source_enabled(paths, url, false, apply)
}

fn set_source_enabled(
    paths: &AppPaths,
    url: &str,
    enabled: bool,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    validate_url(url)?;
    let config = load_declared_with(paths)?;
    let mut found = false;
    for source in &config.subscriptions.sources {
        if source.url == url {
            found = true;
            if source.enabled == enabled {
                // Already in the desired state; no-op.
                return Ok(if apply {
                    SubWriteOutcome::Applied
                } else {
                    SubWriteOutcome::DryRun
                });
            }
        }
    }
    if !found {
        return Err(SubCmdError::NotDeclared(url.to_owned()));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    let path = config_yaml_path(paths);
    backup_config_yaml(&path).map_err(SubCmdError::from)?;
    let mut next = config.subscriptions.clone();
    for source in &mut next.sources {
        if source.url == url {
            source.enabled = enabled;
        }
    }
    write_subscriptions(&path, &next)?;
    Ok(SubWriteOutcome::Applied)
}

/// `set sub import --name <name> --nodes <nodes> [--apply]`.
///
/// Writes a fresh `providers:` entry whose
/// `kind: InlineNodes([…])` carries the operator's
/// node URIs. The name is path-safe ASCII (re-using
/// the same predicate as `profile::add`).
#[allow(dead_code)] // wired in `set sub import` once a `--save`
                   // flag lands (the existing `import` is a
                   // preview-only path through the bridge).
pub fn import_inline(
    paths: &AppPaths,
    name: &str,
    nodes: Vec<String>,
    apply: bool,
) -> Result<SubWriteOutcome, SubCmdError> {
    if !is_path_safe_name(name) {
        return Err(SubCmdError::InvalidName(name.to_owned()));
    }
    if nodes.is_empty() {
        return Err(SubCmdError::InvalidUrl(
            "import: nodes list is empty (use --clipboard or --file)".to_owned(),
        ));
    }
    if !apply {
        return Ok(SubWriteOutcome::DryRun);
    }
    let path = config_yaml_path(paths);
    backup_config_yaml(&path).map_err(SubCmdError::from)?;
    let provider = ProviderConfig { name: name.to_owned(), kind: ProviderKind::InlineNodes(nodes) };
    let existing = read_providers(&path)?;
    if existing.iter().any(|p| p.name == provider.name) {
        return Err(SubCmdError::AlreadyDeclared(provider.name.clone()));
    }
    let mut next = existing;
    next.push(provider);
    write_providers(&path, &next)?;
    Ok(SubWriteOutcome::Applied)
}

// ── Internal helpers (struct-typed write paths) ────────

fn validate_url(url: &str) -> Result<(), SubCmdError> {
    let url = url.trim();
    if url.is_empty() {
        return Err(SubCmdError::InvalidUrl("URL is empty".to_owned()));
    }
    if !(url.starts_with("http://") || url.starts_with("https://")) {
        return Err(SubCmdError::InvalidUrl(format!(
            "URL must start with `http://` or `https://` (got `{url}`)"
        )));
    }
    Ok(())
}

#[allow(dead_code)] // reserved for the `set sub import` `--save`
                   // path (Round 15+); tests exercise it today.
fn is_path_safe_name(name: &str) -> bool {
    !name.is_empty()
        && name.chars().all(|c| {
            c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.'
        })
}

fn read_yaml_value(path: &std::path::Path) -> Result<serde_norway::Value, SubCmdError> {
    let bytes = std::fs::read(path).map_err(|error| SubCmdError::Write(format!(
        "cannot read {}: {error}",
        path.display()
    )))?;
    serde_norway::from_slice(&bytes).map_err(|error| SubCmdError::Parse(format!(
        "cannot parse {}: {error}",
        path.display()
    )))
}

fn write_yaml_value(
    path: &std::path::Path,
    value: &serde_norway::Value,
) -> Result<(), SubCmdError> {
    let serialized = serde_norway::to_string(value).map_err(|error| {
        SubCmdError::Parse(format!("serialize {}: {error}", path.display()))
    })?;
    caly_config::schema::parse_and_validate_yaml(serialized.as_bytes()).map_err(|error| {
        SubCmdError::Validate(format!(
            "post-write validation failed for {}: {error}",
            path.display()
        ))
    })?;
    let mut temp = path.to_path_buf();
    let file_name = path
        .file_name()
        .map_or_else(|| "config.yaml".to_owned(), |n| n.to_string_lossy().into_owned());
    let pid = std::process::id();
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| d.as_nanos());
    temp.set_file_name(format!(".{file_name}.{pid}.{nanos}.tmp"));
    std::fs::write(&temp, &serialized).map_err(|error| {
        SubCmdError::Write(format!("cannot write {}: {error}", temp.display()))
    })?;
    std::fs::rename(&temp, path).map_err(|error| SubCmdError::Write(format!(
        "cannot rename {} -> {}: {error}",
        temp.display(),
        path.display()
    )))?;
    Ok(())
}

fn write_subscriptions(
    path: &std::path::Path,
    next: &caly_config::schema::SubscriptionConfig,
) -> Result<(), SubCmdError> {
    let mut value = read_yaml_value(path)?;
    let mapping = value
        .as_mapping_mut()
        .ok_or_else(|| SubCmdError::Parse("config root must be a mapping".to_owned()))?;
    let key = serde_norway::Value::String("subscriptions".to_owned());
    let rendered = serde_norway::to_value(next).map_err(|error| {
        SubCmdError::Parse(format!("serialize `subscriptions:`: {error}"))
    })?;
    mapping.insert(key, rendered);
    write_yaml_value(path, &value)
}

#[allow(dead_code)] // reserved for the `set sub import` `--save`
                   // path (Round 15+); tests exercise it today.
fn read_providers(path: &std::path::Path) -> Result<Vec<ProviderConfig>, SubCmdError> {
    let value = read_yaml_value(path)?;
    let mapping = value
        .as_mapping()
        .ok_or_else(|| SubCmdError::Parse("config root must be a mapping".to_owned()))?;
    let key = serde_norway::Value::String("providers".to_owned());
    match mapping.get(&key) {
        Some(serde_norway::Value::Sequence(_)) => serde_norway::from_value(mapping[&key].clone())
            .map_err(|error| SubCmdError::Parse(format!("`providers:` is invalid: {error}"))),
        Some(_) => Err(SubCmdError::Parse("`providers:` must be a list".to_owned())),
        None => Ok(Vec::new()),
    }
}

#[allow(dead_code)] // same rationale as read_providers
fn write_providers(
    path: &std::path::Path,
    providers: &[ProviderConfig],
) -> Result<(), SubCmdError> {
    let mut value = read_yaml_value(path)?;
    let mapping = value
        .as_mapping_mut()
        .ok_or_else(|| SubCmdError::Parse("config root must be a mapping".to_owned()))?;
    let key = serde_norway::Value::String("providers".to_owned());
    let rendered = serde_norway::to_value(providers)
        .map_err(|error| SubCmdError::Parse(format!("serialize `providers:`: {error}")))?;
    mapping.insert(key, rendered);
    write_yaml_value(path, &value)
}

// ── Round 16: offline subscription inspection ───────────────
//
// `show sub providers` / `show sub parse` / `show sub
// import` (and the legacy `set sub import` preview)
// all live here. The shape matches what
// `commands::bridge::sub_*` used to print; the source
// of truth moves to this module so the bridge shim can
// be deleted in a future round.

/// `show sub providers` — list the configured
/// subscription providers (default provider +
/// inline-nodes providers), with their resolved
/// sources.
pub fn list_providers(json: bool) -> std::process::ExitCode {
    use caly_config::schema::ProviderKind;
    use std::process::ExitCode;
    let root = caly_platform::paths::AppPaths::from_env().config;
    let (sources, providers) = match crate::daemon_config::load_from(root) {
        Ok(None) => (Vec::new(), Vec::new()),
        Ok(Some(config)) => (
            config.subscriptions.enabled_source_urls(),
            config.resolved_providers(),
        ),
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error.to_string() }));
            } else {
                eprintln!("subscription list failed: {error}");
            }
            return ExitCode::FAILURE;
        }
    };
    if providers.is_empty() {
        if json {
            println!(
                "{}",
                serde_json::json!({ "providers": [], "sources": [], "count": 0 })
            );
        } else {
            println!("no subscription provider configured");
            println!("hint: set `subscriptions.url` or `subscriptions.sources` in config.yaml to create the default provider");
        }
        return ExitCode::SUCCESS;
    }
    if json {
        let items: Vec<serde_json::Value> = providers
            .iter()
            .map(|p| {
                let embedded: Vec<serde_json::Value> = sources
                    .iter()
                    .enumerate()
                    .map(|(i, url)| {
                        serde_json::json!({ "index": i, "url": url, "enabled": true })
                    })
                    .collect();
                serde_json::json!({
                    "name": p.name,
                    "kind": match &p.kind {
                        ProviderKind::SubscriptionSources => "subscription-sources",
                        ProviderKind::InlineNodes(_) => "inline-nodes",
                    },
                    "sources": embedded,
                })
            })
            .collect();
        println!(
            "{}",
            serde_json::json!({
                "providers": items,
                "sources": sources.iter().map(String::as_str).collect::<Vec<_>>(),
                "count": sources.len(),
            })
        );
    } else {
        for p in &providers {
            match &p.kind {
                ProviderKind::SubscriptionSources => {
                    println!(
                        "provider: {} (enumeration of {} source(s))",
                        p.name,
                        sources.len()
                    );
                    for (i, url) in sources.iter().enumerate() {
                        println!("  [{}] {} (enabled)", i + 1, url);
                    }
                }
                ProviderKind::InlineNodes(nodes) => {
                    println!("provider: {} ({} inline node(s))", p.name, nodes.len());
                    for n in nodes {
                        println!("  - {n}");
                    }
                }
            }
        }
        println!("{} provider(s)", providers.len());
    }
    ExitCode::SUCCESS
}

/// `show sub parse <path>` — offline subscription
/// summary for one file (or stdin if `path` is
/// `Some("-")` and `--clipboard` is false; Round 16
/// keeps the path-only form to match the existing CLI).
pub fn check_subscription(
    path: &std::path::Path,
    userinfo: Option<&str>,
    json: bool,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    match crate::subscription::inspect_subscription_with_userinfo(path, userinfo) {
        Ok(summary) => {
            if json {
                println!("{}", crate::subscription::render_json(&summary));
            } else {
                print!("{}", crate::subscription::render_human(&summary));
            }
            if crate::subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error.to_string() }));
            } else {
                eprintln!("subscription check failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

/// `show sub import <path>` / `--clipboard` — parse a
/// URI list and print a preview. Round 16: preview only;
/// the persisted path is `client::subscription::import_inline`
/// (a future leaf surfaces the `--save` flag).
pub fn import_preview(
    path: Option<&std::path::Path>,
    clipboard: bool,
    json: bool,
) -> std::process::ExitCode {
    use std::process::ExitCode;
    let summary = match (clipboard, path) {
        (true, Some(_)) => {
            eprintln!("error: `sub import --clipboard` takes no path argument");
            return ExitCode::from(2);
        }
        (true, None) | (false, None) => crate::subscription::read_clipboard(),
        (false, Some(path)) => crate::subscription::inspect_subscription_with_userinfo(path, None),
    };
    match summary {
        Ok(summary) => {
            if json {
                println!("{}", crate::subscription::render_json(&summary));
            } else {
                print!("{}", crate::subscription::render_human(&summary));
                if summary.format == "url-list" {
                    println!("This is a subscription *source* (fetchable URL). It is not persisted by `import`; add its URL to `subscriptions.sources` in config.yaml and it will appear in `caly sub list` as the default provider.");
                } else {
                    println!("Preview only — nothing was saved. These are proxy node URIs (no upstream subscription URL), so they cannot form a subscription provider and won't appear in `sub list`. Paste a source subscription URL for a refreshable provider.");
                }
            }
            if crate::subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error.to_string() }));
            } else {
                eprintln!("subscription import failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_config::schema::AppConfig;
    use std::ffi::OsString;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};

    /// Generates a unique temp dir for one test. We avoid
    /// the `tempfile` crate (not a workspace dep) by
    /// composing `std::env::temp_dir()` with the test
    /// counter + process id + nanoseconds.
    fn temp_root(name: &str) -> PathBuf {
        static COUNTER: AtomicUsize = AtomicUsize::new(0);
        let n = COUNTER.fetch_add(1, Ordering::Relaxed);
        let pid = std::process::id();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos());
        let path = std::env::temp_dir().join(format!("caly-sub-{name}-{pid}-{n}-{nanos}"));
        fs::create_dir_all(&path).unwrap_or_else(|_| std::process::abort());
        path
    }

    /// Writes a seed `config.yaml` (with a `core:` /
    /// `schema_version:`) so the layered loader accepts
    /// it on read. `AppPaths::from_env_vars` joins
    /// `<xdg_config>/caly/...`, so the operator's
    /// `config.yaml` lives in `<dir>/caly/config.yaml`.
    fn seed_config_at_roots(dir: &std::path::Path) -> AppPaths {
        let paths = hermetic_paths(dir);
        let target = paths.config.join("config.yaml");
        fs::create_dir_all(&paths.config).unwrap_or_else(|_| std::process::abort());
        fs::write(
            &target,
            "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        paths
    }

    /// Hermetic env with explicit XDG roots pointing at
    /// the test temp dir. Mirrors the `doctor_tests`
    /// pattern (Rust 2024 makes `set_var` unsafe; the
    /// `from_env_vars` reader keeps tests hermetic
    /// without mutating process state).
    fn hermetic_paths(dir: &std::path::Path) -> AppPaths {
        let env = |key: &str| -> Option<OsString> {
            match key {
                "HOME" => Some(OsString::from("/home/test")),
                "XDG_RUNTIME_DIR" => Some(OsString::from("/run/user/1000")),
                "XDG_STATE_HOME" => Some(OsString::from(dir.as_os_str())),
                "XDG_CONFIG_HOME" => Some(OsString::from(dir.as_os_str())),
                _ => None,
            }
        };
        AppPaths::from_env_vars(&env)
    }

    #[test]
    fn validate_url_rejects_non_http_schemes() {
        assert!(matches!(
            validate_url("file:///etc/passwd"),
            Err(SubCmdError::InvalidUrl(_))
        ));
        assert!(matches!(
            validate_url("data:text/plain,hello"),
            Err(SubCmdError::InvalidUrl(_))
        ));
        assert!(matches!(validate_url(""), Err(SubCmdError::InvalidUrl(_))));
        assert!(validate_url("https://example.com/sub").is_ok());
    }

    #[test]
    fn add_source_dry_run_does_not_touch_disk() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        let outcome = add_source(&paths, "https://example.com/sub", false).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::DryRun);
        // Disk is unchanged: no `sources` key was written.
        // The dry-run writer must not have touched disk at
        // all — so the seed YAML is still byte-identical
        // to what we wrote in `seed_config_at_roots`.
        let expected = "schema_version: 1\ncore: mihomo\nsubscriptions: {}\n";
        let after = std::fs::read_to_string(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(after, expected);
    }

    #[test]
    fn add_source_apply_persists_a_new_source() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        let outcome = add_source(&paths, "https://example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        let bytes = fs::read(paths.config.join("config.yaml")).unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(sources) = value
            .get("subscriptions")
            .and_then(|v| v.get("sources"))
            .and_then(|v| v.as_sequence())
        else {
            std::process::abort();
        };
        assert_eq!(sources.len(), 1);
        assert_eq!(sources[0].get("url").and_then(|v| v.as_str()), Some("https://example.com/sub"));
        assert_eq!(sources[0].get("enabled").and_then(serde_norway::Value::as_bool), Some(true));
        // A `.bak` sidecar must exist.
        let backup = paths.config.join("config.yaml.bak");
        assert!(backup.exists(), "backup sidecar must be written");
    }

    #[test]
    fn add_source_rejects_duplicate_url() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        let result = add_source(&paths, "https://example.com/sub", true);
        assert!(matches!(result, Err(SubCmdError::AlreadyDeclared(_))));
    }

    #[test]
    fn remove_source_filters_a_matching_url() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        add_source(&paths, "https://b.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        let outcome = remove_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        let config: AppConfig = caly_config::loader::load_layered_yaml_with(
            &caly_config::loader::LayeredConfigPaths::new(paths.config.clone(), None),
            caly_config::loader::LoaderLimits::secure_default(),
            &caly_config::loader::InMemoryProfileResolver::lenient(),
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(config.subscriptions.sources.len(), 1);
        assert_eq!(config.subscriptions.sources[0].url, "https://b.example.com/sub");
    }

    #[test]
    fn remove_source_rejects_unknown_url() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        let result = remove_source(&paths, "https://unknown.example.com/sub", true);
        assert!(matches!(result, Err(SubCmdError::NotDeclared(_))));
    }

    #[test]
    fn disable_source_flips_the_enabled_flag() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        let outcome = disable_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        let config: AppConfig = caly_config::loader::load_layered_yaml_with(
            &caly_config::loader::LayeredConfigPaths::new(paths.config.clone(), None),
            caly_config::loader::LoaderLimits::secure_default(),
            &caly_config::loader::InMemoryProfileResolver::lenient(),
        )
        .unwrap_or_else(|_| std::process::abort());
        assert!(!config.subscriptions.sources[0].enabled);
    }

    #[test]
    fn enable_source_is_a_noop_when_already_enabled() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        add_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        let outcome = enable_source(&paths, "https://a.example.com/sub", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
    }

    #[test]
    fn import_inline_writes_a_provider_with_inline_nodes() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        let outcome = import_inline(
            &paths,
            "pasted",
            vec!["vmess://abc".to_owned(), "ss://def".to_owned()],
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, SubWriteOutcome::Applied);
        let bytes = fs::read(paths.config.join("config.yaml")).unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value
            .get("providers")
            .and_then(|v| v.as_sequence())
        else {
            std::process::abort();
        };
        assert_eq!(providers.len(), 1);
        let first = &providers[0];
        assert_eq!(first.get("name").and_then(|v| v.as_str()), Some("pasted"));
        // `ProviderKind` is a tagged enum:
        // `kind: !inline-nodes` followed by the node list.
        // The nodes are the tagged scalar value, not a
        // sub-key.
        let Some(kind) = first.get("kind") else {
            std::process::abort();
        };
        let Some(nodes) = kind.as_sequence() else {
            std::process::abort();
        };
        assert_eq!(nodes.len(), 2);
        assert_eq!(nodes[0].as_str(), Some("vmess://abc"));
        assert_eq!(nodes[1].as_str(), Some("ss://def"));
    }

    #[test]
    fn import_inline_rejects_empty_node_list() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        let result = import_inline(&paths, "pasted", Vec::new(), true);
        assert!(matches!(result, Err(SubCmdError::InvalidUrl(_))));
    }

    #[test]
    fn import_inline_rejects_unsafe_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_config_at_roots(dir.as_path());
        let result = import_inline(&paths, "../escape", vec!["ss://x".to_owned()], true);
        assert!(matches!(result, Err(SubCmdError::InvalidName(_))));
    }
}
