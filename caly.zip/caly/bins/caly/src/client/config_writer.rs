//! Round 14: generic YAML mutator for the `config.yaml`
//! writer pattern.
//!
//! `set <resource> <verb>` writers all share the same
//! "backup → read → parse → mutate key → re-validate →
//! write" shape. Round 13 inlined this pattern into
//! `client::profile::mutate_profiles_in_config`; Round 14
//! lifts it to a typed helper so `set sub add|remove|…`
//! can reuse the same read-validate-write loop without
//! duplicating the file-I/O and error-envelope code.
//!
//! The mutator is **key-typed** (`subscriptions` /
//! `profiles` / `rule_providers` / `providers`) and the
//! value type is whatever the schema module exposes for
//! that key. The helper owns:
//!
//! 1. `fs::read` + `serde_norway::from_slice` (raw read).
//! 2. Mutating the `serde_norway::Value` mapping at the
//!    named key with the caller-supplied closure.
//! 3. Serialising back with `serde_norway::to_string`.
//! 4. `fs::write` (atomic-replace via temp file + rename,
//!    so a crash mid-write never leaves a half-written
//!    `config.yaml`).
//!
//! The caller owns the **backup** step (taken before the
//! read so a power loss between the read and the write
//! still leaves the operator with a recoverable copy).
//! See [`backup_config_yaml`] for the matching backup
//! helper.

use std::{fs, path::Path};

use caly_config::schema::AppConfig;
use serde::{Serialize, de::DeserializeOwned};

/// The single write error type for all `set <resource>`
/// writers. Each variant carries the path + reason so the
/// CLI can print a stable error envelope without losing
/// the operator's trail to the original failure.
#[allow(dead_code)] // `Parse` and `Mutator` are reserved for the
                   // future `set profile` / `set rule-provider`
                   // writers (Round 15+) which will round-trip
                   // through the same enum; `Read` / `Write` /
                   // `Validate` already serve `set sub`.
#[derive(Debug)]
pub enum ConfigWriteError {
    /// `fs::read(config.yaml)` failed.
    Read {
        path: std::path::PathBuf,
        reason: String,
    },
    /// `serde_norway::from_slice` failed.
    Parse {
        path: std::path::PathBuf,
        reason: String,
    },
    /// The mutator returned an error (e.g. already declared
    /// / not declared / invalid id).
    Mutator(String),
    /// The post-mutation schema validation failed.
    Validate {
        path: std::path::PathBuf,
        reason: String,
    },
    /// `fs::rename` (temp → real) failed.
    Write {
        path: std::path::PathBuf,
        reason: String,
    },
}

impl core::fmt::Display for ConfigWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Read { path, reason } => {
                write!(formatter, "cannot read {}: {reason}", path.display())
            }
            Self::Parse { path, reason } => {
                write!(formatter, "cannot parse {}: {reason}", path.display())
            }
            Self::Mutator(reason) => write!(formatter, "{reason}"),
            Self::Validate { path, reason } => {
                write!(formatter, "post-write validation failed for {}: {reason}", path.display())
            }
            Self::Write { path, reason } => {
                write!(formatter, "cannot write {}: {reason}", path.display())
            }
        }
    }
}

impl std::error::Error for ConfigWriteError {}

/// Loads `config.yaml` into a `serde_norway::Value`
/// mapping. Used by every `mutate_yaml_key` caller; the
/// same read pipeline is exercised so a typo'd
/// `config.yaml` fails the same way in every `set`
/// leaf.
#[allow(dead_code)] // public API; Round 15+ will reach for it from the `set profile` / `set rule-provider` writers
fn read_config_value(path: &Path) -> Result<serde_norway::Value, ConfigWriteError> {
    let bytes = fs::read(path).map_err(|error| ConfigWriteError::Read {
        path: path.to_path_buf(),
        reason: error.to_string(),
    })?;
    serde_norway::from_slice::<serde_norway::Value>(&bytes).map_err(|error| {
        ConfigWriteError::Parse {
            path: path.to_path_buf(),
            reason: error.to_string(),
        }
    })
}

/// Writes the new YAML to a sibling temp file, then
/// atomically renames over the real path. A crash between
/// the temp-file write and the rename leaves the original
/// `config.yaml` untouched (the operator can `cat` /
/// recover from it). The temp file is in the same
/// directory so the rename stays a single-filesystem
/// operation.
#[allow(dead_code)] // same rationale as read_config_value
fn write_atomic(path: &Path, contents: &str) -> Result<(), ConfigWriteError> {
    let parent = path.parent().unwrap_or_else(|| Path::new("."));
    fs::create_dir_all(parent).map_err(|error| ConfigWriteError::Write {
        path: path.to_path_buf(),
        reason: format!("create_dir_all {}: {error}", parent.display()),
    })?;
    let mut temp = path.to_path_buf();
    let file_name = path
        .file_name()
        .map_or_else(|| "config.yaml".to_owned(), |name| name.to_string_lossy().into_owned());
    let pid = std::process::id();
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    temp.set_file_name(format!(".{file_name}.{pid}.{nanos}.tmp"));
    fs::write(&temp, contents).map_err(|error| ConfigWriteError::Write {
        path: temp.clone(),
        reason: error.to_string(),
    })?;
    fs::rename(&temp, path).map_err(|error| ConfigWriteError::Write {
        path: path.to_path_buf(),
        reason: format!("rename {} -> {}: {error}", temp.display(), path.display()),
    })?;
    Ok(())
}

/// Generic mutator: reads `config_path`, applies
/// `mutate(current_value)` to the `key` entry, and
/// re-serialises + re-validates the result. The mutator's
/// return is the *new* value for that key (the canonical
/// "produce the next state" pattern that the profile
/// writers introduced in Round 11).
///
/// The post-write step runs the layered loader's
/// `parse_and_validate_yaml` on the new file. A failed
/// validation means the in-memory mutation made the
/// `AppConfig` inconsistent (e.g. two sources with the
/// same URL, an `id` that fails path-safety); the writer
/// rolls back by **not** writing the mutated file when
/// validation fails inside the mutator.
///
/// `mutate` runs on the **deserialised** value (so the
/// `SubscriptionSource` / `RuleProviderConfig` schema
/// types are available; no raw YAML poking). When the
/// key is missing, the helper passes `&mut Vec::new()`.
#[allow(dead_code)] // same rationale as read_config_value
pub fn mutate_yaml_key<T, F>(
    config_path: &Path,
    key: &str,
    mutate: F,
) -> Result<(), ConfigWriteError>
where
    T: DeserializeOwned + Serialize + Clone,
    F: FnOnce(&[T]) -> Result<Vec<T>, ConfigWriteError>,
{
    let mut value = read_config_value(config_path)?;
    let mapping = value
        .as_mapping_mut()
        .ok_or_else(|| ConfigWriteError::Parse {
            path: config_path.to_path_buf(),
            reason: "config root must be a mapping".to_owned(),
        })?;
    let key_value = serde_norway::Value::String(key.to_owned());
    // Pull the current value out of the YAML as the typed
    // `Vec<T>`. A `null` / missing / wrong-shape value is
    // treated as empty (the operator's first `add` works on
    // a fresh install).
    let current: Vec<T> = match mapping.get(&key_value) {
        Some(serde_norway::Value::Sequence(_)) => {
            serde_norway::from_value(mapping[&key_value].clone()).map_err(|error| {
                ConfigWriteError::Parse {
                    path: config_path.to_path_buf(),
                    reason: format!("`{key}:` is not a list of the expected shape: {error}"),
                }
            })?
        }
        Some(_) => {
            return Err(ConfigWriteError::Parse {
                path: config_path.to_path_buf(),
                reason: format!("`{key}:` must be a list"),
            });
        }
        None => Vec::new(),
    };
    let next = mutate(&current)?;
    let rendered: serde_norway::Value = serde_norway::to_value(&next).map_err(|error| {
        ConfigWriteError::Parse {
            path: config_path.to_path_buf(),
            reason: format!("serialize `{key}:` value: {error}"),
        }
    })?;
    mapping.insert(key_value, rendered);
    let serialized = serde_norway::to_string(&value).map_err(|error| ConfigWriteError::Parse {
        path: config_path.to_path_buf(),
        reason: error.to_string(),
    })?;
    // Validate the new file *before* writing it: a failed
    // validation never reaches disk. The loader's own
    // `parse_and_validate_yaml` re-runs every schema
    // invariant on the new content.
    if let Err(error) = caly_config::schema::parse_and_validate_yaml(serialized.as_bytes()) {
        return Err(ConfigWriteError::Validate {
            path: config_path.to_path_buf(),
            reason: error.to_string(),
        });
    }
    write_atomic(config_path, &serialized)
}

/// Copies `config.yaml` to `config.yaml.bak` before any
/// destructive operation. Round 11 introduced this in
/// `client::profile::backup_config`; Round 14 moves it
/// here so every writer shares the same sidecar
/// semantics. The sidecar is overwritten on every call —
/// at most one backup per `config.yaml` between two
/// `cp config.yaml.bak config.yaml` rollbacks. A missing
/// source file is a no-op (fresh install).
pub fn backup_config_yaml(config_path: &Path) -> Result<(), ConfigWriteError> {
    if !config_path.is_file() {
        return Ok(());
    }
    let backup = config_path.with_extension("yaml.bak");
    fs::copy(config_path, &backup).map_err(|error| ConfigWriteError::Write {
        path: backup,
        reason: error.to_string(),
    })?;
    Ok(())
}

/// Round 14: helper reserved for a future
/// `set profile` / `set rule_provider` writer that
/// needs to re-use the `ConfigWriteError` shape with a
/// different outer error type. Today the
/// `client::subscription::From<ConfigWriteError>`
/// impl inlines the same mapping.
#[allow(dead_code)]
pub fn into_sub_err(error: ConfigWriteError) -> String {
    error.to_string()
}

/// Validates a `config.yaml` round-trip after a write:
/// the layered loader must accept the new content. The
/// Round 13 `set profile add` path uses the same loader
/// indirectly (through `parse_and_validate_yaml`); this
/// helper is the dedicated test entry so a writer can
/// assert "the file the writer produced is what the
/// loader will read".
#[allow(dead_code)]
pub fn post_write_validate(path: &Path) -> Result<AppConfig, ConfigWriteError> {
    let bytes = fs::read(path).map_err(|error| ConfigWriteError::Read {
        path: path.to_path_buf(),
        reason: error.to_string(),
    })?;
    caly_config::schema::parse_and_validate_yaml(&bytes).map_err(|error| ConfigWriteError::Validate {
        path: path.to_path_buf(),
        reason: error.to_string(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn temp_root(name: &str) -> PathBuf {
        static COUNTER: AtomicUsize = AtomicUsize::new(0);
        let n = COUNTER.fetch_add(1, Ordering::Relaxed);
        let pid = std::process::id();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos());
        let path = std::env::temp_dir().join(format!("caly-writer-{name}-{pid}-{n}-{nanos}"));
        fs::create_dir_all(&path).unwrap_or_else(|_| std::process::abort());
        path
    }

    #[test]
    fn mutate_yaml_key_appends_to_an_empty_list() {
        let dir = temp_root("append_empty");
        let path = dir.join("config.yaml");
        fs::write(
            &path,
            "schema_version: 1\ncore: mihomo\nproviders: []\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        // The post-write validation re-runs the loader, so
        // the test must seed a schema-valid value shape.
        // `ProviderConfig::default()` is a
        // `SubscriptionSources` provider (zero sources is
        // valid; the schema doesn't require at least one).
        let seed = caly_config::schema::ProviderConfig { name: "alpha".to_owned(), ..Default::default() };
        mutate_yaml_key::<caly_config::schema::ProviderConfig, _>(&path, "providers", |current| {
            assert!(current.is_empty());
            Ok(vec![seed.clone()])
        })
        .unwrap_or_else(|_| std::process::abort());
        let bytes = fs::read(&path).unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("providers").and_then(|v| v.as_sequence()) else {
            std::process::abort();
        };
        assert_eq!(providers.len(), 1);
        assert_eq!(providers[0].get("name").and_then(|v| v.as_str()), Some("alpha"));
    }

    #[test]
    fn mutate_yaml_key_preserves_other_top_level_keys() {
        let dir = temp_root("preserves");
        let path = dir.join("config.yaml");
        fs::write(
            &path,
            "schema_version: 1\ncore: mihomo\ncore_binaries: {}\nproviders: []\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        let seed = caly_config::schema::ProviderConfig { name: "x".to_owned(), ..Default::default() };
        mutate_yaml_key::<caly_config::schema::ProviderConfig, _>(&path, "providers", |_| {
            Ok(vec![seed.clone()])
        })
        .unwrap_or_else(|_| std::process::abort());
        let bytes = fs::read(&path).unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value = serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(mapping) = value.as_mapping() else {
            std::process::abort();
        };
        // The original `core_binaries:` must still be there.
        assert!(mapping.contains_key("core_binaries"));
        // The new `providers:` is the only mutation.
        assert!(mapping.contains_key("providers"));
    }

    #[test]
    fn mutate_yaml_key_rejects_a_mis_shaped_existing_value() {
        let dir = temp_root("bad_shape");
        let path = dir.join("config.yaml");
        // `providers:` is a string, not a list. The mutator
        // must fail loud, never silently coerce.
        fs::write(
            &path,
            "schema_version: 1\ncore: mihomo\nproviders: not-a-list\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        let result = mutate_yaml_key::<caly_config::schema::ProviderConfig, _>(
            &path,
            "providers",
            |c| Ok(c.to_vec()),
        );
        assert!(matches!(result, Err(ConfigWriteError::Parse { .. })));
    }

    #[test]
    fn backup_config_yaml_writes_a_sidecar() {
        let dir = temp_root("backup");
        let path = dir.join("config.yaml");
        fs::write(&path, "schema_version: 1\ncore: mihomo\n").unwrap_or_else(|_| std::process::abort());
        backup_config_yaml(&path).unwrap_or_else(|_| std::process::abort());
        let backup = path.with_extension("yaml.bak");
        let mut originals = HashMap::new();
        originals.insert(path.display().to_string(), fs::read(&path).unwrap_or_else(|_| std::process::abort()));
        originals.insert(backup.display().to_string(), fs::read(&backup).unwrap_or_else(|_| std::process::abort()));
        assert_eq!(originals.len(), 2);
        assert_eq!(
            originals[&path.display().to_string()],
            originals[&backup.display().to_string()]
        );
    }

    #[test]
    fn backup_config_yaml_is_a_noop_when_the_source_is_missing() {
        let dir = temp_root("noop");
        let path = dir.join("config.yaml");
        backup_config_yaml(&path).unwrap_or_else(|_| std::process::abort());
        assert!(!path.with_extension("yaml.bak").exists());
    }
}
