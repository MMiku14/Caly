//! Daemon operation execution for CLI leaves.
//!
//! Maps each mutation leaf to its wire command, executes it with a fresh
//! operation id, and polls to a terminal state. Human output reports a
//! semantic summary of the requested change; JSON output keeps the raw
//! operation record for scripts. All wire discriminants come from the
//! protocol's typed wire layer (`caly_protocol::protocol::v2`).

use caly_platform::paths::AppPaths;
use serde_json::json;
use std::process::ExitCode;
use std::sync::PoisonError;

/// Per-probe timeout for the full latency sweep (`delay --all`).
const PROBE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(5);

use caly_protocol::{
    client::{ClientContract, ClientError, UdsClient},
    protocol::v2::{
        ExecuteRequest, GetOperationStatusRequest, HandshakeRequest, ProtocolVersion,
        RawOperationState, WireCommand, WireCoreAction, WireCoreKind, WireMode, all_features,
    },
};

use super::{Query, hex, operation_id, output};
use crate::client::legacy::{ConfigCmd, CoreCmd, SysCmd};

/// Validates a single configuration file offline (`config check <file>`).
pub(crate) fn check_single_config_file(path: &std::path::Path, json: bool) -> ExitCode {
    match crate::cli::check_config_file(path) {
        Ok(()) => {
            if json {
                println!(
                    "{}",
                    serde_json::json!({"ok": true, "configuration": "valid"})
                );
            } else {
                println!("configuration is valid");
            }
            ExitCode::SUCCESS
        }
        Err(error) => output::report_config_check_failed(&error.to_string(), json),
    }
}

/// Executes a `config` family leaf.
pub(super) fn execute_config_cmd(client: &mut UdsClient, cmd: ConfigCmd, json: bool) -> ExitCode {
    match cmd {
        ConfigCmd::Apply => execute_operation_with(client, json, "apply configuration", |id| {
            WireCommand::ApplyConfig { candidate_id: id }
        }),
        // Intercepted as offline commands before connecting; defensive.
        ConfigCmd::Generate
        | ConfigCmd::Default
        | ConfigCmd::Validate
        | ConfigCmd::Check(_)
        | ConfigCmd::Path
        | ConfigCmd::Files
        | ConfigCmd::Edit(_) => ExitCode::FAILURE,
    }
}

/// Maps a `core` command leaf to an offline read-only query, if it is one.
pub(super) fn core_query(cmd: &CoreCmd) -> Option<Query> {
    match cmd {
        CoreCmd::ProxyGroups => Some(Query::ProxyGroups),
        CoreCmd::ListConnections => Some(Query::Connections),
        CoreCmd::Traffic => Some(Query::Traffic),
        CoreCmd::Delay { all: true, .. } => None,
        CoreCmd::Delay {
            name: Some(name),
            url,
            samples,
            ..
        } => Some(Query::UrlTest {
            name: name.clone(),
            url: url.clone(),
            samples: crate::client::query::resolve_samples(*samples),
        }),
        CoreCmd::Delay {
            all: false,
            name: None,
            ..
        } => {
            // Unreachable: clap rejects delay with neither --all nor a name.
            None
        }
        _ => None,
    }
}

/// Executes a `core` family leaf. `core` is the resolved `--core` target;
/// only lifecycle leaves (start/stop/restart) use it.
pub(super) fn execute_core_cmd(
    client: &mut UdsClient,
    cmd: CoreCmd,
    core: Option<&str>,
    json: bool,
) -> ExitCode {
    match cmd {
        CoreCmd::Start => execute_core(client, WireCoreAction::Start, core, json),
        CoreCmd::Stop => execute_core(client, WireCoreAction::Stop, core, json),
        CoreCmd::Restart => execute_core(client, WireCoreAction::Restart, core, json),
        CoreCmd::Switch(target) => execute_switch_core(client, &target, json),
        CoreCmd::Select { node, delay } => {
            execute_select_proxy(client, node.as_deref(), delay, json)
        }
        CoreCmd::Delay { all: true, url, .. } => execute_delay_all(client, url.as_deref(), json),
        CoreCmd::CloseConnections => {
            execute_operation_with(client, json, "close all connections", |_| {
                WireCommand::CloseAllConnections
            })
        }
        CoreCmd::Mode(mode) => execute_set_mode(client, &mode, json),
        CoreCmd::ListNodes => output::print_nodes(client, json),
        // These are intercepted as offline queries before connecting.
        CoreCmd::ProxyGroups
        | CoreCmd::ListConnections
        | CoreCmd::Traffic
        | CoreCmd::Delay { .. }
        | CoreCmd::Rules
        | CoreCmd::RuleMatch(_) => ExitCode::FAILURE,
    }
}

/// The layered override fragment `caly sys tun` writes so the TUN intent
/// survives daemon restarts without editing the user's 60-tun.yaml: it sorts
/// after that file, so its `tun.enabled` wins in the layered merge.
const TUN_TOGGLE_OVERRIDE: &str = "65-tun-toggle.yaml";

/// Persists the hot TUN intent into the layered config directory. Returns an
/// exit code on failure; the caller aborts before touching the daemon.
fn patch_tun_enabled(enabled: bool, json: bool) -> Result<(), ExitCode> {
    let directory = AppPaths::from_env().config.join("config.d");
    let contents = format!(
        "# Hot TUN toggle written by `caly sys tun`; layered over\n\
         # config.d/60-tun.yaml so the core renderer sees tun.enabled={enabled}\n\
         # without editing the user's config. Delete this file to hand the\n\
         # TUN setting back to the layered config files.\n\
         tun:\n  enabled: {enabled}\n"
    );
    let path = directory.join(TUN_TOGGLE_OVERRIDE);
    std::fs::write(&path, contents).map_err(|error| {
        output::report_failure(
            &format!(
                "cannot persist TUN toggle {}: {error} (inspect config-directory ownership)",
                path.display()
            ),
            json,
        )
    })?;
    Ok(())
}

/// Executes a `sys` family leaf.
pub(super) fn execute_sys_cmd(client: &mut UdsClient, cmd: SysCmd, json: bool) -> ExitCode {
    match cmd {
        SysCmd::Proxy(enabled) => {
            let summary = if enabled {
                "enable system proxy"
            } else {
                "disable system proxy"
            };
            execute_operation_with(client, json, summary, |_| WireCommand::SetSystemProxy {
                enabled,
            })
        }
        SysCmd::Tun(enabled) => {
            // Hot TUN toggle: no daemon restart needed. The core renderer
            // re-reads the layered TUN config on every apply, so persist the
            // intent into a small override fragment layered after
            // config.d/60-tun.yaml, re-render+commit the core config, then
            // engage/restore the platform TUN device and routes. Ordering
            // matters: the engine must expose the tun inbound before the
            // device comes up (no silent half-engagement), and the inbound
            // goes away before the device is restored on shutdown.
            if let Err(code) = patch_tun_enabled(enabled, json) {
                return code;
            }
            let applied = execute_operation_with(
                client,
                json,
                "apply configuration for TUN",
                |id| WireCommand::ApplyConfig { candidate_id: id },
            );
            if applied != ExitCode::SUCCESS {
                return applied;
            }
            let summary = if enabled { "engage TUN" } else { "restore TUN" };
            let outcome =
                execute_operation_with(client, json, summary, |_| WireCommand::SetTun { enabled });
            // Rollback transaction: a failed engage must never leave the
            // committed tun-inbound config in effect — the core would keep
            // hijacking traffic into a device the platform layer did not
            // confirm, black-holing the network (the half-engaged state that
            // broke direct connectivity in the field). Reversing the enable
            // sequence restores the invariant: toggle off, then re-apply so
            // the core restarts without the tun inbound, releasing the
            // device and tearing down auto-route rules.
            if enabled && outcome != ExitCode::SUCCESS {
                let _ = patch_tun_enabled(false, json);
                let reverted = execute_operation_with(
                    client,
                    json,
                    "revert TUN configuration after failed engage",
                    |id| WireCommand::ApplyConfig { candidate_id: id },
                );
                let message = if reverted == ExitCode::SUCCESS {
                    "TUN engage failed; the configuration was reverted, so routing is restored (fix the cause and retry `caly set tun on`)"
                } else {
                    "TUN engage failed AND the config revert failed; the core may still route traffic through the TUN device — run `caly set tun off` to restore"
                };
                crate::output::CliOutput::from_json_flag(json).info(message);
            }
            outcome
        }
    }
}

/// Executes the configured subscription refresh.
pub(super) fn execute_refresh_subscription(client: &mut UdsClient, json: bool) -> ExitCode {
    execute_operation_with(client, json, "refresh subscription", |_| {
        WireCommand::RefreshSubscription {
            subscription_id: [0_u8; 16],
        }
    })
}

/// Round 17: `set daemon stop`. The server
/// tears down the runtime after the response is
/// serialized; the client gets the final operation
/// status before the daemon process exits, so
/// polling is unnecessary (and would race the
/// `stop_notifier` that closes the UDS socket right
/// after this response is written).
pub(super) fn execute_stop_daemon(client: &mut UdsClient, json: bool) -> ExitCode {
    execute_lifecycle_immediate(client, json, "stop daemon", |_id| WireCommand::StopDaemon)
}

/// Round 17: `set daemon reload`. The server
/// re-reads `config.yaml` and re-applies the current
/// candidate; the operation completes immediately
/// on the application side, so the response is
/// already terminal and polling is unnecessary.
pub(super) fn execute_reload_config(client: &mut UdsClient, json: bool) -> ExitCode {
    execute_lifecycle_immediate(client, json, "reload config", |_id| WireCommand::ReloadConfig)
}

/// Executes a Round-17 lifecycle command whose operation completes on the
/// application side in the same `execute` call: the server returns the
/// final `WireOperationStatus` inside the `ExecuteResponse`, so the client
/// must NOT poll (the `StopDaemon` path closes the UDS socket right after
/// the response, and polling for a stale id would surface a confusing
/// `connect_failed` error). If the response is somehow non-terminal
/// (defensive), fall through to a bounded poll.
fn execute_lifecycle_immediate(
    client: &mut UdsClient,
    json: bool,
    summary: &str,
    build: impl FnOnce([u8; 16]) -> WireCommand,
) -> ExitCode {
    let id = operation_id();
    match client.execute(ExecuteRequest {
        operation_id: id,
        command: build(id),
    }) {
        Ok(response) => {
            let status = response.operation;
            if status.state.is_terminal() {
                output::print_operation_status(&status, json, summary);
                terminal_exit_code(status.state)
            } else {
                // Defensive: the typed path is supposed to be terminal here,
                // but the server may be running an older build that returns a
                // non-terminal status. Poll for a bounded window so the
                // caller still gets a definitive answer.
                poll_operation(client, id, json, summary)
            }
        }
        Err(error) => output::report_error(error, json),
    }
}

/// The single mutation path: assign an operation id, execute the command the
/// caller builds from it, then poll to a terminal state.
fn execute_operation_with(
    client: &mut UdsClient,
    json: bool,
    summary: &str,
    build: impl FnOnce([u8; 16]) -> WireCommand,
) -> ExitCode {
    let id = operation_id();
    match client.execute(ExecuteRequest {
        operation_id: id,
        command: build(id),
    }) {
        Ok(_) => poll_operation(client, id, json, summary),
        Err(error) => output::report_error(error, json),
    }
}

/// Executes a `SetMode` operation against the daemon.
fn execute_set_mode(client: &mut UdsClient, mode: &str, json: bool) -> ExitCode {
    let Some(mode_value) = WireMode::from_label(mode) else {
        return output::report_usage_error("mode must be rule, global, or direct", json);
    };
    execute_operation_with(client, json, &format!("set mode to {mode}"), |_| {
        WireCommand::SetMode {
            mode: mode_value.wire(),
        }
    })
}

/// Switches the active core to `target` (stop previous kernel, start target).
fn execute_switch_core(client: &mut UdsClient, target: &str, json: bool) -> ExitCode {
    let kind = match target {
        "sing-box" => WireCoreKind::SingBox,
        "mihomo" => WireCoreKind::Mihomo,
        other => {
            return output::report_usage_error(
                &format!("unknown core `{other}`; use mihomo or sing-box"),
                json,
            );
        }
    };
    execute_operation_with(
        client,
        json,
        &format!("switch core to {}", kind.label()),
        |_| WireCommand::SwitchCore {
            core_kind: kind.wire(),
            action: WireCoreAction::Restart.wire(),
        },
    )
}

/// Executes a core lifecycle action (start/stop/restart) for the resolved core.
///
/// Without an explicit `--core`/`CALY_CORE`, the target follows the daemon's
/// runtime active core — so `caly core restart` restarts the kernel the user
/// actually switched to instead of silently switching to (or stopping it for)
/// a hardcoded mihomo.
fn execute_core(
    client: &mut UdsClient,
    action: WireCoreAction,
    core: Option<&str>,
    json: bool,
) -> ExitCode {
    let effective = match core {
        Some(core) => Some(core.to_owned()),
        None => active_core_kind(client).map(|kind| kind.label().to_owned()),
    };
    let kind = match resolved_core_kind(effective.as_deref()) {
        Ok(kind) => kind,
        Err(message) => {
            if json {
                println!("{}", serde_json::json!({ "ok": false, "error": message }));
            } else {
                eprintln!("error: {message}");
            }
            return ExitCode::from(2);
        }
    };
    let label = kind.label();
    let verb = match action {
        WireCoreAction::Start => "start",
        WireCoreAction::Stop => "stop",
        WireCoreAction::Restart => "restart",
    };
    execute_operation_with(client, json, &format!("{verb} {label}"), |_| {
        WireCommand::SwitchCore {
            core_kind: kind.wire(),
            action: action.wire(),
        }
    })
}

/// Reads the daemon snapshot for the runtime active core kind.
fn active_core_kind(client: &mut UdsClient) -> Option<WireCoreKind> {
    use caly_protocol::client::ClientContract;
    let snapshot = client.snapshot().ok()?;
    WireCoreKind::from_wire(snapshot.applied.core_kind?)
}

/// Resolves the target core: `--core` flag first, then `CALY_CORE`, default
/// mihomo. Unknown values fail loudly instead of silently falling back to
/// mihomo (a typo like `--core mihomoo` must not silently act on the wrong
/// kernel).
fn resolved_core_kind(core: Option<&str>) -> Result<WireCoreKind, String> {
    let effective = core
        .map(str::to_owned)
        .or_else(|| std::env::var("CALY_CORE").ok());
    match effective.as_deref() {
        None | Some("mihomo") => Ok(WireCoreKind::Mihomo),
        Some("sing-box") => Ok(WireCoreKind::SingBox),
        Some("xray") => Ok(WireCoreKind::Xray),
        Some(other) => Err(format!(
            "unknown core target `{other}` (expected mihomo, sing-box or xray)"
        )),
    }
}

/// Selects a proxy node: by ID/name/prefix, or automatically the lowest
/// latency node (never direct) with `--delay`.
fn execute_select_proxy(
    client: &mut UdsClient,
    node: Option<&str>,
    delay: bool,
    json: bool,
) -> ExitCode {
    if delay {
        let Some(best) = lowest_latency_node(client, json) else {
            return ExitCode::from(2);
        };
        let label = best.1;
        return execute_operation_with(client, json, &format!("select node `{label}`"), |_| {
            WireCommand::SelectProxy { node_id: best.0 }
        });
    }
    let Some(node) = node else {
        return output::report_usage_error(
            "select needs a node ID/name, or --delay to pick the fastest node",
            json,
        );
    };
    let Some((node_id, label)) = resolve_node(client, node, json) else {
        return ExitCode::from(2);
    };
    execute_operation_with(client, json, &format!("select node `{label}`"), |_| {
        WireCommand::SelectProxy { node_id }
    })
}

/// Sweeps the snapshot's registered nodes against the active core controller
/// and returns the lowest-latency reachable one, or `None` when none answers.
/// Every non-reachable outcome is reported so a silent "no node answers" is
/// never confused with a naming/apply mismatch or a controller outage.
fn lowest_latency_node(client: &mut UdsClient, json: bool) -> Option<([u8; 16], String)> {
    let rows = match sweep_snapshot_delays(client, None) {
        Ok(rows) => rows,
        Err(error) => {
            let _ = output::report_failure(&error, json);
            return None;
        }
    };
    let reachable: Vec<(u32, [u8; 16], String)> = rows
        .iter()
        .filter_map(|row| match &row.outcome {
            DelayOutcome::Reachable { samples, .. } => {
                row.outcome.median_ms().map(|ms| (ms, row.node_id, row.name.clone()))
                    .or_else(|| {
                        // Defensive: an empty
                        // `Reachable` shouldn't
                        // happen (the writer
                        // maps empty to
                        // `Unreachable`), but the
                        // contract is "reachable
                        // has at least one sample".
                        let _ = samples;
                        None
                    })
            }
            _ => None,
        })
        .collect();
    let best = reachable.iter().min_by_key(|(ms, _, _)| *ms);
    if best.is_none() {
        let unreachable = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::Unreachable)
            .count();
        let not_in_kernel = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::NotInKernel)
            .count();
        let failed = rows
            .iter()
            .filter(|row| row.outcome == DelayOutcome::ProbeFailed)
            .count();
        let _ = output::report_failure(
            &format!(
                "no node answered the latency probe ({unreachable} unreachable, {not_in_kernel} not in the kernel config, {failed} probe errors)"
            ),
            json,
        );
        return None;
    }
    best.map(|(_, node_id, name)| (*node_id, name.clone()))
}

/// Latency-sweeps the daemon snapshot's nodes against the active core
/// controller (offline). The controller-side name is derived from the core:
/// sing-box outbounds are tagged `proxy-<canonical-hex>`; Mihomo uses the
/// rendered display name. Output rows carry the node ID so they can feed
/// `core select` directly.
fn execute_delay_all(client: &mut UdsClient, url: Option<&str>, json: bool) -> ExitCode {
    match sweep_snapshot_delays(client, url) {
        Ok(rows) => {
            print_delay_sweep(&rows, json);
            ExitCode::SUCCESS
        }
        Err(error) => output::report_failure(&error, json),
    }
}

/// How one node's latency probe ended. Every failure mode stays distinct so a
/// sweep never silently collapses a naming/apply mismatch or a controller
/// outage into the same "unreachable" row. The reachable variant carries
/// the full per-sample list (sorted ascending) so the JSON envelope can
/// report `samples` and `jitter_ms` alongside the median.
#[derive(Clone, Debug, Eq, PartialEq)]
enum DelayOutcome {
    /// Kernel answered at least one probe; the
    /// `samples` are sorted ascending in milliseconds.
    /// `median` (the lower middle on even counts) is
    /// the historical single-number summary.
    Reachable {
        samples: Vec<u32>,
        /// URL the kernel answered (stable for this
        /// row; `None` only for the
        /// unreachable-from-every-URL case, but
        /// that lives in the `Unreachable` variant).
        url: String,
    },
    /// Kernel ran the probe but no URL answered.
    Unreachable,
    /// The controller name is not present in the running kernel's proxy set.
    NotInKernel,
    /// Transport/API failure while probing (controller went away, etc.).
    ProbeFailed,
}

impl DelayOutcome {
    /// One-number summary for sorting / printing.
    /// `Reachable` returns the median; every other
    /// variant returns `None` so the caller can
    /// skip the row in `core select --delay`.
    fn median_ms(&self) -> Option<u32> {
        match self {
            Self::Reachable { samples, .. } => {
                if samples.is_empty() {
                    None
                } else {
                    Some(samples[samples.len() / 2])
                }
            }
            _ => None,
        }
    }
}

/// Builds the `Reachable` outcome from a successful
/// probe. Extracted so the worker closure inside
/// `sweep_snapshot_delays` stays under the 100-line
/// clippy ceiling; the helper is trivial but the
/// closure is the hot loop that has to inline-clean.
fn build_reachable_outcome(probe: super::query::DelayProbe) -> DelayOutcome {
    let url = probe.url().unwrap_or("").to_owned();
    DelayOutcome::Reachable {
        samples: probe.samples().to_vec(),
        url,
    }
}

/// One row of a latency sweep: the node identity plus its probe outcome.
struct SweepRow {
    node_id: [u8; 16],
    name: String,
    /// Controller-side name used for the probe (and the kernel-set match).
    controller_name: String,
    outcome: DelayOutcome,
}

/// Maximum concurrent controller probes in one sweep. Bounded so a 267-node
/// subscription never opens one socket/thread per node against the kernel;
/// the kernel serves probes concurrently, but unbounded client fan-out is
/// wasteful and noisy. 32 balances wall-clock time (dead-node probes burn
/// their full per-probe timeout) against connection fan-out.
const MAX_CONCURRENT_PROBES: usize = 32;

/// Probes every snapshot node through the active core controller with bounded
/// concurrency. Nodes whose controller name is absent from the kernel's real
/// proxy list are reported as `NotInKernel` without probing: probing them
/// would only yield a 404 that the old algorithm silently rendered as
/// "unreachable" (e.g. a subscription that was never applied).
#[allow(clippy::too_many_lines)]
fn sweep_snapshot_delays(
    client: &mut UdsClient,
    url: Option<&str>,
) -> Result<Vec<SweepRow>, String> {
    use caly_protocol::client::ClientContract;
    let snapshot = client.snapshot().map_err(|error| {
        let _ = error;
        "cannot read the daemon snapshot for the node list (is the daemon running?)".to_owned()
    })?;
    let core = active_core_kind(client)
        .map_or_else(|| "mihomo".to_owned(), |kind| kind.label().to_owned());
    let mut rows: Vec<SweepRow> = snapshot
        .nodes
        .iter()
        .map(|node| {
            let controller_name = if core == "sing-box" {
                format!("proxy-{}", caly_domain::to_hex(node.node_id))
            } else {
                node.name.clone()
            };
            SweepRow {
                node_id: node.node_id,
                name: node.name.clone(),
                controller_name,
                outcome: DelayOutcome::Unreachable,
            }
        })
        .collect();
    // Reconcile against the kernel's real proxy set before probing anything, so
    // a stale/unapplied kernel config surfaces as `NotInKernel` instead of a
    // wall of silent 404s.
    let mut control = crate::client::query::build_control(&core)
        .map_err(|error| format!("cannot reach the {core} controller: {error}"))?;
    let kernel_names: std::collections::BTreeSet<String> = control
        .proxy_names(PROBE_TIMEOUT)
        .map_err(|error| format!("cannot read the {core} kernel proxy list: {error}"))?
        .into_iter()
        .collect();
    let mut targets: Vec<(usize, String)> = Vec::new();
    for (index, row) in rows.iter_mut().enumerate() {
        if kernel_names.contains(&row.controller_name) {
            targets.push((index, row.controller_name.clone()));
        } else {
            row.outcome = DelayOutcome::NotInKernel;
        }
    }
    if targets.is_empty() {
        return Ok(rows);
    }
    // Bounded worker pool; each worker owns one controller (fresh secret read)
    // and drains the shared target queue.
    let worker_count = targets.len().min(MAX_CONCURRENT_PROBES);
    let mut controls = Vec::with_capacity(worker_count);
    controls.push(control); // reuse the reconcile controller for probing
    for _ in 1..worker_count {
        if let Ok(control) = crate::client::query::build_control(&core) {
            controls.push(control);
        }
    }
    if controls.is_empty() {
        return Err(format!("cannot build a {core} controller for probing"));
    }
    let shared = std::sync::Mutex::new(targets);
    let shared = &shared;
    let results: Vec<(usize, DelayOutcome)> = std::thread::scope(|scope| {
        let mut workers = Vec::new();
        for mut control in controls {
            workers.push(scope.spawn(move || {
                let mut local = Vec::new();
                loop {
                    let item = {
                        let mut guard = shared.lock().unwrap_or_else(PoisonError::into_inner);
                        guard.pop()
                    };
                    let Some((index, controller_name)) = item else {
                        break;
                    };
                    let outcome = match super::query::probe_delay(
                        &mut *control,
                        &controller_name,
                        url,
                        PROBE_TIMEOUT,
                        // The sweep always takes 3 samples:
                        // a single sample is dominated by
                        // TCP slow-start, two is
                        // sensitive to a single
                        // hiccup, three is the
                        // sweet spot. `--samples N` on
                        // the per-node leaf is the
                        // operator-level escape
                        // hatch; the bulk sweep keeps
                        // its own policy so a
                        // 267-node sweep doesn't take
                        // 22 minutes.
                        3,
                    ) {
                        Ok(probe) if probe.is_reachable() => {
                            build_reachable_outcome(probe)
                        }
                        Ok(_) => DelayOutcome::Unreachable,
                        // A probe that outlived the socket budget (the
                        // kernel hung past its own timeout) is unreachable
                        // from the user's viewpoint, not a controller
                        // transport failure; connect failures stay loud.
                        Err(error)
                            if error.kind
                                == caly_kernel::ports::KernelFailureKind::DeadlineExceeded =>
                        {
                            DelayOutcome::Unreachable
                        }
                        Err(_) => DelayOutcome::ProbeFailed,
                    };
                    local.push((index, outcome));
                }
                local
            }));
        }
        workers
            .into_iter()
            .flat_map(|worker| worker.join().ok().into_iter().flatten())
            .collect()
    });
    for (index, outcome) in results {
        rows[index].outcome = outcome;
    }
    Ok(rows)
}

/// Renders one sweep row as a JSON object. The
/// `delay_ms` field is the median (kept for
/// historical `jq .delay_ms` consumers); `jitter_ms`
/// and the full `samples` array are additive so a
/// script consumer can see the spread and the
/// per-sample distribution. `controller_name` is
/// added to every row so a script can grep the
/// kernel-side name even when the snapshot's
/// `name` is a hash-derived label (sing-box).
fn sweep_row_to_json(row: &SweepRow) -> serde_json::Value {
    let mut value = match &row.outcome {
        DelayOutcome::Reachable { samples, url } => {
            let median = row.outcome.median_ms();
            let jitter = samples
                .first()
                .zip(samples.last())
                .map_or(0, |(lo, hi)| hi - lo);
            serde_json::json!({
                "id": hex(row.node_id),
                "name": row.name.as_str(),
                "status": "ok",
                "median_ms": median,
                "delay_ms": median,
                "jitter_ms": if samples.len() >= 2 { Some(jitter) } else { None },
                "samples": samples,
                "url": url,
            })
        }
        DelayOutcome::Unreachable => serde_json::json!({
            "id": hex(row.node_id),
            "name": row.name.as_str(),
            "status": "unreachable",
            "median_ms": null,
            "delay_ms": null,
        }),
        DelayOutcome::NotInKernel => serde_json::json!({
            "id": hex(row.node_id),
            "name": row.name.as_str(),
            "status": "not_in_kernel",
            "median_ms": null,
            "delay_ms": null,
        }),
        DelayOutcome::ProbeFailed => serde_json::json!({
            "id": hex(row.node_id),
            "name": row.name.as_str(),
            "status": "error",
            "median_ms": null,
            "delay_ms": null,
        }),
    };
    if let serde_json::Value::Object(map) = &mut value {
        map.insert(
            "controller_name".to_owned(),
            serde_json::Value::String(row.controller_name.clone()),
        );
    }
    value
}

/// Renders the delay sweep: reachable first (ascending by median), then
/// unreachable in name order, then nodes missing from the kernel config.
/// Every row includes the node ID for `core select`. The JSON form
/// carries `samples` and `jitter_ms` per reachable row so a script
/// consumer can see the full distribution; the human form prints the
/// median and a one-character jitter glyph.
fn print_delay_sweep(rows: &[SweepRow], json: bool) {
    let mut reachable: Vec<&SweepRow> = rows
        .iter()
        .filter(|row| matches!(row.outcome, DelayOutcome::Reachable { .. }))
        .collect();
    // Sort by the median (the lower middle), not the
    // min — a node with [50, 200, 800] sorts at 200,
    // the historical `min` policy would have placed
    // it at 50 next to a node that answered 50, 50,
    // 50. The operator's `core select --delay`
    // choice should be the stable one, not the lucky
    // sample.
    reachable.sort_by_key(|row| row.outcome.median_ms().unwrap_or(u32::MAX));
    let unreachable = sorted_by_name(rows, DelayOutcome::Unreachable);
    let not_in_kernel = sorted_by_name(rows, DelayOutcome::NotInKernel);
    let probe_failed = sorted_by_name(rows, DelayOutcome::ProbeFailed);
    if json {
        let rows_json: Vec<serde_json::Value> = rows
            .iter()
            .map(sweep_row_to_json)
            .collect();
        println!(
            "{}",
            json!({
                "probes": rows_json,
                "total": rows.len(),
                "reachable": reachable.len(),
                "unreachable": unreachable.len(),
                "not_in_kernel": not_in_kernel.len(),
                "probe_errors": probe_failed.len(),
            })
        );
        return;
    }
    let suffix = if not_in_kernel.is_empty() {
        String::new()
    } else {
        format!(", {} not in kernel config", not_in_kernel.len())
    };
    let failed_suffix = if probe_failed.is_empty() {
        String::new()
    } else {
        format!(", {} probe errors", probe_failed.len())
    };
    println!(
        "probes: {} total, {} reachable, {} unreachable{suffix}{failed_suffix} (run `core select --delay` for the fastest)",
        rows.len(),
        reachable.len(),
        unreachable.len()
    );
    for row in &reachable {
        let DelayOutcome::Reachable { samples, .. } = &row.outcome else {
            continue;
        };
        let median = row.outcome.median_ms().unwrap_or(0);
        // One-character jitter glyph:
        // `.` — steady (jitter <= 10ms, or single sample)
        // `~` — mild   (jitter <= 25% of median)
        // `!` — spiky  (jitter > 25% of median)
        // The operator learns at a glance which
                        // "fast" nodes are actually reliable.
        let jitter = samples
            .first()
            .zip(samples.last())
            .map_or(0, |(lo, hi)| hi - lo);
        let glyph = if samples.len() < 2 {
            '.'
        } else if median == 0 {
            '~'
        } else if jitter * 4 <= median {
            '.'
        } else if jitter * 4 <= median * 5 {
            '~'
        } else {
            '!'
        };
        print_sweep_row(
            row,
            &format!("{median:>6} ms {glyph}"),
            "",
        );
    }
    for row in &unreachable {
        print_sweep_row(row, "-", "");
    }
    for row in &not_in_kernel {
        print_sweep_row(row, "!", "  not in kernel config");
    }
    for row in &probe_failed {
        print_sweep_row(row, "?", "  probe error");
    }
    if !not_in_kernel.is_empty() {
        println!(
            "hint: nodes not in the running kernel config — run `caly config apply` to publish subscription nodes, then retry `delay --all`"
        );
    }
}

/// Rows with the given outcome, name-ordered (deterministic sweep tables).
fn sorted_by_name(rows: &[SweepRow], outcome: DelayOutcome) -> Vec<&SweepRow> {
    let mut selected: Vec<&SweepRow> = rows.iter().filter(|row| row.outcome == outcome).collect();
    selected.sort_by(|a, b| a.name.cmp(&b.name));
    selected
}

/// Prints one sweep row: `<marker>  <32-hex ID>  <name>[annotation]`.
/// The marker column is fixed-width so every row's ID column aligns.
/// Width 10 accommodates `9999 ms !` (the `!` glyph marks
/// spiky jitter; the per-row human rendering adds a single
/// trailing character so 7 was the historical width and 10
/// covers the four-digit case without clipping).
fn print_sweep_row(row: &SweepRow, marker: &str, annotation: &str) {
    println!(
        "  {marker:<10}  {}  {}{}",
        hex(row.node_id),
        row.name.as_str(),
        annotation
    );
}

/// Resolves a `select` argument: a 32-hex node ID is used as-is; anything
/// else is matched against the snapshot's node display names (exact match
/// first, then a unique case-insensitive match).
fn resolve_node(client: &mut UdsClient, node: &str, json: bool) -> Option<([u8; 16], String)> {
    if let Some(id) = parse_node_id(node) {
        return Some((id, node.to_owned()));
    }
    let snapshot = match client.snapshot() {
        Ok(snapshot) => snapshot,
        Err(error) => {
            let _ = output::report_error(error, json);
            return None;
        }
    };
    let exact: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| {
            candidate.name == node || output::decode_display_name(&candidate.name) == node
        })
        .collect();
    if exact.len() == 1 {
        return Some((exact[0].node_id, exact[0].name.clone()));
    }
    if exact.len() > 1 {
        let ids = exact
            .iter()
            .map(|candidate| format!("  {} ({})", hex(candidate.node_id), candidate.protocol))
            .collect::<Vec<_>>()
            .join("\n");
        output::report_usage_error(
            &format!(
                "{} nodes share the name `{node}`; select one by ID:\n{ids}",
                exact.len()
            ),
            json,
        );
        return None;
    }
    let fuzzy: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| candidate.name.eq_ignore_ascii_case(node))
        .collect();
    if fuzzy.len() == 1 {
        return Some((fuzzy[0].node_id, fuzzy[0].name.clone()));
    }
    // Unique case-insensitive prefix match: select by a short unambiguous
    // fragment of the display name (e.g. the country flag or keyword).
    let prefix: Vec<_> = snapshot
        .nodes
        .iter()
        .filter(|candidate| {
            candidate
                .name
                .to_lowercase()
                .starts_with(&node.to_lowercase())
        })
        .collect();
    if prefix.len() == 1 {
        return Some((prefix[0].node_id, prefix[0].name.clone()));
    }
    if prefix.len() > 1 {
        let ids = prefix
            .iter()
            .take(8)
            .map(|candidate| format!("  {} ({})", hex(candidate.node_id), candidate.name))
            .collect::<Vec<_>>()
            .join("\n");
        output::report_usage_error(
            &format!(
                "`{node}` matches {} nodes; use a longer prefix or an ID:\n{ids}",
                prefix.len()
            ),
            json,
        );
        return None;
    }
    output::report_usage_error(
        &format!("no node named `{node}`; list nodes with `caly core list-nodes`"),
        json,
    );
    None
}

/// Parses a 32-hex-character node id into its 16-byte wire form.
pub(super) fn parse_node_id(hex_value: &str) -> Option<[u8; 16]> {
    if hex_value.len() != 32 {
        return None;
    }
    let mut id = [0_u8; 16];
    for (index, pair) in hex_value.as_bytes().chunks(2).enumerate() {
        let hi = u8::try_from((pair[0] as char).to_digit(16)?).ok()?;
        let lo = u8::try_from((pair[1] as char).to_digit(16)?).ok()?;
        id[index] = (hi << 4) | lo;
    }
    Some(id)
}

/// Polls an operation until it reaches a terminal state (or a bounded timeout).
/// `summary` describes the requested change for the human-readable result line.
fn poll_operation(client: &mut UdsClient, id: [u8; 16], json: bool, summary: &str) -> ExitCode {
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(20);
    loop {
        match client.operation_status(GetOperationStatusRequest { operation_id: id }) {
            Ok(status) => {
                if status.state.is_terminal() {
                    output::print_operation_status(&status, json, summary);
                    return terminal_exit_code(status.state);
                }
                if std::time::Instant::now() >= deadline {
                    output::print_operation_status(&status, json, summary);
                    return ExitCode::from(6); // TimedOutStillRunning
                }
            }
            Err(error) => return output::report_error(error, json),
        }
        std::thread::sleep(std::time::Duration::from_millis(200));
    }
}

/// Maps a terminal operation state to the CLI exit-code contract.
fn terminal_exit_code(state: RawOperationState) -> ExitCode {
    use caly_protocol::protocol::v2::WireOperationState;
    match state.known() {
        Some(WireOperationState::Completed) => ExitCode::SUCCESS,
        Some(WireOperationState::Failed) => ExitCode::from(3),
        Some(WireOperationState::Cancelled) => ExitCode::from(7),
        _ => ExitCode::from(6), // still running / unknown
    }
}

/// Performs the v2 handshake over an established client connection.
pub(crate) fn handshake(client: &mut UdsClient) -> Result<(), ClientError> {
    client.handshake(HandshakeRequest {
        client_version: ProtocolVersion::V2_0,
        requested_features: all_features(),
    })?;
    Ok(())
}

/// Connects to the UDS, retrying briefly on `TransportUnavailable` to absorb a
/// daemon-startup race. Non-transport failures surface immediately.
pub(super) fn connect_with_retry(socket: &std::path::Path) -> Result<UdsClient, ClientError> {
    const MAX_ATTEMPTS: u32 = 5;
    const RETRY_MS: u64 = 200;
    let mut last = ClientError::TransportUnavailable;
    for attempt in 0..MAX_ATTEMPTS {
        match UdsClient::connect(socket.to_path_buf()) {
            Ok(client) => return Ok(client),
            Err(error) => {
                last = error;
                if !matches!(last, ClientError::TransportUnavailable) || attempt + 1 == MAX_ATTEMPTS
                {
                    break;
                }
                std::thread::sleep(std::time::Duration::from_millis(RETRY_MS));
            }
        }
    }
    Err(last)
}

#[cfg(test)]
mod core_target_tests {
    use super::resolved_core_kind;
    use caly_protocol::protocol::v2::WireCoreKind;

    #[test]
    fn accepts_known_targets() -> Result<(), String> {
        assert_eq!(
            resolved_core_kind(None).map_err(|e| e.clone())?,
            WireCoreKind::Mihomo
        );
        assert_eq!(
            resolved_core_kind(Some("mihomo")).map_err(|e| e.clone())?,
            WireCoreKind::Mihomo
        );
        assert_eq!(
            resolved_core_kind(Some("sing-box")).map_err(|e| e.clone())?,
            WireCoreKind::SingBox
        );
        Ok(())
    }

    #[test]
    fn rejects_unknown_targets_loudly() {
        // A typo must fail instead of silently acting on mihomo.
        assert!(resolved_core_kind(Some("mihomoo")).is_err());
        assert!(resolved_core_kind(Some("singbox")).is_err());
        assert!(resolved_core_kind(Some("")).is_err());
    }
}
