//! Human and JSON presentation of daemon snapshots and operation status.
//!
//! All JSON is produced through `serde_json` (never hand-assembled strings),
//! and all wire discriminants render through the protocol's typed wire layer.

use std::process::ExitCode;

/// Whether stdout is a real terminal (colored tabular output only then; piped
/// output stays plain and script-friendly).
fn ansi_enabled() -> bool {
    use std::io::IsTerminal;
    std::io::stdout().is_terminal()
}

/// Wraps `text` in an ANSI color class by latency when stdout is a terminal.
fn latency_color(ms: Option<u32>, text: &str) -> String {
    if !ansi_enabled() {
        return text.to_owned();
    }
    let color = match ms {
        Some(value) if value < 200 => "32",
        Some(value) if value < 500 => "33",
        _ => "0",
    };
    format!("\x1b[{color}m{text}\x1b[0m")
}

use caly_protocol::{
    client::{ClientContract, ClientError, UdsClient},
    protocol::v2::{
        WireCoreKind, WireMode, WireObservedState, WireOperationState, WireOperationStatus,
        WirePlatformEffect, WirePresentationSnapshot, WireRunState,
    },
};
use serde_json::json;

use super::hex;
use super::output_capabilities::print_capabilities;

fn mode_label(value: i32) -> String {
    WireMode::from_wire(value).map_or_else(
        || format!("unknown({value})"),
        |mode| mode.label().to_owned(),
    )
}

fn core_label(value: i32) -> String {
    WireCoreKind::from_wire(value).map_or_else(
        || format!("unknown({value})"),
        |core| core.label().to_owned(),
    )
}

fn run_state_label(value: i32) -> String {
    WireRunState::from_wire(value).map_or_else(
        || format!("unknown({value})"),
        |state| state.label().to_owned(),
    )
}

/// Renders `caly status` as human text or a single JSON line.
pub(super) fn print_status(client: &mut UdsClient, json: bool) -> ExitCode {
    match client.snapshot() {
        Ok(snapshot) if json => {
            println!("{}", status_json(&snapshot));
            ExitCode::SUCCESS
        }
        Ok(snapshot) => {
            println!("daemon:      {}", hex(snapshot.daemon_instance_id));
            println!("revision:    {}", snapshot.revision);
            println!("sequence:    {}", snapshot.cursor.sequence);
            println!();
            print_desired(&snapshot);
            print_applied(&snapshot);
            print_observed(&snapshot);
            print_platform(&snapshot);
            println!();
            println!("nodes: {}", snapshot.nodes.len());
            print_capabilities(&snapshot);
            ExitCode::SUCCESS
        }
        Err(error) => report_error(error, json),
    }
}

/// Renders a terminal operation status as human text or JSON. `summary`
/// describes the requested change so a successful mutation reports what
/// happened instead of only an opaque operation id.
pub(super) fn print_operation_status(status: &WireOperationStatus, json: bool, summary: &str) {
    if json {
        let failure = status.failure.as_ref().map(|failure| {
            json!({
                "code": failure.code.0,
                "message": failure.message,
                "hint": failure.suggested_action,
            })
        });
        println!(
            "{}",
            json!({
                "operation_id": hex(status.operation_id),
                "state": status.state.0,
                "created_at_ms": status.created_at_unix_ms,
                "updated_at_ms": status.updated_at_unix_ms,
                "failure": failure,
            })
        );
    } else if matches!(status.state.known(), Some(WireOperationState::Completed)) {
        println!("ok: {summary}");
    } else {
        eprintln!(
            "operation {} {}: {summary}",
            hex(status.operation_id),
            status.state.label()
        );
        if let Some(failure) = &status.failure {
            eprintln!(
                "error: {}\nhint: {}",
                failure.message, failure.suggested_action
            );
        }
    }
}

/// Renders `caly core list-nodes` from the daemon snapshot so users can obtain
/// node IDs (required by `core select`) without the TUI.
pub(super) fn print_nodes(client: &mut UdsClient, json: bool) -> ExitCode {
    match client.snapshot() {
        Ok(snapshot) if json => {
            let nodes: Vec<serde_json::Value> = snapshot
                .nodes
                .iter()
                .map(|node| {
                    json!({
                        "id": hex(node.node_id),
                        "name": decode_display_name(&node.name),
                        "protocol": node.protocol,
                        "available": node.available,
                        "latency_ms": node.latency_ms,
                    })
                })
                .collect();
            println!("{}", json!({ "nodes": nodes }));
            ExitCode::SUCCESS
        }
        Ok(snapshot) => {
            if snapshot.nodes.is_empty() {
                println!("nodes: 0 (refresh a subscription with `caly sub refresh`)");
                return ExitCode::SUCCESS;
            }
            println!("nodes: {}", snapshot.nodes.len());
            if ansi_enabled() {
                println!("  ID                                 PROTOCOL   LATENCY    NAME");
            }
            for node in &snapshot.nodes {
                let latency = node
                    .latency_ms
                    .map_or_else(|| "-".to_owned(), |ms| format!("{ms} ms"));
                let latency = latency_color(node.latency_ms, &latency);
                if ansi_enabled() {
                    println!(
                        "  {:<32}  {:<9}  {:<10}  {}",
                        hex(node.node_id),
                        node.protocol,
                        latency,
                        node.name.as_str()
                    );
                } else {
                    println!(
                        "  {}  {:<9} latency={:<9} {}",
                        hex(node.node_id),
                        node.protocol,
                        latency,
                        node.name.as_str()
                    );
                }
            }
            ExitCode::SUCCESS
        }
        Err(error) => report_error(error, json),
    }
}

/// Reports an invalid `--core` target value before any connection attempt.
pub(super) fn report_invalid_core(value: &str, json: bool) -> ExitCode {
    report_usage_error(
        &format!("core must be mihomo or sing-box (got `{value}`)"),
        json,
    )
}

/// Reports a usage/validation error (bad arguments, unknown names): exit 2.
pub(super) fn report_usage_error(message: &str, json: bool) -> ExitCode {
    if json {
        eprintln!("{}", json!({ "ok": false, "error": message }));
    } else {
        eprintln!("{message}");
    }
    ExitCode::from(2)
}

/// Reports a runtime failure without daemon-specific detail: exit 1.
pub(super) fn report_failure(message: &str, json: bool) -> ExitCode {
    if json {
        eprintln!("{}", json!({ "ok": false, "error": message }));
    } else {
        eprintln!("{message}");
    }
    ExitCode::FAILURE
}

/// Renders a client failure; JSON emits a single structured line.
pub(super) fn report_error(error: ClientError, json: bool) -> ExitCode {
    // Errors always go to stderr so that stdout carries only successful data,
    // regardless of output mode. In `--json` mode the error is still a JSON object.
    let (message, suggested_action) = client_error_details(&error);
    if json {
        eprintln!(
            "{}",
            json!({ "ok": false, "error": message, "hint": suggested_action })
        );
    } else {
        eprintln!("client command failed: {message}\nhint: {suggested_action}");
    }
    ExitCode::FAILURE
}

/// Converts protocol-only errors into stable user-facing remediation.
fn client_error_details(error: &ClientError) -> (&str, &str) {
    match error {
        ClientError::TransportUnavailable => (
            "cannot reach the caly daemon",
            "start it with `caly daemon`, or pass the correct --socket PATH",
        ),
        ClientError::DeadlineExceeded => (
            "the daemon did not respond before the deadline",
            "check `caly status` and daemon logs, then retry",
        ),
        ClientError::IncompatibleVersion => (
            "the client and daemon protocol versions are incompatible",
            "upgrade or restart caly so client and daemon use the same version",
        ),
        ClientError::AuthenticationRejected => (
            "the daemon rejected this client session",
            "restart the daemon and ensure the socket belongs to the same user",
        ),
        ClientError::ResourceExhausted => (
            "the daemon is busy and its request queue is full",
            "wait briefly and retry; do not start multiple competing clients",
        ),
        ClientError::DecodeRejected {
            reason,
            suggested_action,
        } => (reason, suggested_action),
    }
}

fn print_desired(snapshot: &WirePresentationSnapshot) {
    println!("desired:");
    println!("  mode:             {}", mode_label(snapshot.desired.mode));
    println!("  tun:              {}", snapshot.desired.tun_requested);
    println!(
        "  system-proxy:     {}",
        snapshot.desired.system_proxy_requested
    );
    println!();
}

fn print_applied(snapshot: &WirePresentationSnapshot) {
    println!("applied:");
    println!(
        "  core:             {}",
        snapshot
            .applied
            .core_kind
            .map_or_else(|| "none".to_owned(), core_label)
    );
    println!(
        "  run-state:        {}",
        run_state_label(snapshot.applied.run_state)
    );
    println!(
        "  config-generation: {}",
        snapshot
            .applied
            .config_generation
            .map_or_else(|| "-".to_owned(), |value| value.to_string())
    );
    if let Some(node_id) = snapshot.applied.selected_node_id {
        let name = snapshot
            .nodes
            .iter()
            .find(|node| node.node_id == node_id)
            .map_or_else(
                || "-".to_owned(),
                |node| decode_display_name(node.name.as_str()),
            );
        println!("  selected-node:    {}  {}", hex(node_id), name);
    }
    println!();
}

fn print_observed(snapshot: &WirePresentationSnapshot) {
    println!("observed:");
    println!(
        "  up:               {} B/s",
        snapshot.observed.upload_bytes_per_second
    );
    println!(
        "  down:             {} B/s",
        snapshot.observed.download_bytes_per_second
    );
    println!(
        "  connections:      {}",
        snapshot.observed.active_connections
    );
    println!(
        "  restarts:         {}",
        snapshot.observed.core_restart_count
    );
    println!(
        "  restart-backoff:  {} ms",
        snapshot.observed.core_restart_backoff_ms
    );
    println!();
}

fn print_platform(snapshot: &WirePresentationSnapshot) {
    println!("platform:");
    println!("  proxy-engaged:    {}", snapshot.platform.proxy_engaged);
    println!("  tun-engaged:      {}", snapshot.platform.tun_engaged);
    println!("  recovery-pending: {}", snapshot.platform.recovery_pending);
    println!(
        "  degraded:         {}",
        snapshot.platform.degraded_reason.as_deref().unwrap_or("-")
    );
    println!();
}

/// Serializes the snapshot as one JSON line. Absent optional fields stay
/// `null` so field types are stable for script consumers.
fn status_json(snapshot: &WirePresentationSnapshot) -> String {
    json!({
        "daemon": hex(snapshot.daemon_instance_id),
        "revision": snapshot.revision,
        "sequence": snapshot.cursor.sequence,
        "desired": {
            "mode": mode_label(snapshot.desired.mode),
            "tun": snapshot.desired.tun_requested,
            "system_proxy": snapshot.desired.system_proxy_requested,
        },
        "applied": {
            "core": snapshot.applied.core_kind.map(core_label),
            "run_state": run_state_label(snapshot.applied.run_state),
            "config_generation": snapshot.applied.config_generation,
            "selected_node": snapshot.applied.selected_node_id.map(|node_id| {
                let name = snapshot
                    .nodes
                    .iter()
                    .find(|node| node.node_id == node_id)
                    .map_or_else(|| "-".to_owned(), |node| decode_display_name(node.name.as_str()));
                json!({ "id": hex(node_id), "name": name })
            }),
        },
        "observed": observed_json(&snapshot.observed),
        "nodes": snapshot.nodes.len(),
        "platform": platform_json(&snapshot.platform),
    })
    .to_string()
}

fn observed_json(observed: &WireObservedState) -> serde_json::Value {
    json!({
        "up_bps": observed.upload_bytes_per_second,
        "down_bps": observed.download_bytes_per_second,
        "connections": observed.active_connections,
        "restarts": observed.core_restart_count,
        "restart_backoff_ms": observed.core_restart_backoff_ms,
    })
}

fn platform_json(platform: &WirePlatformEffect) -> serde_json::Value {
    json!({
        "proxy_engaged": platform.proxy_engaged,
        "tun_engaged": platform.tun_engaged,
        "recovery_pending": platform.recovery_pending,
    })
}

/// Decodes a percent-encoded display name for humans. Idempotent for plain
/// text; some subscription sources ship URL-encoded tags, so decoding at the
/// presentation layer keeps `list-nodes`/`status`/delay output readable while
/// the registry keeps the raw tag for controller matching.
pub(super) fn decode_display_name(name: &str) -> String {
    use percent_encoding::percent_decode_str;
    match percent_decode_str(name).decode_utf8() {
        Ok(decoded) => decoded.into_owned(),
        Err(_) => name.to_owned(),
    }
}
