//! Round 16: legacy client RPC enums.
//!
//! Before Round 11, the CLI shipped a single `Command`
//! enum with `Core` / `Sub` / `Sys` / `Config` /
//! `Profile` variants that mapped 1-for-1 to the
//! `core` / `sub` / `sys` / `config` / `profile`
//! daemon RPCs. Round 11 replaced the public surface
//! with the 5-namespace grammar (`daemon` / `tool` /
//! `show` / `set` / `completions`); the legacy enums
//! stayed as the *internal* input shape of
//! `commands::bridge::old_*`. Round 16 retires
//! `commands::bridge` (its 5 `old_*` shims are dead
//! after Round 15 rewired the dispatch) and moves the
//! 5 legacy enums here as private client RPC types.
//!
//! `ClientCommand` (in `client::mod.rs`) carries the
//! `Core` / `Sys` / `Config` variants that the UDS
//! pipeline still needs. The `SubCmd` and `ProfileCmd`
//! enums are kept as dead code so a future refactor can
//! re-use them without re-defining the variant surface.

use std::path::PathBuf;

use crate::cli::Editor;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ConfigCmd {
    Apply, Generate, Default, Validate,
    Check(PathBuf), Path, Files, Edit(Editor),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SysCmd { Proxy(bool), Tun(bool) }

#[allow(dead_code)] // Round 16: `SubCmd` is no longer reachable
                   // from any dispatch (the bridge that owned
                   // it is gone). Kept as a private
                   // client RPC enum for a future round that
                   // folds `sub_*` shims into the typed
                   // `ClientCommand` shape.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SubCmd {
    Refresh, List,
    Check { path: PathBuf, userinfo: Option<String> },
    Import { path: Option<PathBuf>, clipboard: bool },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CoreCmd {
    Start, Stop, Restart, Switch(String),
    Select { node: Option<String>, delay: bool },
    CloseConnections, Mode(String),
    ProxyGroups, ListConnections, ListNodes, Traffic,
    Delay {
        all: bool,
        name: Option<String>,
        url: Option<String>,
        /// Per-URL sample count (1..=5); `None`
        /// means "use the default". The offline
        /// `Query::UrlTest` path resolves the
        /// default at the dispatch boundary.
        samples: Option<u32>,
    },
    Rules, RuleMatch(String),
}

#[allow(dead_code)] // Round 16: `ProfileCmd` is no longer
                   // reachable from any dispatch (`show
                   // profile` goes through `client::profile`
                   // directly). Kept as a private client
                   // RPC enum for documentation / future
                   // refactors.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ProfileCmd {
    List, Show { id: String },
}
