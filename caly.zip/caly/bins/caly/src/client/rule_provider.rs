//! Round 15: offline rule-provider writer for the
//! `set rule-provider …` leaves.
//!
//! The 6 CRUD leaves (`add-http` / `add-file` / `add-inline` /
//! `remove` / `enable` / `disable`) round-trip
//! `rule_providers: Vec<RuleProviderConfig>` in
//! `config.yaml`. `refresh` is the daemon-RPC
//! path (separate wire command) and stays outside this
//! module.
//!
//! # Why a separate module (not inside `subscription.rs`)
//!
//! `subscription` and `rule_provider` both touch
//! "declared remote source" lists but the resource kind is
//! different: subscription bodies are *proxy* node URIs,
//! rule-provider bodies are *rule matchers*. The
//! `Refreshable` trait already treats them as two
//! different families (`sub` vs `rule_provider`); the
//! writer module follows the same split so future per-family
//! tweak (e.g. an `apply` semantic for rule-provider
//! payload validation) lands in one place without leaking
//! into the other.
//!
//! # Round 15 error model
//!
//! Every writer returns `Result<_, RpWriteError>`. The CLI
//! dispatch in `commands::set::rule_provider` maps each
//! variant to a stable `code:` in the JSON envelope:
//!
//! | variant                | code                       |
//! |------------------------|----------------------------|
//! | `InvalidName`          | `rule_provider.invalid_name` |
//! | `AlreadyDeclared`      | `rule_provider.already_declared` |
//! | `NotDeclared`          | `rule_provider.not_declared` |
//! | `InvalidBehavior`      | `rule_provider.invalid_behavior` |
//! | `InvalidUrl`           | `rule_provider.invalid_url` |
//! | `Write`                | `rule_provider.write_failed` |
//! | `Parse`                | `rule_provider.parse_failed` |
//! | `Validate`             | `rule_provider.validate_failed` |

use std::path::PathBuf;

use caly_config::schema::{
    RuleProviderBehaviorConfig, RuleProviderConfig, RuleProviderFormatConfig,
    RuleProviderSourceConfig,
};
use caly_platform::paths::AppPaths;

use super::config_writer::{ConfigWriteError, backup_config_yaml, mutate_yaml_key};

/// Single error type for the 6 CRUD writers. The CLI maps
/// each variant to a stable `code:` so the operator gets
/// a consistent envelope across writers.
#[allow(dead_code)] // `Parse` / `Validate` mirror the
                   // `subscription` shape for a future
                   // `set rule-provider import` leaf.
#[derive(Debug)]
pub enum RpWriteError {
    /// The provider name is empty or not path-safe ASCII.
    InvalidName(String),
    /// `add` on a name that's already in `rule_providers:`.
    AlreadyDeclared(String),
    /// `remove` / `enable` / `disable` on a name that's
    /// not in `rule_providers:`.
    NotDeclared(String),
    /// The `behavior:` is not a known matcher kind
    /// (rejected by the schema enum, surfaced for
    /// diagnostics).
    InvalidBehavior(String),
    /// The HTTP URL is empty or not `http(s)://`.
    InvalidUrl(String),
    /// A `ConfigWriteError` from the generic writer.
    Write(String),
    /// A `ConfigWriteError::Parse` shorthand.
    Parse(String),
    /// A `ConfigWriteError::Validate` shorthand.
    Validate(String),
}

impl core::fmt::Display for RpWriteError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::InvalidName(name) =>
                write!(formatter, "rule provider name `{name}` is not path-safe ASCII"),
            Self::AlreadyDeclared(name) =>
                write!(formatter, "rule provider `{name}` is already declared"),
            Self::NotDeclared(name) =>
                write!(formatter, "rule provider `{name}` is not declared"),
            Self::InvalidBehavior(reason) =>
                write!(formatter, "invalid rule provider behavior: {reason}"),
            Self::InvalidUrl(reason) =>
                write!(formatter, "invalid rule provider URL: {reason}"),
            Self::Write(reason) | Self::Parse(reason) | Self::Validate(reason) =>
                write!(formatter, "{reason}"),
        }
    }
}

impl std::error::Error for RpWriteError {}

impl From<ConfigWriteError> for RpWriteError {
    fn from(value: ConfigWriteError) -> Self {
        match &value {
            ConfigWriteError::Read { .. } | ConfigWriteError::Write { .. } =>
                Self::Write(value.to_string()),
            ConfigWriteError::Parse { .. } => Self::Parse(value.to_string()),
            ConfigWriteError::Validate { .. } => Self::Validate(value.to_string()),
            ConfigWriteError::Mutator(_) => Self::Write(value.to_string()),
        }
    }
}

/// Source-kind spec for the CLI writer. Mirrors
/// `cli::RuleProviderSourceSpec` but erases the bounded
/// text / the file path. The CLI dispatch converts
/// between the two shapes.
#[derive(Debug, Clone)]
pub enum RpSourceSpec {
    Http { url: String, interval_ms: u64 },
    File { path: PathBuf },
    Inline { payload: String },
}

/// The behavior the rule body contains. Mirrors
/// `RuleProviderBehaviorConfig` but stays a CLI-side enum
/// (the dispatch maps the user-typed `--behavior` flag to
/// one of these; the writer converts to the schema enum).
#[allow(dead_code)] // `DomainSuffix` / `IpCidr` / `Classical`
                   // / `parse` are reserved for a future
                   // `set rule-provider add-* --behavior` flag
                   // (Round 16+). Round 15 defaults to `Domain`
                   // for all new entries.
#[derive(Debug, Clone, Copy)]
pub enum RpBehavior {
    Domain,
    DomainSuffix,
    IpCidr,
    Classical,
}

impl RpBehavior {
    /// The default behavior when the operator does not pass
    /// `--behavior` explicitly. Round 15 default: `Domain`
    /// (the most common pattern in mihomo rule-providers).
    pub const DEFAULT: Self = Self::Domain;

    #[allow(dead_code)] // future `set rule-provider add --behavior`
    pub fn parse(s: &str) -> Option<Self> {
        match s.trim() {
            "domain" | "Domain" => Some(Self::Domain),
            "domain-suffix" | "DomainSuffix" => Some(Self::DomainSuffix),
            "ip-cidr" | "IpCidr" => Some(Self::IpCidr),
            "classical" | "Classical" => Some(Self::Classical),
            _ => None,
        }
    }

    pub const fn to_schema(self) -> RuleProviderBehaviorConfig {
        match self {
            Self::Domain => RuleProviderBehaviorConfig::Domain,
            Self::DomainSuffix => RuleProviderBehaviorConfig::DomainSuffix,
            Self::IpCidr => RuleProviderBehaviorConfig::IpCidr,
            Self::Classical => RuleProviderBehaviorConfig::Classical,
        }
    }
}

/// What an `add` / `remove` / `enable` / `disable` call
/// did. `DryRun` is what `--dry-run` (the default) returns
/// when the call would have written.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RpWriteOutcome {
    Applied,
    DryRun,
}

fn config_yaml_path(paths: &AppPaths) -> PathBuf {
    paths.config.join("config.yaml")
}

fn is_path_safe_name(name: &str) -> bool {
    !name.is_empty()
        && name.chars().all(|c| {
            c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.'
        })
}

fn build_config(
    name: &str,
    source: &RpSourceSpec,
    behavior: RpBehavior,
) -> Result<RuleProviderConfig, RpWriteError> {
    if !is_path_safe_name(name) {
        return Err(RpWriteError::InvalidName(name.to_owned()));
    }
    let kind = match source {
        RpSourceSpec::Http { url, interval_ms } => {
            let url = url.trim();
            if !url.starts_with("http://") && !url.starts_with("https://") {
                return Err(RpWriteError::InvalidUrl(format!(
                    "URL must start with `http://` or `https://` (got `{url}`)"
                )));
            }
            RuleProviderSourceConfig::Http {
                url: url.to_owned(),
                interval_ms: *interval_ms,
            }
        }
        RpSourceSpec::File { path } => RuleProviderSourceConfig::File {
            path: path.display().to_string(),
        },
        RpSourceSpec::Inline { payload } => RuleProviderSourceConfig::Inline {
            payload: payload.clone(),
        },
    };
    Ok(RuleProviderConfig {
        name: name.to_owned(),
        kind,
        behavior: behavior.to_schema(),
        format: RuleProviderFormatConfig::Source,
        enabled: true,
    })
}

/// `set rule-provider add-http|add-file|add-inline`.
///
/// Default: dry-run. `--apply` is the only thing that
/// actually mutates `config.yaml`.
pub fn add_provider(
    paths: &AppPaths,
    name: &str,
    source: &RpSourceSpec,
    behavior: RpBehavior,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    let entry = build_config(name, source, behavior)?;
    if !apply {
        return Ok(RpWriteOutcome::DryRun);
    }
    let path = config_yaml_path(paths);
    backup_config_yaml(&path)?;
    mutate_yaml_key::<RuleProviderConfig, _>(&path, "rule_providers", |current| {
        if current.iter().any(|p| p.name == entry.name) {
            return Err(ConfigWriteError::Mutator(format!(
                "rule provider `{}` is already declared",
                entry.name
            )));
        }
        let mut next = current.to_vec();
        next.push(entry);
        Ok(next)
    })?;
    Ok(RpWriteOutcome::Applied)
}

/// `set rule-provider remove` — filters the
/// `rule_providers:` list by name. Returns
/// `RpWriteError::NotDeclared` if the name is not in the
/// list.
pub fn remove_provider(
    paths: &AppPaths,
    name: &str,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    if !is_path_safe_name(name) {
        return Err(RpWriteError::InvalidName(name.to_owned()));
    }
    if !apply {
        // Round 15: dry-run still validates the name shape
        // and the existing-list lookup, but never touches
        // disk.
        return Ok(RpWriteOutcome::DryRun);
    }
    let path = config_yaml_path(paths);
    backup_config_yaml(&path)?;
    mutate_yaml_key::<RuleProviderConfig, _>(&path, "rule_providers", |current| {
        if !current.iter().any(|p| p.name == name) {
            return Err(ConfigWriteError::Mutator(format!(
                "rule provider `{name}` is not declared"
            )));
        }
        let target = name.to_owned();
        Ok(current.iter().filter(|p| p.name != target).cloned().collect())
    })?;
    Ok(RpWriteOutcome::Applied)
}

/// `set rule-provider enable|disable` — flips the
/// `enabled` flag. The schema default is `enabled: true`
/// (Round 15 added the field), so `enable` is a no-op
/// for a fresh entry and `disable` is the meaningful
/// state transition.
pub fn set_enabled(
    paths: &AppPaths,
    name: &str,
    enabled: bool,
    apply: bool,
) -> Result<RpWriteOutcome, RpWriteError> {
    if !is_path_safe_name(name) {
        return Err(RpWriteError::InvalidName(name.to_owned()));
    }
    if !apply {
        return Ok(RpWriteOutcome::DryRun);
    }
    let path = config_yaml_path(paths);
    backup_config_yaml(&path)?;
    mutate_yaml_key::<RuleProviderConfig, _>(&path, "rule_providers", |current| {
        if !current.iter().any(|p| p.name == name) {
            return Err(ConfigWriteError::Mutator(format!(
                "rule provider `{name}` is not declared"
            )));
        }
        let target = name.to_owned();
        let next: Vec<RuleProviderConfig> = current
            .iter()
            .map(|p| {
                let mut p = p.clone();
                if p.name == target {
                    p.enabled = enabled;
                }
                p
            })
            .collect();
        Ok(next)
    })?;
    Ok(RpWriteOutcome::Applied)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::ffi::OsString;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn temp_root(name: &str) -> PathBuf {
        static COUNTER: AtomicUsize = AtomicUsize::new(0);
        let n = COUNTER.fetch_add(1, Ordering::Relaxed);
        let pid = std::process::id();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos());
        let path = std::env::temp_dir().join(format!("caly-rp-{name}-{pid}-{n}-{nanos}"));
        fs::create_dir_all(&path).unwrap_or_else(|_| std::process::abort());
        path
    }

    fn seed_at_roots(dir: &std::path::Path) -> AppPaths {
        let env = |key: &str| -> Option<OsString> {
            match key {
                "HOME" => Some(OsString::from("/home/test")),
                "XDG_RUNTIME_DIR" => Some(OsString::from("/run/user/1000")),
                "XDG_STATE_HOME" => Some(OsString::from(dir.as_os_str())),
                "XDG_CONFIG_HOME" => Some(OsString::from(dir.as_os_str())),
                _ => None,
            }
        };
        let paths = AppPaths::from_env_vars(&env);
        let target = paths.config.join("config.yaml");
        fs::create_dir_all(&paths.config).unwrap_or_else(|_| std::process::abort());
        fs::write(
            &target,
            "schema_version: 1\ncore: mihomo\nrule_providers: []\n",
        )
        .unwrap_or_else(|_| std::process::abort());
        paths
    }

    /// `&'static Vec<serde_norway::Value>` placeholder for
    /// the test assertions (see `config_writer` tests for
    /// the same pattern). The `static` inside the helper
    /// gives the borrow checker its `&'static` lifetime.
    #[allow(dead_code)] // reserved for future round-trip
                       // tests; the current 9 tests don't
                       // need a fallback.
    fn empty_seq() -> &'static Vec<serde_norway::Value> {
        static EMPTY: Vec<serde_norway::Value> = Vec::new();
        &EMPTY
    }

    #[test]
    fn add_http_dry_run_does_not_touch_disk() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let outcome = add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/geoip-cn".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            false,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::DryRun);
        let expected = "schema_version: 1\ncore: mihomo\nrule_providers: []\n";
        let after = std::fs::read_to_string(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(after, expected);
    }

    #[test]
    fn add_http_apply_persists_a_new_provider() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let outcome = add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/geoip-cn".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::DomainSuffix,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(providers.len(), 1);
        assert_eq!(
            providers[0].get("name").and_then(|v| v.as_str()),
            Some("geoip-cn")
        );
        assert_eq!(
            providers[0].get("type").and_then(|v| v.as_str()),
            Some("http")
        );
        assert_eq!(
            providers[0].get("behavior").and_then(|v| v.as_str()),
            Some("domain_suffix")
        );
        // The default `enabled: true` is preserved.
        assert_eq!(
            providers[0].get("enabled").and_then(serde_norway::Value::as_bool),
            Some(true)
        );
        // A backup sidecar must exist.
        let backup = paths.config.join("config.yaml.bak");
        assert!(backup.exists(), "backup sidecar must be written");
    }

    #[test]
    fn add_inline_apply_writes_an_inline_provider() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let outcome = add_provider(
            &paths,
            "local-rules",
            &RpSourceSpec::Inline {
                payload: "DOMAIN,example.com,auto\n".to_owned(),
            },
            RpBehavior::Classical,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(providers.len(), 1);
        assert_eq!(
            providers[0].get("type").and_then(|v| v.as_str()),
            Some("inline")
        );
    }

    #[test]
    fn add_provider_rejects_duplicate_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/geoip-cn".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        let result = add_provider(
            &paths,
            "geoip-cn",
            &RpSourceSpec::Http {
                url: "https://example.com/other".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        );
        assert!(matches!(result, Err(RpWriteError::Write(_))));
    }

    #[test]
    fn add_provider_rejects_unsafe_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let result = add_provider(
            &paths,
            "../escape",
            &RpSourceSpec::Http {
                url: "https://example.com/x".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        );
        assert!(matches!(result, Err(RpWriteError::InvalidName(_))));
    }

    #[test]
    fn add_provider_rejects_non_http_url() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let result = add_provider(
            &paths,
            "x",
            &RpSourceSpec::Http {
                url: "file:///etc/passwd".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        );
        assert!(matches!(result, Err(RpWriteError::InvalidUrl(_))));
    }

    #[test]
    fn remove_provider_filters_a_matching_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        add_provider(
            &paths,
            "a",
            &RpSourceSpec::Http {
                url: "https://example.com/a".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        add_provider(
            &paths,
            "b",
            &RpSourceSpec::Http {
                url: "https://example.com/b".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        let outcome = remove_provider(&paths, "a", true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(providers.len(), 1);
        assert_eq!(
            providers[0].get("name").and_then(|v| v.as_str()),
            Some("b")
        );
    }

    #[test]
    fn remove_provider_rejects_unknown_name() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        let result = remove_provider(&paths, "nope", true);
        assert!(matches!(result, Err(RpWriteError::Write(_))));
    }

    #[test]
    fn set_enabled_flips_the_flag() {
        let dir = temp_root("__FUNC__");
        let paths = seed_at_roots(dir.as_path());
        add_provider(
            &paths,
            "a",
            &RpSourceSpec::Http {
                url: "https://example.com/a".to_owned(),
                interval_ms: 86_400_000,
            },
            RpBehavior::Domain,
            true,
        )
        .unwrap_or_else(|_| std::process::abort());
        let outcome =
            set_enabled(&paths, "a", false, true).unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, RpWriteOutcome::Applied);
        let bytes = std::fs::read(paths.config.join("config.yaml"))
            .unwrap_or_else(|_| std::process::abort());
        let value: serde_norway::Value =
            serde_norway::from_slice(&bytes).unwrap_or_else(|_| std::process::abort());
        let Some(providers) = value.get("rule_providers").and_then(|v| v.as_sequence()) else { std::process::abort(); };
        assert_eq!(
            providers[0].get("enabled").and_then(serde_norway::Value::as_bool),
            Some(false)
        );
    }
}
