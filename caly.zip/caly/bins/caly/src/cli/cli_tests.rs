//! Declarative CLI mapping tests for Round 11 5-namespace grammar.
//!
//! Each namespace (`daemon` / `tool` / `show` / `set`) and every new
//! capability introduced in Round 11 has a parse-level assertion here
//! so that the grammar stays locked against accidental drift.

use super::*;

fn parse(values: &[&str]) -> Invocation {
    match parse_args(values.iter().map(|value| (*value).to_owned())) {
        Ok(invocation) => invocation,
        Err(error) => {
            eprintln!("parse failed for {values:?}: {error}");
            std::process::abort()
        }
    }
}

fn parse_err(values: &[&str]) -> clap::Error {
    match parse_args(values.iter().map(|value| (*value).to_owned())) {
        Ok(_) => {
            eprintln!("expected parse failure for {values:?}");
            std::process::abort()
        }
        Err(error) => error,
    }
}

// ── Global options ──────────────────────────────────────────────

#[test]
fn global_options_are_mapped_to_all_namespaces() {
    let invocation = parse(&["--json", "show", "status"]);
    assert!(invocation.options.json);
    assert_eq!(invocation.command, Command::Show(ShowCmd::Status));

    let invocation = parse(&["--core", "mihomo", "show", "core", "nodes"]);
    assert_eq!(invocation.options.core.as_deref(), Some("mihomo"));
    assert_eq!(
        invocation.command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );

    let invocation = parse(&[
        "daemon",
        "--mihomo-bin=/opt/mihomo",
        "--sing-box-bin",
        "/opt/sing-box",
    ]);
    assert_eq!(invocation.command, Command::Daemon);
    assert_eq!(
        invocation.options.mihomo_bin,
        Some(PathBuf::from("/opt/mihomo"))
    );
    assert_eq!(
        invocation.options.sing_box_bin,
        Some(PathBuf::from("/opt/sing-box"))
    );
}

// ── tool namespace (5 leaves) ──────────────────────────────────

#[test]
fn tool_namespace_parses_all_five_leaves() {
    assert_eq!(
        parse(&["tool", "help"]).command,
        Command::Tool(ToolCmd::Help(None))
    );
    assert_eq!(
        parse(&["tool", "help", "set"]).command,
        Command::Tool(ToolCmd::Help(Some("set".to_owned())))
    );
    assert_eq!(
        parse(&["tool", "version"]).command,
        Command::Tool(ToolCmd::Version)
    );
    assert_eq!(
        parse(&["tool", "doctor"]).command,
        Command::Tool(ToolCmd::Doctor { fix: false })
    );
    assert_eq!(
        parse(&["tool", "doctor", "--fix"]).command,
        Command::Tool(ToolCmd::Doctor { fix: true })
    );
    assert_eq!(
        parse(&["tool", "tui"]).command,
        Command::Tool(ToolCmd::Tui { readonly: false })
    );
    assert_eq!(
        parse(&["tool", "tui", "--readonly"]).command,
        Command::Tool(ToolCmd::Tui { readonly: true })
    );
    assert_eq!(
        parse(&["tool", "dns", "example.com"]).command,
        Command::Tool(ToolCmd::Dns(Some("example.com".to_owned())))
    );
    assert_eq!(
        parse(&["tool", "dns"]).command,
        Command::Tool(ToolCmd::Dns(None))
    );
}

// ── show namespace (6 resources) ───────────────────────────────

#[test]
fn show_status_is_a_top_level_subcommand() {
    assert_eq!(
        parse(&["show", "status"]).command,
        Command::Show(ShowCmd::Status)
    );
}

#[test]
fn show_core_parses_seven_leaves() {
    assert_eq!(
        parse(&["show", "core", "nodes"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Nodes))
    );
    assert_eq!(
        parse(&["show", "core", "groups"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Groups))
    );
    assert_eq!(
        parse(&["show", "core", "connections"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Connections))
    );
    assert_eq!(
        parse(&["show", "core", "traffic"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Traffic))
    );
    assert_eq!(
        parse(&["show", "core", "mode"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Mode))
    );
    assert_eq!(
        parse(&["show", "core", "rules"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Rules { r#match: None }))
    );
    assert_eq!(
        parse(&["show", "core", "rules", "--match", "example.com"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Rules {
            r#match: Some("example.com".to_owned())
        }))
    );
    // New Round 11 capability: `show core health`
    assert_eq!(
        parse(&["show", "core", "health"]).command,
        Command::Show(ShowCmd::Core(ShowCoreCmd::Health))
    );
}

#[test]
fn show_sub_parses_three_leaves_including_renamed_parse() {
    assert_eq!(
        parse(&["show", "sub", "providers"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Providers))
    );
    assert_eq!(
        parse(&["show", "sub", "parse", "/tmp/sub.txt"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Parse {
            path: PathBuf::from("/tmp/sub.txt"),
            userinfo: None,
        }))
    );
    assert_eq!(
        parse(&["show", "sub", "parse", "/tmp/sub.txt", "--userinfo", "u=100"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Parse {
            path: PathBuf::from("/tmp/sub.txt"),
            userinfo: Some("u=100".to_owned()),
        }))
    );
    assert_eq!(
        parse(&["show", "sub", "import"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Import {
            path: None,
            clipboard: false,
        }))
    );
    assert_eq!(
        parse(&["show", "sub", "import", "--clipboard"]).command,
        Command::Show(ShowCmd::Sub(ShowSubCmd::Import {
            path: None,
            clipboard: true,
        }))
    );
}

#[test]
fn show_profile_parses_list_and_show() {
    assert_eq!(
        parse(&["show", "profile", "list"]).command,
        Command::Show(ShowCmd::Profile(ShowProfileCmd::List))
    );
    assert_eq!(
        parse(&["show", "profile", "show", "team"]).command,
        Command::Show(ShowCmd::Profile(ShowProfileCmd::Show {
            id: "team".to_owned()
        }))
    );
}

#[test]
fn show_proxy_parses_three_leaves() {
    assert_eq!(
        parse(&["show", "proxy", "list"]).command,
        Command::Show(ShowCmd::Proxy(ShowProxyCmd::List))
    );
    assert_eq!(
        parse(&["show", "proxy", "show", "abc"]).command,
        Command::Show(ShowCmd::Proxy(ShowProxyCmd::Show {
            id: "abc".to_owned()
        }))
    );
    assert_eq!(
        parse(&["show", "proxy", "groups"]).command,
        Command::Show(ShowCmd::Proxy(ShowProxyCmd::Groups))
    );
}

#[test]
fn show_config_parses_three_leaves() {
    assert_eq!(
        parse(&["show", "config", "path"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Path))
    );
    assert_eq!(
        parse(&["show", "config", "files"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Files))
    );
    assert_eq!(
        parse(&["show", "config", "validate"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Validate { file: None }))
    );
    assert_eq!(
        parse(&["show", "config", "validate", "--file", "/tmp/x.yaml"]).command,
        Command::Show(ShowCmd::Config(ShowConfigCmd::Validate {
            file: Some(PathBuf::from("/tmp/x.yaml")),
        }))
    );
}

// ── set namespace (7 resources) ────────────────────────────────

#[test]
fn set_core_parses_eight_leaves_including_url_test() {
    assert_eq!(
        parse(&["set", "core", "start"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Start))
    );
    assert_eq!(
        parse(&["set", "core", "stop"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Stop))
    );
    assert_eq!(
        parse(&["set", "core", "restart"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Restart))
    );
    assert_eq!(
        parse(&["set", "core", "switch", "mihomo"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Switch("mihomo".to_owned())))
    );
    assert_eq!(
        parse(&["set", "core", "switch", "sing-box"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Switch("sing-box".to_owned())))
    );
    assert_eq!(
        parse(&["set", "core", "select"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: None,
            delay: false,
            group: None,
        }))
    );
    assert_eq!(
        parse(&["set", "core", "select", "node1", "--delay"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: Some("node1".to_owned()),
            delay: true,
            group: None,
        }))
    );
    // New Round 11 capability: `--group` on select
    assert_eq!(
        parse(&["set", "core", "select", "--group", "Auto"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: None,
            delay: false,
            group: Some("Auto".to_owned()),
        }))
    );
    assert_eq!(
        parse(&["set", "core", "select", "node1", "--group", "Auto"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Select {
            node: Some("node1".to_owned()),
            delay: false,
            group: Some("Auto".to_owned()),
        }))
    );
    assert_eq!(
        parse(&["set", "core", "mode", "global"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Mode("global".to_owned())))
    );
    assert_eq!(
        parse(&["set", "core", "close-connections"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::CloseConnections))
    );
    assert_eq!(
        parse(&["set", "core", "delay", "--all"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name: None,
            all: true,
            url: None,
            samples: None,
        }))
    );
    // New Round 11 capability: `set core url-test`
    assert_eq!(
        parse(&["set", "core", "url-test", "node1"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "node1".to_owned(),
            url: None,
            timeout: None,
            samples: None,
        }))
    );
    assert_eq!(
        parse(&[
            "set", "core", "url-test", "node1", "--url", "http://g", "--timeout", "3000"
        ])
        .command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "node1".to_owned(),
            url: Some("http://g".to_owned()),
            timeout: Some(3000),
            samples: None,
        }))
    );
}

#[test]
fn set_core_delay_samples_flag_is_optional_and_parses() {
    // Round 20: `--samples N` lets the operator
    // pick the per-URL sample count for jitter-
    // sensitive probes. The default (None) is
    // resolved at the dispatch boundary; the
    // CLI just preserves whatever the user passed.
    assert_eq!(
        parse(&["set", "core", "delay", "node1", "--samples", "1"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name: Some("node1".to_owned()),
            all: false,
            url: None,
            samples: Some(1),
        }))
    );
    assert_eq!(
        parse(&["set", "core", "delay", "--all", "--samples", "5"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::Delay {
            name: None,
            all: true,
            url: None,
            samples: Some(5),
        }))
    );
    assert_eq!(
        parse(&["set", "core", "url-test", "node1", "--samples", "3"]).command,
        Command::Set(SetCmd::Core(SetCoreCmd::UrlTest {
            name: "node1".to_owned(),
            url: None,
            timeout: None,
            samples: Some(3),
        }))
    );
}

#[test]
fn set_proxy_parses_four_crud_leaves_plus_on_off() {
    // New Round 11 capabilities: add / edit / remove / import
    assert_eq!(
        parse(&["set", "proxy", "add", "ss://abc"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add {
            uri: "ss://abc".to_owned(),
            group: None,
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy", "add", "ss://abc", "--group", "G", "--apply"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add {
            uri: "ss://abc".to_owned(),
            group: Some("G".to_owned()),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy", "edit", "id1", "--apply"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Edit {
            id: "id1".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy", "remove", "id1"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Remove {
            id: "id1".to_owned(),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "proxy", "import", "/tmp/uri.list", "--apply"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Import {
            path: PathBuf::from("/tmp/uri.list"),
            apply: true,
            dry_run: false,
        }))
    );
    // Old `set sys proxy on/off` is now `set proxy on/off`
    assert_eq!(
        parse(&["set", "proxy", "on"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::On))
    );
    assert_eq!(
        parse(&["set", "proxy", "off"]).command,
        Command::Set(SetCmd::Proxy(SetProxyCmd::Off))
    );
}

#[test]
fn set_tun_parses_on_off() {
    assert_eq!(
        parse(&["set", "tun", "on"]).command,
        Command::Set(SetCmd::Tun(true))
    );
    assert_eq!(
        parse(&["set", "tun", "off"]).command,
        Command::Set(SetCmd::Tun(false))
    );
}

#[test]
fn set_sub_parses_five_crud_leaves() {
    assert_eq!(
        parse(&["set", "sub", "refresh"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Refresh))
    );
    assert_eq!(
        parse(&["set", "sub", "add", "https://x"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Add {
            url: "https://x".to_owned(),
            name: None,
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "add", "https://x", "--name", "team", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Add {
            url: "https://x".to_owned(),
            name: Some("team".to_owned()),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "remove", "https://x", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Remove {
            url: "https://x".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "enable", "https://x", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Enable {
            url: "https://x".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "disable", "https://x", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Disable {
            url: "https://x".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "sub", "import", "/tmp/u", "--clipboard", "--apply"]).command,
        Command::Set(SetCmd::Sub(SetSubCmd::Import {
            path: Some(PathBuf::from("/tmp/u")),
            clipboard: true,
            apply: true,
            dry_run: false,
        }))
    );
}

#[test]
fn set_profile_parses_seven_leaves() {
    assert_eq!(
        parse(&["set", "profile", "add", "team", "remote:https://x"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Add {
            id: "team".to_owned(),
            source: "remote:https://x".to_owned(),
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "remove", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Remove {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    // New Round 11: edit / export / enable / disable
    assert_eq!(
        parse(&["set", "profile", "edit", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Edit {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "export", "team", "--out", "/tmp/p.yaml"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Export {
            id: "team".to_owned(),
            out: PathBuf::from("/tmp/p.yaml"),
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "enable", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Enable {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "profile", "disable", "team", "--apply"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Disable {
            id: "team".to_owned(),
            apply: true,
            dry_run: false,
        }))
    );
    // Refresh stays (was Round 10); now under `set` namespace.
    // Round 12: refresh always writes (the body IS the cache),
    // so `--apply` / `--dry-run` flags are not accepted.
    assert_eq!(
        parse(&["set", "profile", "refresh"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Refresh { id: None }))
    );
    assert_eq!(
        parse(&["set", "profile", "refresh", "team"]).command,
        Command::Set(SetCmd::Profile(SetProfileCmd::Refresh {
            id: Some("team".to_owned())
        }))
    );
}

#[test]
fn set_profile_refresh_rejects_apply_and_dry_run_flags() {
    // Round 12: refresh always writes. A `--apply` / `--dry-run`
    // flag is rejected at parse time, not silently coerced
    // (the previous behavior was a no-op that confused
    // operators about whether a refresh actually wrote).
    for removed in [
        vec!["set", "profile", "refresh", "--apply"],
        vec!["set", "profile", "refresh", "--dry-run"],
        vec!["set", "profile", "refresh", "team", "--apply"],
    ] {
        let result = parse_args(removed.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected refresh flag to be rejected: {removed:?}"
        );
    }
}

#[test]
fn set_config_parses_six_leaves_including_diff() {
    assert_eq!(
        parse(&["set", "config", "apply"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Apply))
    );
    assert_eq!(
        parse(&["set", "config", "generate"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Generate))
    );
    assert_eq!(
        parse(&["set", "config", "default"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Default))
    );
    // New Round 11 capability: `set config diff`
    assert_eq!(
        parse(&["set", "config", "diff"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Diff { file: None }))
    );
    assert_eq!(
        parse(&["set", "config", "diff", "--file", "/tmp/c.yaml"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Diff {
            file: Some(PathBuf::from("/tmp/c.yaml")),
        }))
    );
    assert_eq!(
        parse(&["set", "config", "edit", "vim"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Edit(Editor::Vim)))
    );
    assert_eq!(
        parse(&["set", "config", "edit", "nvim"]).command,
        Command::Set(SetCmd::Config(SetConfigCmd::Edit(Editor::Nvim)))
    );
}

#[test]
fn set_daemon_parses_four_lifecycle_leaves() {
    // New Round 11 capability: `set daemon stop/reload/restart/status`
    assert_eq!(
        parse(&["set", "daemon", "stop"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Stop))
    );
    assert_eq!(
        parse(&["set", "daemon", "reload"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Reload))
    );
    assert_eq!(
        parse(&["set", "daemon", "restart"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Restart))
    );
    assert_eq!(
        parse(&["set", "daemon", "status"]).command,
        Command::Set(SetCmd::Daemon(SetDaemonCmd::Status))
    );
}

#[test]
fn set_rule_provider_parses_six_leaves() {
    // Round 12: declarative CRUD for `rule_providers:`. The
    // grammar uses three sub-commands (`add-http` /
    // `add-file` / `add-inline`) so each source kind has its
    // own typed argument shape (no `kind <KIND> <body>` slot).
    use crate::cli::RuleProviderSourceSpec;
    assert_eq!(
        parse(&["set", "rule-provider", "add-http", "geosite-cn", "https://x/y"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Add {
            name: "geosite-cn".to_owned(),
            source: RuleProviderSourceSpec::Http { url: "https://x/y".to_owned(), interval_ms: 86_400_000 },
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "add-file", "adblock", "/etc/r.yaml"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Add {
            name: "adblock".to_owned(),
            source: RuleProviderSourceSpec::File { path: PathBuf::from("/etc/r.yaml") },
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "add-inline", "small", "--payload", "a\nb"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Add {
            name: "small".to_owned(),
            source: RuleProviderSourceSpec::Inline { payload: "a\nb".to_owned() },
            apply: false,
            dry_run: false,
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "remove", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Remove { name: "geosite-cn".to_owned(), apply: false, dry_run: false }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "enable", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Enable { name: "geosite-cn".to_owned(), apply: false, dry_run: false }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "disable", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Disable { name: "geosite-cn".to_owned(), apply: false, dry_run: false }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "refresh"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Refresh { name: None }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "refresh", "geosite-cn"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::Refresh {
            name: Some("geosite-cn".to_owned())
        }))
    );
    assert_eq!(
        parse(&["set", "rule-provider", "list"]).command,
        Command::Set(SetCmd::RuleProvider(SetRuleProviderCmd::List))
    );
}

#[test]
fn set_rule_provider_dry_run_policy_matches_sibling_resources() {
    // The CRUD leaves take the same `--apply` / `--dry-run`
    // policy as the other `set` resources: default dry-run,
    // `--apply` writes, the two flags are mutually exclusive.
    for args in [
        vec!["set", "rule-provider", "add-http", "n", "https://x", "--apply"],
        vec!["set", "rule-provider", "add-file", "n", "/etc/r", "--apply"],
        vec!["set", "rule-provider", "add-inline", "n", "--payload", "x", "--apply"],
        vec!["set", "rule-provider", "remove", "n", "--apply"],
        vec!["set", "rule-provider", "enable", "n", "--apply"],
        vec!["set", "rule-provider", "disable", "n", "--apply"],
    ] {
        let result = parse_args(args.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_ok(),
            "expected apply leaf to parse: {args:?} -> {result:?}"
        );
    }
    for args in [
        vec!["set", "rule-provider", "remove", "n", "--apply", "--dry-run"],
        vec!["set", "rule-provider", "add-http", "n", "https://x", "--apply", "--dry-run"],
    ] {
        let result = parse_args(args.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected conflict to be rejected: {args:?}"
        );
    }
}

#[test]
fn set_rule_provider_refresh_rejects_apply_and_dry_run_flags() {
    // Like `set profile refresh`, this leaf always writes.
    // A `--apply` / `--dry-run` flag is rejected at parse time.
    for removed in [
        vec!["set", "rule-provider", "refresh", "--apply"],
        vec!["set", "rule-provider", "refresh", "--dry-run"],
    ] {
        let result = parse_args(removed.iter().map(|s| (*s).to_owned()));
        assert!(
            result.is_err(),
            "expected refresh flag to be rejected: {removed:?}"
        );
    }
}

// ── Dry-run semantics ──────────────────────────────────────────

fn expect_set_proxy_add(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Proxy(SetProxyCmd::Add { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            eprintln!("expected set proxy add, got {other:?}");
            std::process::abort()
        }
    }
}

fn expect_set_proxy_remove(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Proxy(SetProxyCmd::Remove { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            eprintln!("expected set proxy remove, got {other:?}");
            std::process::abort()
        }
    }
}

fn expect_set_proxy_import(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Proxy(SetProxyCmd::Import { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            eprintln!("expected set proxy import, got {other:?}");
            std::process::abort()
        }
    }
}

fn expect_set_sub_add(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Sub(SetSubCmd::Add { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            eprintln!("expected set sub add, got {other:?}");
            std::process::abort()
        }
    }
}

fn expect_set_sub_remove(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Sub(SetSubCmd::Remove { apply, dry_run, .. })) => (apply, dry_run),
        other => {
            eprintln!("expected set sub remove, got {other:?}");
            std::process::abort()
        }
    }
}

fn expect_set_profile_remove(command: Command) -> (bool, bool) {
    match command {
        Command::Set(SetCmd::Profile(SetProfileCmd::Remove { apply, dry_run, .. })) =>
            (apply, dry_run),
        other => {
            eprintln!("expected set profile remove, got {other:?}");
            std::process::abort()
        }
    }
}

#[test]
fn dry_run_defaults_to_false_on_writes() {
    // Every write command should default to `apply: false, dry_run: false`
    // per the Round 11 spec (dry-run is the SAFE default; the user must
    // explicitly opt in to writing by adding `--apply`).
    let (apply, dry_run) = expect_set_proxy_add(parse(&["set", "proxy", "add", "ss://abc"]).command);
    assert!(!apply);
    assert!(!dry_run);

    let (apply, dry_run) = expect_set_proxy_remove(parse(&["set", "proxy", "remove", "id1"]).command);
    assert!(!apply);
    assert!(!dry_run);

    let (apply, dry_run) = expect_set_proxy_import(parse(&["set", "proxy", "import", "/tmp/u"]).command);
    assert!(!apply);
    assert!(!dry_run);

    let (apply, dry_run) = expect_set_sub_add(parse(&["set", "sub", "add", "https://x"]).command);
    assert!(!apply);
    assert!(!dry_run);
}

#[test]
fn apply_flag_sets_apply_true() {
    let (apply, dry_run) = expect_set_proxy_add(
        parse(&["set", "proxy", "add", "ss://abc", "--apply"]).command,
    );
    assert!(apply);
    assert!(!dry_run);

    let (apply, dry_run) = expect_set_sub_remove(
        parse(&["set", "sub", "remove", "https://x", "--apply"]).command,
    );
    assert!(apply);
    assert!(!dry_run);

    let (apply, dry_run) = expect_set_profile_remove(
        parse(&["set", "profile", "remove", "team", "--apply"]).command,
    );
    assert!(apply);
    assert!(!dry_run);
}

#[test]
fn dry_run_flag_is_still_accepted_explicitly() {
    // Round 10 had --dry-run as the opt-in. Round 11 makes it the default
    // via `--apply`, but the legacy `--dry-run` flag must still parse and
    // be honored for backwards compatibility.
    let (apply, dry_run) = expect_set_proxy_remove(
        parse(&["set", "proxy", "remove", "id1", "--dry-run"]).command,
    );
    assert!(!apply);
    assert!(dry_run);

    let (apply, dry_run) = expect_set_sub_add(
        parse(&["set", "sub", "add", "https://x", "--dry-run"]).command,
    );
    assert!(!apply);
    assert!(dry_run);
}

#[test]
fn apply_and_dry_run_must_not_both_be_true() {
    // Clap should reject the contradictory combination; a parse error
    // is the expected outcome.
    let err = parse_err(&["set", "proxy", "add", "ss://abc", "--apply", "--dry-run"]);
    let message = err.to_string();
    assert!(
        message.contains("cannot be used with") || message.contains("conflict"),
        "expected conflict error, got: {message}"
    );
}

// ── Removed old spellings are rejected ─────────────────────────

#[test]
fn old_top_level_spellings_are_rejected() {
    for removed in [
        vec!["core".to_owned(), "start".to_owned()],
        vec!["core".to_owned(), "stop".to_owned()],
        vec!["core".to_owned(), "restart".to_owned()],
        vec!["core".to_owned(), "mode".to_owned(), "rule".to_owned()],
        vec!["core".to_owned(), "switch".to_owned(), "mihomo".to_owned()],
        vec!["sub".to_owned(), "list".to_owned()],
        vec!["sub".to_owned(), "refresh".to_owned()],
        vec!["sub".to_owned(), "check".to_owned(), "/tmp/x".to_owned()],
        vec!["sub".to_owned(), "import".to_owned(), "/tmp/x".to_owned()],
        vec!["sys".to_owned(), "tun".to_owned(), "on".to_owned()],
        vec!["sys".to_owned(), "proxy".to_owned(), "off".to_owned()],
        vec!["profile".to_owned(), "list".to_owned()],
        vec!["profile".to_owned(), "show".to_owned(), "team".to_owned()],
        vec!["profile".to_owned(), "add".to_owned(), "x".to_owned(), "remote:y".to_owned()],
        vec!["config".to_owned(), "apply".to_owned()],
        vec!["config".to_owned(), "generate".to_owned()],
        vec!["config".to_owned(), "default".to_owned()],
        vec!["config".to_owned(), "check".to_owned(), "/tmp/x".to_owned()],
        vec!["config".to_owned(), "vim".to_owned()],
        vec!["status".to_owned()],
        vec!["doctor".to_owned()],
        vec!["tui".to_owned()],
        vec!["dns".to_owned(), "example.com".to_owned()],
        vec!["help".to_owned()],
        vec!["version".to_owned()],
    ] {
        assert!(
            parse_args(removed.clone()).is_err(),
            "expected removed top-level spelling to be rejected: {removed:?}"
        );
    }
}

#[test]
fn old_short_flag_aliases_are_rejected() {
    for removed in [
        vec!["-t".to_owned()],
        vec!["-d".to_owned()],
        vec!["-c".to_owned(), "start".to_owned()],
        vec!["-s".to_owned(), "refresh".to_owned()],
        vec!["-p".to_owned(), "proxy".to_owned(), "on".to_owned()],
    ] {
        assert!(
            parse_args(removed.clone()).is_err(),
            "expected removed short flag to be rejected: {removed:?}"
        );
    }
}

// ── Completions (top-level) ────────────────────────────────────

#[test]
fn completions_stays_as_a_top_level_subcommand() {
    assert_eq!(
        parse(&["completions", "zsh"]).command,
        Command::Completions(CompletionShell::Zsh)
    );
    assert_eq!(
        parse(&["completions", "bash"]).command,
        Command::Completions(CompletionShell::Bash)
    );
    assert_eq!(
        parse(&["completions", "fish"]).command,
        Command::Completions(CompletionShell::Fish)
    );
    assert_eq!(
        parse(&["completions", "elvish"]).command,
        Command::Completions(CompletionShell::Elvish)
    );
    assert_eq!(
        parse(&["completions", "powershell"]).command,
        Command::Completions(CompletionShell::PowerShell)
    );
}

// ── Help-text contract ─────────────────────────────────────────

#[test]
fn top_level_help_lists_all_four_namespaces() {
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let mut buffer = Vec::new();
    cmd.write_long_help(&mut buffer).unwrap_or_else(|error| {
        eprintln!("help render failed: {error}");
        std::process::abort()
    });
    let text = String::from_utf8(buffer).unwrap_or_else(|error| {
        eprintln!("help text is not UTF-8: {error}");
        std::process::abort()
    });
    assert!(
        text.contains("daemon") && text.contains("tool") && text.contains("show") && text.contains("set"),
        "top-level help must list all 4 namespaces"
    );
    assert!(
        text.contains("Common workflows"),
        "after-help must point at the common workflows section"
    );
    assert!(
        text.contains("caly set sub refresh") || text.contains("cal set sub refresh"),
        "after-help must include an example set command"
    );
    assert!(
        text.contains("--apply"),
        "after-help must mention the --apply flag (Round 11 dry-run policy)"
    );
}

#[test]
fn set_subcommand_help_lists_all_eight_resources() {
    // Round 12: `rule-provider` joined the 7 Round 11 resources
    // (core / proxy / tun / sub / profile / config / daemon).
    // The help text must name all eight so a new operator can
    // discover the third "remote source" resource.
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let Some(set_cmd) = cmd.find_subcommand_mut("set") else {
        eprintln!("set subcommand must exist");
        std::process::abort();
    };
    let mut buffer = Vec::new();
    set_cmd.write_long_help(&mut buffer).unwrap_or_else(|error| {
        eprintln!("help render failed: {error}");
        std::process::abort()
    });
    let text = String::from_utf8(buffer).unwrap_or_else(|error| {
        eprintln!("help text is not UTF-8: {error}");
        std::process::abort()
    });
    for resource in ["core", "proxy", "tun", "sub", "profile", "config", "daemon", "rule-provider"] {
        assert!(
            text.contains(resource),
            "set help must list resource `{resource}`"
        );
    }
}

#[test]
fn show_subcommand_help_lists_all_six_resources() {
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let Some(show_cmd) = cmd.find_subcommand_mut("show") else {
        eprintln!("show subcommand must exist");
        std::process::abort();
    };
    let mut buffer = Vec::new();
    show_cmd.write_long_help(&mut buffer).unwrap_or_else(|error| {
        eprintln!("help render failed: {error}");
        std::process::abort()
    });
    let text = String::from_utf8(buffer).unwrap_or_else(|error| {
        eprintln!("help text is not UTF-8: {error}");
        std::process::abort()
    });
    for resource in ["status", "core", "sub", "profile", "proxy", "config"] {
        assert!(
            text.contains(resource),
            "show help must list resource `{resource}`"
        );
    }
}

#[test]
fn tool_subcommand_help_lists_all_five_leaves() {
    let mut cmd = <grammar::ClapCli as clap::CommandFactory>::command();
    let Some(tool_cmd) = cmd.find_subcommand_mut("tool") else {
        eprintln!("tool subcommand must exist");
        std::process::abort();
    };
    let mut buffer = Vec::new();
    tool_cmd.write_long_help(&mut buffer).unwrap_or_else(|error| {
        eprintln!("help render failed: {error}");
        std::process::abort()
    });
    let text = String::from_utf8(buffer).unwrap_or_else(|error| {
        eprintln!("help text is not UTF-8: {error}");
        std::process::abort()
    });
    for leaf in ["help", "version", "doctor", "tui", "dns"] {
        assert!(
            text.contains(leaf),
            "tool help must list leaf `{leaf}`"
        );
    }
}

// ── CliOptions default works (the original SIGABRT) ────────────

#[test]
fn cli_options_default_is_constructible() {
    // Regression: CliOptions lost its Default derive during the rewrite.
    // Every parse-level test that compares against `CliOptions::default()`
    // depends on this.
    let default = CliOptions::default();
    assert!(default.socket.is_none());
    assert!(!default.json);
    assert!(default.core.is_none());
    assert!(default.mihomo_bin.is_none());
    assert!(default.sing_box_bin.is_none());
}

// ── Round 13: `set` module split + `Refreshable` trait wiring ──

#[test]
fn set_dispatch_routes_to_eight_resource_modules() {
    // Round 13 regression: every `SetCmd` variant must be
    // dispatchable. The 8 resource sub-modules (core /
    // proxy / tun / sub / profile / config / daemon /
    // rule_provider) are the public dispatch surface; the
    // Round 12 monolithic `commands::set` was split into
    // them, and a typo'd `super::super::bridge` path would
    // otherwise only surface in `cargo build`.
    use crate::cli::{
        SetCmd, SetConfigCmd, SetCoreCmd, SetDaemonCmd, SetProfileCmd, SetProxyCmd,
        SetRuleProviderCmd, SetSubCmd,
    };
    use crate::output::CliOutput;

    fn empty_output() -> CliOutput { CliOutput::Human }
    fn empty_options() -> crate::cli::CliOptions { crate::cli::CliOptions::default() }

    let cases: Vec<(&str, SetCmd)> = vec![
        ("set core start", SetCmd::Core(SetCoreCmd::Start)),
        ("set proxy on", SetCmd::Proxy(SetProxyCmd::On)),
        ("set proxy off", SetCmd::Proxy(SetProxyCmd::Off)),
        ("set tun on", SetCmd::Tun(true)),
        ("set tun off", SetCmd::Tun(false)),
        ("set sub refresh", SetCmd::Sub(SetSubCmd::Refresh)),
        ("set sub add https://x", SetCmd::Sub(SetSubCmd::Add {
            url: "https://x".to_owned(), name: None, apply: false, dry_run: false,
        })),
        ("set profile add x remote:y", SetCmd::Profile(SetProfileCmd::Add {
            id: "x".to_owned(), source: "remote:y".to_owned(), apply: false, dry_run: false,
        })),
        ("set config apply", SetCmd::Config(SetConfigCmd::Apply)),
        ("set config diff", SetCmd::Config(SetConfigCmd::Diff { file: None })),
        ("set daemon stop", SetCmd::Daemon(SetDaemonCmd::Stop)),
        ("set rule-provider list", SetCmd::RuleProvider(SetRuleProviderCmd::List)),
        ("set rule-provider refresh", SetCmd::RuleProvider(SetRuleProviderCmd::Refresh { name: None })),
    ];
    for (label, cmd) in cases {
        // The dispatch must not panic on construction; the
        // exit code is `SUCCESS` for `planned_ok` stubs and
        // any failure code for the daemon-routed ones (no
        // daemon running in tests). The point is the path
        // through `set::run` — every variant must reach its
        // resource module.
        let _ = crate::commands::set::run(cmd, empty_options(), empty_output());
        // Suppress the unused `label` warning while keeping
        // it for human inspection if the test ever panics.
        let _ = label;
    }
}

#[test]
fn set_mod_exposes_eight_sub_modules() {
    // Round 13 regression: the `commands::set` module tree
    // must keep all 8 resource sub-modules. Catches
    // accidental deletions of `set/<resource>.rs`. We
    // check by file existence (Rust's module system
    // requires the `mod` declaration to be valid; the
    // existence of each `set/<resource>.rs` source file
    // is what we lock here).
    let set_dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/commands/set");
    for resource in &[
        "common.rs", "config.rs", "core.rs", "daemon.rs", "profile.rs", "proxy.rs",
        "rule_provider.rs", "sub.rs", "tun.rs",
    ] {
        let path = set_dir.join(resource);
        assert!(
            path.is_file(),
            "commands/set/{resource} must exist (Round 13 split: one file per resource)"
        );
    }
}

#[test]
fn refreshable_trait_is_wired_into_set_dispatch() {
    // Round 13: the three `Refreshable` impls are routed
    // through by the corresponding `set <res> refresh`
    // leaves. A failure here means the trait shape slipped
    // and a resource silently bypassed the unified envelope.
    use crate::commands::refresh::Refreshable;
    fn assert_impl<T: Refreshable>() {}
    assert_impl::<crate::commands::refresh::SubscriptionRefresh>();
    assert_impl::<crate::commands::refresh::ProfileRefresh>();
    assert_impl::<crate::commands::refresh::RuleProviderRefresh>();
}
