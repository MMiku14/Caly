//! Declarative CLI mapping tests.

use super::*;

fn parse(values: &[&str]) -> Invocation {
    parse_args(values.iter().map(|value| (*value).to_owned())).unwrap_or_else(|error| {
        eprintln!("parse failed for {values:?}: {error}");
        std::process::abort()
    })
}

#[test]
fn tree_commands_map_to_the_existing_application_model() {
    assert_eq!(
        parse(&["core", "mode", "global", "--core", "sing-box"]),
        Invocation {
            command: Command::Core(CoreCmd::Mode("global".to_owned())),
            options: CliOptions {
                core: Some("sing-box".to_owned()),
                ..CliOptions::default()
            },
        }
    );
    assert_eq!(
        parse(&["sub", "check", "/tmp/sub.txt", "--userinfo", "total=100"]),
        Invocation {
            command: Command::Sub(SubCmd::Check {
                path: PathBuf::from("/tmp/sub.txt"),
                userinfo: Some("total=100".to_owned()),
            }),
            options: CliOptions::default(),
        }
    );
    assert_eq!(
        parse(&["sys", "tun", "on"]),
        Invocation {
            command: Command::Sys(SysCmd::Tun(true)),
            options: CliOptions::default(),
        }
    );
}

#[test]
fn every_capability_has_exactly_one_canonical_spelling() {
    assert_eq!(
        parse(&["core", "start"]).command,
        Command::Core(CoreCmd::Start)
    );
    assert_eq!(
        parse(&["sub", "refresh"]).command,
        Command::Sub(SubCmd::Refresh)
    );
    assert_eq!(
        parse(&["sub", "list"]).command,
        Command::Sub(SubCmd::List)
    );
    assert_eq!(
        parse(&["sys", "proxy", "off"]).command,
        Command::Sys(SysCmd::Proxy(false))
    );
    assert_eq!(
        parse(&["core", "close-connections"]).command,
        Command::Core(CoreCmd::CloseConnections)
    );
    assert_eq!(
        parse(&["core", "list-nodes"]).command,
        Command::Core(CoreCmd::ListNodes)
    );
    assert_eq!(
        parse(&["config", "check", "/tmp/config.yaml"]).command,
        Command::Config(ConfigCmd::Check(PathBuf::from("/tmp/config.yaml")))
    );
    assert_eq!(
        parse(&["config", "generate"]).command,
        Command::Config(ConfigCmd::Generate)
    );
}

#[test]
fn removed_shortcuts_and_dash_aliases_are_rejected() {
    for removed in [
        vec!["start".to_owned()],
        vec!["stop".to_owned()],
        vec!["restart".to_owned()],
        vec!["refresh".to_owned()],
        vec!["proxy".to_owned(), "on".to_owned()],
        vec!["tun".to_owned(), "off".to_owned()],
        vec!["-t".to_owned()],
        vec!["-d".to_owned()],
        vec!["-c".to_owned(), "start".to_owned()],
        vec!["-s".to_owned(), "refresh".to_owned()],
        vec!["-p".to_owned(), "proxy".to_owned(), "on".to_owned()],
        vec!["-g".to_owned(), "path".to_owned()],
        vec!["config-check".to_owned(), "/tmp/x.yaml".to_owned()],
        vec!["config".to_owned(), "-vim".to_owned()],
        vec!["config".to_owned(), "--default".to_owned()],
    ] {
        assert!(
            parse_args(removed.clone()).is_err(),
            "expected removed spelling to be rejected: {removed:?}"
        );
    }
}

#[test]
fn config_flags_and_binary_overrides_are_mapped() {
    assert_eq!(
        parse(&["config", "default"]).command,
        Command::Config(ConfigCmd::Default)
    );
    assert_eq!(
        parse(&["config", "vim"]).command,
        Command::Config(ConfigCmd::Edit(Editor::Vim))
    );
    assert_eq!(
        parse(&["config", "nvim"]).command,
        Command::Config(ConfigCmd::Edit(Editor::Nvim))
    );
    let invocation = parse(&[
        "daemon",
        "--mihomo-bin=/opt/mihomo",
        "--sing-box-bin",
        "/opt/sing-box",
    ]);
    assert_eq!(invocation.command, Command::Daemon);
    assert_eq!(
        invocation.options.mihomo_bin,
        Some(PathBuf::from("/opt/mihomo"))
    );
    assert_eq!(
        invocation.options.sing_box_bin,
        Some(PathBuf::from("/opt/sing-box"))
    );
}

#[test]
fn typed_values_reject_bad_core_mode_and_toggle() {
    assert!(parse_args(["core", "start", "--core", "xray"].map(str::to_owned)).is_err());
    assert!(parse_args(["core", "mode", "invalid"].map(str::to_owned)).is_err());
    assert!(parse_args(["sys", "proxy", "maybe"].map(str::to_owned)).is_err());
}

#[test]
fn select_accepts_both_hex_ids_and_display_names() {
    // A 32-hex ID and a human display name both parse; resolution happens
    // against the daemon snapshot at execution time.
    assert_eq!(
        parse(&["core", "select", "00000000000000000000000000000001"]).command,
        Command::Core(CoreCmd::Select {
            node: Some("00000000000000000000000000000001".to_owned()),
            delay: false,
        })
    );
    assert_eq!(
        parse(&["core", "select", "🇭🇰_HK_中国香港"]).command,
        Command::Core(CoreCmd::Select {
            node: Some("🇭🇰_HK_中国香港".to_owned()),
            delay: false,
        })
    );
}

#[test]
fn completions_are_typed_commands() {
    assert_eq!(
        parse(&["completions", "zsh"]).command,
        Command::Completions(CompletionShell::Zsh)
    );
}
