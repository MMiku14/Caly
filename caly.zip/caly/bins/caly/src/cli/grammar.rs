//! Declarative clap grammar: the single source of truth for syntax, help
//! output and generated shell completions.
//!
//! Kept separate from the parsed command model so both layers stay within the
//! file-size budget; all grammar types are crate-private.

use std::path::PathBuf;

use clap::{Args, Parser, Subcommand, ValueEnum};

use super::CompletionShell;

/// The typed top-level CLI definition. This is the single source of truth for
/// syntax, help output and generated shell completions.
#[derive(Parser, Debug)]
#[command(
    name = "caly",
    version,
    about = "Daemon-first proxy core manager (Mihomo + sing-box)"
)]
#[command(arg_required_else_help = true, disable_help_subcommand = true)]
pub(super) struct ClapCli {
    #[command(flatten)]
    pub(super) global: GlobalOpts,
    #[command(subcommand)]
    pub(super) command: ClapCommand,
}

#[derive(Args, Debug, Clone)]
pub(super) struct GlobalOpts {
    /// UDS socket path (overrides CALY_SOCKET).
    #[arg(long, global = true, value_name = "PATH")]
    pub(super) socket: Option<PathBuf>,
    /// Emit JSON rather than human-readable output.
    #[arg(long, global = true)]
    pub(super) json: bool,
    /// Core target (overrides CALY_CORE).
    #[arg(long, global = true, value_enum, value_name = "CORE")]
    pub(super) core: Option<CoreTarget>,
    /// One-run Mihomo executable override (daemon only).
    #[arg(long, global = true, value_name = "PATH")]
    pub(super) mihomo_bin: Option<PathBuf>,
    /// One-run sing-box executable override (daemon only).
    #[arg(long, global = true, value_name = "PATH")]
    pub(super) sing_box_bin: Option<PathBuf>,
}

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub(super) enum CoreTarget {
    Mihomo,
    #[value(name = "sing-box")]
    SingBox,
}

impl CoreTarget {
    pub(super) const fn as_str(&self) -> &'static str {
        match self {
            Self::Mihomo => "mihomo",
            Self::SingBox => "sing-box",
        }
    }
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapCommand {
    /// Print this help text.
    Help,
    /// Print version information.
    Version,
    /// Run the daemon.
    Daemon,
    /// Show daemon state.
    Status,
    /// Run offline diagnostics.
    Doctor {
        /// Grant missing CAP_NET_ADMIN to ip and core binaries with one sudo prompt.
        #[arg(long)]
        fix: bool,
    },
    /// Run the terminal user interface.
    Tui,
    /// Resolve an optional domain through configured DNS servers.
    Dns { domain: Option<String> },
    /// Core lifecycle and control.
    Core {
        #[command(subcommand)]
        command: ClapCoreCmd,
    },
    /// Subscription control.
    Sub {
        #[command(subcommand)]
        command: ClapSubCmd,
    },
    /// System and platform control.
    Sys {
        #[command(subcommand)]
        command: ClapSysCmd,
    },
    /// Configuration management.
    Config {
        #[command(subcommand)]
        command: ClapConfigCmd,
    },
    /// Generate shell completion scripts to stdout (bash, zsh, fish, elvish, powershell).
    #[command(arg_required_else_help = true)]
    Completions {
        /// Target shell. Redirect stdout to the shell's completion directory.
        shell: CompletionShell,
    },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapCoreCmd {
    /// Start the active core (Start/Restart on another kernel switches to it).
    #[command(alias = "up")]
    Start,
    /// Stop the active core.
    #[command(alias = "down")]
    Stop,
    /// Restart the active core.
    Restart,
    /// Switch the active core between mihomo and sing-box (hot switch).
    Switch {
        /// Target core.
        #[arg(value_enum)]
        core: CoreTarget,
    },
    /// Select a proxy node by ID, display name, or unique prefix.
    #[command(alias = "use")]
    Select {
        /// Node ID or display name; omit with `--delay`.
        node: Option<String>,
        /// Probe every node and select the lowest-latency one (never direct).
        #[arg(long)]
        delay: bool,
    },
    /// Close all active connections.
    #[command(name = "close-connections", alias = "connections", alias = "close")]
    CloseConnections,
    /// Set routing mode.
    Mode { mode: RoutingMode },
    /// List proxy groups and their selection.
    #[command(name = "proxy-groups", alias = "groups")]
    ProxyGroups,
    /// List active connections.
    #[command(name = "list-connections", alias = "conns")]
    ListConnections,
    /// List registered proxy nodes with their IDs.
    #[command(name = "list-nodes", alias = "ls")]
    ListNodes,
    /// Show traffic totals.
    Traffic,
    /// Test latency for a named proxy, or sweep all nodes with `--all`.
    Delay {
        /// Probe every real proxy and print the latency-sorted table.
        #[arg(long)]
        all: bool,
        /// Name of the proxy to test (omit with `--all`).
        name: Option<String>,
        /// Latency probe target URL (default: Google generate_204).
        #[arg(long)]
        url: Option<String>,
    },
    /// List the configured routing rules (offline).
    Rules,
    /// Show which configured rule a host or IP matches (offline diagnostic).
    #[command(name = "rule-match")]
    RuleMatch {
        /// Hostname or IP address to evaluate against the rules.
        target: String,
    },
}

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub(super) enum RoutingMode {
    Rule,
    Global,
    Direct,
}

impl RoutingMode {
    pub(super) const fn as_str(&self) -> &'static str {
        match self {
            Self::Rule => "rule",
            Self::Global => "global",
            Self::Direct => "direct",
        }
    }
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSubCmd {
    /// Refresh all configured subscription sources through the daemon.
    Refresh,
    /// List configured subscription sources (url + enabled state).
    List,
    /// Parse a local subscription file offline and report its nodes.
    Check {
        path: PathBuf,
        /// Optional Subscription-UserInfo header for quota inspection.
        #[arg(long)]
        userinfo: Option<String>,
    },
    /// Import proxy URIs from a file or the clipboard and report the parsed nodes.
    Import {
        /// Subscription file or URI list; defaults to reading the clipboard.
        path: Option<PathBuf>,
        /// Read the node list from the system clipboard (wl-paste / xclip / xsel).
        #[arg(long)]
        clipboard: bool,
    },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSysCmd {
    /// Enable or disable the desktop system proxy.
    Proxy { state: Toggle },
    /// Engage or restore the TUN interface.
    Tun { state: Toggle },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapConfigCmd {
    /// Apply a new configuration generation through the daemon.
    Apply,
    /// Generate a documented default config in the XDG config directory.
    #[command(alias = "init")]
    Generate,
    /// Validate base config, active profile, and config.d fragments.
    Validate,
    /// Validate a single YAML or JSON configuration file.
    Check { path: PathBuf },
    /// Print the active configuration directory.
    Path,
    /// List base, fragment, and profile configuration files.
    Files,
    /// Reset to a default config after moving any existing file to a backup.
    Default,
    /// Open the config directory in Vim.
    Vim,
    /// Open the config directory in Neovim.
    Nvim,
}

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub(super) enum Toggle {
    On,
    Off,
}

impl Toggle {
    pub(super) const fn enabled(&self) -> bool {
        matches!(self, Self::On)
    }
}
