//! Declarative clap grammar: 5-namespace (daemon/tool/show/set) tree.

use std::path::PathBuf;

use clap::{Args, Parser, Subcommand, ValueEnum};

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub enum CompletionShell {
    Bash, Elvish, Fish,
    #[value(name = "powershell")]
    PowerShell, Zsh,
}

#[derive(Parser, Debug)]
#[command(name = "caly", version,
    about = "Daemon-first proxy core manager (Mihomo + sing-box)",
    long_about = "caly manages Mihomo and sing-box through one daemon, with a shared\n\
                 config tree, a profile system, and a typed control plane.\n\
                 Five top-level namespaces: `daemon`, `tool`, `show`, `set`. Use\n\
                 `caly tool help <command>` for per-namespace help.",
    after_help = "Common workflows:\n\
                  \n\
                  \x20 caly tool doctor            # offline diagnostics\n\
                  \x20 caly daemon                # run the control plane\n\
                  \x20 caly show status           # show daemon state\n\
                  \x20 caly set sub refresh       # fetch subscriptions\n\
                  \x20 caly show core nodes       # get node IDs for `set core select`\n\
                  \x20 caly set core select <id>  # select a node\n\
                  \x20 caly set profile add <id> remote:<url>  # declare a profile\n\
                  \x20 caly set config apply      # push config to daemon\n\
                  \n\
                  Every write command defaults to `--dry-run`; pass `--apply` to\n\
                  actually write. Use `caly tool completions <shell>` for\n\
                  completion scripts."
)]
#[command(arg_required_else_help = true, disable_help_subcommand = true)]
pub(super) struct ClapCli {
    #[command(flatten)]
    pub(super) global: GlobalOpts,
    #[command(subcommand)]
    pub(super) command: ClapCommand,
}

#[derive(Args, Debug, Clone)]
pub(super) struct GlobalOpts {
    #[arg(long, global = true, value_name = "PATH")]
    pub(super) socket: Option<PathBuf>,
    #[arg(long, global = true)]
    pub(super) json: bool,
    #[arg(long, global = true, value_enum, value_name = "CORE")]
    pub(super) core: Option<CoreTarget>,
    #[arg(long, global = true, value_name = "PATH")]
    pub(super) mihomo_bin: Option<PathBuf>,
    #[arg(long, global = true, value_name = "PATH")]
    pub(super) sing_box_bin: Option<PathBuf>,
}

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub(super) enum CoreTarget {
    Mihomo,
    #[value(name = "sing-box")]
    SingBox,
}

impl CoreTarget {
    pub(super) const fn as_str(&self) -> &'static str { match self { Self::Mihomo => "mihomo", Self::SingBox => "sing-box" } }
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapCommand {
    /// Run the daemon (foreground).
    Daemon,
    /// Static / one-shot tools.
    Tool { #[command(subcommand)] command: ClapToolCmd },
    /// Read-only queries (offline or live).
    Show { #[command(subcommand)] command: ClapShowCmd },
    /// Mutate config / kernel / daemon.
    Set { #[command(subcommand)] command: ClapSetCmd },
    /// Generate shell completion scripts.
    #[command(arg_required_else_help = true)]
    Completions { shell: CompletionShell },
}

// ── tool ────────────────────────────────────────────────────────
#[derive(Subcommand, Debug)]
#[command(disable_help_subcommand = true)]
pub(super) enum ClapToolCmd {
    /// Print help text.
    Help { command: Option<String> },
    /// Print version.
    Version,
    /// Offline diagnostics.
    Doctor { #[arg(long)] fix: bool },
    /// Run the TUI.
    Tui { #[arg(long)] readonly: bool },
    /// Resolve a domain through configured nameservers.
    Dns { domain: Option<String> },
}

// ── show ────────────────────────────────────────────────────────
#[derive(Subcommand, Debug)]
pub(super) enum ClapShowCmd {
    /// Show daemon state.
    Status,
    /// Core / kernel state.
    Core { #[command(subcommand)] command: ClapShowCoreCmd },
    /// Subscriptions.
    Sub { #[command(subcommand)] command: ClapShowSubCmd },
    /// Profiles.
    Profile { #[command(subcommand)] command: ClapShowProfileCmd },
    /// Inline proxies.
    Proxy { #[command(subcommand)] command: ClapShowProxyCmd },
    /// Config files.
    Config { #[command(subcommand)] command: ClapShowConfigCmd },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapShowCoreCmd {
    /// List registered nodes.
    Nodes,
    /// List proxy groups.
    Groups,
    /// List active connections.
    Connections,
    /// Show traffic totals.
    Traffic,
    /// Show current routing mode.
    Mode,
    /// List rules; with --match, evaluate a target.
    Rules { #[arg(long)] r#match: Option<String> },
    /// Daemon + kernel health summary.
    Health,
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapShowSubCmd {
    /// List configured providers.
    Providers,
    /// Parse a subscription file (offline).
    Parse { path: PathBuf, #[arg(long)] userinfo: Option<String> },
    /// Parse a URI list / clipboard (offline preview).
    Import { path: Option<PathBuf>, #[arg(long)] clipboard: bool },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapShowProfileCmd {
    /// List declared profiles.
    List,
    /// Show one profile.
    Show { id: String },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapShowProxyCmd {
    /// List inline proxies (registered nodes).
    List,
    /// Show one inline proxy.
    Show { id: String },
    /// List proxy groups.
    Groups,
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapShowConfigCmd {
    /// Print active config dir.
    Path,
    /// List base + fragments.
    Files,
    /// Validate merged config or a single file.
    Validate { #[arg(long)] file: Option<PathBuf> },
}

// ── set ─────────────────────────────────────────────────────────
#[derive(Subcommand, Debug)]
pub(super) enum ClapSetCmd {
    /// Core / kernel control.
    Core { #[command(subcommand)] command: ClapSetCoreCmd },
    /// Inline proxy CRUD + system proxy on/off.
    Proxy { #[command(subcommand)] command: ClapSetProxyCmd },
    /// TUN on/off.
    Tun { state: Toggle },
    /// Subscription CRUD + refresh.
    Sub { #[command(subcommand)] command: ClapSetSubCmd },
    /// Profile CRUD.
    Profile { #[command(subcommand)] command: ClapSetProfileCmd },
    /// Config management.
    Config { #[command(subcommand)] command: ClapSetConfigCmd },
    /// Daemon lifecycle.
    Daemon { #[command(subcommand)] command: ClapSetDaemonCmd },
    /// Rule providers (declarative `rule_providers:` CRUD + refresh).
    #[command(name = "rule-provider")]
    RuleProvider { #[command(subcommand)] command: ClapSetRuleProviderCmd },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSetCoreCmd {
    /// Start the active core.
    Start,
    /// Stop the active core.
    Stop,
    /// Restart the active core.
    Restart,
    /// Switch active core (mihomo ↔ sing-box).
    Switch { #[arg(value_enum)] core: CoreTarget },
    /// Select a node (ID, name, or --delay to pick fastest).
    Select {
        node: Option<String>,
        #[arg(long)] delay: bool,
        #[arg(long, value_name = "GROUP")] group: Option<String>,
    },
    /// Set routing mode.
    Mode { mode: RoutingMode },
    /// Close all active connections.
    #[command(name = "close-connections")] CloseConnections,
    /// Latency-sweep a single node, or every node with --all.
    Delay {
        name: Option<String>,
        #[arg(long)] all: bool,
        #[arg(long)] url: Option<String>,
        /// Per-node sample count (1..=5). Default 3.
        /// Larger counts reduce jitter at the cost
        /// of `delay --all` wall-clock time.
        #[arg(long, value_name = "N")]
        samples: Option<u32>,
    },
    /// Probe a single proxy's URL.
    #[command(name = "url-test")]
    UrlTest {
        name: String,
        #[arg(long)] url: Option<String>,
        #[arg(long, value_name = "MS")] timeout: Option<u32>,
        /// Per-URL sample count (1..=5). Default 3.
        #[arg(long, value_name = "N")]
        samples: Option<u32>,
    },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSetProxyCmd {
    /// Add an inline proxy URI.
    Add {
        uri: String,
        #[arg(long, value_name = "GROUP")] group: Option<String>,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Edit an inline proxy in your editor.
    Edit { id: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Remove an inline proxy.
    Remove { id: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Import a URI list file.
    Import { path: PathBuf, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Enable / disable desktop system proxy.
    On,
    Off,
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSetSubCmd {
    /// Refresh every configured subscription source.
    Refresh,
    /// Add a new subscription source URL.
    Add {
        url: String,
        #[arg(long, value_name = "NAME")] name: Option<String>,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Remove a subscription source URL.
    Remove { url: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Enable a subscription source.
    Enable { url: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Disable a subscription source.
    Disable { url: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Import a URI list / clipboard; with --apply, save inline.
    Import { path: Option<PathBuf>, #[arg(long)] clipboard: bool, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSetProfileCmd {
    /// Declare a new profile.
    Add {
        id: String,
        source: String,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Remove a profile.
    Remove { id: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Edit a profile body in your editor.
    Edit { id: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Refresh a profile body (SSRF-safe fetch).
    /// Round 12: refresh always writes; the body IS the cache,
    /// so `--apply` / `--dry-run` are not exposed (a `NotModified`
    /// outcome is a real outcome, not a dry-run).
    Refresh { id: Option<String> },
    /// Export a profile body to a file.
    Export { id: String, #[arg(long, value_name = "PATH")] out: PathBuf },
    /// Enable a profile.
    Enable { id: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
    /// Disable a profile.
    Disable { id: String, #[arg(long, conflicts_with = "dry_run")] apply: bool, #[arg(long, conflicts_with = "apply")] dry_run: bool },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSetConfigCmd {
    /// Apply current config to the daemon.
    Apply,
    /// Generate a documented default config.
    Generate,
    /// Reset to a default config (backup first).
    Default,
    /// Diff current config against default.
    Diff { #[arg(long)] file: Option<PathBuf> },
    /// Open config dir in editor.
    Edit { editor: Editor },
}

#[derive(Subcommand, Debug)]
pub(super) enum ClapSetDaemonCmd {
    /// Stop the daemon gracefully.
    Stop,
    /// Reload config without restart.
    Reload,
    /// Restart the daemon.
    Restart,
    /// Quick status (boot-time).
    Status,
}

/// Round 12: declarative CRUD for `rule_providers:`. Each leaf
/// takes the same `--apply` / `--dry-run` policy as the other
/// `set` resources; `refresh` always writes (the materialised
/// file IS the body the kernel reads).
#[derive(Subcommand, Debug)]
#[command(disable_help_subcommand = true)]
pub(super) enum ClapSetRuleProviderCmd {
    /// Add a new `http` rule provider. The body is fetched
    /// from `<URL>` on a `<MS>` cadence (default 24h).
    #[command(name = "add-http")]
    AddHttp {
        name: String,
        url: String,
        #[arg(long, value_name = "MS", default_value_t = 86_400_000)]
        interval_ms: u64,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Add a new `file` rule provider. The body is read from
    /// `<PATH>` at boot and on `mtime` change.
    #[command(name = "add-file")]
    AddFile {
        name: String,
        path: PathBuf,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Add a new `inline` rule provider. The body is a
    /// bounded inline payload (capped at 256 KiB).
    #[command(name = "add-inline")]
    AddInline {
        name: String,
        #[arg(long, value_name = "PAYLOAD")]
        payload: String,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Remove a provider from `rule_providers:`.
    Remove {
        name: String,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Enable a disabled provider.
    Enable {
        name: String,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Disable a provider.
    Disable {
        name: String,
        #[arg(long, conflicts_with = "dry_run")] apply: bool,
        #[arg(long, conflicts_with = "apply")] dry_run: bool,
    },
    /// Refresh the materialised body of one or every provider.
    /// Always writes; no `--apply` / `--dry-run` flag.
    Refresh { name: Option<String> },
    /// List declared providers (and their enable state).
    List,
}

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub(super) enum RoutingMode {
    Rule, Global, Direct,
}

impl RoutingMode {
    pub(super) const fn as_str(&self) -> &'static str {
        match self { Self::Rule => "rule", Self::Global => "global", Self::Direct => "direct" }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, ValueEnum)]
pub enum Editor {
    Vim, Nvim,
}

#[derive(Clone, Debug, Eq, PartialEq, ValueEnum)]
pub(super) enum Toggle {
    On, Off,
}

impl Toggle {
    pub(super) const fn enabled(&self) -> bool { matches!(self, Self::On) }
}
