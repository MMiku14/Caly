//! `caly tool …` — static / one-shot tools.

use std::process::ExitCode;

use crate::cli::ToolCmd;
use crate::output::{self, CliOutput};

pub fn run(cmd: ToolCmd, options: crate::cli::CliOptions) -> ExitCode {
    let output = CliOutput::from_json_flag(options.json);
    match cmd {
        ToolCmd::Help(sub) => {
            if let Some(sub) = sub {
                let _ = crate::cli::parse_args([sub, "--help".to_owned()]).map_err(|e| e.print());
            } else {
                let _ = crate::cli::parse_args(["--help".to_owned()]).map_err(|e| e.print());
            }
            ExitCode::SUCCESS
        }
        ToolCmd::Version => { println!("caly {}", env!("CARGO_PKG_VERSION")); ExitCode::SUCCESS }
        ToolCmd::Doctor { fix } => super::doctor::run(options, fix),
        ToolCmd::Tui { readonly: _ } => {
            if options.json {
                return output::report_error_returning(output,
                    crate::error::json_not_valid("tool tui"));
            }
            crate::tui::run_tui(options)
        }
        ToolCmd::Dns(d) => super::dns::run(d),
    }
}
