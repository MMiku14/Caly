//! Shared helpers for `set` resource dispatch.
//!
//! Round 13: extracted from `commands::set::profile` so the
//! other resources can reuse the same shape if they grow
//! past pure planned-ok stubs.

use std::process::ExitCode;

use crate::output::{self, CliOutput};

/// Round 13: standard `Ok` exit with a payload merged into
/// the success envelope. `apply` / `dry_run` are reported in
/// the JSON output so a downstream tool can branch on the
/// effective policy without parsing the human message.
pub fn success_with_dry_run(
    output: CliOutput,
    summary: impl Into<String>,
    id: &str,
    dry_run: bool,
    apply: bool,
) -> ExitCode {
    output.success(
        &summary.into(),
        serde_json::json!({ "id": id, "dry_run": dry_run, "apply": apply }),
    );
    ExitCode::SUCCESS
}

/// Round 13: standard `Err` exit that maps a domain
/// `ProfileCmdError` (or similar) to a `CliError` and
/// returns the right `ExitCode`. The command string is
/// stamped on the envelope so log-grep can find which leaf
/// failed.
pub fn report_profile_error(
    output: CliOutput,
    error: &crate::client::profile::ProfileCmdError,
    command: &str,
) -> ExitCode {
    output::report_error_returning(output, crate::error::profile::from_cmd_error(error, command))
}
