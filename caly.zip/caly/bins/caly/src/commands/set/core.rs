//! `set core …` dispatch.
//!
//! Round 15: each `SetCoreCmd` variant maps to the typed
//! `client::ClientCommand::Core(...)` path directly (the
//! `bridge` shim was retired). Round 16: `url-test` is
//! the single-node `core delay` path with explicit
//! `--url`; the `--timeout` parameter is reserved for a
//! future `WireCommand::UrlTest` and is silently ignored
//! today.

use std::process::ExitCode;

use crate::cli::SetCoreCmd;
use crate::client::legacy::CoreCmd;
use crate::output::CliOutput;

pub fn dispatch(c: SetCoreCmd, options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    let mapped = match c {
        SetCoreCmd::Start => CoreCmd::Start,
        SetCoreCmd::Stop => CoreCmd::Stop,
        SetCoreCmd::Restart => CoreCmd::Restart,
        SetCoreCmd::Switch(core) => CoreCmd::Switch(core),
        SetCoreCmd::Select { node, delay, group: _ } => CoreCmd::Select { node, delay },
        SetCoreCmd::Mode(m) => CoreCmd::Mode(m),
        SetCoreCmd::CloseConnections => CoreCmd::CloseConnections,
        SetCoreCmd::Delay { name, all, url, samples } => {
            CoreCmd::Delay { all, name, url, samples }
        }
        // Round 15: `set core url-test` is still routed
        // through the existing single-node `core delay`
        // path. A dedicated `WireCommand::UrlTest` is on
        // the roadmap; the fallback means a Round 15
        // user can already exercise the new leaf today.
        // The `samples` argument is honoured: the
        // offline `Query::UrlTest` resolver maps
        // `None` to the writer's default (3).
        SetCoreCmd::UrlTest {
            name,
            url,
            timeout: _,
            samples,
        } => {
            return crate::client::run_client(
                crate::ClientCommand::Core(CoreCmd::Delay {
                    all: false,
                    name: Some(name),
                    url,
                    samples,
                }),
                options,
            );
        }
    };
    crate::client::run_client(crate::ClientCommand::Core(mapped), options)
}
