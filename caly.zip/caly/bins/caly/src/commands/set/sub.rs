//! `set sub …` dispatch.
//!
//! Round 14: 4 of the 6 leaves (`add` / `remove` /
//! `enable` / `disable`) now go through real
//! `client::subscription` writers that round-trip
//! `config.yaml` (with backup, post-write schema
//! validation, and a stable JSON envelope). `import`
//! and `refresh` keep the bridge for now:
//!
//! - `refresh` drives the daemon RPC; the daemon
//!   returns `ExitCode`, not `Result`, and the typed
//!   `run_client_collect` is the future hook for a
//!   real `SubscriptionRefresh` trait integration.
//! - `import` inspects a file/clipboard and prints a
//!   preview; the inline-node writer
//!   (`import_inline`) is wired in `client::subscription`
//!   and lands in `set sub import` once a `--save`
//!   flag ships (the existing `import` is a dry-run
//!   by design).
//!
//! Every writer returns `Result<SubWriteOutcome,
//! SubCmdError>`; the dispatch maps each variant to a
//! stable `code:` in the JSON envelope and uses the
//! same `output.success` / `output.planned_ok`
//! envelopes as the rest of the `set` namespace.

use std::process::ExitCode;

use crate::client::subscription as cmd;
use crate::cli::SetSubCmd;
use crate::output::CliOutput;

pub fn dispatch(c: SetSubCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    let paths = cmd::resolve_paths();
    match c {
        SetSubCmd::Refresh => {
            // Round 14: the daemon RPC returns `ExitCode`,
            // Round 16: route through `client::run_client`
            // directly. The legacy `SubCmd` enum's `Refresh`
            // variant is still in `cli::ClientCommand` via
            // the `RefreshSubscription` arm.
            crate::client::run_client(
                crate::ClientCommand::RefreshSubscription,
                options,
            )
        }
        SetSubCmd::Add { url, name, apply, dry_run: _ } => run_writer(
            output,
            "set sub add",
            &url,
            name.as_deref(),
            || cmd::add_source(&paths, &url, apply),
        ),
        SetSubCmd::Remove { url, apply, dry_run: _ } => run_writer(
            output,
            "set sub remove",
            &url,
            None,
            || cmd::remove_source(&paths, &url, apply),
        ),
        SetSubCmd::Enable { url, apply, dry_run: _ } => run_writer(
            output,
            "set sub enable",
            &url,
            None,
            || cmd::enable_source(&paths, &url, apply),
        ),
        SetSubCmd::Disable { url, apply, dry_run: _ } => run_writer(
            output,
            "set sub disable",
            &url,
            None,
            || cmd::disable_source(&paths, &url, apply),
        ),
        SetSubCmd::Import { path, clipboard, apply: _, dry_run: _ } => {
            // Round 16: `import` is a preview-only path
            // (the operator can pipe a clipboard / file
            // and see the format). The write path
            // (`import_inline`) is wired in
            // `client::subscription` and will surface
            // once a `--save` flag lands.
            crate::client::subscription::import_preview(
                path.as_deref(),
                clipboard,
                options.json,
            )
        }
    }
}

/// Centralised writer dispatcher. Every `set sub` leaf
/// goes through this so the JSON envelope (success vs
/// `dry_run:true|false` vs error code) is consistent
/// across the 4 source-CRUD writers. Round 19: the
/// envelope always carries the `url` (and the optional
/// `name` for `add`) so a script can grep which source
/// the envelope refers to without re-parsing the leaf
/// string.
fn run_writer(
    output: CliOutput,
    leaf: &'static str,
    url: &str,
    name: Option<&str>,
    write: impl FnOnce() -> Result<cmd::SubWriteOutcome, cmd::SubCmdError>,
) -> ExitCode {
    match write() {
        Ok(cmd::SubWriteOutcome::Applied) => {
            let summary = match leaf {
                "set sub add" => "subscription source added",
                "set sub remove" => "subscription source removed",
                "set sub enable" => "subscription source enabled",
                "set sub disable" => "subscription source disabled",
                other => other,
            };
            let mut payload = serde_json::json!({
                "url": url,
                "leaf": leaf,
                "dry_run": false,
            });
            if let Some(n) = name {
                if let serde_json::Value::Object(ref mut map) = payload {
                    map.insert("name".to_owned(), serde_json::Value::String(n.to_owned()));
                }
            }
            output.success(summary, payload);
            ExitCode::SUCCESS
        }
        Ok(cmd::SubWriteOutcome::DryRun) => {
            let summary = match leaf {
                "set sub add" => "subscription source would be added (dry-run)",
                "set sub remove" => "subscription source would be removed (dry-run)",
                "set sub enable" => "subscription source would be enabled (dry-run)",
                "set sub disable" => "subscription source would be disabled (dry-run)",
                other => other,
            };
            let mut payload = serde_json::json!({
                "url": url,
                "leaf": leaf,
                "dry_run": true,
            });
            if let Some(n) = name {
                if let serde_json::Value::Object(ref mut map) = payload {
                    map.insert("name".to_owned(), serde_json::Value::String(n.to_owned()));
                }
            }
            output.success(summary, payload);
            ExitCode::SUCCESS
        }
        Err(error) => {
            let code = match &error {
                cmd::SubCmdError::InvalidUrl(_) => "sub.invalid_url",
                cmd::SubCmdError::AlreadyDeclared(_) => "sub.already_declared",
                cmd::SubCmdError::NotDeclared(_) => "sub.not_declared",
                cmd::SubCmdError::InvalidName(_) => "sub.invalid_name",
                cmd::SubCmdError::Write(_) => "sub.write_failed",
                cmd::SubCmdError::Parse(_) => "sub.parse_failed",
                cmd::SubCmdError::Validate(_) => "sub.validate_failed",
                cmd::SubCmdError::Mutator(_) => "sub.mutator_failed",
            };
            let mut cli = crate::output::CliError::new(code, error.to_string(), leaf);
            if let cmd::SubCmdError::InvalidUrl(_) = &error {
                cli = cli.with_hint("URL must start with `http://` or `https://`");
            }
            crate::output::report_error_returning(output, cli)
        }
    }
}
