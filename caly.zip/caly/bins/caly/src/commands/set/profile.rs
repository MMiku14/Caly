//! `set profile …` dispatch.
//!
//! Round 13: `add` / `remove` go through the real
//! `client::profile` writers; `refresh` goes through
//! `Refreshable::refresh` (the trait impl is the source of
//! truth for the success envelope shape). The four CRUD
//! leaves (`edit` / `export` / `enable` / `disable`) are
//! `planned_ok` placeholders — the `$EDITOR` spawn,
//! merged body write, and enable-flag writer land in
//! Round 14.

use std::process::ExitCode;

use crate::cli::SetProfileCmd;
use crate::commands::refresh::{
    ProfileRefresh, RefreshContext, RefreshTarget, Refreshable, report_refreshed,
};
use crate::output::CliOutput;

pub fn dispatch(c: SetProfileCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    match c {
        SetProfileCmd::Add { id, source, apply, dry_run: _ } => add_apply(&id, &source, apply, output),
        SetProfileCmd::Remove { id, apply, dry_run: _ } => remove_apply(&id, apply, output),
        SetProfileCmd::Edit { id, apply, dry_run } => edit_apply(&id, apply && !dry_run, output),
        SetProfileCmd::Export { id, out } => export_apply(&id, &out, output),
        SetProfileCmd::Enable { id, apply, dry_run } => enable_apply(&id, apply && !dry_run, output),
        SetProfileCmd::Disable { id, apply, dry_run } => disable_apply(&id, apply && !dry_run, output),
        // Refresh always writes the body (the body IS the
        // cache). A `NotModified` HTTP 304 is a real outcome,
        // not a dry-run.
        SetProfileCmd::Refresh { id } => refresh(id.as_deref(), options, output),
    }
}

fn edit_apply(id: &str, apply: bool, output: CliOutput) -> ExitCode {
    use crate::client::profile as cmd;
    let paths = cmd::resolve_paths();
    // Round 19: always call the writer so the
    // dry-run path goes through the same `NotDeclared`
    // / `InvalidId` / `Store` checks the apply path
    // does. The previous early-return skipped every
    // validation, so a `set profile edit nonexistent
    // --dry-run` reported `ok: would be edited`
    // even though the writer would have rejected
    // the same id. Dry-run is the safety net, not
    // a success-by-default branch.
    match cmd::edit_profile(&paths, id, apply) {
        Ok(cmd::AddOutcome::Applied) => {
            output.success(
                &format!("profile `{id}` edited"),
                serde_json::json!({"id": id, "dry_run": false, "leaf": format!("set profile edit {id}")}),
            );
            ExitCode::SUCCESS
        }
        Ok(cmd::AddOutcome::DryRun) => {
            output.success(
                &format!("profile `{id}` would be edited (dry-run)"),
                serde_json::json!({"id": id, "dry_run": true, "leaf": format!("set profile edit {id}")}),
            );
            ExitCode::SUCCESS
        }
        Err(e) => super::common::report_profile_error(output, &e, "set profile edit"),
    }
}

fn export_apply(id: &str, out: &std::path::Path, output: CliOutput) -> ExitCode {
    use crate::client::profile as cmd;
    let paths = cmd::resolve_paths();
    match cmd::export_profile(&paths, id, out) {
        Ok(()) => {
            let summary = format!("profile `{id}` exported to {}", out.display());
            let payload = serde_json::json!({
                "id": id,
                "out": out.display().to_string(),
            });
            output.success(&summary, payload);
            ExitCode::SUCCESS
        }
        Err(e) => super::common::report_profile_error(output, &e, "set profile export"),
    }
}

fn enable_apply(id: &str, apply: bool, output: CliOutput) -> ExitCode {
    set_enabled_apply(id, true, apply, output)
}

fn disable_apply(id: &str, apply: bool, output: CliOutput) -> ExitCode {
    set_enabled_apply(id, false, apply, output)
}

fn set_enabled_apply(
    id: &str,
    enabled: bool,
    apply: bool,
    output: CliOutput,
) -> ExitCode {
    use crate::client::profile as cmd;
    let paths = cmd::resolve_paths();
    if apply {
        return set_enabled_apply_write(&paths, id, enabled, output);
    }
    set_enabled_apply_dry_run(&paths, id, enabled, output)
}

/// Apply-mode path for `set profile enable|disable`.
/// Delegates to the writer; surfaces any writer error
/// (`NotDeclared`, `InvalidId`, …) verbatim.
fn set_enabled_apply_write(
    paths: &caly_platform::paths::AppPaths,
    id: &str,
    enabled: bool,
    output: CliOutput,
) -> ExitCode {
    use crate::client::profile as cmd;
    match cmd::set_profile_enabled(paths, id, enabled) {
        Ok(_) => {
            let summary = format!(
                "profile `{id}` {}",
                if enabled { "enabled" } else { "disabled" },
            );
            super::common::success_with_dry_run(
                output,
                summary,
                id,
                false,
                true,
            )
        }
        Err(e) => super::common::report_profile_error(output, &e, leaf_for(enabled)),
    }
}

/// Dry-run path for `set profile enable|disable`.
/// Goes through the writer's read-only surface
/// (`load_declared_profiles` + `is_path_safe_component`)
/// so a dry-run against an unknown id surfaces
/// `NotDeclared` instead of a fabricated success.
/// The writer's actual `set_profile_enabled` is
/// apply-only (it mutates the on-disk config), so
/// this is the only way to keep dry-run truly
/// read-only while still surfacing the same
/// validation errors the apply path does.
fn set_enabled_apply_dry_run(
    paths: &caly_platform::paths::AppPaths,
    id: &str,
    enabled: bool,
    output: CliOutput,
) -> ExitCode {
    use crate::client::profile as cmd;
    if !is_valid_id(id) {
        return super::common::report_profile_error(
            output,
            &cmd::ProfileCmdError::InvalidId(id.to_owned()),
            leaf_for(enabled),
        );
    }
    match cmd::load_declared_profiles(paths) {
        Err(e) => super::common::report_profile_error(output, &e, leaf_for(enabled)),
        Ok((config, _store)) => {
            if !config.profiles.iter().any(|p| p.id == id) {
                return super::common::report_profile_error(
                    output,
                    &cmd::ProfileCmdError::NotDeclared(id.to_owned()),
                    leaf_for(enabled),
                );
            }
            output.success(
                &format!(
                    "profile `{id}` would be {} (dry-run)",
                    if enabled { "enabled" } else { "disabled" },
                ),
                serde_json::json!({
                    "id": id,
                    "enabled": enabled,
                    "dry_run": true,
                    "leaf": leaf_for_enabled(enabled, id),
                }),
            );
            ExitCode::SUCCESS
        }
    }
}

fn leaf_for(enabled: bool) -> &'static str {
    if enabled {
        "set profile enable"
    } else {
        "set profile disable"
    }
}

fn leaf_for_enabled(enabled: bool, id: &str) -> String {
    format!("set profile {} {id}", if enabled { "enable" } else { "disable" })
}

fn is_valid_id(id: &str) -> bool {
    caly_domain::is_path_safe_component(id)
}

fn add_apply(id: &str, source: &str, apply: bool, output: CliOutput) -> ExitCode {
    use crate::client::profile as cmd;
    let parsed = match cmd::parse_source_spec(source) {
        Ok(v) => v,
        Err(e) => {
            return super::common::report_profile_error(output, &e, "set profile add");
        }
    };
    let paths = cmd::resolve_paths();
    // Round 19: the writer's `dry_run` flag IS
    // `!apply` by definition. Pass `apply` as the
    // writer's "write" flag so the dispatch and
    // writer share the same boolean. The envelope
    // drops the redundant `apply` field.
    let write = apply;
    match cmd::add_profile(&paths, id, parsed, !write) {
        Ok(cmd::AddOutcome::Applied) => {
            output.success(
                &format!("profile `{id}` added"),
                serde_json::json!({
                    "id": id,
                    "dry_run": false,
                    "leaf": format!("set profile add {id}"),
                }),
            );
            ExitCode::SUCCESS
        }
        Ok(cmd::AddOutcome::DryRun) => {
            output.success(
                &format!("profile `{id}` would be added (dry-run)"),
                serde_json::json!({
                    "id": id,
                    "dry_run": true,
                    "leaf": format!("set profile add {id}"),
                }),
            );
            ExitCode::SUCCESS
        }
        Err(e) => super::common::report_profile_error(output, &e, "set profile add"),
    }
}

fn remove_apply(id: &str, apply: bool, output: CliOutput) -> ExitCode {
    use crate::client::profile as cmd;
    let paths = cmd::resolve_paths();
    let write = apply;
    match cmd::remove_profile(&paths, id, !write) {
        Ok(cmd::RemoveOutcome::Applied) => {
            output.success(
                &format!("profile `{id}` removed"),
                serde_json::json!({
                    "id": id,
                    "dry_run": false,
                    "leaf": format!("set profile remove {id}"),
                }),
            );
            ExitCode::SUCCESS
        }
        Ok(cmd::RemoveOutcome::DryRun) => {
            output.success(
                &format!("profile `{id}` would be removed (dry-run)"),
                serde_json::json!({
                    "id": id,
                    "dry_run": true,
                    "leaf": format!("set profile remove {id}"),
                }),
            );
            ExitCode::SUCCESS
        }
        Err(e) => super::common::report_profile_error(output, &e, "set profile remove"),
    }
}

fn refresh(
    id: Option<&str>,
    _options: crate::cli::CliOptions,
    output: CliOutput,
) -> ExitCode {
    // Round 13: route through `Refreshable::refresh`. The
    // trait impl owns the success / error envelope shape.
    let target = id.map_or_else(
        || RefreshTarget::ProfileId("(all)".to_owned()),
        |s| RefreshTarget::ProfileId(s.to_owned()),
    );
    let ctx = RefreshContext::always_writes(output, "set profile refresh");
    match <ProfileRefresh as Refreshable>::refresh(&target, &ctx) {
        Ok(outcome) => {
            report_refreshed(output, &target, &outcome);
            ExitCode::SUCCESS
        }
        Err(e) => {
            let mut cli = crate::output::CliError::new(e.code(), e.message(), "set profile refresh");
            if let Some(hint) = e.hint() {
                cli = cli.with_hint(hint);
            }
            crate::output::report_error_returning(output, cli)
        }
    }
}

#[cfg(test)]
mod dry_run_validation_tests {
    //! Round 19: every `set profile …` dry-run must
    //! surface the same validation errors the apply
    //! path does. Before this change, `edit` /
    //! `enable` / `disable` short-circuited with a
    //! fabricated `ok: would be …` envelope before
    //! the writer ever saw the id, so a dry-run
    //! against a non-existent id reported success.
    //!
    //! These tests exercise the underlying writers
    //! (`client::profile::edit_profile` /
    //! `set_profile_enabled`) with a hermetic
    //! `AppPaths`, so the dry-run return value is
    //! the same one the dispatch now sees.
    //!
    //! The dispatch layer forwards the writer's
    //! outcome to the CLI envelope unchanged, so an
    //! `Err(NotDeclared)` from the writer reaches
    //! the operator as a `profile.not_declared`
    //! error envelope, not a fabricated success.

    use crate::client::profile as cmd;
    use caly_platform::paths::AppPaths;
    use std::ffi::OsString;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn temp_root(label: &str) -> PathBuf {
        static COUNTER: AtomicUsize = AtomicUsize::new(0);
        let n = COUNTER.fetch_add(1, Ordering::Relaxed);
        let pid = std::process::id();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos());
        let path = std::env::temp_dir().join(format!(
            "caly-profile-dryrun-{label}-{pid}-{n}-{nanos}"
        ));
        fs::create_dir_all(&path).unwrap_or_else(|_| std::process::abort());
        path
    }

    fn hermetic_paths(dir: &std::path::Path) -> AppPaths {
        let env = |key: &str| -> Option<OsString> {
            match key {
                "HOME" => Some(OsString::from("/home/test")),
                "XDG_RUNTIME_DIR" => Some(OsString::from("/run/user/1000")),
                "XDG_STATE_HOME" => Some(OsString::from(dir.as_os_str())),
                "XDG_CONFIG_HOME" => Some(OsString::from(dir.as_os_str())),
                _ => None,
            }
        };
        AppPaths::from_env_vars(&env)
    }

    fn seed_config(paths: &AppPaths) {
        fs::create_dir_all(&paths.config).unwrap_or_else(|_| std::process::abort());
        fs::write(
            paths.config.join("config.yaml"),
            "schema_version: 1\ncore: mihomo\nprofiles: []\n",
        )
        .unwrap_or_else(|_| std::process::abort());
    }

    #[test]
    fn edit_dry_run_against_unknown_id_surfaces_not_declared() {
        // Round 19 regression: pre-Round 19, the
        // dispatch short-circuited with `ok: would be
        // edited` even when the id was unknown. The
        // writer now sees the request and rejects it
        // with `NotDeclared`; the dispatch surfaces
        // the same error.
        let dir = temp_root("edit-dry");
        let paths = hermetic_paths(&dir);
        seed_config(&paths);
        let result = cmd::edit_profile(&paths, "missing-id", false);
        assert!(
            matches!(result, Err(cmd::ProfileCmdError::NotDeclared(_))),
            "expected NotDeclared, got {result:?}"
        );
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn enable_dry_run_against_unknown_id_surfaces_not_declared() {
        // Round 19 regression: dry-run `enable` must
        // reject an unknown id. The writer's
        // `set_profile_enabled` already does the
        // `find_declared` check; the dispatch now
        // routes through it.
        let dir = temp_root("enable-dry");
        let paths = hermetic_paths(&dir);
        seed_config(&paths);
        let result = cmd::set_profile_enabled(&paths, "missing-id", true);
        assert!(
            matches!(result, Err(cmd::ProfileCmdError::NotDeclared(_))),
            "expected NotDeclared, got {result:?}"
        );
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn disable_dry_run_against_unknown_id_surfaces_not_declared() {
        let dir = temp_root("disable-dry");
        let paths = hermetic_paths(&dir);
        seed_config(&paths);
        let result = cmd::set_profile_enabled(&paths, "missing-id", false);
        assert!(
            matches!(result, Err(cmd::ProfileCmdError::NotDeclared(_))),
            "expected NotDeclared, got {result:?}"
        );
        let _ = fs::remove_dir_all(&dir);
    }
}
