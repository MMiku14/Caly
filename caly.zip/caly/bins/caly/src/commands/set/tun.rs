//! `set tun …` dispatch.
//!
//! Round 15: TUN is a daemon mutation (`SetTun` RPC), so
//! the leaf routes through the typed
//! `client::run_client` path (the `bridge` shim was
//! retired).

use std::process::ExitCode;

use crate::client::legacy::SysCmd;
use crate::output::CliOutput;

pub fn dispatch(state: bool, options: crate::cli::CliOptions, _output: CliOutput) -> ExitCode {
    crate::client::run_client(crate::ClientCommand::Sys(SysCmd::Tun(state)), options)
}
