//! `caly set …` — mutations.
//!
//! Round 13 split: the dispatch is one declarative match on
//! `SetCmd`, and each resource family lives in its own
//! sub-module (`core` / `proxy` / `tun` / `sub` / `profile` /
//! `config` / `daemon` / `rule_provider`). The sub-modules
//! each export a `dispatch` function with the same
//! `(cmd, options, output) -> ExitCode` signature so the
//! top-level match stays trivial.
//!
//! # Dry-run policy
//!
//! Write commands default to `apply: false, dry_run: false`
//! (safe — no write). The operator must pass `--apply` to
//! actually mutate. The legacy `--dry-run` flag is still
//! accepted and still honored; `--apply` / `--dry-run` are
//! mutually exclusive (`clap::Arg::conflicts_with`).
//!
//! # Refresh semantics
//!
//! `refresh` always writes the body. The `--apply` /
//! `--dry-run` flags were dropped from `set profile refresh`
//! and `set rule-provider refresh` in Round 12 (a
//! `NotModified` HTTP 304 is a real outcome, not a dry-run).

use std::process::ExitCode;

use crate::cli::SetCmd;
use crate::output::CliOutput;

pub mod common;
pub mod config;
pub mod core;
pub mod daemon;
pub mod profile;
pub mod proxy;
pub mod rule_provider;
pub mod sub;
pub mod tun;

/// Top-level dispatch. Round 13: each resource's `dispatch`
/// function lives in its own sub-module; the match here is
/// pure pass-through.
pub fn run(cmd: SetCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    match cmd {
        SetCmd::Core(c) => core::dispatch(c, options, output),
        SetCmd::Proxy(c) => proxy::dispatch(c, options, output),
        SetCmd::Tun(on) => tun::dispatch(on, options, output),
        SetCmd::Sub(c) => sub::dispatch(c, options, output),
        SetCmd::Profile(c) => profile::dispatch(c, options, output),
        SetCmd::Config(c) => config::dispatch(c, options, output),
        SetCmd::Daemon(c) => daemon::dispatch(c, output),
        SetCmd::RuleProvider(c) => rule_provider::dispatch(c, options, output),
    }
}
