//! `set proxy …` dispatch.
//!
//! Round 15: `On` / `Off` route through the typed
//! `client::run_client` path. Round 16: the four CRUD
//! leaves (`add` / `edit` / `remove` / `import`) write
//! `<state>/inline-proxies/<id>.json` via
//! `client::inline_proxy`.
//!
//! Round 18: dry-run no longer reports `: planned.` —
//! every leaf now returns the same `{"ok": true, "dry_run":
//! true, ...}` envelope the JSON consumers already
//! expect, so a `caly --json | jq` pipeline can branch on
//! the `dry_run` flag without parsing the human summary.

use std::process::ExitCode;

use crate::cli::SetProxyCmd;
use crate::client::inline_proxy::{ImportOutcome, InlineProxyError, InlineProxyOutcome};
use crate::client::legacy::SysCmd;
use crate::output::{CliError, CliOutput};

pub fn dispatch(c: SetProxyCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    match c {
        SetProxyCmd::On => {
            crate::client::run_client(crate::ClientCommand::Sys(SysCmd::Proxy(true)), options)
        }
        SetProxyCmd::Off => {
            crate::client::run_client(crate::ClientCommand::Sys(SysCmd::Proxy(false)), options)
        }
        SetProxyCmd::Add { uri, group, apply, dry_run } => {
            add_apply(&uri, group.as_deref(), apply && !dry_run, output)
        }
        SetProxyCmd::Edit { id, apply, dry_run } => {
            edit_apply(&id, apply && !dry_run, output)
        }
        SetProxyCmd::Remove { id, apply, dry_run } => {
            remove_apply(&id, apply && !dry_run, output)
        }
        SetProxyCmd::Import { path, apply, dry_run } => {
            import_apply(&path, apply && !dry_run, output)
        }
    }
}

fn add_apply(uri: &str, group: Option<&str>, apply: bool, output: CliOutput) -> ExitCode {
    use crate::client::inline_proxy as cmd;
    let paths = cmd::resolve_paths_pub();
    match cmd::add_proxy(&paths, uri, group, apply) {
        Ok((InlineProxyOutcome::Applied, id)) => {
            output.success(
                &format!("inline proxy `{id}` added"),
                serde_json::json!({
                    "id": id,
                    "uri": uri,
                    "group": group,
                    "dry_run": false,
                }),
            );
            ExitCode::SUCCESS
        }
        Ok((InlineProxyOutcome::DryRun, id)) => {
            output.success(
                &format!("inline proxy `{id}` would be added (dry-run)"),
                serde_json::json!({
                    "id": id,
                    "uri": uri,
                    "group": group,
                    "dry_run": true,
                }),
            );
            ExitCode::SUCCESS
        }
        Err(error) => report_inline_proxy_error(output, &error, "set proxy add"),
    }
}

fn edit_apply(id: &str, apply: bool, output: CliOutput) -> ExitCode {
    use crate::client::inline_proxy as cmd;
    let paths = cmd::resolve_paths_pub();
    match cmd::edit_proxy(&paths, id, apply) {
        Ok(InlineProxyOutcome::Applied) => {
            output.success(
                &format!("inline proxy `{id}` edited"),
                serde_json::json!({"id": id, "dry_run": false}),
            );
            ExitCode::SUCCESS
        }
        Ok(InlineProxyOutcome::DryRun) => {
            output.success(
                &format!("inline proxy `{id}` would be edited (dry-run)"),
                serde_json::json!({"id": id, "dry_run": true}),
            );
            ExitCode::SUCCESS
        }
        Err(error) => report_inline_proxy_error(output, &error, "set proxy edit"),
    }
}

fn remove_apply(id: &str, apply: bool, output: CliOutput) -> ExitCode {
    use crate::client::inline_proxy as cmd;
    let paths = cmd::resolve_paths_pub();
    match cmd::remove_proxy(&paths, id, apply) {
        Ok(InlineProxyOutcome::Applied) => {
            output.success(
                &format!("inline proxy `{id}` removed"),
                serde_json::json!({"id": id, "dry_run": false}),
            );
            ExitCode::SUCCESS
        }
        Ok(InlineProxyOutcome::DryRun) => {
            output.success(
                &format!("inline proxy `{id}` would be removed (dry-run)"),
                serde_json::json!({"id": id, "dry_run": true}),
            );
            ExitCode::SUCCESS
        }
        Err(error) => report_inline_proxy_error(output, &error, "set proxy remove"),
    }
}

fn import_apply(path: &std::path::Path, apply: bool, output: CliOutput) -> ExitCode {
    use crate::client::inline_proxy as cmd;
    let paths = cmd::resolve_paths_pub();
    match cmd::import_proxy(&paths, path, apply) {
        Ok(ImportOutcome::Applied(count)) => {
            output.success(
                &format!("imported {count} inline proxy(s) from {}", path.display()),
                serde_json::json!({
                    "path": path.display().to_string(),
                    "count": count,
                    "dry_run": false,
                }),
            );
            ExitCode::SUCCESS
        }
        Ok(ImportOutcome::DryRun(count)) => {
            output.success(
                &format!(
                    "would import {count} inline proxy(s) from {} (dry-run)",
                    path.display()
                ),
                serde_json::json!({
                    "path": path.display().to_string(),
                    "count": count,
                    "dry_run": true,
                }),
            );
            ExitCode::SUCCESS
        }
        Ok(ImportOutcome::NoOp) => {
            // Round 19: apply mode with no new entries
            // is an idempotent success (no `dry_run:true`
            // even when `apply` is false). The
            // dispatch picks the dry_run flag from the
            // operator's intent, not from whether
            // anything changed.
            let summary = if apply {
                format!(
                    "no new inline proxies in {} (all already declared)",
                    path.display()
                )
            } else {
                format!(
                    "no new inline proxies would be imported from {} (dry-run)",
                    path.display()
                )
            };
            output.success(
                &summary,
                serde_json::json!({
                    "path": path.display().to_string(),
                    "count": 0,
                    "dry_run": !apply,
                }),
            );
            ExitCode::SUCCESS
        }
        Err(error) => report_inline_proxy_error(output, &error, "set proxy import"),
    }
}

/// Maps an [`InlineProxyError`] to a stable CLI error
/// envelope (`code` + `message` + `command`) and writes
/// the failure to the right channel. Round 18 lifted
/// this out of the four per-leaf bodies so the
/// variant → `code` mapping lives in one place; before
/// the refactor each leaf inlined its own `match` and
/// the `code` strings drifted between call sites.
fn report_inline_proxy_error(
    output: CliOutput,
    error: &InlineProxyError,
    command: &'static str,
) -> ExitCode {
    let code = match error {
        InlineProxyError::InvalidUri(_) => "proxy.invalid_uri",
        InlineProxyError::AlreadyDeclared(_) => "proxy.already_declared",
        InlineProxyError::NotDeclared(_) => "proxy.not_declared",
        InlineProxyError::Io(_) => "proxy.write_failed",
    };
    let cli = CliError::new(code, error.to_string(), command);
    crate::output::report_error_returning(output, cli)
}

#[cfg(test)]
mod dry_run_envelope_tests {
    use super::*;
    use crate::client::inline_proxy as cmd;
    use caly_platform::paths::AppPaths;
    use std::ffi::OsString;

    fn hermetic_paths(dir: &std::path::Path) -> AppPaths {
        let env = |key: &str| -> Option<OsString> {
            match key {
                "HOME" => Some(OsString::from("/home/test")),
                "XDG_RUNTIME_DIR" => Some(OsString::from("/run/user/1000")),
                "XDG_STATE_HOME" => Some(OsString::from(dir.as_os_str())),
                "XDG_CONFIG_HOME" => Some(OsString::from(dir.as_os_str())),
                _ => None,
            }
        };
        AppPaths::from_env_vars(&env)
    }

    /// Each `add` / `edit` / `remove` / `import` dry-run
    /// must return the same JSON shape the operator's
    /// `jq` pipeline expects (`ok: true` + the relevant
    /// identifiers + `dry_run: true`). Round 18 replaced
    /// the `planned_ok(": planned.")` envelope with this
    /// contract; the regression catches any leaf that
    /// drifts back to the old stub. Round 19: the test
    /// also exercises `import` in the
    /// `apply-with-no-new-entries` (`NoOp`) shape so
    /// the envelope reports `dry_run:false` and
    /// `count:0` instead of misleading the operator
    /// with `dry_run:true` after an explicit `--apply`.
    /// It also asserts dry-run is truly read-only at
    /// the filesystem level (no `create_dir_all`
    /// side-effect on the inline-proxies dir).
    #[test]
    fn dry_run_envelopes_match_applied_envelopes() {
        let dir = std::env::temp_dir().join(format!(
            "caly-proxy-dryrun-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_nanos())
                .unwrap_or(0)
        ));
        std::fs::create_dir_all(&dir).unwrap_or_else(|_| std::process::abort());
        let paths = hermetic_paths(&dir);
        let uri = "vmess://dryrun-test";

        // `add` (dry-run): must not write the proxy file
        // AND must not create the inline-proxies dir.
        // Round 19: pre-Round 19 the path lookup
        // unconditionally called `create_dir_all` on
        // the parent, so a fresh state root with no
        // `<state>/caly/inline-proxies/` would silently
        // grow one during a dry-run. The fix: use the
        // read-only path helper for the `path.exists()`
        // check.
        let inline_dir = paths.state.join("inline-proxies");
        assert!(
            !inline_dir.exists(),
            "inline-proxies must not pre-exist (test setup must be hermetic)"
        );
        let (outcome, _id) = cmd::add_proxy(&paths, uri, Some("g"), false)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::DryRun);
        assert!(
            !inline_dir.exists(),
            "dry-run add must not create the inline-proxies directory"
        );
        assert!(
            cmd::list_proxies(&paths).is_empty(),
            "dry-run add must not persist any entry"
        );

        // `add` (apply): must write the proxy file and
        // create the inline-proxies dir as a side effect.
        let (outcome, id) = cmd::add_proxy(&paths, uri, Some("g"), true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::Applied);
        assert!(inline_dir.exists());
        assert_eq!(cmd::list_proxies(&paths).len(), 1);

        // `edit` (dry-run): the writer does the same
        // `NotDeclared` / `Store` validation as apply,
        // so a dry-run against a real id is `DryRun`.
        let outcome = cmd::edit_proxy(&paths, &id, false)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::DryRun);

        // `remove` (dry-run): the file is still present.
        let outcome = cmd::remove_proxy(&paths, &id, false)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, InlineProxyOutcome::DryRun);
        assert_eq!(cmd::list_proxies(&paths).len(), 1);

        // `import` (dry-run) on a fresh path: zero writes.
        let list_path = dir.join("list.txt");
        std::fs::write(&list_path, "ss://a\nvmess://b\n").unwrap_or_else(|_| std::process::abort());
        let baseline = cmd::list_proxies(&paths).len();
        let outcome = cmd::import_proxy(&paths, &list_path, false)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, ImportOutcome::DryRun(2));
        assert_eq!(
            cmd::list_proxies(&paths).len(),
            baseline,
            "dry-run import must not write any proxy file"
        );

        // `import` (apply) on the same file: writes 2
        // new entries. `Applied(2)`, not `NoOp` — the
        // previous count-based short-circuit collapsed
        // this into `DryRun`, which the operator cannot
        // tell apart from a true dry-run. Round 19
        // makes the apply path honest about having
        // written.
        let outcome = cmd::import_proxy(&paths, &list_path, true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, ImportOutcome::Applied(2));

        // `import` (apply) again on the same file: every
        // entry is already declared, so the apply path
        // is a no-op. The envelope must report `NoOp`
        // (not `Applied(0)` and not `DryRun`) so the
        // dispatch can map the operator's `--apply` to
        // `dry_run:false` in the JSON envelope. The
        // earlier `count == 0 → DryRun` short-circuit
        // would have lied here.
        let outcome = cmd::import_proxy(&paths, &list_path, true)
            .unwrap_or_else(|_| std::process::abort());
        assert_eq!(outcome, ImportOutcome::NoOp);

        let _ = std::fs::remove_dir_all(&dir);
    }
}
