//! `set rule-provider …` dispatch.
//!
//! Round 13: thin wrapper that delegates to the canonical
//! `commands::rule_provider::dispatch`. Kept in `set/` so
//! the `set/mod.rs` top-level match has the same shape for
//! every resource.

use std::process::ExitCode;

use crate::cli::SetRuleProviderCmd;
use crate::output::CliOutput;

pub fn dispatch(c: SetRuleProviderCmd, options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    super::super::rule_provider::dispatch(c, options, output)
}
