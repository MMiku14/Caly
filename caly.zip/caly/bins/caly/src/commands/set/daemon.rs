//! `set daemon …` dispatch.
//!
//! Round 17: all four lifecycle leaves are real —
//! `status` reuses `show core health`, `stop` / `reload`
//! go through the typed `client::run_client_collect` path
//! (the daemon tears down on `stop` and re-reads config on
//! `reload`), and `restart` is a client-side `Stop` +
//! `Command::spawn("caly daemon")` sequence. Zero stub
//! leaves remain in the `set` namespace.

use std::process::ExitCode;

use crate::cli::SetDaemonCmd;
use crate::output::CliOutput;

pub fn dispatch(c: SetDaemonCmd, output: CliOutput) -> ExitCode {
    let options = crate::cli::CliOptions {
        json: output.is_json(),
        ..crate::cli::CliOptions::default()
    };
    match c {
        SetDaemonCmd::Status => super::super::show::run(
            crate::cli::ShowCmd::Core(crate::cli::ShowCoreCmd::Health),
            crate::cli::CliOptions {
                json: output.is_json(),
                ..crate::cli::CliOptions::default()
            },
            output,
        ),
        SetDaemonCmd::Stop => stop_daemon(options),
        SetDaemonCmd::Reload => reload_config(options),
        SetDaemonCmd::Restart => restart_daemon(output),
    }
}

/// `set daemon stop` — request the running daemon to exit
/// cleanly. The server-side handler triggers the
/// `stop_notifier` after the response is serialized, so
/// the client receives the final operation status
/// before the daemon process exits.
fn stop_daemon(options: crate::cli::CliOptions) -> ExitCode {
    crate::client::run_client(crate::client::ClientCommand::StopDaemon, options)
}

/// `set daemon reload` — request the running daemon to
/// re-read `config.yaml` and re-apply the current
/// candidate. The server-side handler is a typed
/// no-op; the actual re-apply is driven by the
/// `ReloadConfig` operation completing (Round 17
/// delivers the operation status; Round 18+ can wire
/// the runtime to observe the status and trigger a
/// follow-up `ApplyConfig`).
fn reload_config(options: crate::cli::CliOptions) -> ExitCode {
    crate::client::run_client(crate::client::ClientCommand::ReloadConfig, options)
}

/// `set daemon restart` — client-side: `Stop` the
/// running daemon, then spawn a fresh `caly daemon`
/// process. The new process picks up the same XDG /
/// env / config the operator had running, so the
/// restart is "transparent" to the operator.
fn restart_daemon(output: CliOutput) -> ExitCode {
    let options = crate::cli::CliOptions {
        json: output.is_json(),
        ..crate::cli::CliOptions::default()
    };
    let stop_exit = crate::client::run_client(crate::client::ClientCommand::StopDaemon, options);
    if stop_exit != ExitCode::SUCCESS {
        return stop_exit;
    }
    // Wait for the previous daemon to release its
    // lockfile. The Stop response is serialized
    // before the server tears down the transport,
    // but the original daemon's `finish_daemon` runs
    // a small amount of post-serve cleanup (the
    // controller secret removal, the lock release)
    // and the new daemon's `acquire` would otherwise
    // race the lock release. A 500ms bounded wait
    // keeps the operator's UX snappy while leaving
    // comfortable headroom for slow CI.
    std::thread::sleep(std::time::Duration::from_millis(500));
    let mut command = std::process::Command::new(std::env::current_exe().unwrap_or_else(|_| "caly".into()));
    command
        .arg("daemon")
        .envs(restart_daemon_env())
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::null())
        .stderr(spawn_stderr_redirect());
    match command.spawn()
    {
        Ok(child) => {
            // The child runs detached; we don't wait for
            // it (the operator uses `set daemon status`
            // / `show status` to verify boot).
            let pid = child.id();
            if output.is_json() {
                println!("{{\"ok\":true,\"pid\":{pid}}}");
            } else {
                println!("ok: new daemon spawned (pid {pid})");
            }
            ExitCode::SUCCESS
        }
        Err(error) => {
            eprintln!("error: cannot spawn `caly daemon` after stop: {error}");
            ExitCode::FAILURE
        }
    }
}

/// Env keys a `caly daemon` process needs to bind the
/// same UDS path, the same lockfile, and the same
/// controller secret as the operator's running
/// daemon. The new process inherits everything else
/// from the parent (XDG / HOME / locale), so only the
/// `CALY_*` overrides are forwarded explicitly.
///
/// Forwarding a fixed set (rather than the whole
/// parent env) keeps the restart deterministic: a
/// stray `CALY_*` set by a one-off shell doesn't
/// silently leak into the new daemon. Operators
/// needing a custom env can re-run the daemon under
/// their own `env -S … caly daemon` shell.
fn restart_daemon_env() -> std::vec::IntoIter<(String, String)> {
    const FORWARDED: &[&str] = &[
        "CALY_CORE",
        "CALY_SOCKET",
        "CALY_LOCK",
        "CALY_MIHOMO_BIN",
        "CALY_MIHOMO_CONTROLLER",
        "CALY_MIHOMO_DIR",
        "CALY_SINGBOX_BIN",
        "CALY_SINGBOX_CONTROLLER",
        "CALY_SINGBOX_DIR",
    ];
    FORWARDED
        .iter()
        .filter_map(|key| {
            std::env::var(key)
                .ok()
                .map(|value| ((*key).to_owned(), value))
        })
        .collect::<Vec<_>>()
        .into_iter()
}

/// Redirects the spawned daemon's stderr to a file
/// under the active runtime root so a failed
/// restart can be diagnosed without a TTY. Honors
/// `CALY_RESTART_LOG` for tests / operators that
/// want a different path; otherwise writes
/// `<runtime>/restart.log` next to the daemon's
/// own `daemon.log`.
fn spawn_stderr_redirect() -> std::process::Stdio {
    if let Ok(path) = std::env::var("CALY_RESTART_LOG") {
        if let Ok(file) = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&path)
        {
            return std::process::Stdio::from(file);
        }
    }
    if let Some(runtime) = std::env::var_os("XDG_RUNTIME_DIR") {
        let path = std::path::PathBuf::from(runtime).join("restart.log");
        if let Ok(file) = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&path)
        {
            return std::process::Stdio::from(file);
        }
    }
    std::process::Stdio::null()
}
