//! Round 15: `set rule-provider` CLI leaf dispatcher.
//!
//! Each `SetRuleProviderCmd` variant is one leaf in the
//! `set rule-provider` family. The 6 CRUD leaves
//! (`add-http` / `add-file` / `add-inline` / `remove` /
//! `enable` / `disable`) round-trip
//! `rule_providers: Vec<RuleProviderConfig>` in
//! `config.yaml` through `client::rule_provider`. The
//! `refresh` leaf drives the daemon RPC through the
//! `Refreshable` trait (Round 14 fully wired).
//!
//! Round 12 was all `planned_ok(...)` place-holders; Round 13
//! wired the writer module; Round 15 replaces the dispatch
//! arms 1-for-1 with real writer calls (no API churn).

use std::path::PathBuf;
use std::process::ExitCode;

use crate::cli::{RuleProviderSourceSpec, SetRuleProviderCmd};
use crate::client::rule_provider as cmd;
use crate::output::CliOutput;

/// Dispatches a `set rule-provider` leaf to the matching
/// implementation. Round 15: every CRUD leaf is a real
/// writer; `refresh` is the typed trait path; `list` reads
/// the layered `rule_providers:` list.
pub fn dispatch(cmd_arg: SetRuleProviderCmd, _options: crate::cli::CliOptions, output: CliOutput) -> ExitCode {
    let paths = caly_platform::paths::AppPaths::from_env();
    match cmd_arg {
        SetRuleProviderCmd::Add { name, source, apply, dry_run } => {
            // `--apply` and `--dry-run` are mutually exclusive
            // (clap enforces it). `apply: true` writes,
            // `dry_run: true` runs every check + reports
            // planned, both `false` (default) is the safe
            // dry-run path.
            let effective_apply = apply && !dry_run;
            add(&paths, &name, &source, effective_apply, output)
        }
        SetRuleProviderCmd::Remove { name, apply, dry_run } => {
            remove(&paths, &name, apply && !dry_run, output)
        }
        SetRuleProviderCmd::Enable { name, apply, dry_run } => {
            enable(&paths, &name, apply && !dry_run, output)
        }
        SetRuleProviderCmd::Disable { name, apply, dry_run } => {
            disable(&paths, &name, apply && !dry_run, output)
        }
        SetRuleProviderCmd::Refresh { name } =>
            refresh(name, output),
        SetRuleProviderCmd::List =>
            list(&paths, output),
    }
}

/// Maps the CLI `RuleProviderSourceSpec` to the writer's
/// `RpSourceSpec`. The writer doesn't import the CLI
/// grammar (separation of concerns), so this conversion
/// stays here.
fn to_writer_source(source: &RuleProviderSourceSpec) -> cmd::RpSourceSpec {
    match source {
        RuleProviderSourceSpec::Http { url, interval_ms } => cmd::RpSourceSpec::Http {
            url: url.clone(),
            interval_ms: *interval_ms,
        },
        RuleProviderSourceSpec::File { path } => cmd::RpSourceSpec::File {
            path: path.clone(),
        },
        RuleProviderSourceSpec::Inline { payload } => cmd::RpSourceSpec::Inline {
            payload: payload.clone(),
        },
    }
}

fn add(
    paths: &caly_platform::paths::AppPaths,
    name: &str,
    source: &RuleProviderSourceSpec,
    apply: bool,
    output: CliOutput,
) -> ExitCode {
    let writer_source = to_writer_source(source);
    let leaf = format!("set rule-provider add {name}");
    run_writer(
        output,
        &leaf,
        name,
        || cmd::add_provider(paths, name, &writer_source, cmd::RpBehavior::DEFAULT, apply),
    )
}

fn remove(
    paths: &caly_platform::paths::AppPaths,
    name: &str,
    apply: bool,
    output: CliOutput,
) -> ExitCode {
    let leaf = format!("set rule-provider remove {name}");
    run_writer(output, &leaf, name, || cmd::remove_provider(paths, name, apply))
}

fn enable(
    paths: &caly_platform::paths::AppPaths,
    name: &str,
    apply: bool,
    output: CliOutput,
) -> ExitCode {
    let leaf = format!("set rule-provider enable {name}");
    run_writer(output, &leaf, name, || cmd::set_enabled(paths, name, true, apply))
}

fn disable(
    paths: &caly_platform::paths::AppPaths,
    name: &str,
    apply: bool,
    output: CliOutput,
) -> ExitCode {
    let leaf = format!("set rule-provider disable {name}");
    run_writer(output, &leaf, name, || cmd::set_enabled(paths, name, false, apply))
}

fn refresh(name: Option<String>, output: CliOutput) -> ExitCode {
    let target = name.map_or_else(
        || crate::commands::refresh::RefreshTarget::RuleProviderName("(all)".to_owned()),
        crate::commands::refresh::RefreshTarget::RuleProviderName,
    );
    let ctx = crate::commands::refresh::RefreshContext::always_writes(output, "set rule-provider refresh");
    match <crate::commands::refresh::RuleProviderRefresh as crate::commands::refresh::Refreshable>::refresh(
        &target, &ctx,
    ) {
        Ok(outcome) => {
            crate::commands::refresh::report_refreshed(output, &target, &outcome);
            ExitCode::SUCCESS
        }
        Err(e) => {
            let mut cli = crate::output::CliError::new(
                e.code(),
                e.message(),
                "set rule-provider refresh",
            );
            if let Some(hint) = e.hint() {
                cli = cli.with_hint(hint);
            }
            crate::output::report_error_returning(output, cli)
        }
    }
}

fn list(paths: &caly_platform::paths::AppPaths, output: CliOutput) -> ExitCode {
    let providers = read_declared(paths);
    if output.is_json() {
        let items: Vec<serde_json::Value> = providers
            .into_iter()
            .map(|(name, enabled, behavior, source_kind)| serde_json::json!({
                "name": name,
                "enabled": enabled,
                "behavior": behavior,
                "source": source_kind,
            }))
            .collect();
        output.success(
            &format!("listed {} rule provider(s)", items.len()),
            serde_json::json!({ "providers": items, "count": items.len() }),
        );
    } else {
        for (name, enabled, behavior, source_kind) in &providers {
            println!("rule-provider: {name} ({source_kind}, behavior: {behavior}, enabled: {enabled})");
        }
        println!("{} provider(s)", providers.len());
    }
    ExitCode::SUCCESS
}

/// Round 15: real `list` impl using the layered loader. The
/// loader returns the merged `rule_providers:` list (base +
/// `CALY_PROFILE` + `config.d/*`). Each entry's `enabled`
/// and `behavior` flags are read from the typed config.
pub(crate) fn read_declared(
    paths: &caly_platform::paths::AppPaths,
) -> Vec<(String, bool, String, String)> {
    use caly_config::loader::{InMemoryProfileResolver, LayeredConfigPaths, LoaderLimits};
    use caly_config::schema::RuleProviderSourceConfig;
    let limits = LoaderLimits::secure_default();
    let layered = LayeredConfigPaths::new(paths.config.clone(), None);
    let resolver = InMemoryProfileResolver::lenient();
    match caly_config::loader::load_layered_yaml_with(&layered, limits, &resolver) {
        Ok(config) => config
            .rule_providers
            .into_iter()
            .map(|p| {
                let behavior = format!("{:?}", p.behavior).to_lowercase();
                let source_kind = match &p.kind {
                    RuleProviderSourceConfig::Http { .. } => "http",
                    RuleProviderSourceConfig::File { .. } => "file",
                    RuleProviderSourceConfig::Inline { .. } => "inline",
                }
                .to_owned();
                (p.name, p.enabled, behavior, source_kind)
            })
            .collect(),
        Err(_) => Vec::new(),
    }
}

/// Round 12: helper for the Round 13 `add` writer. PathBuf
/// helper for the materialised body of a rule provider
/// (`<workdir>/rule-providers/<name>.yaml`).
#[allow(dead_code)]
pub(crate) fn ensure_rule_provider_path(workdir: &std::path::Path, name: &str) -> PathBuf {
    workdir.join("rule-providers").join(format!("{name}.yaml"))
}

/// Round 15: centralised writer dispatcher for the 4
/// CRUD leaves. Same shape as `set::sub::run_writer`.
/// Round 19: the envelope always carries the rule
/// provider `name` so a script can grep which entry
/// the envelope refers to without re-parsing the leaf
/// string.
fn run_writer(
    output: CliOutput,
    leaf: &str,
    name: &str,
    write: impl FnOnce() -> Result<cmd::RpWriteOutcome, cmd::RpWriteError>,
) -> ExitCode {
    match write() {
        Ok(cmd::RpWriteOutcome::Applied) => {
            let summary = match leaf {
                _ if leaf.starts_with("set rule-provider add") => "rule provider added",
                _ if leaf.starts_with("set rule-provider remove") => "rule provider removed",
                _ if leaf.starts_with("set rule-provider enable") => "rule provider enabled",
                _ if leaf.starts_with("set rule-provider disable") => "rule provider disabled",
                other => other,
            };
            let payload = serde_json::json!({
                "name": name,
                "leaf": leaf,
                "dry_run": false,
            });
            output.success(summary, payload);
            ExitCode::SUCCESS
        }
        Ok(cmd::RpWriteOutcome::DryRun) => {
            // Round 18: dry-run reports the same JSON
            // envelope the JSON consumers expect, with
            // `dry_run: true` so scripts can branch on
            // the flag without parsing the human summary.
            let summary = match leaf {
                _ if leaf.starts_with("set rule-provider add") => "rule provider would be added (dry-run)",
                _ if leaf.starts_with("set rule-provider remove") => "rule provider would be removed (dry-run)",
                _ if leaf.starts_with("set rule-provider enable") => "rule provider would be enabled (dry-run)",
                _ if leaf.starts_with("set rule-provider disable") => "rule provider would be disabled (dry-run)",
                other => other,
            };
            let payload = serde_json::json!({
                "name": name,
                "leaf": leaf,
                "dry_run": true,
            });
            output.success(summary, payload);
            ExitCode::SUCCESS
        }
        Err(error) => {
            let code = match &error {
                cmd::RpWriteError::InvalidName(_) => "rule_provider.invalid_name",
                cmd::RpWriteError::AlreadyDeclared(_) => "rule_provider.already_declared",
                cmd::RpWriteError::NotDeclared(_) => "rule_provider.not_declared",
                cmd::RpWriteError::InvalidBehavior(_) => "rule_provider.invalid_behavior",
                cmd::RpWriteError::InvalidUrl(_) => "rule_provider.invalid_url",
                cmd::RpWriteError::Write(_) => "rule_provider.write_failed",
                cmd::RpWriteError::Parse(_) => "rule_provider.parse_failed",
                cmd::RpWriteError::Validate(_) => "rule_provider.validate_failed",
            };
            let cli = crate::output::CliError::new(code, error.to_string(), leaf);
            crate::output::report_error_returning(output, cli)
        }
    }
}
