//! `Refreshable` — the single shape for "declare a remote
//! source + refresh it".
//!
//! Three resources share the same mental model: a *declared*
//! name, an *underlying URL or path*, a *cached body* under
//! `<state>/...`, and a *refresh* action that re-fetches the
//! body through the SSRF-safe pipeline.
//!
//! - `set sub refresh` — refreshes the body of one or every
//!   subscription source URL.
//! - `set profile refresh` — refreshes the body of one or
//!   every `Remote` profile (depth-first for `Merge`).
//! - `set rule-provider refresh` — refreshes the materialised
//!   body of one or every rule provider.
//!
//! # Round 14: all 3 impls are wired through the typed path
//!
//! `SubscriptionRefresh::refresh` now folds the daemon
//! RPC result (via `client::run_client_collect`) into the
//! shared [`RefreshError`] envelope. `ProfileRefresh`
//! (Round 13) and `RuleProviderRefresh` (still a
//! `RefreshError::Other` planned-stub for the not-yet-shipped
//! `WireCommand::RuleProviderRefresh`) round out the trio.

use std::process::ExitCode;

use crate::output::CliOutput;

/// Per-call context shared across all `Refreshable` impls.
/// The `apply` / `dry_run` semantics are decided by the leaf
/// in `commands::set` before constructing the context; this
/// struct only carries the resolved values.
///
/// A `Refreshable` whose semantics are "refresh always
/// writes" (e.g. `set profile refresh`) constructs the context
/// with `apply: true, dry_run: false` and ignores the input
/// flags. The `Refreshable` impl is the source of truth for
/// the policy.
#[allow(dead_code)] // fields are public for future API; only `output` is read today
pub struct RefreshContext<'a> {
    pub output: CliOutput,
    /// Ignored by refreshes that always write. Kept so the
    /// trait can grow a "skip writes" outcome in the future
    /// without breaking the call site.
    pub apply: bool,
    pub dry_run: bool,
    /// The user-typed command line (e.g.
    /// `"set profile refresh team"`). Used in the error
    /// envelope so the dispatch can name the failing leaf.
    pub command: &'a str,
}

impl<'a> RefreshContext<'a> {
    /// Convenience constructor: a "always write" refresh.
    /// Used by `set profile refresh` / `set rule-provider
    /// refresh` where `--apply` / `--dry-run` are not
    /// exposed.
    pub const fn always_writes(output: CliOutput, command: &'a str) -> Self {
        Self { output, apply: true, dry_run: false, command }
    }
}

/// Uniform shape of "what to refresh" across the three
/// remote resources. Each `Refreshable` impl projects its
/// domain identifier into this enum so the dispatch in
/// `commands::set` can route the right one.
#[allow(dead_code)] // `SubscriptionUrl` is reserved for Round 14 `set sub refresh` route
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RefreshTarget {
    /// A single subscription source URL.
    SubscriptionUrl(String),
    /// A single declared profile id.
    ProfileId(String),
    /// A single declared rule-provider name.
    RuleProviderName(String),
}

impl RefreshTarget {
    pub fn as_str(&self) -> &str {
        match self {
            Self::SubscriptionUrl(s) | Self::ProfileId(s) | Self::RuleProviderName(s) => s,
        }
    }

    /// Stable family code for the JSON error envelope.
    /// Round 13: a single function, no per-resource string
    /// duplication.
    #[allow(dead_code)] // public API; future callers (Round 14) will use it
    pub fn family(&self) -> &'static str {
        match self {
            Self::SubscriptionUrl(_) => "sub",
            Self::ProfileId(_) => "profile",
            Self::RuleProviderName(_) => "rule_provider",
        }
    }
}

/// What a refresh can report. Implementations that produce
/// only a count can use [`RefreshOutcome::fetched`];
/// richer implementations can attach a custom summary.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct RefreshOutcome {
    /// Number of bodies that were actually re-fetched (a
    /// `NotModified` HTTP 304 does **not** count).
    pub fetched: usize,
    /// Optional human-readable summary (e.g. "refreshed 2
    /// remote profile(s)"). The implementations that produce
    /// a count-only summary can leave this as `None` and the
    /// caller falls back to a default line.
    pub summary: Option<String>,
}

impl RefreshOutcome {
    pub fn fetched(count: usize) -> Self {
        Self { fetched: count, summary: None }
    }

    #[allow(dead_code)] // public API; future callers (Round 14) will use it
    pub fn with_summary(mut self, summary: impl Into<String>) -> Self {
        self.summary = Some(summary.into());
        self
    }
}

/// Unified refresh error type. Each `Refreshable` impl maps
/// its domain-specific failure (e.g. `ProfileCmdError`,
/// `SubscriptionRefreshFailure`) into one of these
/// variants; the dispatch then maps to a stable
/// `code: &'static str` for the JSON envelope.
#[derive(Debug)]
pub enum RefreshError {
    /// The operator-supplied identifier is not declared in
    /// the resource's config.
    NotDeclared { family: &'static str, id: String },
    /// The body could not be fetched (network or SSRF).
    Fetch { family: &'static str, id: String, reason: String },
    /// `Merge.parts` referenced a `Remote` whose fetch failed;
    /// the outer error wraps the inner failure so the
    /// operator sees both the offender and the cause.
    FetchChain { family: &'static str, id: String, reason: String },
    /// The on-disk cache write failed.
    Store { family: &'static str, id: String, reason: String },
    /// Catch-all for refreshes that don't have a more
    /// specific shape yet.
    Other { family: &'static str, id: String, reason: String },
}

impl RefreshError {
    /// Stable error code (e.g. `"profile.not_declared"`).
    pub fn code(&self) -> &'static str {
        match self {
            Self::NotDeclared { family, .. } => match *family {
                "sub" => "sub.not_declared",
                "profile" => "profile.not_declared",
                "rule_provider" => "rule_provider.not_declared",
                _ => "refresh.not_declared",
            },
            Self::Fetch { family, .. } => match *family {
                "sub" => "sub.fetch_failed",
                "profile" => "profile.fetch",
                "rule_provider" => "rule_provider.fetch_failed",
                _ => "refresh.fetch",
            },
            Self::FetchChain { family, .. } => match *family {
                "profile" => "profile.fetch_chain",
                _ => "refresh.fetch_chain",
            },
            Self::Store { family, .. } => match *family {
                "profile" => "profile.store",
                _ => "refresh.store",
            },
            Self::Other { family, .. } => match *family {
                "profile" => "profile.refresh_failed",
                "sub" => "sub.refresh_failed",
                "rule_provider" => "rule_provider.refresh_failed",
                _ => "refresh.failed",
            },
        }
    }

    #[allow(dead_code)] // public API; future callers (Round 14) will use it
    pub fn id(&self) -> &str {
        match self {
            Self::NotDeclared { id, .. }
            | Self::Fetch { id, .. }
            | Self::FetchChain { id, .. }
            | Self::Store { id, .. }
            | Self::Other { id, .. } => id,
        }
    }

    pub fn message(&self) -> String {
        match self {
            Self::NotDeclared { family, id } => format!("{family} `{id}` is not declared"),
            Self::Fetch { family, id, reason } => format!("{family} `{id}` fetch: {reason}"),
            Self::FetchChain { family, id, reason } => format!("{family} `{id}` chain fetch: {reason}"),
            Self::Store { family, id, reason } => format!("{family} `{id}` store: {reason}"),
            Self::Other { family, id, reason } => format!("{family} `{id}` refresh: {reason}"),
        }
    }

    pub fn hint(&self) -> Option<&'static str> {
        match self {
            Self::NotDeclared { family, .. } => match *family {
                "profile" => Some("declare it first with `caly profile add <id> ...`"),
                "sub" => Some("configure the URL in <config>/config.yaml and run `caly sub refresh`"),
                "rule_provider" => Some("declare it with `caly set rule-provider add-http|add-file|add-inline <name> ...`"),
                _ => None,
            },
            Self::Fetch { .. } | Self::FetchChain { .. } =>
                Some("check the URL, your network, and the SSRF guard; try `--dry-run` first"),
            Self::Store { family, .. } => match *family {
                "profile" => Some("check the state directory is writable"),
                _ => None,
            },
            Self::Other { .. } => None,
        }
    }
}

impl std::fmt::Display for RefreshError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str(&self.message())
    }
}

impl std::error::Error for RefreshError {}

/// A "remote source" resource that can be refreshed.
pub trait Refreshable {
    /// Refreshes the resource identified by `target`. The
    /// `ctx` carries the apply / dry-run / output channel.
    fn refresh(
        target: &RefreshTarget,
        ctx: &RefreshContext<'_>,
    ) -> Result<RefreshOutcome, RefreshError>;

    /// Renders the success line for `outcome` in human mode.
    /// The default `format!("refreshed {} item(s)",
    /// outcome.fetched)` is what most resources use; rule
    /// providers override to include the provider name.
    #[allow(dead_code)] // trait default; current dispatch uses `report_refreshed` directly
    fn format_outcome(target: &RefreshTarget, outcome: &RefreshOutcome) -> String {
        let _ = target;
        outcome
            .summary
            .clone()
            .unwrap_or_else(|| format!("refreshed {} item(s)", outcome.fetched))
    }
}

// ── Three concrete impls ────────────────────────────────────

/// `set sub refresh` dispatch. Round 14: the actual
/// daemon RPC is folded into this trait impl via the
/// new `client::run_client_collect` (returns
/// `Result<(), ClientError>`). The dispatch in
/// `commands::set::sub` still has a fallback bridge
/// for the offline-everything path, but the canonical
/// `Refreshable::refresh` path is now real and emits
/// the unified `RefreshError` envelope.
pub struct SubscriptionRefresh;

impl Refreshable for SubscriptionRefresh {
    fn refresh(
        target: &RefreshTarget,
        ctx: &RefreshContext<'_>,
    ) -> Result<RefreshOutcome, RefreshError> {
        let _ = ctx;
        // The refresh always targets the whole
        // `subscriptions.sources` list (a per-URL
        // refresh is reserved for Round 15+ when the
        // daemon gains a single-source RPC). The
        // `target` is therefore advisory — kept in the
        // `RefreshOutcome` summary so the operator can
        // see which URL was the entry point.
        let url = match target {
            RefreshTarget::SubscriptionUrl(url) => url.clone(),
            _ => "(all)".to_owned(),
        };
        crate::client::run_client_collect(
            &crate::client::ClientCommand::RefreshSubscription,
            &crate::cli::CliOptions::default(),
        )
        .map_err(|error| {
            let family = "sub";
            let reason = error.to_string();
            let id = url.clone();
            match error {
                caly_protocol::client::ClientError::TransportUnavailable => {
                    RefreshError::Fetch { family, id, reason }
                }
                caly_protocol::client::ClientError::DecodeRejected { reason, .. } => {
                    RefreshError::Fetch { family, id, reason }
                }
                _ => RefreshError::Other { family, id, reason },
            }
        })?;
        Ok(RefreshOutcome::fetched(1).with_summary(format!("refreshed subscription source `{url}`")))
    }

    fn format_outcome(target: &RefreshTarget, outcome: &RefreshOutcome) -> String {
        let RefreshTarget::SubscriptionUrl(url) = target else {
            return format!("refreshed {} subscription source(s)", outcome.fetched);
        };
        format!("refreshed subscription source `{url}`")
    }
}

/// `set profile refresh` dispatch. Round 13: delegates to
/// `client::profile::refresh_all`, mapping `ProfileCmdError`
/// into the shared `RefreshError` shape.
pub struct ProfileRefresh;

impl Refreshable for ProfileRefresh {
    fn refresh(
        target: &RefreshTarget,
        ctx: &RefreshContext<'_>,
    ) -> Result<RefreshOutcome, RefreshError> {
        let id = match target {
            RefreshTarget::ProfileId(id) => Some(id.as_str()),
            _ => None,
        };
        let paths = crate::client::profile::resolve_paths();
        crate::client::profile::refresh_all(&paths, id).map_or_else(
            |err| {
                use crate::client::profile::ProfileCmdError as E;
                let family = "profile";
                let mapped = match &err {
                    E::NotDeclared(name) => RefreshError::NotDeclared {
                        family,
                        id: name.clone(),
                    },
                    E::Fetch(reason) => RefreshError::Fetch {
                        family,
                        id: id.unwrap_or("(all)").to_owned(),
                        reason: reason.to_string(),
                    },
                    E::FetchChain { id, source } => RefreshError::FetchChain {
                        family,
                        id: id.clone(),
                        reason: source.to_string(),
                    },
                    E::Store(reason) => RefreshError::Store {
                        family,
                        id: id.unwrap_or("(all)").to_owned(),
                        reason: reason.to_string(),
                    },
                    _ => RefreshError::Other {
                        family,
                        id: id.unwrap_or("(all)").to_owned(),
                        reason: err.to_string(),
                    },
                };
                // The dispatch path is `commands::set::profile::dispatch`,
                // which owns the error envelope. Returning
                // `Err(mapped)` is enough.
                let _ = ctx;
                Err(mapped)
            },
            |count| Ok(RefreshOutcome::fetched(count)),
        )
    }
}

/// `set rule-provider refresh` dispatch. Round 13: stub —
/// the materialised body is on the daemon's
/// `RuleProviderStore` (not exposed in the CLI today);
/// the CLI will route through a new
/// `WireCommand::RuleProviderRefresh` once it lands.
pub struct RuleProviderRefresh;

impl Refreshable for RuleProviderRefresh {
    fn refresh(
        target: &RefreshTarget,
        ctx: &RefreshContext<'_>,
    ) -> Result<RefreshOutcome, RefreshError> {
        let _ = target;
        let _ = ctx;
        // Round 13: until `WireCommand::RuleProviderRefresh`
        // is in place, this leaf is a `planned_ok`
        // (Round 12 contract). Returning Ok with 0 fetched
        // would mislead the operator, so we report
        // `Other` with an explicit "planned" reason.
        Err(RefreshError::Other {
            family: "rule_provider",
            id: target.as_str().to_owned(),
            reason: "rule-provider refresh wire command ships in Round 14".to_owned(),
        })
    }
}

// ── Dispatch helpers ─────────────────────────────────────────
//
// Round 14 note: `SubscriptionRefresh::refresh` now drives
// the daemon RPC itself (the bridge shim is kept for the
// `set sub refresh` dispatch path's offline-fallback
// shape, but the canonical path is the trait). The
// dispatch helpers below are still the single render
// point for success / error envelopes so the three impls
// emit the same JSON shape.

/// Round 13: print the success envelope for a refresh in
/// human or JSON mode. Centralised so the three impls emit
/// the same JSON shape.
#[allow(dead_code)]
pub fn report_refreshed(
    output: CliOutput,
    target: &RefreshTarget,
    outcome: &RefreshOutcome,
) {
    let summary = match target {
        RefreshTarget::SubscriptionUrl(url) =>
            format!("refreshed {} subscription source(s) for {url}", outcome.fetched),
        RefreshTarget::ProfileId(id) =>
            format!("refreshed profile `{id}` ({} source(s))", outcome.fetched),
        RefreshTarget::RuleProviderName(name) =>
            format!("refreshed rule-provider `{name}`"),
    };
    let payload = serde_json::json!({
        "refreshed": outcome.fetched,
        "target": target.as_str(),
    });
    output.success(&summary, payload);
}

/// Round 13: print a structured error envelope for a refresh
/// failure.
#[allow(dead_code)]
pub fn report_refresh_error(
    output: CliOutput,
    error: &RefreshError,
    command: &str,
) -> ExitCode {
    let mut cli_error = crate::output::CliError::new(
        error.code(),
        error.message(),
        command,
    );
    if let Some(hint) = error.hint() {
        cli_error = cli_error.with_hint(hint);
    }
    crate::output::report_error_returning(output, cli_error)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn refreshable_trait_shape_is_locked() {
        // The 3 impls satisfy the trait. Compile-time check.
        fn assert_refreshable<T: Refreshable>() {}
        assert_refreshable::<SubscriptionRefresh>();
        assert_refreshable::<ProfileRefresh>();
        assert_refreshable::<RuleProviderRefresh>();
    }

    #[test]
    fn refresh_target_family_is_stable() {
        assert_eq!(RefreshTarget::SubscriptionUrl("x".to_owned()).family(), "sub");
        assert_eq!(RefreshTarget::ProfileId("x".to_owned()).family(), "profile");
        assert_eq!(
            RefreshTarget::RuleProviderName("x".to_owned()).family(),
            "rule_provider"
        );
    }

    #[test]
    fn refresh_error_codes_are_stable() {
        let err = RefreshError::NotDeclared {
            family: "profile",
            id: "team".to_owned(),
        };
        assert_eq!(err.code(), "profile.not_declared");
        assert_eq!(err.id(), "team");
        assert!(err.hint().is_some());

        let err = RefreshError::Fetch {
            family: "sub",
            id: "https://x".to_owned(),
            reason: "timeout".to_owned(),
        };
        assert_eq!(err.code(), "sub.fetch_failed");
        assert_eq!(err.id(), "https://x");
        assert!(err.hint().is_some());
    }

    #[test]
    fn subscription_refresh_folds_no_daemon_into_fetch_error() {
        // Round 14: the `SubscriptionRefresh::refresh`
        // trait impl drives the daemon RPC through
        // `client::run_client_collect`. When no daemon
        // is running, the call returns
        // `ClientError::TransportUnavailable` and the
        // trait must fold it into a typed
        // `RefreshError::Fetch` (so the dispatch can
        // surface the same JSON envelope as the other
        // two resources — no special case for "sub").
        let target = RefreshTarget::SubscriptionUrl("https://example.com/sub".to_owned());
        let ctx = RefreshContext::always_writes(
            crate::output::CliOutput::from_json_flag(false),
            "set sub refresh",
        );
        // The daemon isn't running in the unit-test
        // environment, so the RPC must report a fetch
        // failure with the right family / id shape.
        let result = <SubscriptionRefresh as Refreshable>::refresh(&target, &ctx);
        match result {
            Err(RefreshError::Fetch { family, id, .. })
            | Err(RefreshError::Other { family, id, .. }) => {
                assert_eq!(family, "sub");
                assert_eq!(id, "https://example.com/sub");
            }
            Err(other) => assert!(
                matches!(other, RefreshError::Fetch { .. } | RefreshError::Other { .. }),
                "expected a Fetch/Other envelope, got {other:?}"
            ),
            Ok(_) => assert!(
                matches!(result, Err(RefreshError::Fetch { .. }) | Err(RefreshError::Other { .. })),
                "no daemon must surface as a typed RefreshError, got {result:?}"
            ),
        }
    }
}
