//! `caly doctor` — offline daemon/environment diagnostics.
//!
//! Each check runs without a running daemon and reports a stable verdict, so a
//! user can diagnose a broken install or runtime path before starting the
//! daemon. Output is human text by default and structured JSON with `--json`.

use std::{
    panic::{AssertUnwindSafe, catch_unwind},
    path::{Path, PathBuf},
    process::{Command, Stdio},
};

use serde::Serialize;

use caly_backends::platform::detect_desktop_mode;
use caly_platform::{paths::AppPaths, uds::validate_uds_path};

/// Stable diagnostic verdict for one check.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum DoctorVerdict {
    Ok,
    Warn,
    Fail,
}

/// Machine-readable evidence attached to an individual diagnostic.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum DoctorDetail {
    Path {
        path: PathBuf,
        exists: bool,
    },
    UdsPath {
        path: PathBuf,
        safe_to_bind: bool,
    },
    Desktop {
        mode: String,
        supported_backends: Vec<String>,
    },
}

/// One diagnostic result with a stable identifier, human summary and optional
/// structured evidence for scripts.
#[derive(Clone, Debug, Eq, PartialEq, Serialize)]
pub struct DoctorResult {
    #[serde(rename = "check")]
    pub name: String,
    pub category: &'static str,
    pub verdict: DoctorVerdict,
    pub detail: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<DoctorDetail>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub remediation: Option<String>,
}

impl DoctorResult {
    fn make(name: &str, verdict: DoctorVerdict, detail: String) -> Self {
        let category = match name {
            "runtime-dir" | "state-dir" | "config-dir" | "core-workdir" => "filesystem",
            "socket" | "uds-safe" => "security",
            "system-proxy" => "desktop",
            _ => "runtime",
        };
        let remediation = match (&verdict, name) {
            (DoctorVerdict::Warn, "config-dir") => Some("run `caly config generate` to create a documented config".to_owned()),
            (DoctorVerdict::Warn, "runtime-dir" | "state-dir" | "core-workdir") => Some("start `caly daemon`; required directories are created automatically".to_owned()),
            (DoctorVerdict::Warn, "socket") => Some("start `caly daemon` if you intend to use client commands".to_owned()),
            (DoctorVerdict::Warn, "system-proxy") => Some("use GNOME, KDE Plasma, or niri; otherwise configure the system proxy manually".to_owned()),
            (DoctorVerdict::Warn, "core-binaries") => Some("run scripts/fetch-test-kernels.sh, or point core_binaries at installed executables in the config".to_owned()),
            (DoctorVerdict::Warn, "tun-device") => Some("load the tun kernel module (modprobe tun) or run in an environment that exposes /dev/net/tun; or set tun.enabled to false".to_owned()),
            (DoctorVerdict::Warn, "tun-cap") => Some("run `caly doctor --fix` to grant CAP_NET_ADMIN to ip and the core binaries with a single sudo prompt".to_owned()),
            (DoctorVerdict::Fail, "uds-safe") => Some("remove the unsafe socket path only after confirming no daemon owns it, then restart caly".to_owned()),
            (DoctorVerdict::Fail, _) => Some("inspect the diagnostic detail and report a reproducible failure".to_owned()),
            _ => None,
        };
        Self {
            name: name.to_owned(),
            category,
            verdict,
            detail,
            data: None,
            remediation,
        }
    }

    fn with_data(mut self, data: DoctorDetail) -> Self {
        self.data = Some(data);
        self
    }

    fn ok(name: &str, detail: String) -> Self {
        Self::make(name, DoctorVerdict::Ok, detail)
    }
    fn warn(name: &str, detail: String) -> Self {
        Self::make(name, DoctorVerdict::Warn, detail)
    }
    fn fail(name: &str, detail: String) -> Self {
        Self::make(name, DoctorVerdict::Fail, detail)
    }
}

/// One offline diagnostic implementation keyed by a stable check name.
type DoctorCheck = fn(&AppPaths) -> DoctorResult;

/// Runs all offline diagnostics against the resolved runtime paths.
pub fn run_checks(env: &dyn Fn(&str) -> Option<std::ffi::OsString>) -> Vec<DoctorResult> {
    let paths = AppPaths::from_env_vars(env);
    let checks: [(&str, DoctorCheck); 10] = [
        ("runtime-dir", check_runtime_dir),
        ("state-dir", check_state_dir),
        ("config-dir", check_config_dir),
        ("socket", check_socket_path),
        ("uds-safe", |paths| check_uds_safety(&paths.socket_path())),
        ("system-proxy", |_| check_desktop_proxy()),
        ("core-workdir", check_core_work_dir),
        ("core-binaries", check_core_binaries),
        ("tun-device", check_tun_device),
        ("tun-cap", check_tun_cap),
    ];
    checks
        .into_iter()
        .map(|(name, check)| {
            catch_unwind(AssertUnwindSafe(|| check(&paths))).unwrap_or_else(|_| {
                DoctorResult::fail(name, "check panicked during execution".to_owned())
            })
        })
        .collect()
}

fn check_runtime_dir(paths: &AppPaths) -> DoctorResult {
    let exists = paths.runtime.exists();
    let result = if exists {
        DoctorResult::ok("runtime-dir", format!("{} exists", paths.runtime.display()))
    } else {
        DoctorResult::warn(
            "runtime-dir",
            format!(
                "{} does not exist (created on daemon start)",
                paths.runtime.display()
            ),
        )
    };
    result.with_data(DoctorDetail::Path {
        path: paths.runtime.clone(),
        exists,
    })
}

fn check_state_dir(paths: &AppPaths) -> DoctorResult {
    let exists = paths.state.exists();
    let result = if exists {
        DoctorResult::ok("state-dir", format!("{} exists", paths.state.display()))
    } else {
        DoctorResult::warn(
            "state-dir",
            format!(
                "{} does not exist (created on first write)",
                paths.state.display()
            ),
        )
    };
    result.with_data(DoctorDetail::Path {
        path: paths.state.clone(),
        exists,
    })
}

fn check_config_dir(paths: &AppPaths) -> DoctorResult {
    let exists = paths.config.exists();
    let result = if exists {
        DoctorResult::ok("config-dir", format!("{} exists", paths.config.display()))
    } else {
        DoctorResult::warn(
            "config-dir",
            format!("{} does not exist (defaults apply)", paths.config.display()),
        )
    };
    result.with_data(DoctorDetail::Path {
        path: paths.config.clone(),
        exists,
    })
}

fn check_socket_path(paths: &AppPaths) -> DoctorResult {
    let socket = paths.socket_path();
    let exists = socket.exists();
    let result = if exists {
        DoctorResult::ok("socket", format!("{} present", socket.display()))
    } else {
        DoctorResult::warn(
            "socket",
            format!("{} not present (daemon not running)", socket.display()),
        )
    };
    result.with_data(DoctorDetail::Path {
        path: socket,
        exists,
    })
}

fn check_uds_safety(socket: &Path) -> DoctorResult {
    let safe = validate_uds_path(socket).is_ok();
    let result = if safe {
        DoctorResult::ok("uds-safe", format!("{} is safe to bind", socket.display()))
    } else {
        DoctorResult::fail(
            "uds-safe",
            format!(
                "{} is a non-owner or non-socket node; refusing to overwrite",
                socket.display()
            ),
        )
    };
    result.with_data(DoctorDetail::UdsPath {
        path: socket.to_path_buf(),
        safe_to_bind: safe,
    })
}

fn check_desktop_proxy() -> DoctorResult {
    let mode = detect_desktop_mode();
    let mode_name = format!("{mode:?}");
    let supported = !matches!(mode, caly_backends::platform::DesktopProxyMode::Unsupported);
    let result = if supported {
        DoctorResult::ok(
            "system-proxy",
            "a supported desktop proxy backend is available".to_owned(),
        )
    } else {
        DoctorResult::warn(
            "system-proxy",
            "no supported desktop proxy backend (GNOME/KDE/niri) detected".to_owned(),
        )
    };
    result.with_data(DoctorDetail::Desktop {
        mode: mode_name,
        supported_backends: vec!["gnome".to_owned(), "kde".to_owned(), "niri".to_owned()],
    })
}

fn check_core_work_dir(paths: &AppPaths) -> DoctorResult {
    let path = paths.core_work_dir();
    let exists = path.exists();
    let result = if exists {
        DoctorResult::ok("core-workdir", format!("{} exists", path.display()))
    } else {
        DoctorResult::warn(
            "core-workdir",
            format!("{} does not exist (created on core start)", path.display()),
        )
    };
    result.with_data(DoctorDetail::Path { path, exists })
}

/// Verifies that both managed core executables resolve to an existing,
/// executable file. A missing kernel is the most common daemon start failure,
/// so doctor surfaces it before the user hits it at runtime.
fn check_core_binaries(paths: &AppPaths) -> DoctorResult {
    let configured =
        crate::daemon_config::core_binaries_from(paths.config.clone()).unwrap_or_default();
    let mut all_ok = true;
    let mut lines = Vec::new();
    for (name, configured_path) in [
        ("mihomo", configured.mihomo),
        ("sing-box", configured.sing_box),
    ] {
        let path = configured_path.unwrap_or_else(|| bundled_core_binary(name));
        if is_executable(&path) {
            lines.push(format!("{name}: {} (executable)", path.display()));
        } else {
            all_ok = false;
            lines.push(format!(
                "{name}: {} (missing or not executable)",
                path.display()
            ));
        }
    }
    let detail = lines.join("; ");
    if all_ok {
        DoctorResult::ok("core-binaries", detail)
    } else {
        DoctorResult::warn("core-binaries", detail)
    }
}

/// Warns when the config enables TUN but the kernel TUN device node is
/// missing/unreadable, because the core process will then exit at start.
/// Resolves the kernel TUN device node the core needs when TUN is enabled.
fn check_tun_device(paths: &AppPaths) -> DoctorResult {
    let enabled = crate::daemon_config::load_from(paths.config.clone())
        .ok()
        .flatten()
        .is_some_and(|config| config.tun.enabled);
    if !enabled {
        return DoctorResult::ok(
            "tun-device",
            "tun disabled in config (device not needed)".to_owned(),
        );
    }
    let dev = Path::new("/dev/net/tun");
    if dev.exists() {
        DoctorResult::ok("tun-device", "/dev/net/tun present".to_owned())
    } else {
        DoctorResult::warn(
            "tun-device",
            "tun.enabled is true but /dev/net/tun is missing (the core will fail to start)"
                .to_owned(),
        )
    }
}

/// Warns when TUN is enabled and any of the processes that need it lack
/// `CAP_NET_ADMIN`: the `ip` binary (engaging the interface) and the managed
/// core binaries (opening the TUN device). Missing grants are the most common
/// silent TUN failure, so doctor names the exact binaries and points at
/// `caly doctor --fix` for a single-password remediation.
fn check_tun_cap(paths: &AppPaths) -> DoctorResult {
    let enabled = crate::daemon_config::load_from(paths.config.clone())
        .ok()
        .flatten()
        .is_some_and(|config| config.tun.enabled);
    if !enabled {
        return DoctorResult::ok(
            "tun-cap",
            "tun disabled in config (capability not needed)".to_owned(),
        );
    }
    let mut missing = Vec::new();
    let mut detail = Vec::new();
    for (label, path) in tun_capability_targets(paths) {
        let has = has_cap_net_admin(&path);
        detail.push(format!(
            "{}: {} ({})",
            label,
            path.display(),
            if has { "cap" } else { "no cap" }
        ));
        if !has {
            missing.push(label);
        }
    }
    let joined = detail.join("; ");
    if missing.is_empty() {
        DoctorResult::ok("tun-cap", joined)
    } else {
        DoctorResult::warn(
            "tun-cap",
            format!("{joined}; run `caly doctor --fix` to grant CAP_NET_ADMIN with one sudo prompt"),
        )
    }
}

/// The binaries that need `CAP_NET_ADMIN` when TUN is enabled: the `ip`
/// command the daemon runs to create/configure the interface, plus both
/// managed core binaries (whichever is active opens the TUN device).
fn tun_capability_targets(paths: &AppPaths) -> Vec<(&'static str, PathBuf)> {
    let configured =
        crate::daemon_config::core_binaries_from(paths.config.clone()).unwrap_or_default();
    let mut targets = Vec::new();
    targets.push(("ip", resolve_ip_binary()));
    for (name, configured_path) in [
        ("mihomo", configured.mihomo),
        ("sing-box", configured.sing_box),
    ] {
        let path = configured_path.unwrap_or_else(|| bundled_core_binary(name));
        targets.push((name, path));
    }
    targets
}

/// Resolves the `ip` executable the daemon uses, preferring the PATH lookup
/// (the daemon spawns `ip` by name), falling back to `/usr/sbin/ip` and
/// `/sbin/ip` where the command lives on typical Linux distributions.
fn resolve_ip_binary() -> PathBuf {
    let path_var = std::env::var_os("PATH");
    if let Some(search) = path_var {
        for directory in std::env::split_paths(&search) {
            let candidate = directory.join("ip");
            if is_executable(&candidate) {
                return candidate;
            }
        }
    }
    for fallback in ["/usr/sbin/ip", "/sbin/ip"] {
        if is_executable(Path::new(fallback)) {
            return PathBuf::from(fallback);
        }
    }
    PathBuf::from("ip")
}

/// Whether a binary currently carries `cap_net_admin` (checked via `getcap`;
/// missing `getcap` or a missing binary reports false).
fn has_cap_net_admin(path: &Path) -> bool {
    let output = Command::new("getcap")
        .arg(path)
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .output();
    match output {
        Ok(output) if output.status.success() => {
            String::from_utf8_lossy(&output.stdout).contains("cap_net_admin")
        }
        _ => false,
    }
}

/// Grants `CAP_NET_ADMIN` to every binary that needs it for TUN (the `ip`
/// binary plus the managed core binaries), through ONE sudo prompt. All
/// `setcap` calls run inside a single escalated `sh -c`, so the user
/// authenticates once; sudo's credential cache covers the whole batch.
/// Idempotent: binaries that already carry the capability are skipped.
pub fn grant_tun_capabilities() -> Result<(), String> {
    let paths = AppPaths::from_env();
    let targets = tun_capability_targets(&paths);
    let mut missing = Vec::new();
    for (label, path) in &targets {
        if !path.exists() {
            println!("doctor: {label} {} — missing, skipping", path.display());
            continue;
        }
        if has_cap_net_admin(path) {
            println!("doctor: {label} {} — already has CAP_NET_ADMIN", path.display());
        } else {
            println!("doctor: {label} {} — needs CAP_NET_ADMIN", path.display());
            missing.push(path.clone());
        }
    }
    if missing.is_empty() {
        println!("doctor: nothing to grant");
        return Ok(());
    }
    // One escalated batch: quote every path as a single shell word.
    let grants = missing
        .iter()
        .map(|path| format!("setcap cap_net_admin=+ep '{}'", shell_quote(path)))
        .collect::<Vec<_>>()
        .join(" && ");
    let status = Command::new("sudo")
        .args(["sh", "-c"])
        .arg(grants)
        .status()
        .map_err(|error| format!("cannot run sudo: {error}"))?;
    if !status.success() {
        return Err("sudo setcap failed (check the password and that setcap is installed)".to_owned());
    }
    println!("doctor: granted CAP_NET_ADMIN to {} binary(ies)", missing.len());
    Ok(())
}

/// Quotes a path for embedding into a shell word, escaping single quotes.
fn shell_quote(path: &Path) -> String {
    path.to_string_lossy().replace('\'', "'\\''")
}

/// Mirrors the composition-root fallback: a `vendor/bin` kernel bundled next
/// to the executable, then the historical CWD-relative path.
fn bundled_core_binary(name: &str) -> PathBuf {
    if let Ok(executable) = std::env::current_exe() {
        for directory in executable.ancestors() {
            let candidate = directory.join("vendor").join("bin").join(name);
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    PathBuf::from("vendor").join("bin").join(name)
}

fn is_executable(path: &Path) -> bool {
    use std::os::unix::fs::PermissionsExt;
    path.metadata()
        .is_ok_and(|meta| meta.is_file() && meta.permissions().mode() & 0o111 != 0)
}

/// Renders the diagnostics as human-readable lines.
pub fn render_human(results: &[DoctorResult]) -> String {
    let mut out = String::new();
    for result in results {
        let mark = match result.verdict {
            DoctorVerdict::Ok => "ok  ",
            DoctorVerdict::Warn => "warn",
            DoctorVerdict::Fail => "fail",
        };
        let _ = std::fmt::Write::write_fmt(
            &mut out,
            format_args!("{mark}  {:<16} {}\n", result.name, result.detail),
        );
    }
    out
}

/// Renders the diagnostics as one-line JSON.
pub fn render_json(results: &[DoctorResult]) -> Result<String, serde_json::Error> {
    serde_json::to_string(results)
}

/// Returns whether any check failed (used for the process exit code).
pub fn any_failed(results: &[DoctorResult]) -> bool {
    results.iter().any(|r| r.verdict == DoctorVerdict::Fail)
}

#[cfg(test)]
mod doctor_tests;
