//! caly composition root.

#![forbid(unsafe_code)]

use std::process::ExitCode;

use cli::{Command, parse_args};
use caly_domain::DaemonInstanceId;

pub mod bootstrap;
mod cli;
mod client;
mod daemon_config;
mod dns;
mod doctor;
mod logging;
mod subscription;
mod tui;

fn main() -> ExitCode {
    install_broken_pipe_hook();
    let _ = logging::init();
    let args = std::env::args().skip(1);
    match parse_args(args) {
        Ok(invocation) => run(invocation.command, invocation.options),
        Err(error) => {
            let code = error.exit_code();
            let _ = error.print();
            ExitCode::from(u8::try_from(code).unwrap_or(2))
        }
    }
}

/// Exits quietly with the conventional SIGPIPE code (128+13) when stdout was
/// closed by a downstream consumer (for example `caly status | head`). The
/// crate forbids unsafe code, so SIGPIPE cannot be restored directly; instead
/// the panic raised by a failed stdout write is intercepted here before any
/// backtrace reaches the user.
fn install_broken_pipe_hook() {
    let default = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let is_broken_pipe = info
            .payload()
            .downcast_ref::<std::io::Error>()
            .is_some_and(|error| error.kind() == std::io::ErrorKind::BrokenPipe)
            || info.to_string().contains("Broken pipe");
        if is_broken_pipe {
            std::process::exit(141);
        }
        default(info);
    }));
}

fn run(command: Command, options: cli::CliOptions) -> ExitCode {
    if !matches!(&command, Command::Daemon)
        && (options.mihomo_bin.is_some() || options.sing_box_bin.is_some())
    {
        eprintln!("--mihomo-bin and --sing-box-bin are valid only with `caly daemon`");
        return ExitCode::from(2);
    }
    match command {
        Command::Help => {
            // clap owns canonical help output. The explicit command remains as
            // a compatibility spelling alongside `--help`.
            let _ = parse_args(["--help".to_owned()]).map_err(|error| error.print());
            ExitCode::SUCCESS
        }
        Command::Version => {
            println!("caly {}", env!("CARGO_PKG_VERSION"));
            ExitCode::SUCCESS
        }
        Command::Completions(shell) => {
            if options.json {
                eprintln!("--json cannot be used with generated shell completions");
                ExitCode::from(2)
            } else {
                cli::generate_completions(shell);
                ExitCode::SUCCESS
            }
        }
        Command::Daemon => {
            // The daemon is not a thin client; `--json` has no meaning here.
            if options.json {
                eprintln!("--json is only valid for client commands");
                return ExitCode::from(2);
            }
            run_daemon(options)
        }
        Command::Status => client::run_client(ClientCommand::Status, options),
        Command::Core(core) => client::run_client(ClientCommand::Core(core), options),
        Command::Sub(sub) => match sub {
            cli::SubCmd::Check { path, userinfo } => {
                run_subscription_check(&path, userinfo.as_deref(), options.json)
            }
            cli::SubCmd::Refresh => client::run_client(ClientCommand::RefreshSubscription, options),
            cli::SubCmd::List => run_subscription_list(options.json),
            cli::SubCmd::Import { path, clipboard } => {
                run_subscription_import(path.as_deref(), clipboard, options.json)
            }
        },
        Command::Sys(sys) => client::run_client(ClientCommand::Sys(sys), options),
        Command::Config(config) => client::run_client(ClientCommand::Config(config), options),
        Command::Tui => tui::run_tui(options),
        Command::Doctor(fix) => run_doctor(options, fix),
        Command::Dns(domain) => dns::run_dns(domain),
    }
}

/// Client-facing command surface (maps the tree leaves to protocol calls).
#[derive(Clone, Debug)]
pub enum ClientCommand {
    Status,
    Core(cli::CoreCmd),
    RefreshSubscription,
    Sys(cli::SysCmd),
    Config(cli::ConfigCmd),
}

/// Runs `caly sub check` against a subscription file.
fn run_subscription_check(path: &std::path::Path, userinfo: Option<&str>, json: bool) -> ExitCode {
    match subscription::inspect_subscription_with_userinfo(path, userinfo) {
        Ok(summary) => {
            if json {
                println!("{}", subscription::render_json(&summary));
            } else {
                print!("{}", subscription::render_human(&summary));
            }
            if subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error }));
            } else {
                eprintln!("subscription check failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

/// Runs `caly sub import` — parses a proxy-URI list from a file or the
/// clipboard and reports the parsed nodes (an offline preview like `sub check`).
pub fn run_subscription_import(
    path: Option<&std::path::Path>,
    clipboard: bool,
    json: bool,
) -> ExitCode {
    // `--clipboard` and a path are mutually exclusive; using neither means
    // the clipboard is the implicit source.
    let summary = match (clipboard, path) {
        (true, Some(_)) => {
            eprintln!("error: `sub import --clipboard` takes no path argument");
            return ExitCode::from(2);
        }
        (true, None) | (false, None) => subscription::read_clipboard(),
        (false, Some(path)) => subscription::inspect_subscription_with_userinfo(path, None),
    };
    match summary {
        Ok(summary) => {
            if json {
                println!("{}", subscription::render_json(&summary));
            } else {
                print!("{}", subscription::render_human(&summary));
                if summary.format == "url-list" {
                    println!(
                        "This is a subscription *source* (fetchable URL). It is not persisted by `import`; add its URL to `subscriptions.sources` in config.yaml and it will appear in `caly sub list` as the default provider."
                    );
                } else {
                    println!(
                        "Preview only — nothing was saved. These are proxy node URIs (no upstream subscription URL), so they cannot form a subscription provider and won't appear in `sub list`. Paste a source subscription URL for a refreshable provider."
                    );
                }
            }
            if subscription::is_usable(&summary) {
                ExitCode::SUCCESS
            } else {
                ExitCode::from(1)
            }
        }
        Err(error) => {
            if json {
                eprintln!("{}", serde_json::json!({ "ok": false, "error": error }));
            } else {
                eprintln!("subscription import failed: {error}");
            }
            ExitCode::FAILURE
        }
    }
}

/// Runs `caly sub list` — lists the configured subscription providers and, for
/// the auto 枚举型 `default` provider, the subscription sources it contains
/// (`subscriptions.url` folded in alongside any explicit `sources`). Read-only;
/// mirrors `config validate`'s client-side config view.
pub fn run_subscription_list(json: bool) -> ExitCode {
    let root = caly_platform::paths::AppPaths::from_env().config;
    let (sources, providers) = match crate::daemon_config::load_from(root) {
        Ok(None) => (Vec::new(), Vec::new()),
        Ok(Some(config)) => {
            let sources = config.subscriptions.enabled_source_urls();
            let providers = config.resolved_providers();
            (sources, providers)
        }
        Err(error) => {
            if json {
                eprintln!(
                    "{}",
                    serde_json::json!({ "ok": false, "error": error.to_string() })
                );
            } else {
                eprintln!("subscription list failed: {error}");
            }
            return ExitCode::FAILURE;
        }
    };
    if providers.is_empty() {
        if json {
            println!(
                "{}",
                serde_json::json!({ "providers": [], "sources": [], "count": 0 })
            );
        } else {
            println!("no subscription provider configured");
            println!(
                "hint: set `subscriptions.url` or `subscriptions.sources` in config.yaml to create the default provider"
            );
        }
        return ExitCode::SUCCESS;
    }
    if json {
        let provider_items: Vec<serde_json::Value> = providers
            .iter()
            .map(|provider| {
                let embedded_sources: Vec<serde_json::Value> = sources
                    .iter()
                    .enumerate()
                    .map(|(index, url)| {
                        serde_json::json!({ "index": index, "url": url, "enabled": true })
                    })
                    .collect();
                serde_json::json!({
                    "name": provider.name,
                    "kind": match &provider.kind {
                        caly_config::schema::ProviderKind::SubscriptionSources => "subscription-sources",
                        caly_config::schema::ProviderKind::InlineNodes(_) => "inline-nodes",
                    },
                    "sources": embedded_sources,
                })
            })
            .collect();
        println!(
            "{}",
            serde_json::json!({
                "providers": provider_items,
                "sources": sources.iter().map(String::as_str).collect::<Vec<_>>(),
                "count": sources.len(),
            })
        );
    } else {
        for provider in &providers {
            match &provider.kind {
                caly_config::schema::ProviderKind::SubscriptionSources => {
                    println!(
                        "provider: {} (enumeration of {} source(s))",
                        provider.name,
                        sources.len()
                    );
                    for (index, url) in sources.iter().enumerate() {
                        println!("  [{}] {} (enabled)", index + 1, url);
                    }
                }
                caly_config::schema::ProviderKind::InlineNodes(nodes) => {
                    println!(
                        "provider: {} ({} inline node(s))",
                        provider.name,
                        nodes.len()
                    );
                    for node in nodes {
                        println!("  - {node}");
                    }
                }
            }
        }
        println!("{} provider(s)", providers.len());
    }
    ExitCode::SUCCESS
}

/// Runs the offline `caly doctor` diagnostics and reports them. With `--fix`,
/// missing TUN `CAP_NET_ADMIN` grants are first applied through a single sudo
/// prompt, then the full diagnostic set is re-run so the user sees the outcome.
fn run_doctor(options: cli::CliOptions, fix: bool) -> ExitCode {
    if fix {
        if let Err(error) = doctor::grant_tun_capabilities() {
            eprintln!("doctor fix failed: {error}");
            return ExitCode::FAILURE;
        }
        println!();
    }
    let results = doctor::run_checks(&|key| std::env::var_os(key));
    if options.json {
        match doctor::render_json(&results) {
            Ok(json) => println!("{json}"),
            Err(error) => {
                eprintln!("cannot render doctor JSON: {error}");
                return ExitCode::FAILURE;
            }
        }
    } else {
        print!("{}", doctor::render_human(&results));
    }
    if doctor::any_failed(&results) {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

/// Resolves every config-driven setting from one layered config load; an
/// invalid config fails the whole boot (never silently runs on env defaults).
fn resolve_daemon_config() -> Result<daemon_config::DaemonSettings, daemon_config::DaemonConfigError>
{
    daemon_config::resolve_daemon(caly_platform::paths::AppPaths::from_env().config)
}

fn run_daemon(options: cli::CliOptions) -> ExitCode {
    // Resolve owner-only XDG runtime/state/data roots for the daemon.
    let paths = caly_platform::paths::AppPaths::from_env();
    // A fresh per-boot epoch identity, so a restarted daemon is distinguishable
    // from the previous instance (epoch/snapshot recovery) by clients.
    let daemon_id = DaemonInstanceId::from_bytes(caly_platform::entropy::random_bytes::<16>());
    let lock = match acquire_lock(paths.lock_path()) {
        Ok(value) => value,
        Err(message) => {
            tracing::error!(daemon = ?daemon_id, "daemon lock failed: {message}");
            return ExitCode::FAILURE;
        }
    };
    // Resolve every config-driven setting; a broken config fails boot so the
    // daemon never silently runs on stale env defaults.
    let mut settings = match resolve_daemon_config() {
        Ok(value) => value,
        Err(error) => {
            tracing::error!(daemon = ?daemon_id, "daemon configuration invalid: {error}");
            let _ = lock.release();
            return ExitCode::FAILURE;
        }
    };
    if let Err(code) = apply_daemon_overrides(&mut settings, options, daemon_id) {
        let _ = lock.release();
        return code;
    }
    let mut assembly = match bootstrap::DaemonAssembly::new(
        daemon_id,
        settings.core_override,
        settings.tun,
        settings.controllers,
        settings.binaries,
        settings.subscription_url,
        settings.tuning,
    ) {
        Ok(value) => value,
        Err(error) => {
            tracing::error!(daemon = ?daemon_id, "daemon composition failed: {error:?}");
            let _ = lock.release();
            return ExitCode::FAILURE;
        }
    };
    if !bootstrap_ready(&mut assembly) {
        let _ = lock.release();
        return ExitCode::FAILURE;
    }
    let daemon = match start_daemon_runtime(
        assembly.application,
        daemon_id,
        paths.socket_path(),
        settings.listen,
        settings.auto_start_core,
    ) {
        Ok(value) => value,
        Err(error) => {
            tracing::error!(daemon = ?daemon_id, "{error}");
            let _ = lock.release();
            return ExitCode::FAILURE;
        }
    };
    let socket = daemon.socket.clone();
    tracing::info!(
        daemon = ?daemon_id,
        socket = %socket.display(),
        listen = ?daemon.listen,
        "caly daemon started"
    );
    let result = daemon.serve();
    let shutdown_error = daemon.shutdown();
    finish_daemon(result.and(shutdown_error), lock, &socket)
}

/// Applies one-run CLI overrides: `--core`, `--mihomo-bin`, `--sing-box-bin`.
/// Explicit flags are intentionally last in the precedence order, so a service
/// manager can override an installed config for one run.
fn apply_daemon_overrides(
    settings: &mut daemon_config::DaemonSettings,
    options: cli::CliOptions,
    daemon_id: DaemonInstanceId,
) -> Result<(), ExitCode> {
    // `--core` is a daemon-level one-run override, just like binary paths.
    // Previously it was validated by the CLI but silently ignored by daemon
    // bootstrap, causing `daemon --core sing-box` to start Mihomo.
    if let Some(core) = options.core.as_deref() {
        settings.core_override = match core {
            "mihomo" => Some(caly_domain::CoreKind::Mihomo),
            "sing-box" => Some(caly_domain::CoreKind::SingBox),
            // Defensive: clap ValueEnum rejects this before run_daemon, but a
            // daemon bootstrap must still fail closed if that contract changes.
            _ => {
                tracing::error!(daemon = ?daemon_id, "invalid daemon core override");
                return Err(ExitCode::from(2));
            }
        };
    }
    if options.mihomo_bin.is_some() {
        settings.binaries.mihomo = options.mihomo_bin;
    }
    if options.sing_box_bin.is_some() {
        settings.binaries.sing_box = options.sing_box_bin;
    }
    Ok(())
}

mod daemon;

use daemon::{acquire_lock, bootstrap_ready, finish_daemon, start_daemon_runtime};
