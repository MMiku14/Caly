//! Real daemon + UDS + kernel lifecycle E2E.
//!
//! The ordinary test suite reports a skip when pinned binaries are absent.
//! `CALY_REQUIRE_REAL_E2E=1` turns missing prerequisites into a hard failure.

use std::{
    fs,
    net::{TcpListener, TcpStream},
    os::unix::net::UnixStream,
    path::{Path, PathBuf},
    process::{Child, Command, ExitStatus},
    thread,
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};

const START_TIMEOUT: Duration = Duration::from_secs(12);
const STOP_TIMEOUT: Duration = Duration::from_secs(5);

struct DaemonGuard {
    child: Child,
    runtime: PathBuf,
}

impl DaemonGuard {
    fn terminate(mut self) -> Result<ExitStatus, String> {
        signal_term(self.child.id())?;
        wait_for_exit(&mut self.child, STOP_TIMEOUT)
    }
}

impl Drop for DaemonGuard {
    fn drop(&mut self) {
        // Graceful TERM first so the daemon stops and reaps its core process;
        // a bare SIGKILL orphans the kernel, whose ports then block the next
        // test phase. Fall back to KILL only if the daemon does not exit.
        if self.child.try_wait().ok().flatten().is_none() {
            let _ = signal_term(self.child.id());
            let deadline = Instant::now() + STOP_TIMEOUT;
            while Instant::now() < deadline {
                if self.child.try_wait().ok().flatten().is_some() {
                    break;
                }
                thread::sleep(Duration::from_millis(20));
            }
            if self.child.try_wait().ok().flatten().is_none() {
                let _ = self.child.kill();
                let _ = self.child.wait();
            }
        }
        // A killed or stalled daemon can orphan its managed kernel, whose
        // ports would poison the next phase; reap by runtime-path match.
        let _ = Command::new("pkill")
            .args(["-9", "-f"])
            .arg(self.runtime.display().to_string())
            .status();
    }
}

#[test]
fn real_daemon_lifecycle_for_pinned_kernels() -> Result<(), String> {
    let root = workspace_root();
    let mihomo = root.join("vendor/bin/mihomo");
    let sing_box = root.join("vendor/bin/sing-box");
    if !mihomo.is_file() || !sing_box.is_file() {
        if require_real_e2e() {
            return Err(
                "pinned kernels are required; run scripts/fetch-test-kernels.sh".to_owned(),
            );
        }
        eprintln!("skipping: pinned Mihomo/sing-box binaries are unavailable");
        return Ok(());
    }
    let mihomo_port = alloc_port()?;
    let mihomo_runtime = unique_runtime("mihomo")?;
    run_core(&root, "mihomo", &mihomo, mihomo_port, &mihomo_runtime)?;
    let sing_port = alloc_port()?;
    let sing_runtime = unique_runtime("sing-box")?;
    run_core(&root, "sing-box", &sing_box, sing_port, &sing_runtime)
}

/// The owner-only UDS socket path the daemon binds under an XDG runtime root.
fn socket_path(runtime: &Path) -> PathBuf {
    runtime.join("caly").join("daemon.sock")
}

fn run_core(
    _root: &Path,
    core: &str,
    binary: &Path,
    controller_port: u16,
    runtime: &Path,
) -> Result<(), String> {
    fs::create_dir_all(runtime).map_err(|error| error.to_string())?;
    let lock = runtime.join("caly.lock");
    let workdir = runtime.join("caly").join("cores").join(core);
    fs::create_dir_all(&workdir).map_err(|error| error.to_string())?;
    let mut command = Command::new(caly_binary());
    let log = runtime.join("daemon.log");
    let log_handle = fs::File::create(&log).map_err(|error| error.to_string())?;
    command
        .arg("daemon")
        .env("CALY_CORE", core)
        .env("CALY_LOCK", &lock)
        .env("CALY_MIHOMO_DIR", &workdir)
        .env("XDG_RUNTIME_DIR", runtime)
        .env("XDG_STATE_HOME", runtime.join("state"))
        .env("XDG_CONFIG_HOME", runtime.join("config"))
        .env("HOME", runtime)
        .stdout(log_handle.try_clone().map_err(|error| error.to_string())?)
        .stderr(log_handle);
    if core == "sing-box" {
        command.env("CALY_SINGBOX_BIN", binary);
        command.env(
            "CALY_SINGBOX_CONTROLLER",
            format!("127.0.0.1:{controller_port}"),
        );
    } else {
        command.env("CALY_MIHOMO_BIN", binary);
        command.env(
            "CALY_MIHOMO_CONTROLLER",
            format!("127.0.0.1:{controller_port}"),
        );
    }
    let child = command.spawn().map_err(|error| error.to_string())?;
    let daemon = DaemonGuard {
        child,
        runtime: runtime.to_path_buf(),
    };
    let socket = socket_path(runtime);
    wait_for_socket(&socket, START_TIMEOUT)?;
    wait_for_port(controller_port, START_TIMEOUT).map_err(|error| {
        let log = fs::read_to_string(runtime.join("daemon.log")).unwrap_or_default();
        format!("{error}\ndaemon log:\n{log}")
    })?;

    let status = client(core, runtime, &["status", "--json"])?;
    if !status.contains(&format!("\"core\":\"{core}\""))
        || !status.contains("\"run_state\":\"running\"")
    {
        return Err(format!("unexpected {core} status: {status}"));
    }
    check_config_apply(core, runtime)?;
    client(core, runtime, &["core", "restart", "--json"])?;
    client(core, runtime, &["core", "stop", "--json"])?;
    wait_for_port_closed(controller_port, STOP_TIMEOUT)?;
    client(core, runtime, &["core", "start", "--json"])?;
    wait_for_port(controller_port, START_TIMEOUT)?;

    let status = daemon.terminate()?;
    if !status.success() {
        return Err(format!("{core} daemon exited with {status}"));
    }
    if socket.exists() || lock.exists() {
        return Err(format!("{core} daemon leaked socket or lock"));
    }
    if let Err(error) = fs::remove_dir_all(runtime) {
        return Err(error.to_string());
    }
    Ok(())
}

fn check_config_apply(core: &str, runtime: &Path) -> Result<(), String> {
    // Exercise the config-apply loop: render → validate → commit. Both cores
    // publish an owner-only generation under the XDG config root (sing-box
    // landed its dedicated backend, so no more fail-fast).
    let apply = client(core, runtime, &["config", "apply", "--json"])?;
    if !apply.contains("\"state\":3") {
        return Err(format!("config apply did not complete: {apply}"));
    }
    let committed = if core == "mihomo" {
        runtime.join("config").join("caly").join("mihomo.yaml")
    } else {
        runtime.join("config").join("caly").join("sing-box.json")
    };
    if !committed.is_file() {
        return Err(format!(
            "config apply did not publish {}",
            committed.display()
        ));
    }
    Ok(())
}

/// The thin JSON-framed client used to drive daemon operations.
fn client(core: &str, runtime: &Path, arguments: &[&str]) -> Result<String, String> {
    let output = Command::new(caly_binary())
        .args(arguments)
        .env("CALY_CORE", core)
        .env("XDG_RUNTIME_DIR", runtime)
        .output()
        .map_err(|error| error.to_string())?;
    if !output.status.success() {
        return Err(format!(
            "client {:?} failed: stderr={} stdout={}",
            arguments,
            String::from_utf8_lossy(&output.stderr),
            String::from_utf8_lossy(&output.stdout)
        ));
    }
    String::from_utf8(output.stdout).map_err(|error| error.to_string())
}

fn wait_for_socket(path: &Path, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if UnixStream::connect(path).is_ok() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("socket did not become ready: {}", path.display()))
}

fn wait_for_port(port: u16, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if TcpStream::connect(("127.0.0.1", port)).is_ok() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("controller port {port} did not become ready"))
}

fn wait_for_port_closed(port: u16, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if TcpStream::connect(("127.0.0.1", port)).is_err() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(20));
    }
    Err(format!("controller port {port} remained open"))
}

fn wait_for_exit(child: &mut Child, timeout: Duration) -> Result<ExitStatus, String> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if let Some(status) = child.try_wait().map_err(|error| error.to_string())? {
            return Ok(status);
        }
        thread::sleep(Duration::from_millis(20));
    }
    let _ = child.kill();
    child.wait().map_err(|error| error.to_string())
}

fn signal_term(pid: u32) -> Result<(), String> {
    let status = Command::new("kill")
        .args(["-TERM", &pid.to_string()])
        .status()
        .map_err(|error| error.to_string())?;
    if status.success() {
        Ok(())
    } else {
        Err(format!("cannot signal daemon {pid}: {status}"))
    }
}

/// Allocates a free TCP port by binding a listener and releasing it; the
/// daemon binds it moments later, so collisions are practically impossible.
fn alloc_port() -> Result<u16, String> {
    let listener = TcpListener::bind(("127.0.0.1", 0)).map_err(|error| error.to_string())?;
    let port = listener
        .local_addr()
        .map_err(|error| error.to_string())?
        .port();
    drop(listener);
    Ok(port)
}

/// A short runtime root under `/tmp`: the historical workspace-root layout
/// exceeded the 108-byte Unix `SUN_LEN` for the UDS socket on deep checkouts.
fn unique_runtime(core: &str) -> Result<PathBuf, String> {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|error| error.to_string())?
        .as_nanos();
    Ok(std::env::temp_dir().join(format!("caly-e2e-{core}-{nanos}")))
}

fn workspace_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .and_then(Path::parent)
        .unwrap_or_else(|| Path::new("."))
        .to_path_buf()
}

fn caly_binary() -> &'static str {
    env!("CARGO_BIN_EXE_caly")
}

fn require_real_e2e() -> bool {
    std::env::var("CALY_REQUIRE_REAL_E2E").as_deref() == Ok("1")
}
