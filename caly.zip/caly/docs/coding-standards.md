# Caly Coding Standards

Status: Mandatory baseline.

## Architecture

- Dependency violations require an ADR; comments do not grant exceptions.
- Domain contains no concrete I/O, runtime, platform, path or wire types.
- Thin clients depend directly only on Domain and Transport.
- The binary is assembly only.

## Errors

- Libraries use structured, classifiable errors.
- Production paths do not use `unwrap`, `expect` or `panic!`.
- Errors state what failed, relevant safe context, and the next action.
- Best-effort failure is observable and declares degraded semantics.

## Concurrency

- Each mutable aggregate has one owner.
- No data lock is held across await, network, file or process I/O.
- Every channel is bounded with documented backpressure/drop behavior.
- Every spawned task has an owner, cancellation condition and join path.
- Blocking/CPU-heavy work uses an owned worker mechanism.

## Resources and security

- Process trees, not only direct children, are terminated and reaped.
- Platform side effects have recovery records.
- Atomic owner-only writes are mandatory for sensitive state.
- Unsafe code is denied by default; platform FFI requires a narrow reviewed crate, `SAFETY:` invariants and an ADR.
- Secrets never enter logs, generic serialization or display DTOs.

## Maintainability

- Prefer functions around 50 lines; complex business functions must not exceed 80 lines without an approved split plan.
- Source files should remain at or below 400 lines.
- Public APIs document failure, ownership and cancellation semantics.
- Incomplete work belongs in `TODO.md`, not source `TODO`/`FIXME` comments.

## Verification claims

Never claim compilation or tests passed unless that exact command was run against the current HEAD. Real-kernel E2E scope must list both assertions made and assertions not made.
