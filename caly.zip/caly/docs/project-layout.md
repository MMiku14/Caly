# Project Layout

> 说明：本文描述**当前**源码目录与语义模块布局（以 `main` 分支为准）。本文会随结构调整同步更新。
> 当前能力与验证状态见 [`../STATUS.md`](../STATUS.md)；分层职责与依赖纪律见 [`architecture.md`](architecture.md)。

Caly 按「变更轴 + 所有权边界」拆分 crate。分层方向为 `Presentation → Transport → Application → Infrastructure → Domain`，
由 [`scripts/check-dependency-discipline.sh`](../scripts/check-dependency-discipline.sh) 强制，跨 crate 移动时保持其通过。

```text
caly/
├── bins/
│   ├── caly/                           # composition root；daemon/TUI/CLI 模式装配
│   └── caly-template-worker/         # 模板渲染的子进程 worker
├── crates/
│   ├── caly-domain/                  # 纯值模型，零 I/O（identity/node/operation/event/state/...）
│   ├── caly-ports/                   # 共享 port trait + 统一有界错误 ActorFailure
│   ├── caly-backends/                # 具体适配器（core/subscription/platform/config/...）
│   ├── caly-kernel/                  # Mihomo/sing-box 适配器与校验（Xray 已放弃）
│   ├── caly-config/                  # schema/loader/cache/subscription 渲染与模板 worker
│   ├── caly-platform/                # 文件系统/进程/路径/命令/TUN/恢复/secrets/UDS
│   ├── caly-application/             # use-case actors/handlers、runtime、composition、projection
│   ├── caly-protocol/                # v2 wire 契约、严格转换、薄客户端
│   ├── caly-server/                  # daemon 端 UDS/TCP JSON-framed 传输与 admission
│   └── caly-tui/                     # 终端薄客户端（btop++ 风格）
├── docs/  fixtures/  scripts/  vendor/
```

## 各 crate 源码布局

```text
caly-domain/src/                     # 纯值模型，无 async/fs/net/path/时钟/随机数
  identity.rs  operation.rs  event.rs  capability.rs
  collection.rs  text.rs  secret.rs  tun.rs
  dns.rs  nameserver.rs              # dns=配置模型；nameserver=Nameserver/FakeIpRange 值类型
  node/
    mod.rs  dialable.rs  display.rs  endpoint.rs  protocol.rs  transport.rs
    source.rs  validation.rs  canonical/{mod.rs, protocol_encode.rs}
                                     # canonical=节点身份 SHA-256 编码；protocol_encode=各协议变体编码

caly-ports/src/                      # 契约层：错误 + port trait，无实现
  error.rs  core.rs  lifecycle.rs  platform.rs  subscription.rs  telemetry.rs  config.rs  tun.rs

caly-backends/src/                   # Infrastructure 具体适配器
  lib.rs  capabilities.rs  desired.rs  dns_env.rs  core.rs  lifecycle.rs
  sing_box.rs  telemetry.rs  template.rs  tests.rs
  config/{mod.rs, config_tests.rs}
  platform/{mod.rs, kde.rs, niri.rs, tun.rs, durable.rs, durable_tun.rs, durable_support.rs}
                                     # durable* = system-proxy/TUN 崩溃恢复；durable_support=共享错误转换
  subscription/{mod.rs, http.rs, cached.rs}

caly-kernel/src/
  ports/  common/mod.rs  validation/{mod.rs, linux.rs}  telemetry/mod.rs
  mihomo/{mod.rs, http.rs, api.rs, config.rs, runtime.rs}
                                     # http.rs 内聚 HTTP 传输 + control probe（transport 已并入）
  sing_box/{mod.rs, http.rs, dns_render.rs, registry.rs, runtime.rs}

caly-config/src/
  schema/{mod.rs, error.rs, settings.rs, kernel.rs, validate.rs}
                                     # error.rs=ConfigError Display；settings.rs=controllers/log/telemetry/
                                     # subscriptions/system-proxy；kernel.rs=kernel+dns 节与 DnsSchemaError；
                                     # validate.rs=跨字段校验与 parse 错误映射
  loader/{mod.rs, file.rs, layered.rs, publish.rs}
  cache/{mod.rs, quota.rs}
  subscription/{mod.rs, uri.rs, special_uri.rs, clash.rs, format.rs, http.rs, policy.rs,
                normalize.rs, chain.rs, transform.rs, userinfo.rs, sing_box.rs,
                sing_box/document.rs,    # SingBoxRenderTuning + 订阅文档头（controller/secret/log/mixed inbound）
                mihomo/{mod.rs, render.rs, mihomo_tests.rs}}
  template_worker/{mod.rs, linux.rs, framing.rs}

caly-platform/src/
  error.rs  entropy.rs  secrets.rs  dns_probe.rs  uds.rs
  command/{mod.rs, linux.rs}
  fs/{mod.rs, linux.rs}
  paths/mod.rs
  process/{mod.rs, linux.rs}
  instance_lock/{mod.rs, identity.rs, linux.rs, reclaim.rs}
  recovery/{mod.rs, store.rs}
  tun/{mod.rs, linux.rs}

caly-application/src/                # 纯 use-case 层
  lib.rs  actor_result.rs  routing.rs  routing_fanout.rs
  command_bus/mod.rs
  operations/{mod.rs, admission.rs, cancellation.rs, record.rs, store.rs, update.rs}
  events/{mod.rs, sequencer.rs}
  projection/{mod.rs, projector.rs, runtime.rs}
  actors/
    mod.rs  core_handler.rs  lifecycle_handler.rs  config_command_handler.rs
    platform_handler.rs  subscription_handler.rs  telemetry_handler.rs  reporting.rs
    platform_command.rs  subscription_command.rs  telemetry_command.rs
                                     # 命名约定：`*_command.rs`=该 actor 的命令枚举；`*_handler.rs`=owner handler
  runtime/                           # actor 运行时：task/取消/有序关闭
    {mod.rs, actor_loop.rs, cancellation.rs, fatal.rs, fatal_mapping.rs,
     shutdown.rs, shutdown_runner.rs, task_group.rs, tokio_executor.rs}
  service/                           # Transport 入口门面
    {mod.rs, command_support.rs, results.rs, shared.rs,
     runtime_service.rs, runtime_service/runtime_service_tests.rs}
                                     # 命名约定：`runtime/`=actor 运行时；`service::runtime_service`=RuntimeService 门面
  composition/                       # daemon 装配根
    {mod.rs, backends.rs, bootstrap.rs, handlers.rs, recovery.rs, shutdown.rs, support.rs,
     composition_tests.rs, backends/lifecycle.rs, handlers/handler_tests.rs,
     recovery/recovery_tests.rs}
                                     # support.rs=任务命名/初始快照/core 解析/能力发布等自由 helper；
                                     # backends/lifecycle.rs=双内核 lifecycle 构建与 owner-only 配置发布
  supervision/{mod.rs, topology.rs}

caly-protocol/src/
  lib.rs  local_ipc/mod.rs  framing.rs  json_serde.rs  wire_frames.rs
  protocol/{mod.rs, v2/{mod.rs, handshake.rs, negotiation.rs, operation.rs, snapshot.rs, watch.rs, budget.rs}}
  conversion/{mod.rs, encode.rs, error.rs, event.rs, identity.rs, operation.rs, snapshot.rs}
  client/{mod.rs, contract.rs, uds.rs}

caly-server/src/
  lib.rs  tcp.rs  uds.rs
  json/{mod.rs, adapter.rs, command.rs, error.rs, event.rs, session.rs, service_v2.rs,
       service.rs, service/live_watch_tests.rs}
  compat/{mod.rs, v1.rs}

caly-tui/src/
  lib.rs  terminal.rs
  model/{mod.rs, session.rs}
  client/{mod.rs, live_source.rs, watch_driver.rs, supervisor.rs}
  operation/{mod.rs, tracker.rs}
  render/{mod.rs, action.rs, canvas.rs, format.rs, hotzone.rs, input.rs, layout.rs, panels.rs, style.rs}
  widgets/{mod.rs, node_list.rs, node_tree.rs, viewport.rs}
  editor/{mod.rs, history.rs}
  app/{mod.rs, notifications.rs, runner.rs, runner/runner_tests.rs}
  examples/
```

## 约定

- `X.rs` 定义的模块，其子模块放 `X/<sub>.rs`；`X/mod.rs` 定义的模块，子模块为同目录下的兄弟文件。
- 测试：较大的模块用独立测试文件，父模块通过 `#[cfg(test)] mod xxx_tests;` 引用；不违反上述 `X.rs`/`X/` 解析规则。
- 单一责任命名：`*_command.rs`（actor 命令枚举）与 `*_handler.rs`（owner handler）成对；`*_tests.rs` 与父模块同目录解析。
