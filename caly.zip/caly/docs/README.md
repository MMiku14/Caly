# Caly 文档索引

## 当前事实入口

- `../STATUS.md`：当前能力、限制与独立验证基线（唯一状态入口）
- `../TODO.md`：按优先级 S1–S4 排序的当前待办
- `../CHANGELOG.md`：用户可见变更记录
- `../README.md`：项目简介与快速上手

## 当前规范与运行文档

- `architecture.md`：目标架构与分层边界；不等同于全部已接线
- `project-layout.md`：workspace 目录结构
- `coding-standards.md`：代码规范与静态检查规则
- `agent-workflow.md`：Agent 迭代、验收和 TODO 协作方式

## 设计决策

- `adr/`：架构决策记录（入口 `adr/README.md`）

## 历史归档（不作为当前完成度依据）

- `archive/verification-2026-08-06.md`：逐轮验证证据日志（以 `STATUS.md` 为准）
- `archive/architecture-drift-analysis-2026-08-04.md`：一次性架构偏移分析
- `archive/CONFIGURATION-REDESIGN-v1-2026-08-04.md`：配置系统重构计划（已落地）
- `archive/TODO-2026-08-06-full-history.md` / `archive/TODO-legacy-2026-08-04.md`：早期 TODO 历史
- `archive/historical/`：已完成的路线图、backlog、重构计划、重构日志与能力地图快照
- `archive/reviews/`：早期 Phase/Runtime/Protocol 审查报告

当前状态以根目录 `STATUS.md` 为准，未完成工作以根目录 `TODO.md` 为准。
