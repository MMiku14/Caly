# Caly 文档索引

> 更新时间：2026-08-07（清理不存在的 `docs/archive/`、`docs/agent-workflow.md`、`docs/adr/` 引用；
> 这些目录与文件在本仓库当前快照中尚未建立，对应入口见 `TODO.md` §S3.3 / §S3.4）

## 当前事实入口

- `../STATUS.md`：当前能力、限制与独立验证基线（唯一状态入口）
- `../TODO.md`：按优先级 S1–S4 排序的当前待办（与 `STATUS.md` 严格一一对应）
- `../CHANGELOG.md`：用户可见变更记录
- `../README.md`：项目简介与快速上手

## 当前规范与运行文档

- `architecture.md`：目标架构与分层边界；不等同于全部已接线
- `project-layout.md`：workspace 目录结构
- `coding-standards.md`：代码规范与静态检查规则

## 暂未建立（引用方请勿链入）

以下目录与文件在 `docs/README.md` 旧版本中被引用，但本仓库当前快照尚未建立：

- `agent-workflow.md`：Agent 迭代、验收和 TODO 协作方式（缺失 — `TODO.md` §S3.4）
- `adr/`：架构决策记录（缺失 — `TODO.md` §S3.4）

建立或删除相关引用见 `TODO.md` §S3.3–S3.4。

## 历史归档

历史归档目录 `docs/archive/`（`STATUS-history-2026-08-05.md`、`TODO-2026-08-06-full-history.md`、
`CONFIGURATION-REDESIGN-v1-2026-08-04.md` 等）在当前快照中尚未建立；当前历史信息以
`CHANGELOG.md` 与 git log 为准。重建或清理引用见 `TODO.md` §S3.3。

---

当前状态以根目录 `STATUS.md` 为准，未完成工作以根目录 `TODO.md` 为准。
