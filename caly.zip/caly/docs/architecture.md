# Caly Architecture Baseline

Date: 2026-08-04
Status: Target architecture with a substantially wired implementation. Lifecycle, Clash-API
adapters, live watch, telemetry, durable recovery, ordered shutdown and the TUI watch loop are
connected; contract-only commands fail fast. Xray has been dropped (`CoreKind::Xray` stays
wire-compatible but is always Unsupported); `config apply` for sing-box is an explicit fail-fast
until the `SingBoxConfigBackend` lands. Treat [`../STATUS.md`](../STATUS.md) as
capability truth and [`../TODO.md`](../TODO.md) as the active remediation backlog.

## 1. Product boundary

Caly is a daemon-first proxy management system for the Mihomo and sing-box proxy cores. The daemon owns configuration, proxy-core processes and platform side effects. TUI and CLI are thin clients.

## 2. Dependency rule

The only permitted product-layer direction is:

```text
Presentation → Transport → Application → Infrastructure → Domain
```

Crate mapping:

| Layer | Crates | Responsibility |
|---|---|---|
| Domain | `caly-domain` | Pure values, errors, identities and state views |
| Infrastructure | `caly-ports`, `caly-backends`, `caly-kernel`, `caly-config`, `caly-platform` | Shared ports, concrete adapters, core APIs, configuration pipelines and OS side effects |
| Application | `caly-application` | Owner actors, operations, coordinators and projection (no concrete backends) |
| Transport | `caly-protocol`, `caly-server` | Wire/client contract and daemon-side admission |
| Presentation | `caly-tui` | Thin client |

Direct inward edges may skip a layer when they do not bypass ownership. In particular, all layers may use pure Domain types. Infrastructure peers may use lower-level `caly-platform` capabilities; they must not form cycles.

`caly-protocol` is intentionally separated from `caly-server`: clients need contracts and connection behavior, but must not acquire daemon application dependencies. The local IPC connector may use `caly-platform`; platform-specific implementation remains in that platform crate.

The binary is the composition root and may depend on all layers solely to assemble them. Product logic must not be placed in the binary.

### Forbidden edges

- Domain → any outer layer
- Infrastructure → Application, Transport or Presentation
- Application → Transport or Presentation
- Protocol contracts/client → Application, server or Presentation
- Daemon server → Presentation
- Presentation → Application, Infrastructure or daemon server

## 3. Runtime topology

```text
external mutation
  → Transport admission
  → bounded CommandBus
  → OperationCoordinator/Saga
  → owner actors
  → reliable bounded event ingress
  → single EventSequencer
       ├─ reliable StateProjector channel
       ├─ bounded replay buffer
       └─ best-effort client broadcast
```

Actor dependencies must form a DAG. Actors must not synchronously call one another in a cycle. Cross-owner transactions are driven by an OperationCoordinator that records progress and compensation.

## 4. State model

Five states are distinct and must not share an ambiguous `AppState`:

1. **DesiredState** — persisted user intent.
2. **AppliedState** — configuration acknowledged by the running core.
3. **ObservedState** — telemetry and actual runtime observations.
4. **PlatformEffectState** — system proxy/TUN ownership and recovery status.
5. **PresentationSnapshot** — immutable, redacted client projection.

Concrete platform handles remain inside Infrastructure or their owner actor. Domain exposes only pure views.

## 5. Operation model

Every mutation has an `OperationId`. A client timeout does not cancel an operation. Cancellation is explicit and may return `TooLateToCancel` after a commit point. Pending and running records cannot be evicted; only terminal records are eligible for bounded retention.

## 6. Event ordering

Only EventSequencer allocates event sequences. An event cursor contains both `DaemonInstanceId` and checked `EventSequence`. A daemon-instance mismatch or replay gap requires a full snapshot.

## 7. Resource ownership

- Every spawned task has one owner, cancellation path and awaited shutdown.
- Every process tree has one owner.
- Unix cores use process groups; Windows cores use Job Objects.
- Side effects use RAII where sufficient and durable recovery records where crash recovery is required.
- Template hard timeout requires a worker process; aborting blocking work is not a hard timeout.
- Channels are bounded. Mutation overflow is explicit; telemetry drops are observable.

## 8. Persistence

Multi-file cache commits use immutable generation directories and an atomically replaced `CURRENT` manifest. Sensitive and recovery files are owner-only. Critical replacement includes file and parent-directory durability semantics.

## 9. Secrets

Secrets have redacted `Debug` and `Display`, no general-purpose serialization, no presentation/wire representation, and only scoped exposure for explicit config export or kernel rendering.

## 10. Shutdown order

```text
1. reject new transport mutations
2. close command ingress
3. stop Supervisor
4. settle/cancel coordinators
5. stop Telemetry
6. stop and reap Core process trees
7. restore Platform effects
8. stop Subscription network work
9. finish or roll back Config transactions
10. flush EventSequencer terminal events
11. stop StateProjector
12. release transport and instance lock
```

## 11. Evidence vocabulary

The project distinguishes: implemented, statically checked, compiled, automatically tested, and real platform/kernel E2E validated. One level never implies another.
