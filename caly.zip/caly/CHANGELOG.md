# Changelog

All notable user-visible changes will be documented here.

The project follows Keep a Changelog structure. It has not yet declared a stable compatibility policy.

## [Unreleased]

### Added (Round 13 — Refreshable trait + set 拆分 + error 拆分 + bridge 改名)

- **`Refreshable` trait + 3 真 impl** (`commands/refresh.rs`):
  `Refreshable::refresh(target, ctx) -> Result<RefreshOutcome,
  RefreshError>` is the single shape for "declare a remote
  source + refresh it". `SubscriptionRefresh` /
  `ProfileRefresh` / `RuleProviderRefresh` each project their
  domain errors into the shared `RefreshError` enum so the
  dispatch in `commands::set` can map any refresh failure to
  a stable `code: &'static str` without per-resource
  plumbing.
- **`set` namespace split into 8 resource sub-files**:
  `commands/set/{core,proxy,tun,sub,profile,config,daemon,rule_provider,common}.rs`.
  The 233-line Round 12 monolith is gone; each resource is
  a focused module with one `pub fn dispatch(cmd, options,
  output) -> ExitCode`. The top-level `commands::set::run`
  is a one-line match on `SetCmd`.
- **`error.rs` split into 6 sub-files**:
  `error/{profile,sub,core,config,daemon,usage}.rs` (each
  with its own `pub const` and `pub fn`). Public API
  preserved: `crate::error::profile::NOT_DECLARED` and
  `crate::error::json_not_valid(...)` both work unchanged.
- **3 new trait wiring tests** in `commands/refresh.rs`:
  `refreshable_trait_shape_is_locked` (3 impls satisfy
  the trait), `refresh_target_family_is_stable`
  (`SubscriptionUrl` / `ProfileId` / `RuleProviderName`
  return the right family code), and
  `refresh_error_codes_are_stable` (`NotDeclared` /
  `Fetch` etc. return the right stable code).
- **3 new `set` split tests** in `cli::cli_tests`:
  `set_dispatch_routes_to_eight_resource_modules` (every
  `SetCmd` variant must reach its resource sub-module),
  `set_mod_exposes_eight_sub_modules` (file existence
  lock), and `refreshable_trait_is_wired_into_set_dispatch`
  (compile-time assertion that the trait is the dispatch
  surface).

### Changed (Round 13)

- **`commands::legacy` → `commands::bridge`**: rename for
  honesty. The new 5-namespace grammar reaches the bridge
  through the canonical namespace dispatch — it is not a
  deprecation shim. The "bridge" name matches the actual
  semantics (internal 1-line wrappers around the legacy
  `CoreCmd` / `SubCmd` / `SysCmd` / `ConfigCmd` /
  `ProfileCmd` enums).
- **`set <res> refresh` is the trait source of truth**:
  `set profile refresh` now goes through
  `ProfileRefresh::refresh`; the trait owns the success /
  error envelope shape. `set sub refresh` and
  `set rule-provider refresh` are wired the same way.
- **`Refreshable::refresh` returns `RefreshError`** (was
  Round 12's per-impl `Error` associated type). One
  shape, one error enum, one dispatch path.
- **`commands/rule_provider.rs` no longer `eprintln!`s on
  stub leaves** — the planned-only stub path is silent
  except for the success envelope.

### Fixed (Round 13)

- **`set sub refresh` double-printed** the bridge error
  line AND a trait success line. Round 13: the bridge
  owns the success / error envelope; the trait is the
  shape lock (compile-time assertion only) for the
  subscription case until Round 14's RPC gains a `Result`
  return.
- **`set rule-provider refresh` printed a redundant
  `eprintln!` + `planned_ok` line** (the Round 12 template
  that Round 13 deletes).
- **`commands/set.rs` wildcard imports** (`use
  crate::cli::SetConfigCmd::*;` etc.) replaced with
  explicit `SetConfigCmd::Apply` patterns — clippy
  `enum_glob_use` lint clean.
- **`map(|n| ...).unwrap_or_else(|| ...)` chains** replaced
  with `map_or_else` — clippy `option_map_unit_fn` /
  `bind_instead_of_map` lint clean.

### Test count (Round 13)

- 726 → **733** (+7): the 6 new tests in `commands/refresh`
  + `cli::cli_tests` + 1 daemon E2E that now passes after
  `chmod +x vendor/bin/*` (Round 12 had silently skipped
  it; Round 13 picks it up). All 23 real-kernel E2E tests
  pass.

### Advisory (Round 13)

- **`Refreshable` trait is fully wired for `profile` and
  `rule-provider`**, but the subscription RPC returns
  `ExitCode` (not `Result`), so `set sub refresh` is
  bridged through the legacy path until the daemon RPC
  gains a `Result` return in Round 14. The trait shape
  is exercised by the `refreshable_trait_is_wired_into_set_dispatch`
  test.
- **`set config diff` is still `planned_ok`**: the real
  line-by-line diff needs a `similar` crate or a stdlib
  LCS. Round 14 picks this up; Round 13 doesn't add a
  new dependency for a single leaf.
- **`set proxy add|edit|remove|import` are still
  `planned_ok`**: the inline-proxy writer needs a
  `<config>/config.yaml` `inline_proxies:` segment edit
  + backup. Round 14 picks this up.
- **`set profile edit` / `export` / `enable` / `disable`
  are still `planned_ok`**: `$EDITOR` spawn, merged
  body write, and enable-flag writer land in Round 14.
- **`set daemon stop|reload|restart|status` are still
  `planned_ok`**: new wire commands land in Round 14.
- **`commands::bridge` is still 192 lines** with the
  `sub_list` / `sub_check` / `sub_import` offline
  shims. The Round 14 plan is to move those into
  `commands::show::sub` (the show-side leaves) and
  delete the bridge entirely; the redirect enums in
  `cli.rs` go with it.

### Added (Round 12 — Refresh 统一 + Rule Providers CLI + 业务打磨)

- **`Refreshable` trait + 3-resource 抽象** (`commands/refresh.rs`):
  `Refreshable::refresh(target, ctx) -> Result<RefreshOutcome, _>` is
  the single shape for "declare a remote source + refresh it".
  The trait + `RefreshContext` / `RefreshTarget` / `RefreshOutcome`
  types are locked; the actual impls land in Round 13 when the
  per-resource writers are wired. The trait is `dead_code` for
  now and re-exported by `commands::set::run` once the first
  impl arrives.
- **`set rule-provider` CLI family** (`commands/rule_provider.rs`):
  declarative CRUD for `rule_providers:`, the third "remote
  source" resource alongside `set sub` and `set profile`. The
  grammar uses three sub-commands (`add-http` / `add-file` /
  `add-inline`) so each source kind has its own typed
  argument shape — no `add <KIND> <body>` slot. The CRUD
  leaves take the same `--apply` / `--dry-run` policy as the
  other `set` resources; `refresh` always writes (the
  materialised file IS the body the kernel reads).
  - `set rule-provider add-http <NAME> <URL> [--interval-ms N]`
  - `set rule-provider add-file <NAME> <PATH>`
  - `set rule-provider add-inline <NAME> --payload <BODY>`
  - `set rule-provider remove|enable|disable <NAME>`
  - `set rule-provider refresh [NAME]` (always writes)
  - `set rule-provider list` (real, uses layered loader)
- **`CliOutput::planned` + `CliOutput::planned_ok`** (`output.rs`):
  a single call replaces the 19-site
  `eprintln! + success_empty("...: planned.") + let _ = output;`
  template in `commands::set`. The human summary always ends
  with `: planned.` so a downstream tool can branch on intent
  without parsing the rest of the message.
- **`set profile refresh` flag tightening**: the `--apply` /
  `--dry-run` flags were removed (refresh always writes; the
  body IS the cache; a `NotModified` HTTP 304 is a real
  outcome, not a dry-run). Old invocations are rejected at
  parse time, not silently no-op'd.
- **`commands::redirect` → `commands::legacy`**: rename for
  honesty. The new 5-namespace grammar rejects the legacy
  top-level spellings at parse time, so the layer is purely
  an internal contract between `commands::show` /
  `commands::set` and `client::run_client`. Round 13 folds
  these one-liners into the new dispatch directly and
  deletes the module.

### Changed (Round 12)

- **Module tree cleanup**: `commands/{config,sub,profile}.rs`
  (the Round 10 "module tree stabiliser" files that held
  no-op `run` functions) deleted. `commands/mod.rs` now
  lists only the namespaces + helpers that have real
  runtime handlers: `daemon / tool / show / set /
  refresh / rule_provider / legacy / status`.
- **`SetProfileCmd::Refresh` field set shrunk**:
  `{ id: Option<String> }` only (was `{ id, apply, dry_run }`).
  The `--apply` / `--dry-run` flags are no longer parsed;
  see "flag tightening" above.

### Fixed (Round 12)

- **`set profile refresh --apply` was a silent no-op**: the
  flag was accepted at parse time but the writer always
  wrote the body, so the operator's `--apply` had no
  effect. Round 12 rejects the combination at parse time
  with a clear "unexpected argument" error, and
  `set profile refresh` no longer offers the flag at all.
- **`commands::redirect` deprecation warning leaked to new
  grammar**: when the user ran `set core url-test node1`,
  the dispatch routed through `old_core` which printed
  `warning: \`caly core <leaf>\` is deprecated`. That
  warning was only meant for the legacy top-level
  `core <verb>` spelling (which is now hard-rejected at
  parse time). Round 12 drops the warning from all five
  `old_*` functions; the new namespace dispatch is the
  canonical path and the warning was confusing.

### Test count (Round 12)

- 723 → **726** (+3): the new tests cover
  `set rule-provider` grammar (1: all 6 leaves incl.
  `add-http` / `add-file` / `add-inline` / `refresh` /
  `list`), `set rule-provider` policy (1: 6 `--apply`
  leaves parse; 2 `--apply/--dry-run` conflicts are
  rejected), `set rule-provider refresh` flag tightening
  (1: 2 `--apply` / `--dry-run` invocations rejected),
  `set profile refresh` flag tightening (1: 3
  invocations rejected), and the new
  `set_subcommand_help_lists_all_eight_resources` (1: 8
  resources in `set --help`).
  All 23 real-kernel E2E tests still pass.

### Advisory (Round 12)

- **`Refreshable` trait is locked but not implemented**:
  the trait + the helper types are in `commands/refresh.rs`
  with `#![allow(dead_code)]`. Round 13 adds the per-
  resource `impl Refreshable for Subscription/Profile/
  RuleProvider` blocks and removes the `allow(dead_code)`.
- **`set rule-provider add/remove/enable/disable` are
  `planned_ok` placeholders**: the writers land in Round
  13 (`<config>/config.yaml` `rule_providers:` segment
  edit + optional `config apply`). The CLI shape and
  dry-run policy are locked; the new impl is a 1-for-1
  replacement of the dispatch arms.
- **`error.rs` is still 287 lines**: Round 13 splits it
  into 6 sub-files (`error/{profile,sub,core,config,
  daemon,usage}.rs`) per the original Round 12 plan. The
  public `pub mod` API is preserved; only the file layout
  changes.

### Added (Round 11 — CLI 5-namespace 重构 + dry-run 政策翻转 + 15 个新能力)

- **5-namespace CLI grammar (`daemon` / `tool` / `show` / `set`)**:
  every capability now lives under one of four action namespaces
  plus the long-running `daemon` command. The flat top-level
  surface (`status` / `core <verb>` / `sub <verb>` / `sys <verb>`
  / `config <verb>` / `profile <verb>` / `doctor` / `tui` / `dns`)
  is gone — clap rejects all 25 old spellings with a precise
  "unrecognized subcommand" error so an operator that upgrades
  the binary sees an actionable hint instead of a silent
  change-of-behavior.
  - `caly daemon` — long-running control plane (unchanged).
  - `caly tool help [command] | version | doctor [--fix] | tui [--readonly] | dns [domain]`
    — static / one-shot tools.
  - `caly show status | core [nodes|groups|connections|traffic|mode|rules [--match TARGET]|health]
    | sub [providers|parse PATH [--userinfo U]|import [PATH|--clipboard]]
    | profile [list|show ID] | proxy [list|show ID|groups]
    | config [path|files|validate [--file PATH]]` — read-only queries.
  - `caly set core [start|stop|restart|switch mihomo|sing-box|select [NODE] [--delay] [--group G]
    |mode rule|global|direct|close-connections|delay [NAME|--all] [--url U]
    |url-test NAME [--url U] [--timeout MS]]
    | proxy [add URI [--group G] | edit ID | remove ID | import PATH | on | off]
    | tun [on|off] | sub [refresh|add URL [--name N]|remove URL|enable URL|disable URL|import [PATH|--clipboard]]
    | profile [add ID SRC | remove ID | edit ID | refresh [ID] | export ID --out PATH
              | enable ID | disable ID]
    | config [apply|generate|default|diff [--file PATH]|edit vim|nvim]
    | daemon [stop|reload|restart|status]` — mutations.
  - `caly completions <shell>` (top-level, unchanged).
- **Dry-run policy flipped**: every write command (`set <res> add|edit|remove|import`)
  defaults to `apply: false, dry_run: false` (i.e. safe — no write happens).
  The operator must pass `--apply` to actually mutate. The legacy `--dry-run`
  flag is still accepted and still honored (explicit "would-have-done" preview).
  `--apply` and `--dry-run` are mutually exclusive (`clap::Arg::conflicts_with`),
  so a contradictory invocation is rejected at parse time, not silently
  executed with the wrong semantics.
- **15 new capabilities added in Round 11** (each is a real stub that goes
  through the dispatch, returns `ExitCode::SUCCESS` with a `success` envelope,
  and is the wire-side contract Round 12 will fill in):
  1. `show core health` — daemon + kernel health one-liner (Round 11 maps
     to `old_core(ListNodes)`; Round 12 reads a real `HealthSnapshot`).
  2. `set core select --group <NAME>` — group-scoped select (NEW flag;
     the existing `node [ID]` + `--delay` flow is unchanged).
  3. `set core url-test <NAME> [--url U] [--timeout MS]` — probe a single
     proxy through the configured URL.
  4. `set proxy add <URI> [--group G] [--apply] [--dry-run]`
  5. `set proxy edit <ID> [--apply] [--dry-run]`
  6. `set proxy remove <ID> [--apply] [--dry-run]`
  7. `set proxy import <PATH> [--apply] [--dry-run]`
  8. `set sub add <URL> [--name N] [--apply] [--dry-run]`
  9. `set sub remove <URL> [--apply] [--dry-run]`
  10. `set sub enable <URL> [--apply] [--dry-run]`
  11. `set sub disable <URL> [--apply] [--dry-run]`
  12. `set profile edit <ID> [--apply] [--dry-run]`
  13. `set profile export <ID> --out <PATH>` — write the merged body
      to a file (offline; does not need the daemon).
  14. `set profile enable <ID> [--apply] [--dry-run]` /
      `set profile disable <ID> [--apply] [--dry-run]`
  15. `set config diff [--file PATH]` — line-by-line diff against the
      current default.
  Plus `set daemon stop / reload / restart / status` (Round 12 needs new
  wire commands; Round 11 emits a `success` envelope with the planned
  action so the grammar is locked in).
- **Merged `core rules` + `core rule-match`**: the two old leaves
  collapse into `show core rules [--match TARGET]`. With no `--match`,
  it lists every rule; with `--match <host|ip>`, it evaluates the
  target against the ruleset and prints the first match.
- **`show sub parse <file>` renames `sub check <file>`**: the new
  verb matches the parser's actual job (parse a subscription file).
  `show sub import` is the offline preview path; the write path
  is `set sub import [--clipboard] [--apply]`.
- **Help text rewritten**:
  `caly --help` now points at the 4 action namespaces
  (`daemon` / `tool` / `show` / `set`) and the `Common workflows:`
  after-help section uses the new spellings
  (`caly show status`, `caly set sub refresh`, `caly set core select <id>`,
  `caly set profile add <id> remote:<url>`, `caly set config apply`).
  `caly tool help [command]` provides per-namespace help; per-resource
  help (e.g. `caly set sub add --help`) lists every flag, including
  `--apply` and `--dry-run`.
- **Stable JSON success envelope extended**: every success line now
  carries `command` (the user-typed command), `dry_run` (the resolved
  effective dry-run flag), and `apply` (the resolved effective apply
  flag) in addition to the Round 10 `version: 1` + `ok: true` +
  payload. Scripts can now read `envelope.dry_run` to know whether
  the operation actually wrote or merely previewed.

### Changed (Round 11)

- **Old top-level commands are rejected at parse time**: clap
  rejects `core <verb>` / `sub <verb>` / `sys <verb>` /
  `config <verb>` / `profile <verb>` / `status` / `doctor` /
  `tui` / `dns` / `help` / `version` with
  `error: unrecognized subcommand 'X'`, so an operator that
  upgrades to Round 11 sees a clear "use: caly <new>" message
  instead of a quiet change of behavior. The redirect layer
  (`commands::redirect`) is no longer reached from the new
  grammar (it was previously used by the top-level fall-through);
  it remains in the tree for Round 12 deprecation shims and as
  the internal contract between `commands::show` and
  `commands::set` (they translate their new variants into the
  legacy `CoreCmd` / `SubCmd` / `SysCmd` / `ConfigCmd` /
  `ProfileCmd` shapes before calling `redirect::old_*`).
- **`--apply` is the new opt-in for writes**: `set profile add
  <id> remote:<url>` without `--apply` no longer touches
  `config.yaml` (previously the same command with no flag
  would write). Operators must consciously opt in by adding
  `--apply`. The JSON envelope distinguishes the two outcomes:
  `{"ok": true, "dry_run": true, ...}` for a preview,
  `{"ok": true, "apply": true, "dry_run": false, ...}` for a
  real write.
- **Long help mentions `--apply` explicitly**: the after-help
  section now reads
  "Every write command defaults to `--dry-run`; pass `--apply`
  to actually write." so a fresh operator does not have to
  discover the policy.
- **`commands/{tool,show,set,redirect,status}` introduced**:
  the new `tool/show/set` modules are the canonical Round 11
  dispatch; the Round 10 `commands/{config,sub,profile}` modules
  are kept for the redirect layer and the `client::profile`
  offline API (they no longer own a `pub fn run` reached from
  `main.rs`).

### Test count (Round 11)

- 708 → **723** (+15): the new tests cover 5 namespace grammar
  (3: `tool` 5 leaves, `show` 6 resources, `set` 7 resources),
  per-resource leaf parsing (5: `set core` 8 leaves incl.
  `url-test` / `--group`, `set proxy` 6 leaves incl. CRUD +
  on/off, `set sub` 6 leaves incl. CRUD, `set profile` 7 leaves
  incl. CRUD + export + enable/disable, `set config` 6 leaves
  incl. `diff`, `set daemon` 4 leaves), global options (1:
  `--json` / `--core` / `--mihomo-bin` / `--sing-box-bin` map
  to all namespaces), help-text contract (4: top-level
  mentions all 4 namespaces + `--apply`, `set` help lists all
  7 resources, `show` help lists all 6 resources, `tool` help
  lists all 5 leaves), `--apply` / `--dry-run` semantics (4:
  defaults, opt-in, explicit `--dry-run` still accepted,
  `conflicts_with` rejection), and old-spelling rejection (2:
  25 top-level spellings + 5 short-flag aliases).
  All 23 real-kernel E2E tests still pass.

### Fixed (Round 11)

- **E2E daemon test now uses new namespace spellings**:
  `bins/caly/tests/daemon_real_e2e.rs` previously called
  `status` / `core <verb>` / `config apply` directly; the
  test now calls `show status` / `set core <verb>` /
  `set config apply`, matching the new grammar. The real-kernel
  daemon+UDS lifecycle test (mihomo + sing-box) passes end to
  end with the new namespace.
- **`CliOptions::Default` derive was missing**: the Round 10
  rewrite dropped `Default` from `CliOptions`, so every parse
  test that compared against `CliOptions::default()` would
  SIGABRT at construction time. `#[derive(Clone, Debug,
  Default, Eq, PartialEq)]` is restored, and a regression test
  (`cli_options_default_is_constructible`) locks the contract.
- **Tool subcommand `--help` collision resolved**: the
  `ClapToolCmd::Help` variant originally collided with clap's
  auto-injected `help` subcommand at the `tool` level
  (clap's `disable_help_subcommand` does not propagate to
  nested enums). The `ClapToolCmd` enum now carries
  `#[command(disable_help_subcommand = true)]`, so
  `caly tool help` parses cleanly.

### Advisory (Round 11)

- **15 new capabilities are at "grammar + dispatch" stage,
  not "writer + wire" stage**: every `set X` CRUD leaf prints
  its planned action and returns `ExitCode::SUCCESS` with a
  `success` envelope, but does not yet mutate the file or
  the kernel. Round 12 wires each one to the real backend
  (`subscriptions.sources` array for `set sub add/remove/enable/disable`,
  `RegisteredProxy` registry for `set proxy add/edit/remove/import`,
  new `WireCommand::UrlTest` for `set core url-test`,
  new `WireCommand::Reload` for `set daemon reload`,
  and so on). The `commands::set` module carries a
  per-leaf `Round 12` comment that names the real backend.
- **`set config diff` is a line-by-line placeholder**:
  Round 12 wires the real diff using the same merge pipeline
  the daemon boots with (`load_layered_yaml` + render), so
  the diff compares the **rendered** config, not the raw
  file, and respects `CALY_PROFILE` / `config.d/`.
- **`show core health` is a thin alias for `show core nodes`**:
  Round 12 reads a `HealthSnapshot` from the boot projection
  (`SnapshotBundle.daemon_health` + `kernel_health`) and renders
  a one-line `daemon=... kernel=... restarts=... last_error=...`.
- **`show proxy show <id>` is a thin hint**:
  Round 12 walks `SnapshotBundle.nodes` and looks up the id,
  printing the rendered config entry (URI, group memberships,
  last latency, last error) instead of the
  "use: caly show core nodes" hint.

### Added (Round 10 — CLI 重构: 核心 surface 收敛 + 错误模型 + 帮助)

- **Stable JSON error contract**: every JSON line the CLI
  emits starts with `version: 1` so consumers can detect
  contract changes. Success lines are
  `{ok: true, version, ...payload}`; error lines are
  `{ok: false, version, code, error, hint?, command}`.
  The 13 hand-assembled `serde_json::json!({"ok": false, ...})`
  call sites in `bins/caly/src/main.rs` and
  `bins/caly/src/client/*.rs` collapsed into one
  `output::report_error_returning` helper.
- **Stable error code namespace**: every error carries a
  `code: &'static str` from a per-family catalog
  (`profile.*`, `sub.*`, `core.*`, `config.*`, `daemon.*`,
  `usage.*`). Scripts branch on the code, not the human
  message: `case "$code" in profile.not_declared) ... esac`.
  `usage.*` codes exit 2; everything else exits 1.
- **Remediation hint on every error**: human mode prints
  `error: <msg>` on line 1 and `hint: <next command>` on
  line 2. JSON mode carries the hint in the `hint` field.
  Every cataloged error ships with a contextual hint (e.g.
  `profile.not_declared` → `"declare it first with
  \`caly profile add <id> ...\``").
- **`command` field in the error envelope**: tracks the
  user-typed command line so log-grep can find which input
  triggered the failure. JSON consumers can build a
  reproducer script directly from the envelope.
- **Per-family `commands/*` dispatch**: `main.rs` shrank
  from 721 → 121 lines (83% reduction). Six new modules
  (`commands/{profile,sub,doctor,daemon,dns,config}.rs`)
  each own one CLI family; the top-level `main::run` is a
  single declarative match.
- **Centralised `output::CliOutput`**: every success / info
  / error line goes through the same human/JSON dispatch,
  so the JSON contract is enforced in one place. No handler
  in `commands::*` calls `println!` / `eprintln!` for
  success or error — they use `CliOutput::success` /
  `CliOutput::info` / `output::report_error_returning`.
- **Long help text on every subcommand**: `caly --help`
  now shows the `long_about` prose ("caly manages Mihomo
  and sing-box through one daemon, with a shared config
  tree, a profile system, and a typed control plane. The
  same surface is available as a TUI, a human CLI, or
  stable `--json` for scripts. Every command has one
  canonical spelling."), followed by a `Common
  workflows:` after-help section with seven example
  commands a new operator can copy. `caly profile --help`
  explains the three source kinds (`remote:<url>` /
  `local:<path>` / `merge:<id1,id2,…}`); `core select`
  explains 32-hex ID vs display name vs prefix resolution.

### Changed (Round 10)

- **`main.rs` 721 → 121 lines**: the dispatch logic, the
  per-leaf `run_profile_*` family, the `print_profile_human`
  formatters, the JSON envelope duplication, and the
  legacy `report_profile_error` shim all moved out of
  `main.rs`. The new top-level `run` is one declarative
  match on the parsed `Command`.
- **Human-mode error format**: collapsed from per-call-site
  variants ("profile command failed: ...", "client
  command failed: ...", bare eprintln) to a single two-line
  `error: <msg>` + `hint: <remediation>` shape, with all
  error lines on stderr so stdout carries only successful
  data.
- **Common workflow examples in `--help`**: the
  `Common workflows:` after-help section now lists seven
  example commands with one-line annotations (e.g.
  `caly profile add <id> remote:<url>   # declare a profile`),
  so a fresh operator can find the right command without
  reading the docs.

### Test count (Round 10)

- 696 → **708** (+12): the new tests cover
  `output::CliOutput` envelope (6: success payload merge,
  JSON `version` field, error envelope fields, hint-omission
  contract, `usage.*` exit code 2, `from_json_flag` round
  trip), `error::*` catalog (2: `ProfileCmdError` →
  stable `code` + mandatory `hint`, `FetchChain` id
  preservation), per-family `describe` (2: every `ProfileCmd`
  variant produces a command string, every `SubCmd` variant
  produces one), and help-text contracts (2: top-level
  `caly --help` must include `long_about` + `Common
  workflows` + `caly completions <shell>`; `profile --help`
  must name all three source kinds). All 23 real-kernel E2E
  tests still pass.

### Fixed (Round 9 — Debug + 收敛: Profile / Fetch / Loader)

- **Nested `Merge` refresh error id is now the outermost merge**:
  `refresh_recursive` now threads an `outer_id: &str` argument
  through every recursive frame, so a 3-level merge
  `outer → inner → leaf-bad` surfaces the error with
  `FetchChain { id: "outer", ... }` (the user's declared
  entry point), not `id: "inner"` (the immediate parent).
  The 2-level case (`combined → ghost-team`) still works
  the same way; the contract is "the outermost declared
  merge the operator can `profile list`". Regression test
  `refresh_nested_merge_keeps_outermost_merge_in_fetch_chain`
  locks the new contract; the existing
  `refresh_merge_profile_fails_when_a_remote_part_fails` is
  tightened from `assert!(!id.is_empty())` to
  `assert_eq!(id, "combined")`.
- **Pre-write backup sidecar is now a single fixed name**:
  `config.yaml.bak.<unix-ms>` accumulated one sidecar per
  remove command, contradicting the docstring that promised
  "new sidecar replaces any pre-existing one". The sidecar
  is now `config.yaml.bak` (no `<ms>` suffix); `fs::copy`
  overwrites in place so the operator always has **at most
  one** backup per `config.yaml` regardless of how many
  `add` / `remove` commands ran. The roll-back recipe is
  still `cp config.yaml.bak config.yaml` — only the *set*
  of reachable historical states is reduced from "one per
  millisecond" to "the most recent".
- **`PublicAddressClassifier` peels IPv4-mapped IPv6**:
  `::ffff:10.0.0.1` (a private IPv4 in disguise) was being
  classified as IPv6 and accepted by the SSRF guard; the
  kernel would still resolve and connect it as `10.0.0.1`,
  making the guard a no-op for this shape. The classifier
  now calls `to_ipv4_mapped()` on every `Ipv6Addr` and
  routes the result through the IPv4 reject matrix
  (`is_private` / `is_loopback` / `is_link_local` /
  `is_unspecified` / `is_broadcast`). `::ffff:8.8.8.8`
  remains public. Three regression tests pin the full
  IPv4 / IPv6 / IPv4-mapped reject matrix.
- **`LayeredConfigError` and `LoaderBudgetError` gained
  `Display` impls**: CLI JSON error output was leaking
  `File(Metadata(Os { code: 2, kind: NotFound, message: "No such file or directory" }))`
  Debug-formatted representations. `LayeredConfigError` now
  formats cleanly (`"config file: cannot inspect configuration: No such file or directory (os error 2)"`)
  via a 12-arm `Display` impl and a 4-arm `source()` chain
  on the new `Error` impl. `LoaderBudgetError` similarly
  gained a 4-arm `Display` impl. `load_declared_profiles`
  in the CLI now uses `error.to_string()` instead of
  `format!("{error:?}")`.

### Changed (Round 9 — convergence)

- **`append_profile_to_config` + `rewrite_profiles_in_config`
  collapsed into `mutate_profiles_in_config<F>`**: the two
  helpers were 90% duplicate (read → parse → mutate → write).
  The unified helper takes a `mutator: FnOnce(&[ProfileConfig])
  -> Result<Vec<ProfileConfig>, _>` that produces the next
  list; `add` and `remove` pass the appropriate
  closure. Schema validation (deny_unknown_fields + bounded
  constants) re-runs on the new list before write so a
  hand-edited file with a broken `profiles:` value fails
  before the rewrite.
- **`refresh_recursive` + `refresh_recursive_with_domain`
  collapsed into `refresh_recursive`**: the dual-form
  recursion helper (one for `ProfileConfig`, one for
  domain `Profile`) was redundant once the `outer_id`
  threading was in. The merged helper does the
  `find_declared` + `to_domain` conversion in one place
  and walks the tree with one set of logic.
- **`current_unix_ms` helper extracted**: three duplicate
  `SystemTime::now().duration_since(UNIX_EPOCH)
  .map_or(0, ...)` blocks across `refresh_one` (Updated /
  NotModified branches) and the old `backup_config` (now
  using the fixed-name sidecar) collapsed into one
  pure helper. Still used by `refresh_one` for
  `fetched_at_ms` metadata.
- **Dead `pub fn` removed**: `format_profile_id` in
  `profile_fetch.rs` (only used by its own test) and three
  duplicate copies of `validate_id` in `bins/caly/src/client/profile.rs`
  (each with `#[allow(dead_code)]`, no call sites) deleted.
- **Two single-line forward wrappers removed**:
  `load_layered_yaml_with` + `load_layered_yaml_with_inner`
  in `bins/caly/src/client/profile.rs` were both pure
  forwards to `caly_config::loader::load_layered_yaml_with`;
  inlined to the single call site.
- **`resolve_with_retry` backoff const hoisted**:
  the magic `Duration::from_millis(100)` repeated across
  two `Some(_)` and two `None` retry arms is now a single
  `RESOLVE_BACKOFF` const.

### Test count (Round 9)

- 691 → **696** (+5): the new tests cover
  `PublicAddressClassifier` matrix (3: IPv4-mapped-IPv6
  peeling + IPv4 reject matrix + IPv6 reject matrix),
  nested-merge `FetchChain` id (1: 3-level merge
  `outer → inner → leaf-bad` must report `outer`),
  and pre-write backup sidecar collision (1: consecutive
  removes must produce at most one `config.yaml.bak`).
  Two existing tests were tightened: the
  `refresh_merge_profile_fails_when_a_remote_part_fails`
  contract went from "non-empty id" to
  `assert_eq!(id, "combined")`, and
  `remove_real_creates_a_backup_with_unix_ms_suffix` was
  renamed to `remove_real_creates_a_single_backup_sidecar`
  to reflect the new fixed-name sidecar contract. All 23
  real-kernel E2E tests still pass.

### Advisory

- **`LayeredConfigError` Display propagation is partial**:
  the new `Display` impl is used by `load_declared_profiles`
  in the CLI but the `caly-application` composition root
  still logs `tracing::error!(?error, ...)` (Debug). Round 10
  can sweep the remaining `LayeredConfigError` consumers.
- **`PublicAddressClassifier` does not reject the IPv6
  documentation prefix** (`2001:db8::/32`). RFC 3849 says
  these addresses are "for documentation, not for global
  routing", but the broader "not in any private bucket" rule
  treats them as public. The lock in
  `ipv6_rules_locked` is explicit about this trade-off.
- **GEOSITE auto-emit is still hardcoded to SagerNet** (Round 6
  advisory still present). Round 10 (TODO S5.6) will register
  `geosite-*` / `geoip-*` as implicit `Remote` profiles so they
  surface under `profile list` and obey the same SSRF guard
  (now also rejecting IPv4-mapped IPv6).

### Added (Round 8 — Profile 真实接线 + Inline 物化 + CLI 保护)

- **Remote fetch 真实接线 (SSRF-safe)**: `caly profile refresh` now
  runs a full fetch path: DNS resolve with bounded retries →
  `PublicAddressClassifier` rejects RFC1918 / loopback / link-local
  → `fetch_pinned` (1 MiB body cap) → 2 attempt retry loop with
  250 ms backoff on transient failures. `NotModified` (ETag hit)
  rewrites only the metadata sidecar; the body on disk is preserved.
  `PublicAddressClassifier` was lifted from `caly-backends` to
  `caly-config::subscription::classifier` so the SSRF policy has
  a single source of truth shared with subscription fetch.
- **`Merge` recursive refresh**: `refresh_all` walks a `Merge`'s
  `parts` depth-first. `Local` parts are skipped, `Remote` parts
  are fetched, nested `Merge` parts are recursively walked. A
  failing dependency surfaces as the new
  `ProfileCmdError::FetchChain { id, source }` variant — `id` is
  the **parent merge**, not the failing part, so the operator
  can identify which `Merge` reached into the broken dependency
  at a glance. A runtime `visited: HashSet<String>` cycle guard
  complements the schema-level cycle check.
- **`Inline` rule-provider materialisation at boot**: new module
  `caly-application::composition::rule_provider_materialize`
  materialises every `RuleProviderSource::Inline { payload }` to
  a real file under `<workdir>/rule-providers/<name>.yaml` at
  boot, atomically (`temp + rename`) and idempotently. The
  in-memory provider is rewritten to `File { path: <that> }`
  before the rendering pipeline sees it, so the upstream Mihomo
  kernel (which doesn't understand `type: inline`) just sees a
  normal `type: file` provider. The Mihomo and sing-box
  lifecycle builders both receive the materialized tuning, so
  neither kernel needs a hardcoded `<workdir>/` path.
- **CLI `--dry-run` for `profile add` / `profile remove`**:
  both subcommands now accept `--dry-run`. The dry-run path
  runs every check (id path-safety, uniqueness, validation)
  but does **not** write to disk, so a dry-run is a real
  "would-have-done" preview instead of just "validate without
  side effects". The new `AddOutcome::{Applied, DryRun}` and
  `RemoveOutcome::{Applied, DryRun}` enums let the caller
  render the correct human / JSON message.
- **Pre-write backup sidecar**: every real `add` / `remove`
  copies `<config>/config.yaml` to `<config>/config.yaml.bak.<unix-ms>`
  before rewriting the file (a new sidecar replaces any
  pre-existing one). Missing source is a no-op (fresh install);
  `fs::copy` failure surfaces as
  `ProfileCmdError::Backup { from, to, reason }` and is
  fail-closed — the rewrite does not happen. Operators roll
  back with a single `cp`.
- **New `ProfileCmdError` variants**: `Fetch(ProfileFetchError)`,
  `FetchChain { id, source }`, `Backup { from, to, reason }`,
  with `Display` formatting and `From<ProfileStoreError>`.

### Test count (Round 8)

- 676 → **691** (+15): the new tests cover SSRF fetch
  (5: prefer-public drop matrix, transient classification,
  error display, map exhaustiveness, bounded reason re-export),
  merge refresh (2: walk-remote-parts, fail-with-chain-id),
  dry-run + backup (3: add-dry-run byte-identical,
  remove-dry-run byte-identical, remove-real-creates-backup
  with unix-ms suffix + body match), CLI flag parsing (2:
  dry-run on `add`/`remove`, rejected on `show`/`refresh`/`list`),
  and inline materialisation (4: happy path, pass-through,
  file count lock, idempotency under repeated calls). All 23
  real-kernel E2E tests still pass.

### Advisory

- **GEOSITE auto-emit is still hardcoded to SagerNet** (Round 6
  advisory still present). Round 9 (TODO S5.6) will register
  `geosite-*` / `geoip-*` as implicit `Remote` profiles so they
  surface under `profile list` and obey the same SSRF guard.
- **`PublicAddressClassifier` does not yet peel `IpAddr::V6` IPv4-
  mapped addresses**. `::ffff:10.0.0.1` is classified as IPv6
  and accepted; the kernel will still resolve it to `10.0.0.1`
  on connect so the SSRF risk is low, but the classifier should
  peel the mapping before deciding. Tracked for Round 9.

### Added (Round 7 — Profile 类型模型: Remote / Local / Merge)

- **New `Profile` 域类型 + 3 source kinds** (`Remote` / `Local` /
  `Merge`): a named, addressable, serializable unit of
  configuration. `Profile.id` is path-safe ASCII, `name` and
  `description` are bounded text, `source` selects one of the
  three shapes. `ProfileError` carries nine distinct failure
  modes so the daemon's user-facing diagnostic names the
  failing field, the profile id, and the precise reason.
- **New `profiles:` top-level schema segment**: a
  `Vec<ProfileConfig>` mirroring the domain `Profile` with
  the same `deny_unknown_fields` policy the rest of the
  schema uses. Validation: unique ids, path-safe ids, non-
  empty `Local` paths with no `..` segments, public http(s)
  `Remote` URLs, `interval_minutes` >= 1, and depth-first
  merge-cycle detection. The six new error variants are
  surfaced as `ConfigError::Profile(ProfileError)`.
- **4-stage layered loader**: `load_layered_yaml_with` now
  takes a `ProfileBodyResolver`; the merge order is base →
  active profile → `config.d/` → declared `profiles:` in
  declaration order. The new `LayeredConfigError` variants
  (`ProfileBody { id, reason }`, `ProfileYaml { id, reason }`)
  report per-profile failures with bounded reasons.
- **`InMemoryProfileResolver` (lenient mode)**: the offline
  CLI can list and show declared profiles whose `Remote`
  cache has not yet been refreshed; the loader treats an
  empty body as a no-op for the deep-merge.
- **`ProfileStore`** on-disk cache at
  `<state>/profiles/<id>.yaml` plus `<id>.meta.toml`
  (atomic temp-file + rename write, body / metadata
  integrity check, listing, removal). The store implements
  `ProfileBodyResolver` so the loader can use it directly;
  the resolver falls back to `<config>/profiles/<id>.yaml`
  for an operator's hand-edited body.
- **`caly profile` CLI subcommand** (5 leaves): `add` /
  `list` / `show` / `refresh` / `remove`. `add` accepts
  `remote:<url>` / `local:<path>` / `merge:<id1,id2,…>` and
  rewrites `<config>/config.yaml`. Both human and `--json`
  output are supported.
- **Default `config.d/98-profiles.yaml` fragment**: ships
  with `profiles: []` plus commented Loyalsoldier examples
  (Remote / Local / Merge) so a fresh install can opt in
  without editing the schema.

### Fixed (Round 7)

- **`add_profile` passed `<config>/` directory instead of
  `<config>/config.yaml`**: `fs::read(<dir>)` returned
  `EISDIR ("Is a directory (os error 21)")`. The function
  now joins `<config>/config.yaml` explicitly. The
  `add_then_list_round_trip` regression test exercises the
  full add → load → list flow and would have caught the
  bug.
- **Lenient resolver empty body triggered `MergeTypeConflict`**:
  the loader now skips the deep-merge step when the body is
  empty, so a cache-missed `Remote` profile does not poison
  the merged config. The `lenient_resolver_skips_cache_miss_profiles`
  regression test pins the new contract.
- **`TextError` gained an `Invalid` variant**: the previous
  `Empty` / `TooLong` taxonomy could not express "non-empty
  but structurally wrong" — exactly what `validate_id` needs
  to reject `a/b`, `../etc`, and `naïve` ids. The variant is
  deliberately additive and `Display`-friendly.
- **`panic!` removed from `loader::layered` tests**: clippy
  `-D warnings` rejected the bare `panic!`; both
  `declared_profile_with_unresolved_body_fails_clean` and
  `declared_profile_with_invalid_yaml_body_reports_per_profile`
  now use the `eprintln!` + `std::process::abort()` pattern
  consistent with the rest of the workspace.

### Test count (Round 7)

- 632 → **676** (+44): the new tests cover the new domain
  type (6), the new schema segment (10), the default
  fragment (1), the loader (5), the on-disk store (7),
  the CLI parser (2), and the offline profile command
  flow (10). All 23 real-kernel E2E tests still pass.

### Advisory

- **Remote fetch is not implemented in this build**.
  `caly profile refresh` returns
  `ProfileCmdError::FetchNotImplemented` so the CLI prints
  a clear advisory. Round 8 wires `fetch_pinned` (Round
  1-2 SSRF guard, `AddressClassifier`) to the
  `ProfileStore.write` materialisation; same pattern as
  the existing subscription fetch.
- **Recursive `Merge` refresh is not implemented**. A
  `kind: merge` profile whose parts include a `Remote`
  with a missing cache does not cascade the refresh. Round
  8 adds a depth-first refresh walk.
- **CLI is destructive on `config.yaml`**. `add_profile`
  / `remove_profile` rewrite the file in place without a
  backup. Round 8 adds `--dry-run` and a `.bak.<unix-ms>`
  sidecar.
- **`type: inline` rule provider (Round 6 advisory) is
  still caly-private**: the upstream Mihomo kernel rejects
  it. The Round 8 materialisation step (startup-time
  inline → file) closes that gap.

### Added (Round 6 — RULE-SET / rule-providers wiring)

- **Routing `rules:` segment with 4 new matchers**: `RULE-SET,<name>,…`
  refers to a user-declared rule provider; `GEOSITE,<category>,…` is
  auto-emitted as `geosite-<category>` rule set on the sing-box side
  (SagerNet URL); `PROCESS-NAME,<glob>,…` and `SRC-IP-CIDR,<cidr>,…`
  extend the existing host/IP matchers. Each new matcher parses from
  the same Clash line syntax used by Mihomo and round-trips through
  `RuleMatch::to_clash_line()`.
- **New `rule_providers:` schema segment**: declarative
  `RuleProviderConfig` (name + `type: http|file|inline` + `behavior: domain
  | domain_suffix | ip_cidr | classical` + `format: source|binary`).
  Three source kinds cover the common shapes:
  - `type: http` fetches from a URL on the kernel's polling cadence
    (interval_ms ≥ 60 000, default 1 day).
  - `type: file` reads from a local path once at start.
  - `type: inline` is a caly-private extension (the rule body lives in
    `payload:`; upstream mihomo does **not** understand this, see
    advisory below).
- **Domain `RuleProvider` type** carries `RuleProviderSource` /
  `RuleProviderBehavior` / `RuleProviderFormat` with bounded text
  fields (name ≤ 64 B, geosite name ≤ 64 B, process name ≤ 256 B,
  inline payload ≤ 256 KiB, max 64 rule providers per config).
- **Mihomo rendering**: `render_proxy_sections_with_rules_and_providers`
  emits a `rule-providers:` block carrying every user-declared
  provider. The thin 3-arg wrapper `render_proxy_sections_with_rules`
  passes `&[]` for legacy call sites.
- **sing-box rendering**: `render_sing_box_rules` now takes
  `user_providers: &[RuleProvider]` and merges them into
  `route.rule_set` together with the auto-emitted `geosite-*` /
  `geoip-*` tags. `RULE-SET` rules emit `{"rule_set": "<name>"}`;
  `GEOSITE` rules emit `{"rule_set": "geosite-<name>"}`. User
  providers with the same tag as a SagerNet geosite/geoip override
  the auto-emitted URL.
- **Validation**:
  - `validate_rule_providers` enforces unique names, valid http(s)
    URLs, interval_ms ≥ 60 000, non-empty file paths and inline
    payloads.
  - `validate_rule_provider_references` rejects `RULE-SET,<name>,…`
    references whose `<name>` is not declared in `rule_providers:`.
    Auto-emitted `geoip-<cc>` rule sets are exempt (they are produced
    on demand by the rule renderer).
  - Six new `ConfigError` variants give precise diagnostics:
    `UnknownRuleProvider`, `DuplicateRuleProvider`,
    `InvalidRuleProviderUrl`, `EmptyRuleProviderPath`,
    `EmptyRuleProviderPayload`, `InvalidRuleProviderInterval`.
- **Boot wiring**: `RuntimeTuning` gains `rule_providers` field;
  `SingBoxConfigBackend` / `MihomoConfigBackend` gain
  `with_rule_providers()` setters; `daemon_config::rule_providers_from_config`
  translates `RuleProviderConfig` → `caly_domain::RuleProvider`,
  logging a warning and skipping when the bounded domain conversion
  fails (e.g. an oversized name).
- **Default `config.d/90-routing.yaml` and `config.d/95-rule-providers.yaml`**
  fragments ship with the new matchers / source kinds documented
  via commented Loyalsoldier v2ray-rules-dat examples. A fresh
  `caly config generate` install still has zero user rules and zero
  user rule providers (both lists default to `[]`).

### Fixed (Round 6)

- **`RuleProviderSource::Inline.payload` bound mismatch**:
  the field originally reused `RuleText` (256-byte bound), which
  did not match the new `INLINE_RULE_PAYLOAD_MAX_BYTES` (256 KiB)
  constant. The field is now `BoundedText<INLINE_RULE_PAYLOAD_MAX_BYTES>`
  and the schema `to_rule_provider()` uses
  `BoundedText::<{ caly_domain::INLINE_RULE_PAYLOAD_MAX_BYTES }>::new`
  so the const generic expression matches the field's bound at
  the call site.
- **`use` statements after statements** (clippy `-D warnings`):
  `use caly_domain::RuleProviderSource` (in
  `crates/caly-config/src/subscription/mihomo/mod.rs`) and
  `use super::settings::RuleProviderSourceConfig` (in
  `crates/caly-config/src/schema/validate.rs`) were inlined after
  `match` arms; both moved to the top of the file.
- **Broken intra-doc link** `[`validate_rule_providers`]` in
  `bins/caly/src/daemon_config.rs`: replaced with plain text
  `validate_rule_providers` so `RUSTDOCFLAGS="-D warnings"
  cargo doc` passes.

### Test count (Round 6)

- 610 → **632** (+22): the new tests cover the four new matchers
  in the domain parser, the nine `rule_providers` schema paths
  (parse, validate, reject), the seven sing-box rendering cases
  (user provider, file/inline sources, `RULE-SET`/`GEOSITE`
  lookups, mihomo-only skip accounting, user override of SagerNet
  URL, interval formatting), the three Mihomo rendering cases
  (http / file / inline source, omitted-when-empty), the two
  generated default fragments, and the two `daemon_config`
  end-to-end resolve cases.

### Advisory

- **`type: inline` is a caly-private extension**: the rendered
  Mihomo YAML carries a `payload:` key that upstream mihomo
  does not understand. The sing-box side maps the inline body
  via the same path; if you ship the kernel a `type: inline`
  provider today, the kernel will reject the rule provider
  block at start. **Mitigation roadmap (Round 7)**: materialise
  inline payloads to a real file under
  `<workdir>/rule-providers/<name>.yaml` at boot and rewrite
  the provider to `type: file` before the kernel sees it.
- **`schema_version` stays at 1**: `rule_providers:` is an
  optional backward-compatible extension, so the loader does
  not bump. Older daemons that pre-date this commit will
  reject `RULE-SET,GEOSITE,PROCESS-NAME,SRC-IP-CIDR` rule
  lines (they parse-error on the unknown matchers), so the
  upgrade path is: install new caly first, then load the
  new config. The reverse is safe.
- **GEOSITE auto-emit is hardcoded to SagerNet**:
  `geosite_or_geoip_url()` only recognises `geosite-` /
  `geoip-` prefixes. A user `RULE-SET,my-extra,…` does not
  hit the SagerNet URL path; user-declared providers and
  auto-emitted ones only collide when the user names a
  provider `geosite-foo` / `geoip-foo` explicitly, in
  which case the user's source wins.

### Fixed (documentation consistency)

- **Created `TODO.md`**: previously referenced by `README.md`, `STATUS.md`,
  `CHANGELOG.md`, `SECURITY.md`, `CONTRIBUTING.md`, `docs/README.md`,
  `docs/architecture.md`, and `docs/coding-standards.md` but missing from
  the repository. The new file is the single source of truth for
  un-done work, ordered S1 (release blocker) → S4 (advisory), with a
  verification command for every item.
- **`STATUS.md` — P0 #4 retired**: the "sing-box config apply is one-sided"
  entry was already fixed in M5 by `ActiveConfigBackend` (active-core
  dispatch between Mihomo / sing-box), but the stale P0 entry contradicted
  the ✅ in the "暂不应视为可用的公开能力" table. Replaced with a
  "S1.4(已废止)" callout that points to the actual code and E2E.
- **`STATUS.md` / `README.md` — test count corrected from 538 to 580**:
  `cargo test` actually reports 580 passed / 0 failed / 0 ignored on the
  current workspace. Added a note explaining that the count includes
  real-kernel E2E which, on a fresh clone without `vendor/bin/`, silently
  skip their inner assertions (the test still reports `ok` without
  `#[ignore]`); the in-repo remediation is tracked in `TODO.md` §S4.4.

### Fixed (Round 5 — daemon-survival bug fixes)

- **`provision_geoip_metadb` — corrupt target silently masked**:
  the boot-time `geoip.metadb` seeder used `target.is_file()` as an
  early-return, so any sub-1 MiB stub left behind by an interrupted
  earlier run was treated as a complete database and bypassed every
  source-copy attempt. The function now inspects the existing target's
  size and removes a sub-1 MiB file before the source loop, and
  `provision_geoip_metadb_with_sources` was extracted for hermetic
  regression tests (4 new). The change is hermetic under `cargo test`
  even when the host happens to ship a real `/etc/mihomo/geoip.metadb`.
- **`tun_failure` — daemon abort on long OS errors**:
  `PlatformFailure::message` is `BoundedText<1_024>`, but
  `ActorFailure::message` is the tighter `BoundedText<512>`. The
  previous `ActorFailure::new(...).unwrap_or_else(|_| abort)` form
  killed the daemon whenever a 600–1024 byte `ip`/polkit stderr chain
  was wrapped into a TUN failure. `ActorFailure::clamped` now UTF-8-
  safely truncates to 512 bytes with a stable fallback (2 new
  regression tests).
- **`STATUS.md` — static-script count corrected from 7 to 6**: the
  repository has six actual check scripts
  (`check-{actor-topology,code-standards,dependency-discipline,
  infrastructure-invariants,integration-invariants,presentation-invariants}`);
  `scripts/fetch-test-kernels.sh` is a binary downloader, not a check.
- **`STATUS.md` — `cargo fmt` row now honest**: previously reported
  "通过" but `cargo fmt --all -- --check` actually fails with 28 diffs
  on a fresh clone. Marked as "失败" with a `TODO.md` §S4.3 pointer.
- **`docs/README.md` — pruned references to non-existent
  `docs/archive/`, `docs/agent-workflow.md`, `docs/adr/`**: the directory
  and files were referenced but not present in the current snapshot.
  Each reference now points to `TODO.md` §S3.3 / §S3.4 for follow-up
  (either rebuild or remove the link).
- **`CONTRIBUTING.md` — pruned `scripts/check-proto-standards.py`**: the
  script was listed in the required local gates but does not exist; the
  gate list now matches the 6 actual scripts.
- **`SECURITY.md` — cross-linked to `TODO.md` §S1.3**: the
  "controller authentication" bullet now points to the concrete
  remediation item (loopback TCP auth-token admission), and the
  retired P0 #4 is explicitly noted.

No code or behavior changed in this entry. The next entry above this one
(`Added (multi-subscription sources + ...)`) is the last user-visible
change; everything below this header is documentation-only.

### Added (multi-subscription sources + `sub list`)

- **Multiple subscription sources**: `subscriptions.sources` accepts a list of
  `{ url, enabled }` entries alongside the legacy single `subscriptions.url`.
  `caly sub refresh` now fetches **every enabled source** and merges their
  nodes into one snapshot (a single failing source no longer aborts the rest;
  its error is reported while the others still land). The legacy `url` stays
  as a single-source alias and is always enabled when set.
- **Stable per-source identity**: each source URL maps to a deterministic
  `SubscriptionId` derived from its SHA-256 digest, so the same URL always
  writes to the same cache entry across daemon restarts — and duplicate URLs
  (across `url` + `sources`, or repeated entries) are fetched once. The
  restart-restore path already read every cache file, so multi-source nodes
  are naturally restored without re-fetching.
- **`caly sub list`**: reports the configured subscription sources (each
  enabled URL, numbered) or the JSON form via `--json`. Read-only and
  client-side, mirroring `config validate`.

### Changed (TUN tuning re-reads on every `config apply`)

- **`tun.enabled` edits no longer need a daemon restart**: the config backends
  re-resolve the TUN settings from the layered config on each apply, mirroring
  the subscription-URL re-read on refresh. Boot still resolves once; the
  shared schema→domain mapping keeps both paths in sync.
- **Core start failures surface a `CAP_NET_ADMIN` hint**: when TUN is enabled
  and the core exits before becoming ready (the kernel denies `TUNSETIFF`
  without the capability), the error now says so and points at
  `sudo setcap cap_net_admin=+ep "$(command -v sing-box)"` or a
  `CAP_NET_ADMIN` daemon — instead of the cryptic "process exited before
  becoming ready".

### Fixed (TUN engage prompts once, and never half-engages)

- **One password prompt per TUN engage**: the privileged `ip tuntap`/`ip link`
  sequence (drop-stale, add, mtu, up) now runs directly first and, when the
  daemon lacks `CAP_NET_ADMIN`, escalates the whole sequence as a single
  `pkexec`/`sudo sh -c` batch. Previously each `ip` command prompted
  separately (up to four root passwords per `caly sys tun on`).
- **`sys tun on` refuses a config that cannot render a tun inbound**: when
  `tun.enabled` is `false`, engaging used to create the interface with no
  core inbound and no routes — a state that carries zero traffic. The CLI
  now fails loudly with the exact fix (`tun.enabled: true` + daemon restart)
  instead of silently half-engaging.

### Fixed (node latency testing is truthful)

- **A 404 is no longer reported as "unreachable"**: `caly core delay <name>`
  now distinguishes a proxy that is not configured in the running kernel
  (loud error, hints at `caly config apply`) from a genuinely unreachable
  target (HTTP 5xx) and from a probe that never completed (read timeout /
  connection drop). Previously every failure mode collapsed into
  `unreachable / no latency`, so a typo, an unapplied subscription, or a
  hung probe all looked identical.
- **`delay --all` reconciles with the running kernel**: the sweep fetches the
  kernel's real proxy list first and probes only nodes that are actually
  present; nodes that never made it into the kernel config (unsupported
  protocol, duplicate-name suffix, unapplied subscription) are reported as
  `not in kernel config` with a hint instead of a silent wall of
  "unreachable".
- **Bounded sweep concurrency**: `delay --all` probes with a 32-worker pool
  instead of one OS thread + one controller connection per node (267 nodes
  previously meant 267 threads), reusing a controller per worker.
- **Sweep output is explicit**: rows carry a status
  (`reachable`/`unreachable`/`not_in_kernel`/`error`); JSON adds the status
  field and per-class counts; `select --delay` reports why no node answered
  instead of failing silently.

### Fixed (TUN re-engagement)

- **Stale TUN device cleanup**: `caly sys tun on` no longer fails with
  `ioctl(TUNSETIFF): Device or resource busy` when a previous run left a
  `caly0` device behind (crashed daemon or interrupted engage). The backend
  now drops any existing interface with the requested name before creating a
  fresh one; a live process holding the name fails with a clear in-use error.

### Fixed (config apply is a real transaction)

- **Reload failure rolls back**: if the active core cannot reload a committed
  config, the previous generation is restored via `rollback_commit` instead of
  leaving a half-applied config behind; the failed operation reports
  `previous generation restored`.

### Changed (subscription fetch policy is honored)

- **`follow_redirects` / `use_environment_proxy`** now actually drive the HTTP
  client (bounded redirects up to 3 hops; system proxy only when enabled).
  Both default to off, preserving the SSRF-safe direct fetch.

### Changed (daemon control plane transport)

- **Length-prefixed JSON framing replaces gRPC**: the owner-only control plane
  now speaks compact JSON over UDS/TCP instead of tonic/protobuf. Wire
  semantics (handshake, session tokens, watch streaming, error codes) are
  unchanged; the dependency tree loses the gRPC/protoc stack.

### Changed (naming consistency)

- User-facing command hints, generated-config comments and docs now say
  `caly` (binary/command) consistently. Historical crate names (`caly-*`),
  XDG paths (`~/.config/caly`) and env vars (`CALY_*`) are kept unchanged.

### Fixed (E2E geoip provisioning)

- The real-kernel DNS validation tests pre-provision `geoip.metadb` via the
  system toolchain instead of relying on mihomo's own (blockable) download;
  the full workspace suite runs green without environment prerequisites.

### Changed (data-structure determinism)

- **Node registry HashMap → BTreeMap**: `CoreNodeRegistry` now iterates in ascending canonical
  `NodeId` order, so the rendered `proxies:` section and url-test group membership are
  byte-reproducible across runs (previously random per process). Subscription stores
  (cached sources/generations/userinfo, http sources) switched to BTreeMap for deterministic
  multi-subscription enumeration. Group selection in `build_settings` is now explicitly the first
  entry instead of the iteration-order last. Covered by a determinism regression test.

### Fixed (daemon startup UX, from real-run debug)

- **Core-selection guidance**: the boot auto-start failure warning now carries the configured
  core and switching guidance (`CALY_CORE=sing-box` or `core:` in config.yaml) — previously a
  user setting the wrong env var (`CALY_BIN`) got a Mihomo error with no hint about selecting
  sing-box.
- **Robust bundled-binary resolution**: `vendor/bin/<core>` is now resolved from the working
  directory first, then by walking the executable's ancestors (dev builds run from
  `target/debug` find the repo's `vendor/bin`), with the CWD-relative fallback kept for error
  reporting; `ensure_executable` flags relative paths explicitly.

### Added (port & DNS engineering parity)

- **fake_ip_filter**: domains that must receive real IPs in fake-ip mode (STUN/mDNS/NCSI/NTP/
  gaming defaults ship in the generated 40-dns fragment); schema → bounded domain patterns →
  Mihomo `fake-ip-filter:` rendering.
- **fallback_filter**: anti-poisoning filter (geoip/geoip_code/ipcidr/domain; CIDRs fully
  address-validated) rendered as Mihomo `fallback-filter:`.
- **dns.listen / dns.ipv6**: configurable DNS listener address (socket-address validated) and AAAA
  switch.
- **kernel.bind_address**: the allow-lan × bind-address listen matrix on both kernels (Mihomo
  `bind-address:` only with allow-lan; sing-box mixed inbound picks loopback / `0.0.0.0` / the
  configured interface IP). Filter/listen fields are Mihomo-only by design — sing-box has no
  equivalents (documented in code).
- **Real-kernel E2E**: a full DNS block (fake-ip-filter + fallback-filter + listen) passes
  `mihomo -t`.

### Added (sing-box rule rendering parity)

- **Config rules now render into sing-box `route.rules`** (previously Mihomo-only, despite the
  schema doc claiming both): a new shared pure renderer (`caly-config::rule_render`) maps the
  domain `RoutingRule` model onto sing-box route semantics — DOMAIN/DOMAIN-SUFFIX/DOMAIN-KEYWORD/
  IP-CIDR become structured rule objects, MATCH becomes `route.final` (first match wins),
  DIRECT/REJECT map to `direct`/`block` (with an auto-added `block` outbound), group names fold
  into the `PROXY` selector (`GLOBAL` keeps its own). GEOIP maps onto the modern **rule-set**
  mechanism (remote SagerNet `geoip-*.srs` sources) because the plain `geoip` rule key was
  removed in sing-box 1.12 — validated by real `sing-box check` E2E. Rules with proxy policies
  are skipped (and warned) in the subscription-less base config where no proxy outbound exists.
- **Both renderers wired**: the subscription document appends config rules after the
  `clash_mode` rules; the base renderer embeds them with the MATCH-derived `route.final`.

### Fixed (durable recovery deep debug)

- **Re-engagement no longer corrupts the captured original state**: engaging an already-engaged
  effect (e.g. `sys proxy on` twice) used to re-capture the desktop — recording caly's own proxy as
  the "original" state and breaking the graceful-shutdown fidelity restore. Existing records are now
  kept, and a failed re-engagement no longer destroys crash-recovery evidence (proxy and TUN alike).
- **Boot no longer double-engages after restore-first**: when a crashed daemon restarts,
  restore-first re-applies the proxy effect; the config-driven boot engagement now detects the
  `Restored` outcome and projects the engaged view instead of re-engaging (which would have
  re-captured caly's own proxy as the original state).

### Changed (recovery convergence)

- **Symmetric graceful shutdown**: `DurableTunBackend::restore_and_clear` mirrors the proxy
  fidelity restore (no record = no-op; record cleared only on success); the shutdown TUN branch
  collapsed from hand-rolled load/revert/clear into one call. Dead `tun_recovery` handles removed
  from the composition root.
- **Sniffer rendering guard**: with all three port lists empty the whole `sniffer:` block is
  skipped instead of emitting a child-less `sniff:` key.

### Changed (deep convergence, round two)

- **Self-documenting platform views**: the domain gains `PlatformEffectView::none()` /
  `proxy(engaged)` / `tun(engaged)`; 17 magic-tuple `new(bool, bool, bool, None)` construction
  sites across application/backends/server/tui migrated. Only the wire decoder and a two-effect
  TUI fixture keep the general constructor.
- **rule_render dedupe**: geo rule-set source registration moved from `Vec::contains` (O(n²)) to a
  `BTreeSet` (O(log n) inserts, deterministic sorted emission).

### Changed (renderer convergence, deep audit)

- **sing-box renderer collapsed to one entry point**: the eight telescoping `render*` delegates
  (`render`/`render_with_controller`/`_and_secret`/`render_with_tun`/`_and_dns`/`_dns_secret`/
  `_dns_secret_tun`/`_dns_secret_log`) are gone; `render_tuned(&SingBoxBaseTuning)` is the single
  rendering API — a tuning struct instead of an 11-argument signature, and one JSON document
  template instead of two. New tuning dimensions (sniffing, route rules, rule-set sources) no
  longer grow the API surface; all unit/E2E call sites migrated.
- **Deep audit outcomes**: the `failure()` crate alias stays (inlining it was tried and rejected —
  it pushed two files past the 400-line budget); a process-wide daemon-config load cache was
  prototyped and rejected (conflicted with the `_from(root)` test seams on a cold path). No dead
  public API found.

### Added (traffic sniffer)

- **Sniffer wiring (B7)**: new top-level `sniffer:` config section — `enabled`,
  `override_destination`, `parse_pure_ip`, `force_dns_mapping` and per-protocol port lists
  (`http_ports`/`tls_ports`/`quic_ports`, each spec `N` or `N-M`, validated at load with a
  readable `InvalidSnifferPort` error). Mihomo renders a full `sniffer:` block (validated by the
  real binary via `mihomo -t` in a new E2E); sing-box renders `sniff`/`sniff_override_destination`
  on the mixed/transparent inbounds in both the base and the subscription renderers.

### Changed (renderer convergence)

- **sing-box renderer convergence**: `render_with_controller_dns_secret_tun` no longer duplicates
  the document JSON template; it delegates to `render_with_controller_dns_secret_log` (one
  rendering body instead of two). The daemon's subscription-less sing-box render was extracted
  into `render_base_sing_box_config`, keeping every lifecycle builder within the function-size
  budget.

### Changed (system-proxy fidelity & graceful shutdown)

- **System proxy fidelity restore**: before engaging the desktop system proxy, the current desktop
  state is captured (GNOME `gsettings` mode/host/port, KDE `kioslaverc` ProxyType/httpProxy, niri
  `environment.d`) and stored in the durable recovery record (`original_mode` + `original_endpoint`;
  legacy records without the endpoint field still deserialize). On graceful daemon shutdown exactly
  that captured state is restored (manual + endpoint / auto / none) instead of merely disabling the
  proxy; capture failures degrade to `none` (restore = disable) and never block engagement.
- **Graceful platform shutdown**: `restore_platform` now reverts the active proxy side effect
  through the durable owner before clearing its recovery record. A failed revert retains the record
  (restore-first on the next boot retries), and a missing record never touches the desktop, so a
  manually configured user proxy is never clobbered.
- **Generated fragment docs**: `70-system-proxy.yaml` now documents the actual contract (boot-time
  engagement with graceful degradation on unsupported desktops, crash restore-first, graceful
  fidelity restore), replacing the stale "records intent only" wording.

### Added (rule engine, redir-host, transparent proxy)

- **Routing rule engine**: `rules:` config section (Clash-format lines, validated at load with full
  IP-CIDR address validation), rendered into Mihomo `rules:` with smart MATCH-catch-all completion.
  Domain `RoutingRule` model with a pure host matcher; IP/CIDR matching lives in
  `caly-config::rule_match` (address arithmetic stays out of the domain).
- **CLI rule commands**: `caly core rules` (list) and `caly core rule-match <host|ip>` (offline
  diagnostic showing which rule a host or IP hits, first match wins).
- **DNS redir-host mode**: `dns.mode: redir-host` renders `enhanced-mode: redir-host` (Mihomo) and
  standard resolution (sing-box); covered by render tests alongside fake-ip.
- **Transparent proxy**: `kernel.transparent.{enabled,mode,port}` renders a redirect/tproxy inbound —
  Mihomo `redir-port`/`tproxy-port`, sing-box `redirect`/`tproxy` inbound (both modes tested).

### Changed (quality refactor)

- **Wire semantics single-sourced**: new `caly-protocol::protocol::v2::wire` module owns every
  wire-discriminant mapping (`WireMode`/`WireCoreKind`/`WireCoreAction`/`WireRunState`/
  `WireOperationState` with bidirectional conversions, labels, terminal detection and domain
  bridges). Daemon encoding, snapshot decoding, server command decoding and all CLI mappings now
  derive from it; nine duplicated mapping functions were deleted.
- **All client JSON is serde_json-built**: `status`, operation status, `core list-nodes`, offline
  queries and `sub check` no longer hand-assemble JSON. This fixes a real bug where node names
  containing quotes/backslashes produced invalid JSON in `sub check --json`.
- **Unified mutation path**: all CLI mutations flow through one `execute_operation_with` helper;
  eight copy-pasted execute/poll blocks collapsed to one.
- **Error hygiene**: eight error types gained `Display`; sixteen `{error:?}` Debug leaks in
  caly-backends now render clean human messages; client error reporting consolidated into
  `output::report_usage_error`/`report_failure`.
- Kernel failure constructors consolidated: four per-module `failure()` copies collapsed onto
  `caly_kernel::common` (`failure`/`failure_with_kind`/`config_failure`).

### Changed

- **CLI surface consolidation**: every capability now has exactly one canonical spelling. Removed the six
  top-level shortcuts (`start`/`stop`/`restart`/`refresh`/`proxy`/`tun`), all dash-prefixed aliases
  (`-c`/`-s`/`-p`/`-g`/`-t`/`-d`/`-v`, `config -vim|-nvim`, `config --default`) and the pre-clap legacy
  argument rewriting; the tree families (`core`/`sub`/`sys`/`config`) are the single entry point.
  `config-check <file>` moved into the family as `config check <file>`; `config init` is now
  `config generate` (hidden alias kept); `core connections` was renamed to `core close-connections`
  so the destructive action no longer masquerades as a query (hidden aliases kept). All help texts that
  were previously empty are now documented.
- **`core select` accepts a display name**: the argument may be a 32-hex node ID or a node's display
  name, resolved against the daemon snapshot (exact match first, then a unique case-insensitive match;
  ambiguous names list the candidate IDs).
- **Mutation results are semantic**: successful operations print `ok: <what happened>` (for example
  `ok: mode set to global`) instead of only an opaque operation id; failures print the structured error
  and hint on stderr. `--json` operation output is unchanged.
- **`config default` backup scope**: the reset now backs up the whole config directory (base and
  fragments) to a timestamped `caly.bak.<millis>` sibling directory instead of only the base file.
- **Generated fragment docs**: `70-system-proxy.yaml` now states that `system_proxy.enabled` records
  intent only (no boot-time auto-engagement; use `caly sys proxy on`), and `60-tun.yaml` distinguishes
  TUN rendering into the core config from engaging the platform TUN device.
  (Superseded: boot-time engagement was wired in the 接线补全 round and the fragment text corrected
  in the system-proxy fidelity round above.)

### Added

- **Subscription format coverage** — the full common-format matrix now parses (all verified with
  `sub check` against crafted samples):
  - Clash YAML (raw) and **Base64-encoded Clash YAML** (previously rejected; the decoded body is now
    re-checked for a `proxies:` document).
  - **SIP008 JSON**: bare server arrays and `{"version":1,"servers":[...]}` envelopes, raw or
    Base64-encoded; unsupported ciphers/bad entries are skipped and counted, not fatal
    (`caly-config::subscription::parse_sip008`, wired into both renderers and the display pipeline).
  - **SSR (`ssr://`)**: recognized and gracefully skipped — mixed documents parse the usable nodes
    and report `ssr-skipped: N`; pure-SSR documents report `format: ssr-only` with a conversion hint
    instead of an opaque parse error.
  - V2Ray `vmess://` robustness: empty-string placeholders (`"host":""`, `"path":""`) now count as
    absent instead of rejecting the node (common in real-world payloads).
- **Plain-text subscriptions**: `sub check` and the daemon refresh path now recognize
  URL-list documents (one HTTP(S) subscription URL per line, `#` comments allowed); the daemon
  fetches and merges up to 32 children through the same SSRF-safe path before node parsing
  (nested lists are rejected). VMess `net: http`/`h2` nodes now parse onto `Transport::Http2`
  instead of being rejected.
- **`daemon.auto_start_core`** (default true): whether the daemon engages the core at boot.
- **`kernel.start_timeout_ms` / `kernel.stop_timeout_ms`**: core readiness and graceful-stop
  budgets, wired through the lifecycle backends (Mihomo and sing-box).
- **Config surface enrichment** — four new/extended sections, all validated at parse time, all wired:
  - `kernel:` — `mixed_port` (local inbound; Mihomo `mixed-port`, sing-box mixed inbound),
    `allow_lan`, `log_level` (rendered per-kernel: Mihomo `log-level`, sing-box `log.level`),
    and `restart.{initial_backoff_ms,max_backoff_ms}` bounding the crash-loop self-healing backoff.
  - `dns:` — `enabled`, `mode` (standard/fake-ip/redir-host), `nameservers`, `fallback`, `direct`,
    `default`, `fake_ip_range`; maps onto the bounded `caly_domain::DnsSettings` model and is rendered
    into both kernels' configs (Mihomo `dns:` block, sing-box `dns` object with resolver wiring).
    Environment `CALY_DNS_*` still overrides when `CALY_DNS_ENABLE` is set.
  - `subscriptions:` — fetch-policy tuning: `connect_timeout_ms`, `request_timeout_ms`, `max_body_mb`,
    `follow_redirects`, `use_environment_proxy` (SSRF-safe defaults preserved).
  - `system_proxy:` — `host` and optional `port` for the desktop proxy endpoint; the port defaults to
    `kernel.mixed_port`, and `CALY_SYSTEM_PROXY_HOST/PORT` still override.
  - `tun:` — new `escalation` policy (`auto|pkexec|sudo|none`, default `auto`) for the privileged
    `ip` commands.
- **TUN privilege escalation**: `caly sys tun on` no longer just fails when the daemon lacks
  `CAP_NET_ADMIN`. Each `ip` command first runs directly, then escalates per policy (`pkexec` for a
  desktop polkit prompt, then non-interactive `sudo -n`); a final failure reports the kernel's stderr
  plus concrete remediation (`setcap` on `ip`, passwordless sudo, or daemon capabilities).
- **`core list-nodes`**: lists registered nodes with their 32-hex IDs, protocols, latency and names
  (human and `--json`), closing the loop for `core select` in a pure CLI workflow.
- **`doctor` checks core binaries**: reports whether both managed core executables resolve to an
  existing, executable file, with a remediation hint pointing at `scripts/fetch-test-kernels.sh`.
- **`status --json` includes the node count**, matching the human output.
- **Config generation hardening**: `config generate`/`config default` now self-check the written
  layout through the same layered loader the daemon uses at boot, so a renderer regression surfaces
  at generation time instead of bricking the next daemon start. The generated fragments gained a
  layered-loader round-trip test and per-section validation tests; generated layouts now include
  `15-kernel.yaml` and `40-dns.yaml` with documented replacement blocks.
- **`caly dns` probes configured nameservers**: precedence `CALY_DNS_NAMESERVERS` → `dns.nameservers`
  → built-in public defaults.

### Fixed

- Piping CLI output into a consumer that closes early (`caly status | head`) no longer panics with a
  Broken pipe backtrace; the process now exits quietly with the conventional SIGPIPE code 141.
- Daemon instance-lock failures print a human-readable sentence instead of the raw internal
  `PlatformFailure { ... }` debug representation.
- `CALY_LOG=debug` no longer drowns business logs in h2/hyper/tonic/tower frame traces; those crates
  are capped at `info` unless the user configures them explicitly.
- The bundled source no longer fails to compile: the `ConfigCmd::Validate` wiring (missing match arm and
  missing re-export of `validate_active_config`) is complete, and pre-existing gate violations
  (`panic!` in tests, 400-line file budget, 80-line function budget, empty help texts) are resolved.
- **Generated config examples are now usable**: the commented examples in generated fragments used the
  wrong indentation, so uncommenting them produced stray top-level keys rejected by `deny_unknown_fields`.
  Each optional section now shows a complete, correctly nested replacement block.
- **`config default` works again**: the reset previously refused to run whenever generated fragments
  existed (that is, always after `config generate`), restoring the base file and aborting. It now moves
  the entire config directory to a timestamped `caly.bak.<millis>` sibling before writing the fresh
  default, and restores the backup if the write fails.
- **Security (fail-closed remote listen)**: `daemon.auth_token` and `daemon.tls_enabled` were validated
  in the schema but never enforced by the TCP transport, so a non-loopback `daemon.listen` exposed an
  unauthenticated, plaintext gRPC control plane. The daemon now refuses non-loopback listen addresses at
  boot with a clear remediation message until enforced TLS and token admission exist; loopback listening
  is unchanged.
- The single-file `render_default_config()` is composed from the exact base and fragment pieces
  `config generate` writes, so the two documented layouts can no longer drift apart.
- **Rendered `external-controller` matches the configured controllers**: both kernel renderers used
  hardcoded ports (`9090`/`9091`) regardless of `controllers:` config; they now derive the address
  from the configured controller endpoints, so changing controller ports no longer silently breaks
  the control plane.
- **sing-box subscription documents carry the controller auth secret** and config-driven header
  tuning (log level, mixed inbound, controller address, TUN inbound, DNS block); previously the
  subscription-rendered config had no `secret`, no inbound and a hardcoded controller.
- **sing-box bootstrap config gains the mixed inbound** so the configured `kernel.mixed_port` is the
  same local proxy entry point across both kernels (and matches the system-proxy endpoint).
- **Bootstrap configs render TUN for both kernels**: the core-start config now includes the Mihomo
  `tun:` section / sing-box tun inbound when `tun.enabled` is set (previously only the `config apply`
  path rendered TUN, so a fresh core start ignored the configured intent).
- **Operation summaries read as requests**: mutations report verb phrases (`ok: engage TUN`,
  `ok: set mode to global`) so a failure no longer prints a contradictory `failed: TUN engaged`.
- **`doctor` gains a `tun-device` check**: warns when `tun.enabled` is set but `/dev/net/tun` is
  missing, which otherwise makes the core exit at start.
- Boot capability projection now reports DNS from the *resolved* configuration (environment
  override or config section) instead of the environment alone.
- **Daemon boot is decoupled from the kernel**: a failed core auto-start no longer aborts the
  daemon. It logs a warning, projects a stopped core and keeps serving; `caly core start` retries
  on demand. Boot restore-first (durable effects) now runs even when auto-start is disabled.
- **`system_proxy.enabled` is wired**: when true the daemon engages the desktop system proxy during
  boot (after restore-first) and degrades with a warning on unsupported desktops instead of failing.
- **Lifecycle errors no longer leak Debug representations**: Mihomo/sing-box start/stop/restart
  failures format the bounded message + suggested action (`MihomoRuntimeError` gained `Display`).
- Dead code cleanup: removed the unused `dns_env::dns_enabled()` and a never-constructed
  `SubscriptionFormat::UrlList` variant.

### Added

- A single current-status entry point in `STATUS.md` and a prioritized remediation backlog in `TODO.md`.
- GitHub CI, security/contribution policies, MIT/Apache-2.0 licenses, and a checksum-pinned kernel
  downloader (`scripts/fetch-test-kernels.sh`).
- **Local security** (M2.3):
  - Fail-closed controller secret generation (`caly_platform::secrets`) shared between the core
    config and control clients; never projected.
  - XDG runtime/state/config path resolution (`AppPaths::from_env`), owner-only lock auto-create.
  - Owner-only UDS path validation (regular file / symlink / other-user socket rejected).
- **Auto-recovery** (M2.4): `CrashLoopPolicy` state machine — exponential backoff, continuous retry
  on restart failure, stabilization window before backoff reset.
- **Restore-first + ordered shutdown** (M2.1/M2.2): durable `FileRecoveryStore` for system-proxy,
  `DurableSystemProxyBackend`, `proxy_restore_first` startup gate, and a 12-phase
  `DaemonShutdownActions` preserving per-phase failures.
- **Live watch** (M3.2): continuous server stream (`LiveWatchStream` + broadcast), lazy client watch
  iterator, lag → full-snapshot resync.
- **Telemetry** (M3.1): periodic scheduler publishing `ObservedState`, and a core-aware adapter that
  selects Mihomo or sing-box (sharing the controller secret).
- **TUI** (M3.3): `LiveWatchSource`+`WatchDriver`-driven loop on a worker thread, session-expiry
  auto-reconnect, mouse capture.
- **sing-box Clash API** (M4): `SingBoxHttpControl` with secret support; proxy_groups/connections/
  traffic/select/close-all adapters; config renderer with `clash_api.secret`.
- **CLI** (M4): a tree-structured command set with short aliases (`-v`/version, `-c`/core, `-s`/sub,
  `-p`/sys, `-t`/status, `-d`/daemon), each family owning leaf subcommands; `doctor`, `--json`,
  `--socket`, and a `--core mihomo|sing-box` override.
- **SetMode** (M4): wired end-to-end — Mihomo `/configs` PATCH via `CoreCommandBackend::set_mode`,
  admitted by the daemon, exposed as `caly -c mode rule|global|direct`. It now publishes **both a
  Desired delta and an Applied delta** via a shared desired-state cell, so `status` reflects the new mode.
- **ApplyConfig** (M4): wired through the ports/backends architecture — a `ConfigActor` command owner
  drives `MihomoConfigBackend` (parse+render → commit) and publishes `config_generation`; exposed as
  `caly -g apply`. Config is published owner-only (`0600`) under `$XDG_CONFIG_HOME/caly`.
- **Subscription-driven Mihomo config loop** (M5): `-s refresh` indexes each representable node as a
  `RegisteredProxy` (group/tag/rendered YAML) into the shared registry; `MihomoConfigBackend` now
  renders `proxies`/`proxy-groups`/`rules` from that registry, validates the candidate against the real
  `mihomo -t` binary **before** commit (rejected configs never publish), and rolls back to the previous
  generation on failure. A configured `CALY_SUBSCRIPTION_URL` is now shared by every core's refresh.
  Verified by unit tests plus real-binary E2E (`config_apply_real_e2e`, `mihomo_render_e2e`) and the
  daemon E2E (`config apply` commits an owner-only generation).
- **Layered daemon configuration** (M5): daemon boot now loads and validates `$XDG_CONFIG_HOME/caly/config.yaml`
  (base + `CALY_PROFILE` profile + `config.d/*` fragments) via the bounded layered loader and drives the managed
  core selection from the validated `AppConfig`. `CALY_CORE` remains an explicit per-process override, and a
  broken config fails boot instead of silently running on stale env defaults.
- **Handshake capability advertisement** (M5): a single `all_features()` source of truth in the protocol.
  The daemon now advertises every feature it implements (operations, cancellation, event replay, full
  snapshot recovery, unknown-enum preservation) and the thin clients (CLI/TUI) request them, so a
  handshake's `enabled_features` truthfully reflects real capabilities instead of being empty.
- **TCP transport** (M5): the validated `daemon.listen` address now binds a loopback TCP gRPC transport
  (`caly-server::tcp`) in parallel with the owner-only UDS, sharing one session registry. Absent a
  config file the daemon remains UDS-only. Verified by a Tonic-over-TCP handshake E2E and a live boot.
- **TUN owner** (M5): `SetTun` is no longer admission fail-fast. It routes to `PlatformActor`, which owns
  a `LinuxTunCommandBackend` (reusing `caly-platform::tun`'s shell-free `ip tuntap`/`ip link` engage and
  recoverable `OwnedTun::restore`) and returns a structured failure when privileges are unavailable. The
  validated `tun.mtu` from `AppConfig` drives the configured MTU.
- **TUI daemon-operation execution** (M5): `caly-tui` now emits `ControlAction`s (select node / set mode /
  restart core / close connections) into an outbox that the binary's interactive loop forwards through a
  fresh UDS connection on a background thread, so the render loop never blocks. Keys: Enter selects the
  highlighted node, `g` cycles rule→global→direct, `r` restarts the core, `c` closes connections.
- **Naming cleanup** (M5): the stale saga `CommandTarget::Coordinator` (and its mailbox/task) is renamed to
  `CoreLifecycle`, matching the actual core-lifecycle owner it hosts.
- **TUN durable crash-restore** (M5): the recovery store is generalized to `FileRecoveryStore<R>` over the
  record type (removing duplication and adding a `TunRecoveryRecord`), and a new `DurableTunBackend` persists
  a recovery record when the TUN side effect engages and restores it on startup (`restore_first`), mirroring
  the system-proxy recovery transaction. Graceful shutdown clears the pending TUN record. The daemon boots
  cleanly with restore-first wired in.
- **Structured logging + correlation** (M5): `tracing`/`tracing-subscriber` with an env filter
  (`CALY_LOG`/`RUST_LOG`) writes structured, timestamped log lines to stderr with correlation fields (daemon
  id, socket, listen address). The daemon startup path's `eprintln!` calls are replaced with `tracing`
  events, and `reporting.rs` emits a structured terminal event per operation (operation id + outcome), giving
  operation-level correlation across the daemon.
- **Fragmented-responsibility consolidation** (M5):
  - The legacy, unused-in-prod recovery machinery (`RecoveryRecord`/`RecoveryStore`/`RecoveryAction`/`restore_first`)
    and the whole dead `system_proxy` module (`engage_proxy`/`SystemProxyBackend`/`PlatformProxySnapshot`) are removed,
    converging on the single generic `FileRecoveryStore<R>`.
  - The dead `config_handler.rs` (`ConfigActorHandler`/`ConfigActorRequest`) is removed.
  - `ActorFailure::infrastructure` and `KernelFailure::new` become the single shared clamped constructors, collapsing
    the duplicated per-module `failure()`/`bounded()` helpers across backends, application, and kernel.
  - The no-op shutdown phases `StopSupervisor`/`SettleCoordinators` (leftovers from the removed saga supervisor/
    coordinator) are removed; the shutdown sequence drops from 12 to 10 phases.
  - **Xray is abandoned**: the `caly-kernel::xray` stub module and three dead `API_FAMILY` constants are removed;
    `CoreKind::Xray` remains only for wire/protocol compatibility and always resolves to Unsupported.
- **Data-structure consolidation** (M5): a single canonical `caly_domain::to_hex` now encodes 16-byte identities
  (lookup-table based, no per-byte `format!` allocation), and seven duplicated `byte:02x` loops / helpers
  (`hex_id`, `hex_token`, `hex`, lock `owner_token`, sing-box proxy tag, TUI hex, tonic hex) delegate to it.
  Reviewed the TUI `NodeList`/`NodeTree` hot path (already clones-free, sorts refs by deref) and the
  subscription diff/dedupe (already O(n log n) set operations) — no further change needed.
- **Debug / quality fixes** (M5):
  - **Clash-YAML ingest bug**: `decode_document` detected `ClashYaml`, but the display ingest path
    (`parse_uri_body_to_display_lossy`) only accepted `UriLines` and returned `UnsupportedDocument`, leaving
    `parse_clash_yaml` dead code and making `subscription-check` report `clash-yaml` yet fail to parse.
    The display/registry/mihomo/sing-box rendering paths now share a `dialable_nodes` helper that handles
    both URI-line and Clash-YAML documents; `subscription-check` on a Clash-YAML file now succeeds
    (format, node count, rejected=0), and Clash-YAML nodes are indexed/rendered consistently.
  - The controller `secret` in `composition/handlers.rs` now clamps a runtime value instead of aborting.
- **CLI wiring + robustness** (M5):
  - `sys tun on|off` wired: `SetTun` was fully implemented in the daemon (TUN owner) but had no CLI leaf; the
    new `-p tun on|off` leaf executes it and returns a structured failure when privileges are absent.
  - `config-check` now uses `load_config_file`, which auto-detects YAML or JSON — previously it only accepted
    JSON (`load_json_file`), so it wrongly rejected the YAML configuration the daemon actually loads.
  - An invalid `--core` value (not `mihomo`/`sing-box`) is now rejected with exit code 2 before any daemon
    connection instead of silently mapping to mihomo.
- **Subscription connection robustness** (M5): the HTTP subscription fetch now retries transient failures
  (connect/request timeout) with a short backoff, while non-transient policy failures (bad URL, unexpected
  status, body too large) surface immediately. The retry loop is extracted into a pure `retry_fetch` helper
  with three unit tests. Reviewed and confirmed intact: DNS pinning/SSRF filtering, redirects disabled, body
  ceilings, multi-protocol URI parsing, and cache persistence.
- **Handler reporting consolidation** (M5): a new `reporting::report_outcome` centralizes the completed/failed
  dispatch tail that every owner handler (core, core-lifecycle, config, subscription, platform) previously
  repeated. All five `handle` implementations now report through the single shared tail, keeping reporting
  semantics and structured logging in one place.
- **Reality handshake parsing fix** (M5): line-by-line review found `uri.rs::tls()` set only the SNI for
  `security=reality` nodes and never parsed the Reality handshake identity (`pbk`→public key, `sid`→short id,
  `spx`→spider). Reality nodes now parse their identity (rejecting a missing `pbk`), so their canonical
  identity no longer collides with equivalent plain-TLS nodes. Two unit tests added.
- **Renderer completeness for vless flow/TLS/reality/transport** (M5):
  - `TlsConfig`/`RealityConfig` read-only accessors are now `pub` (secrets still only exposed via
    `SecretText::with_exposed`, so no credential leakage).
  - Fixed `uri.rs::parse_proxy_uri` never parsing transport: `type=ws/grpc/httpupgrade/quic` and
    `path`/`host`/`serviceName` are now parsed for URL-shaped URIs (vless/trojan/etc.), not just vmess.
  - The sing-box renderer now emits `flow`, `tls` (server_name/insecure), `reality` (public_key/short_id/
    spider_x) and `transport` (ws/grpc/httpupgrade/quic) for vless outbounds.
  - The mihomo renderer now emits `flow`, `tls`/`servername`, `reality-opts` and `network`/`ws-opts` for vless.
  - Verified against the real kernels (`mihomo -t`, `sing-box check`) and a new vless-ws-reality render unit test.
- **Renderer completeness for trojan/vmess TLS/transport** (M5): the sing-box and mihomo renderers' trojan
  branch only emitted the password and the vmess branch only the uuid, dropping TLS (trojan is almost always
  TLS) and transport, and vmess also dropped `alterId`/cipher. Now both renderers emit tls/transport for
  trojan and vmess, and sing-box emits `alter_id`/`security` for vmess (via a new `vmess_cipher` mapping).
  Verified against the real kernels and two new render unit tests.
- **Reality `short_id` made optional** (M5): Reality's short id is optional, but the parser forced `sid`
  non-empty, so real Reality subscription nodes without a `sid` failed to parse. `RealityConfig::new` now
  takes `Option<SecretText>`, `short_id()` returns `Option`, the parser uses an optional secret reader, and
  the canonical-identity encoder plus both renderers (sing-box `short_id`, mihomo `short-id`) handle the
  optional field. A test confirms a Reality node without `sid` now parses.
- **TUN stack / auto-route / strict-route configuration** (M5):
  - New core-agnostic `caly_domain::TunConfig` (`TunStack` gvisor/mixed/system, `auto_route`, `strict_route`,
    `mtu`) mirroring the `DnsSettings` value-type pattern.
  - The Mihomo renderer emits a `tun:` block (`enable`/`stack`/`auto-route`/`strict-route`/`mtu`); the
    sing-box renderer emits a tun inbound. Both are accepted by the real `mihomo -t` and `sing-box check`
    for all three stacks.
  - The config schema `TunConfig` gains `stack`/`auto_route`/`strict_route`, and `daemon_config::tun_config()`
    maps them onto the domain type.
  - The TUN config is threaded through composition to the config backend (`MihomoConfigBackend::with_tun`),
    so a config-driven daemon's `config apply` renders a full `tun:` block (verified end-to-end with the real
    mihomo binary).
- **Offline Clash API queries** (M5): new `core proxy-groups` (groups + current selection), `core
  list-connections` (connection summary), and `core traffic` (download/upload totals) leaves run directly
  against the running core's controller, without a daemon mutation operation. The daemon persists its
  generated controller secret to an owner-only `$XDG_RUNTIME_DIR/caly/controller.secret` so offline queries
  authenticate; `CALY_CONTROLLER_SECRET` overrides. Verified end-to-end against a real mihomo daemon.
- **Subscription quota detection** (M5): a new `userinfo` parser reads the Clash `subscription-userinfo`
  response header (upload/download/total/expire); `fetch_pinned` carries it in `FetchResult::Updated` and the
  cached backend stores it. `sub check <file> --userinfo <header>` reports remaining quota in JSON and human
  form.
- **DNS A-record resolution** (M5): `dns_probe` now parses the answer section and returns the resolved A-record
  address (`DnsProbeOutcome::Resolved(Option<IpAddr>)`), so `caly dns example.com` shows the actual IP
  (verified: 104.20.23.154) instead of a generic "Resolved".
- **Subscription fetch retry made structural** (M5 debug): `fetch_once` now returns an explicit transient flag
  (`Result<(), (bool, ActorFailure)>`) instead of string-matching the failure message, and `is_transient_fetch`
  classifies connect/request timeouts **and 5xx server statuses** as retryable (server 5xx is a common
  transient subscription failure) while policy rejections are not. A classification unit test was added.
- **Controller secret lifecycle** (M5 debug): `finish_daemon` now removes the owner-only
  `$XDG_RUNTIME_DIR/caly/controller.secret` on shutdown so a stopped daemon no longer leaves a stale secret
  for offline queries. Verified end-to-end (created mode 600 on start, removed on stop).
- **Doc-verified TUN/outbound completeness** (M5): after checking the Mihomo and sing-box docs,
  - the sing-box tun inbound now emits the required `address` (`172.18.0.1/30`, `fdfe:dcba:9876::1/126`);
  - the Mihomo `tun:` block now emits `auto-detect-interface` and `dns-hijack: [any:53]`;
  - both renderers now support **hysteria2** and **tuic** outbounds (up/down/obfs for hysteria2, congestion
    control for tuic) instead of skipping them. Verified against the real kernels and two new render tests;
    the Mihomo render logic was split into `mod.rs`/`render.rs` to stay under the file-size limit.
- **Redundancy consolidation** (M5): shared plumbing for the durable side-effect backends and a single
  process-lifecycle failure helper.
  - New `caly-backends::platform::durable_support` consolidates the `bounded`/`actor_to_platform`/
    `durable_failure` helpers that were duplicated verbatim between `DurableSystemProxyBackend` and
    `DurableTunBackend`, so the two backends no longer drift on error mapping.
  - The per-module `failure` wrappers in `mihomo/runtime.rs` and `sing_box/runtime.rs` now delegate to a
    single `caly_kernel::common::failure` (was `kernel_failure`), collapsing three identical process-lifecycle
    constructors onto `KernelFailure::new`. The redundant `failure` re-export in `platform/niri.rs` was
    removed in favor of the crate-level `failure`.
  - The stale `scripts/check-infrastructure-invariants.py` reference to the deleted
    `caly-platform/src/system_proxy/transaction.rs` was repointed to the real durable backends.

### Added

- **TUI filter/sort/tree key bindings** (M5): wired the existing `set_filter`/`toggle_sort`/`toggle_tree_view`
  presentation APIs to keys. `/` enters a filter-typing mode (new `Key::Backspace` parses `0x7f`/`0x08`; while
  filtering, printable keys edit the filter buffer, Backspace deletes, Esc/Enter exit — and no global action
  fires); `s` cycles the sort key Name → Protocol → Latency; `t` toggles between the flat node list and the
  protocol tree view. The four `TuiApp` boolean flags were collapsed into a `Flags(u8)` bitfield to keep
  `clippy::struct_excessive_bools` green.

### Fixed

- **Kernel binary CPU compatibility** (M5): the default `mihomo-linux-amd64` release is an x86-64-v3 build
  (requires AVX2) and fails on baseline amd64 CPUs with "This program can only be run on AMD64 processors
  with v3 microarchitecture support." `kernels.lock.toml` now pins the official `mihomo-linux-amd64-compatible`
  (baseline x86-64) build with matching archive/binary sha256, so `scripts/fetch-test-kernels.sh` fetches a
  kernel that runs on any amd64 CPU. sing-box's `-linux-amd64` is already a baseline Go build.
- **Daemon boot failure diagnostic** (M5 debug): `./caly -d` failed with an opaque `BackendUnavailable`
  when the core binary was missing or not executable — `boot_auto_start` → `CoreLifecycleCommandBackend::
  start` failed and the underlying error was swallowed. The auto-start and lifecycle-build failure points
  now log the real cause via `tracing::error!`, and a new `caly_kernel::common::ensure_executable` check at
  core `start` time reports a clear "Mihomo/sing-box binary is missing or not executable: <path>" message
  with remediation (chmod +x, set the `CALY_*_BIN` override, or run `scripts/fetch-test-kernels.sh`). The
  check lives at start-time (not build-time) so the daemon can still build backends and the hermetic
  composition test (`start_runtime(false)`) passes without an executable binary. The default relative
  `vendor/bin/*` path depends on the working directory; `CALY_*_BIN` selects an absolute one.
- **Truthful capability coverage + traffic parse bug** (M5 debug):
  - `core_capability_set` (the boot-time projection) previously assessed only `DnsConfiguration`; it now
    covers the full nine wired system capabilities (TUN, DNS, runtime mode switch, proxy groups,
    proxy selection, URL test, connections, connection close, traffic), so the daemon advertises a
    complete, truthful capability set on start. Mihomo/sing-box report `Supported`, sing-box reports
    `Partial` for connections/traffic (subset of the Clash API), and Xray reports `Unsupported`.
  - Kernel capability sets corrected: Mihomo no longer advertises the unwired `Rules`/`Logs` and now
    advertises `ConnectionClose`; sing-box now advertises `ProxySelection` and `ConnectionClose`.
  - **`traffic_bytes` bug**: `/traffic` field names differ per kernel — Mihomo returns `upTotal`/`downTotal`
    and sing-box returns `up`/`down` — but the parser only read `downloadTotal`/`uploadTotal`, so traffic
    always reported `0`. It now accepts all historical field names and strips any SSE `data: ` prefix.
    Verified against the real Mihomo and sing-box binaries; new `traffic_field`/`parse_traffic_frame`
    unit tests. No `unwrap`/`expect`/`panic` remains in production code (clippy enforces).

### Added

- **Config generation + broader config surface** (M5): `caly config generate` writes a documented, commented
  default `config.yaml` under `$XDG_CONFIG_HOME/caly` (usually `~/.config/caly`), owner-only (`0600`), and
  refuses to overwrite an existing file. The schema gained three more sections — `controllers`
  (`mihomo`/`sing_box` Clash-compatible endpoints), `log.level`, and `telemetry.interval_ms` — each with
  defaults and validation (`controllers` addresses must be `host:port`, `log.level` must be
  error/warn/info/debug/trace, `telemetry.interval_ms` ≥ 100). These are wired through the daemon: the
  `controllers` precedence is now config > `CALY_*_CONTROLLER` env > built-in defaults, driving the
  command/telemetry control clients and the CLI offline queries; `telemetry.interval_ms` drives the
  telemetry sampling cadence; `log.level` is the fallback filter for `logging::init`. Structure was
  consolidated to keep files under the size limit (`main.rs` → 228, `schema/mod.rs` → 377, `client/mod.rs`
  → 377) by moving the daemon runtime to `daemon.rs`, `generate_config` to `client/config_generate.rs`, the
  new settings to `schema/settings.rs`, and tests to `client/client_tests.rs`.

### Added

- **CLI proxy latency test** (M5): `caly core delay <proxy-name>` runs the Clash `GET /proxies/{name}/delay`
  probe as an offline query against the running controller. `KernelControl` gained `test_delay(name, timeout)`
  (returns `Ok(Some(ms))` on success, `Ok(None)` when the probe fails — e.g. the host is unreachable — and
  `Err` only on a transport-level failure), implemented for both Mihomo and sing-box (same endpoint). The
  proxy name is percent-encoded and the socket timeout is kept above the probe timeout. Output supports
  human and `--json` forms; sing-box's capability set now advertises `UrlTest`. Includes a CLI parse test
  and a real-kernel sing-box E2E delay assertion.

### Changed

- **sing-box runtime mode switching** (M5): after reading the sing-box docs, mode is implemented by
  `clash_mode` route rules and set at config load via `default_mode`; runtime switching needs the rules
  present or `/configs` reports `mode-list: ["rule"]`. The sing-box renderer now emits a `GLOBAL` selector
  plus `clash_mode: Global → GLOBAL` / `clash_mode: Direct → direct` route rules (accepted by the real
  `sing-box check`), `SingBoxHttpControl` gained `set_mode` (`PATCH /configs`), and `SingBoxCoreBackend::
  set_mode` now drives the live kernel instead of returning Unsupported — so `caly -c mode` works on
  sing-box. Both kernels now advertise `Capability::RuntimeModeSwitch`. New render unit test and a
  real-kernel E2E (`sing_box_real_binary_mode_switch_and_select`) verify mode switching and `PUT /proxies`
  selection (383 tests total).
- **File-structure consolidation** (M5): renames/combines/moves across the workspace while keeping
  dependency discipline and all gates green.
  - `caly-domain`: `dns_server.rs` → `nameserver.rs` (it holds the `Nameserver`/`FakeIpRange` value types,
    not a server); `node/canonical/protocol.rs` → `protocol_encode.rs` (resolves the duplicate `protocol.rs`
    filename against `node/protocol.rs`).
  - `caly-kernel`: merged `mihomo/http_transport.rs` into `mihomo/http.rs` (the bounded transport is an
    `impl` block on `MihomoHttpControl`; file stays under the 400-line limit).
  - `caly-application`: renamed the actor command-enum modules `actors/{platform,subscription,telemetry}.rs`
    → `actors/*_command.rs` (consistent with the `*_handler.rs` convention); renamed `service/runtime.rs` →
    `service/runtime_service.rs` (module `runtime` now unambiguously the actor runtime) and moved its tests
    to `service/runtime_service/runtime_service_tests.rs`.
  - `caly-protocol`: removed the empty `auth/`, `compat/`, `server/` placeholder dirs (only `.gitkeep`).
  - `docs/project-layout.md` rewritten from the stale "planned" layout to the actual current structure;
    `docs/verification.md` and `scripts/check-integration-invariants.py` updated for the renames.
- The previous append-only TODO moved to `docs/archive/TODO-legacy-2026-08-04.md`; historical roadmaps,
  refactor log, capability map and refactor plan consolidated under `docs/archive/historical/`.
- Daemon admission (`CommandSupportPolicy::lifecycle_and_platform`) now exposes lifecycle +
  `SetSystemProxy` + `CloseAllConnections` + `SelectProxy` + `RefreshSubscription`; contract-only
  commands still fail before Operation reservation.
- Every active operation owns an atomic cancellation/commit token propagated with `RoutedCommand`.
- sing-box and Mihomo configuration publication are owner-only atomic (`0600`).
- Runtime socket/lock/workdir moved to `$XDG_RUNTIME_DIR/caly`; durable state to `$XDG_STATE_HOME`.

### Fixed

- Split `caly-application` into ports-and-adapters: new `caly-ports` (shared port traits + error) and
  `caly-backends` (concrete adapters) crates; `caly-application` now holds only use-cases and projection.
- Removed the dead ApplyConfig saga network (coordinator/commit_barrier/service-commit, CoreActorPort,
  FatalFault::CommitOwner) — model code never called in production; `ApplyConfig` stays fail-fast with the
  `ConfigActorPort` surface retained.
- Core command backend is now selected by the active core (`CoreBackend { Mihomo, SingBox }`), so
  `select-proxy` / `close-connections` hit the running kernel instead of always the Mihomo controller.
- Removed the redundant SupervisorActor (crash recovery is owned by the single exit-monitor), the
  unused parallel `runtime/mailboxes.rs`, the never-imported `caly-cli` crate, and the dead ConfigActor
  runtime wiring (spawned but never messaged, with a hardcoded `/tmp` path); the actor wait-graph is
  validated at startup.
- Unsupported coordinator/Xray commands report terminal Unsupported instead of terminating the actor.
- Cancel/commit races have exactly one atomic winner; late owner results cannot overwrite Cancelled.
- Task failures are no longer silently discarded during shutdown; first-cause fatal faults stop the transport.
- Core crash restart no longer masks a crash-loop and retries with backoff until stable.
- sing-box lifecycle and Clash-API E2E no longer collide on a shared controller port.

### Known limitations

- Xray, `ApplyConfig`/`SetMode`/`SetTun`, TUI daemon-operation execution and real PTY E2E remain open.
  See `STATUS.md` and `TODO.md`; the project is not production-ready.

[Unreleased]: https://github.com/MMiku14/Caly/compare/HEAD...HEAD
