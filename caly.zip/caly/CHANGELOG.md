# Changelog

All notable user-visible changes will be documented here.

The project follows Keep a Changelog structure. It has not yet declared a stable compatibility policy.

## [Unreleased]

### Added (multi-subscription sources + `sub list`)

- **Multiple subscription sources**: `subscriptions.sources` accepts a list of
  `{ url, enabled }` entries alongside the legacy single `subscriptions.url`.
  `caly sub refresh` now fetches **every enabled source** and merges their
  nodes into one snapshot (a single failing source no longer aborts the rest;
  its error is reported while the others still land). The legacy `url` stays
  as a single-source alias and is always enabled when set.
- **Stable per-source identity**: each source URL maps to a deterministic
  `SubscriptionId` derived from its SHA-256 digest, so the same URL always
  writes to the same cache entry across daemon restarts — and duplicate URLs
  (across `url` + `sources`, or repeated entries) are fetched once. The
  restart-restore path already read every cache file, so multi-source nodes
  are naturally restored without re-fetching.
- **`caly sub list`**: reports the configured subscription sources (each
  enabled URL, numbered) or the JSON form via `--json`. Read-only and
  client-side, mirroring `config validate`.

### Changed (TUN tuning re-reads on every `config apply`)

- **`tun.enabled` edits no longer need a daemon restart**: the config backends
  re-resolve the TUN settings from the layered config on each apply, mirroring
  the subscription-URL re-read on refresh. Boot still resolves once; the
  shared schema→domain mapping keeps both paths in sync.
- **Core start failures surface a `CAP_NET_ADMIN` hint**: when TUN is enabled
  and the core exits before becoming ready (the kernel denies `TUNSETIFF`
  without the capability), the error now says so and points at
  `sudo setcap cap_net_admin=+ep "$(command -v sing-box)"` or a
  `CAP_NET_ADMIN` daemon — instead of the cryptic "process exited before
  becoming ready".

### Fixed (TUN engage prompts once, and never half-engages)

- **One password prompt per TUN engage**: the privileged `ip tuntap`/`ip link`
  sequence (drop-stale, add, mtu, up) now runs directly first and, when the
  daemon lacks `CAP_NET_ADMIN`, escalates the whole sequence as a single
  `pkexec`/`sudo sh -c` batch. Previously each `ip` command prompted
  separately (up to four root passwords per `caly sys tun on`).
- **`sys tun on` refuses a config that cannot render a tun inbound**: when
  `tun.enabled` is `false`, engaging used to create the interface with no
  core inbound and no routes — a state that carries zero traffic. The CLI
  now fails loudly with the exact fix (`tun.enabled: true` + daemon restart)
  instead of silently half-engaging.

### Fixed (node latency testing is truthful)

- **A 404 is no longer reported as "unreachable"**: `caly core delay <name>`
  now distinguishes a proxy that is not configured in the running kernel
  (loud error, hints at `caly config apply`) from a genuinely unreachable
  target (HTTP 5xx) and from a probe that never completed (read timeout /
  connection drop). Previously every failure mode collapsed into
  `unreachable / no latency`, so a typo, an unapplied subscription, or a
  hung probe all looked identical.
- **`delay --all` reconciles with the running kernel**: the sweep fetches the
  kernel's real proxy list first and probes only nodes that are actually
  present; nodes that never made it into the kernel config (unsupported
  protocol, duplicate-name suffix, unapplied subscription) are reported as
  `not in kernel config` with a hint instead of a silent wall of
  "unreachable".
- **Bounded sweep concurrency**: `delay --all` probes with a 32-worker pool
  instead of one OS thread + one controller connection per node (267 nodes
  previously meant 267 threads), reusing a controller per worker.
- **Sweep output is explicit**: rows carry a status
  (`reachable`/`unreachable`/`not_in_kernel`/`error`); JSON adds the status
  field and per-class counts; `select --delay` reports why no node answered
  instead of failing silently.

### Fixed (TUN re-engagement)

- **Stale TUN device cleanup**: `caly sys tun on` no longer fails with
  `ioctl(TUNSETIFF): Device or resource busy` when a previous run left a
  `caly0` device behind (crashed daemon or interrupted engage). The backend
  now drops any existing interface with the requested name before creating a
  fresh one; a live process holding the name fails with a clear in-use error.

### Fixed (config apply is a real transaction)

- **Reload failure rolls back**: if the active core cannot reload a committed
  config, the previous generation is restored via `rollback_commit` instead of
  leaving a half-applied config behind; the failed operation reports
  `previous generation restored`.

### Changed (subscription fetch policy is honored)

- **`follow_redirects` / `use_environment_proxy`** now actually drive the HTTP
  client (bounded redirects up to 3 hops; system proxy only when enabled).
  Both default to off, preserving the SSRF-safe direct fetch.

### Changed (daemon control plane transport)

- **Length-prefixed JSON framing replaces gRPC**: the owner-only control plane
  now speaks compact JSON over UDS/TCP instead of tonic/protobuf. Wire
  semantics (handshake, session tokens, watch streaming, error codes) are
  unchanged; the dependency tree loses the gRPC/protoc stack.

### Changed (naming consistency)

- User-facing command hints, generated-config comments and docs now say
  `caly` (binary/command) consistently. Historical crate names (`caly-*`),
  XDG paths (`~/.config/caly`) and env vars (`CALY_*`) are kept unchanged.

### Fixed (E2E geoip provisioning)

- The real-kernel DNS validation tests pre-provision `geoip.metadb` via the
  system toolchain instead of relying on mihomo's own (blockable) download;
  the full workspace suite runs green without environment prerequisites.

### Changed (data-structure determinism)

- **Node registry HashMap → BTreeMap**: `CoreNodeRegistry` now iterates in ascending canonical
  `NodeId` order, so the rendered `proxies:` section and url-test group membership are
  byte-reproducible across runs (previously random per process). Subscription stores
  (cached sources/generations/userinfo, http sources) switched to BTreeMap for deterministic
  multi-subscription enumeration. Group selection in `build_settings` is now explicitly the first
  entry instead of the iteration-order last. Covered by a determinism regression test.

### Fixed (daemon startup UX, from real-run debug)

- **Core-selection guidance**: the boot auto-start failure warning now carries the configured
  core and switching guidance (`CALY_CORE=sing-box` or `core:` in config.yaml) — previously a
  user setting the wrong env var (`CALY_BIN`) got a Mihomo error with no hint about selecting
  sing-box.
- **Robust bundled-binary resolution**: `vendor/bin/<core>` is now resolved from the working
  directory first, then by walking the executable's ancestors (dev builds run from
  `target/debug` find the repo's `vendor/bin`), with the CWD-relative fallback kept for error
  reporting; `ensure_executable` flags relative paths explicitly.

### Added (port & DNS engineering parity)

- **fake_ip_filter**: domains that must receive real IPs in fake-ip mode (STUN/mDNS/NCSI/NTP/
  gaming defaults ship in the generated 40-dns fragment); schema → bounded domain patterns →
  Mihomo `fake-ip-filter:` rendering.
- **fallback_filter**: anti-poisoning filter (geoip/geoip_code/ipcidr/domain; CIDRs fully
  address-validated) rendered as Mihomo `fallback-filter:`.
- **dns.listen / dns.ipv6**: configurable DNS listener address (socket-address validated) and AAAA
  switch.
- **kernel.bind_address**: the allow-lan × bind-address listen matrix on both kernels (Mihomo
  `bind-address:` only with allow-lan; sing-box mixed inbound picks loopback / `0.0.0.0` / the
  configured interface IP). Filter/listen fields are Mihomo-only by design — sing-box has no
  equivalents (documented in code).
- **Real-kernel E2E**: a full DNS block (fake-ip-filter + fallback-filter + listen) passes
  `mihomo -t`.

### Added (sing-box rule rendering parity)

- **Config rules now render into sing-box `route.rules`** (previously Mihomo-only, despite the
  schema doc claiming both): a new shared pure renderer (`caly-config::rule_render`) maps the
  domain `RoutingRule` model onto sing-box route semantics — DOMAIN/DOMAIN-SUFFIX/DOMAIN-KEYWORD/
  IP-CIDR become structured rule objects, MATCH becomes `route.final` (first match wins),
  DIRECT/REJECT map to `direct`/`block` (with an auto-added `block` outbound), group names fold
  into the `PROXY` selector (`GLOBAL` keeps its own). GEOIP maps onto the modern **rule-set**
  mechanism (remote SagerNet `geoip-*.srs` sources) because the plain `geoip` rule key was
  removed in sing-box 1.12 — validated by real `sing-box check` E2E. Rules with proxy policies
  are skipped (and warned) in the subscription-less base config where no proxy outbound exists.
- **Both renderers wired**: the subscription document appends config rules after the
  `clash_mode` rules; the base renderer embeds them with the MATCH-derived `route.final`.

### Fixed (durable recovery deep debug)

- **Re-engagement no longer corrupts the captured original state**: engaging an already-engaged
  effect (e.g. `sys proxy on` twice) used to re-capture the desktop — recording caly's own proxy as
  the "original" state and breaking the graceful-shutdown fidelity restore. Existing records are now
  kept, and a failed re-engagement no longer destroys crash-recovery evidence (proxy and TUN alike).
- **Boot no longer double-engages after restore-first**: when a crashed daemon restarts,
  restore-first re-applies the proxy effect; the config-driven boot engagement now detects the
  `Restored` outcome and projects the engaged view instead of re-engaging (which would have
  re-captured caly's own proxy as the original state).

### Changed (recovery convergence)

- **Symmetric graceful shutdown**: `DurableTunBackend::restore_and_clear` mirrors the proxy
  fidelity restore (no record = no-op; record cleared only on success); the shutdown TUN branch
  collapsed from hand-rolled load/revert/clear into one call. Dead `tun_recovery` handles removed
  from the composition root.
- **Sniffer rendering guard**: with all three port lists empty the whole `sniffer:` block is
  skipped instead of emitting a child-less `sniff:` key.

### Changed (deep convergence, round two)

- **Self-documenting platform views**: the domain gains `PlatformEffectView::none()` /
  `proxy(engaged)` / `tun(engaged)`; 17 magic-tuple `new(bool, bool, bool, None)` construction
  sites across application/backends/server/tui migrated. Only the wire decoder and a two-effect
  TUI fixture keep the general constructor.
- **rule_render dedupe**: geo rule-set source registration moved from `Vec::contains` (O(n²)) to a
  `BTreeSet` (O(log n) inserts, deterministic sorted emission).

### Changed (renderer convergence, deep audit)

- **sing-box renderer collapsed to one entry point**: the eight telescoping `render*` delegates
  (`render`/`render_with_controller`/`_and_secret`/`render_with_tun`/`_and_dns`/`_dns_secret`/
  `_dns_secret_tun`/`_dns_secret_log`) are gone; `render_tuned(&SingBoxBaseTuning)` is the single
  rendering API — a tuning struct instead of an 11-argument signature, and one JSON document
  template instead of two. New tuning dimensions (sniffing, route rules, rule-set sources) no
  longer grow the API surface; all unit/E2E call sites migrated.
- **Deep audit outcomes**: the `failure()` crate alias stays (inlining it was tried and rejected —
  it pushed two files past the 400-line budget); a process-wide daemon-config load cache was
  prototyped and rejected (conflicted with the `_from(root)` test seams on a cold path). No dead
  public API found.

### Added (traffic sniffer)

- **Sniffer wiring (B7)**: new top-level `sniffer:` config section — `enabled`,
  `override_destination`, `parse_pure_ip`, `force_dns_mapping` and per-protocol port lists
  (`http_ports`/`tls_ports`/`quic_ports`, each spec `N` or `N-M`, validated at load with a
  readable `InvalidSnifferPort` error). Mihomo renders a full `sniffer:` block (validated by the
  real binary via `mihomo -t` in a new E2E); sing-box renders `sniff`/`sniff_override_destination`
  on the mixed/transparent inbounds in both the base and the subscription renderers.

### Changed (renderer convergence)

- **sing-box renderer convergence**: `render_with_controller_dns_secret_tun` no longer duplicates
  the document JSON template; it delegates to `render_with_controller_dns_secret_log` (one
  rendering body instead of two). The daemon's subscription-less sing-box render was extracted
  into `render_base_sing_box_config`, keeping every lifecycle builder within the function-size
  budget.

### Changed (system-proxy fidelity & graceful shutdown)

- **System proxy fidelity restore**: before engaging the desktop system proxy, the current desktop
  state is captured (GNOME `gsettings` mode/host/port, KDE `kioslaverc` ProxyType/httpProxy, niri
  `environment.d`) and stored in the durable recovery record (`original_mode` + `original_endpoint`;
  legacy records without the endpoint field still deserialize). On graceful daemon shutdown exactly
  that captured state is restored (manual + endpoint / auto / none) instead of merely disabling the
  proxy; capture failures degrade to `none` (restore = disable) and never block engagement.
- **Graceful platform shutdown**: `restore_platform` now reverts the active proxy side effect
  through the durable owner before clearing its recovery record. A failed revert retains the record
  (restore-first on the next boot retries), and a missing record never touches the desktop, so a
  manually configured user proxy is never clobbered.
- **Generated fragment docs**: `70-system-proxy.yaml` now documents the actual contract (boot-time
  engagement with graceful degradation on unsupported desktops, crash restore-first, graceful
  fidelity restore), replacing the stale "records intent only" wording.

### Added (rule engine, redir-host, transparent proxy)

- **Routing rule engine**: `rules:` config section (Clash-format lines, validated at load with full
  IP-CIDR address validation), rendered into Mihomo `rules:` with smart MATCH-catch-all completion.
  Domain `RoutingRule` model with a pure host matcher; IP/CIDR matching lives in
  `caly-config::rule_match` (address arithmetic stays out of the domain).
- **CLI rule commands**: `caly core rules` (list) and `caly core rule-match <host|ip>` (offline
  diagnostic showing which rule a host or IP hits, first match wins).
- **DNS redir-host mode**: `dns.mode: redir-host` renders `enhanced-mode: redir-host` (Mihomo) and
  standard resolution (sing-box); covered by render tests alongside fake-ip.
- **Transparent proxy**: `kernel.transparent.{enabled,mode,port}` renders a redirect/tproxy inbound —
  Mihomo `redir-port`/`tproxy-port`, sing-box `redirect`/`tproxy` inbound (both modes tested).

### Changed (quality refactor)

- **Wire semantics single-sourced**: new `caly-protocol::protocol::v2::wire` module owns every
  wire-discriminant mapping (`WireMode`/`WireCoreKind`/`WireCoreAction`/`WireRunState`/
  `WireOperationState` with bidirectional conversions, labels, terminal detection and domain
  bridges). Daemon encoding, snapshot decoding, server command decoding and all CLI mappings now
  derive from it; nine duplicated mapping functions were deleted.
- **All client JSON is serde_json-built**: `status`, operation status, `core list-nodes`, offline
  queries and `sub check` no longer hand-assemble JSON. This fixes a real bug where node names
  containing quotes/backslashes produced invalid JSON in `sub check --json`.
- **Unified mutation path**: all CLI mutations flow through one `execute_operation_with` helper;
  eight copy-pasted execute/poll blocks collapsed to one.
- **Error hygiene**: eight error types gained `Display`; sixteen `{error:?}` Debug leaks in
  caly-backends now render clean human messages; client error reporting consolidated into
  `output::report_usage_error`/`report_failure`.
- Kernel failure constructors consolidated: four per-module `failure()` copies collapsed onto
  `caly_kernel::common` (`failure`/`failure_with_kind`/`config_failure`).

### Changed

- **CLI surface consolidation**: every capability now has exactly one canonical spelling. Removed the six
  top-level shortcuts (`start`/`stop`/`restart`/`refresh`/`proxy`/`tun`), all dash-prefixed aliases
  (`-c`/`-s`/`-p`/`-g`/`-t`/`-d`/`-v`, `config -vim|-nvim`, `config --default`) and the pre-clap legacy
  argument rewriting; the tree families (`core`/`sub`/`sys`/`config`) are the single entry point.
  `config-check <file>` moved into the family as `config check <file>`; `config init` is now
  `config generate` (hidden alias kept); `core connections` was renamed to `core close-connections`
  so the destructive action no longer masquerades as a query (hidden aliases kept). All help texts that
  were previously empty are now documented.
- **`core select` accepts a display name**: the argument may be a 32-hex node ID or a node's display
  name, resolved against the daemon snapshot (exact match first, then a unique case-insensitive match;
  ambiguous names list the candidate IDs).
- **Mutation results are semantic**: successful operations print `ok: <what happened>` (for example
  `ok: mode set to global`) instead of only an opaque operation id; failures print the structured error
  and hint on stderr. `--json` operation output is unchanged.
- **`config default` backup scope**: the reset now backs up the whole config directory (base and
  fragments) to a timestamped `caly.bak.<millis>` sibling directory instead of only the base file.
- **Generated fragment docs**: `70-system-proxy.yaml` now states that `system_proxy.enabled` records
  intent only (no boot-time auto-engagement; use `caly sys proxy on`), and `60-tun.yaml` distinguishes
  TUN rendering into the core config from engaging the platform TUN device.
  (Superseded: boot-time engagement was wired in the 接线补全 round and the fragment text corrected
  in the system-proxy fidelity round above.)

### Added

- **Subscription format coverage** — the full common-format matrix now parses (all verified with
  `sub check` against crafted samples):
  - Clash YAML (raw) and **Base64-encoded Clash YAML** (previously rejected; the decoded body is now
    re-checked for a `proxies:` document).
  - **SIP008 JSON**: bare server arrays and `{"version":1,"servers":[...]}` envelopes, raw or
    Base64-encoded; unsupported ciphers/bad entries are skipped and counted, not fatal
    (`caly-config::subscription::parse_sip008`, wired into both renderers and the display pipeline).
  - **SSR (`ssr://`)**: recognized and gracefully skipped — mixed documents parse the usable nodes
    and report `ssr-skipped: N`; pure-SSR documents report `format: ssr-only` with a conversion hint
    instead of an opaque parse error.
  - V2Ray `vmess://` robustness: empty-string placeholders (`"host":""`, `"path":""`) now count as
    absent instead of rejecting the node (common in real-world payloads).
- **Plain-text subscriptions**: `sub check` and the daemon refresh path now recognize
  URL-list documents (one HTTP(S) subscription URL per line, `#` comments allowed); the daemon
  fetches and merges up to 32 children through the same SSRF-safe path before node parsing
  (nested lists are rejected). VMess `net: http`/`h2` nodes now parse onto `Transport::Http2`
  instead of being rejected.
- **`daemon.auto_start_core`** (default true): whether the daemon engages the core at boot.
- **`kernel.start_timeout_ms` / `kernel.stop_timeout_ms`**: core readiness and graceful-stop
  budgets, wired through the lifecycle backends (Mihomo and sing-box).
- **Config surface enrichment** — four new/extended sections, all validated at parse time, all wired:
  - `kernel:` — `mixed_port` (local inbound; Mihomo `mixed-port`, sing-box mixed inbound),
    `allow_lan`, `log_level` (rendered per-kernel: Mihomo `log-level`, sing-box `log.level`),
    and `restart.{initial_backoff_ms,max_backoff_ms}` bounding the crash-loop self-healing backoff.
  - `dns:` — `enabled`, `mode` (standard/fake-ip/redir-host), `nameservers`, `fallback`, `direct`,
    `default`, `fake_ip_range`; maps onto the bounded `caly_domain::DnsSettings` model and is rendered
    into both kernels' configs (Mihomo `dns:` block, sing-box `dns` object with resolver wiring).
    Environment `CALY_DNS_*` still overrides when `CALY_DNS_ENABLE` is set.
  - `subscriptions:` — fetch-policy tuning: `connect_timeout_ms`, `request_timeout_ms`, `max_body_mb`,
    `follow_redirects`, `use_environment_proxy` (SSRF-safe defaults preserved).
  - `system_proxy:` — `host` and optional `port` for the desktop proxy endpoint; the port defaults to
    `kernel.mixed_port`, and `CALY_SYSTEM_PROXY_HOST/PORT` still override.
  - `tun:` — new `escalation` policy (`auto|pkexec|sudo|none`, default `auto`) for the privileged
    `ip` commands.
- **TUN privilege escalation**: `caly sys tun on` no longer just fails when the daemon lacks
  `CAP_NET_ADMIN`. Each `ip` command first runs directly, then escalates per policy (`pkexec` for a
  desktop polkit prompt, then non-interactive `sudo -n`); a final failure reports the kernel's stderr
  plus concrete remediation (`setcap` on `ip`, passwordless sudo, or daemon capabilities).
- **`core list-nodes`**: lists registered nodes with their 32-hex IDs, protocols, latency and names
  (human and `--json`), closing the loop for `core select` in a pure CLI workflow.
- **`doctor` checks core binaries**: reports whether both managed core executables resolve to an
  existing, executable file, with a remediation hint pointing at `scripts/fetch-test-kernels.sh`.
- **`status --json` includes the node count**, matching the human output.
- **Config generation hardening**: `config generate`/`config default` now self-check the written
  layout through the same layered loader the daemon uses at boot, so a renderer regression surfaces
  at generation time instead of bricking the next daemon start. The generated fragments gained a
  layered-loader round-trip test and per-section validation tests; generated layouts now include
  `15-kernel.yaml` and `40-dns.yaml` with documented replacement blocks.
- **`caly dns` probes configured nameservers**: precedence `CALY_DNS_NAMESERVERS` → `dns.nameservers`
  → built-in public defaults.

### Fixed

- Piping CLI output into a consumer that closes early (`caly status | head`) no longer panics with a
  Broken pipe backtrace; the process now exits quietly with the conventional SIGPIPE code 141.
- Daemon instance-lock failures print a human-readable sentence instead of the raw internal
  `PlatformFailure { ... }` debug representation.
- `CALY_LOG=debug` no longer drowns business logs in h2/hyper/tonic/tower frame traces; those crates
  are capped at `info` unless the user configures them explicitly.
- The bundled source no longer fails to compile: the `ConfigCmd::Validate` wiring (missing match arm and
  missing re-export of `validate_active_config`) is complete, and pre-existing gate violations
  (`panic!` in tests, 400-line file budget, 80-line function budget, empty help texts) are resolved.
- **Generated config examples are now usable**: the commented examples in generated fragments used the
  wrong indentation, so uncommenting them produced stray top-level keys rejected by `deny_unknown_fields`.
  Each optional section now shows a complete, correctly nested replacement block.
- **`config default` works again**: the reset previously refused to run whenever generated fragments
  existed (that is, always after `config generate`), restoring the base file and aborting. It now moves
  the entire config directory to a timestamped `caly.bak.<millis>` sibling before writing the fresh
  default, and restores the backup if the write fails.
- **Security (fail-closed remote listen)**: `daemon.auth_token` and `daemon.tls_enabled` were validated
  in the schema but never enforced by the TCP transport, so a non-loopback `daemon.listen` exposed an
  unauthenticated, plaintext gRPC control plane. The daemon now refuses non-loopback listen addresses at
  boot with a clear remediation message until enforced TLS and token admission exist; loopback listening
  is unchanged.
- The single-file `render_default_config()` is composed from the exact base and fragment pieces
  `config generate` writes, so the two documented layouts can no longer drift apart.
- **Rendered `external-controller` matches the configured controllers**: both kernel renderers used
  hardcoded ports (`9090`/`9091`) regardless of `controllers:` config; they now derive the address
  from the configured controller endpoints, so changing controller ports no longer silently breaks
  the control plane.
- **sing-box subscription documents carry the controller auth secret** and config-driven header
  tuning (log level, mixed inbound, controller address, TUN inbound, DNS block); previously the
  subscription-rendered config had no `secret`, no inbound and a hardcoded controller.
- **sing-box bootstrap config gains the mixed inbound** so the configured `kernel.mixed_port` is the
  same local proxy entry point across both kernels (and matches the system-proxy endpoint).
- **Bootstrap configs render TUN for both kernels**: the core-start config now includes the Mihomo
  `tun:` section / sing-box tun inbound when `tun.enabled` is set (previously only the `config apply`
  path rendered TUN, so a fresh core start ignored the configured intent).
- **Operation summaries read as requests**: mutations report verb phrases (`ok: engage TUN`,
  `ok: set mode to global`) so a failure no longer prints a contradictory `failed: TUN engaged`.
- **`doctor` gains a `tun-device` check**: warns when `tun.enabled` is set but `/dev/net/tun` is
  missing, which otherwise makes the core exit at start.
- Boot capability projection now reports DNS from the *resolved* configuration (environment
  override or config section) instead of the environment alone.
- **Daemon boot is decoupled from the kernel**: a failed core auto-start no longer aborts the
  daemon. It logs a warning, projects a stopped core and keeps serving; `caly core start` retries
  on demand. Boot restore-first (durable effects) now runs even when auto-start is disabled.
- **`system_proxy.enabled` is wired**: when true the daemon engages the desktop system proxy during
  boot (after restore-first) and degrades with a warning on unsupported desktops instead of failing.
- **Lifecycle errors no longer leak Debug representations**: Mihomo/sing-box start/stop/restart
  failures format the bounded message + suggested action (`MihomoRuntimeError` gained `Display`).
- Dead code cleanup: removed the unused `dns_env::dns_enabled()` and a never-constructed
  `SubscriptionFormat::UrlList` variant.

### Added

- A single current-status entry point in `STATUS.md` and a prioritized remediation backlog in `TODO.md`.
- GitHub CI, security/contribution policies, MIT/Apache-2.0 licenses, and a checksum-pinned kernel
  downloader (`scripts/fetch-test-kernels.sh`).
- **Local security** (M2.3):
  - Fail-closed controller secret generation (`caly_platform::secrets`) shared between the core
    config and control clients; never projected.
  - XDG runtime/state/config path resolution (`AppPaths::from_env`), owner-only lock auto-create.
  - Owner-only UDS path validation (regular file / symlink / other-user socket rejected).
- **Auto-recovery** (M2.4): `CrashLoopPolicy` state machine — exponential backoff, continuous retry
  on restart failure, stabilization window before backoff reset.
- **Restore-first + ordered shutdown** (M2.1/M2.2): durable `FileRecoveryStore` for system-proxy,
  `DurableSystemProxyBackend`, `proxy_restore_first` startup gate, and a 12-phase
  `DaemonShutdownActions` preserving per-phase failures.
- **Live watch** (M3.2): continuous server stream (`LiveWatchStream` + broadcast), lazy client watch
  iterator, lag → full-snapshot resync.
- **Telemetry** (M3.1): periodic scheduler publishing `ObservedState`, and a core-aware adapter that
  selects Mihomo or sing-box (sharing the controller secret).
- **TUI** (M3.3): `LiveWatchSource`+`WatchDriver`-driven loop on a worker thread, session-expiry
  auto-reconnect, mouse capture.
- **sing-box Clash API** (M4): `SingBoxHttpControl` with secret support; proxy_groups/connections/
  traffic/select/close-all adapters; config renderer with `clash_api.secret`.
- **CLI** (M4): a tree-structured command set with short aliases (`-v`/version, `-c`/core, `-s`/sub,
  `-p`/sys, `-t`/status, `-d`/daemon), each family owning leaf subcommands; `doctor`, `--json`,
  `--socket`, and a `--core mihomo|sing-box` override.
- **SetMode** (M4): wired end-to-end — Mihomo `/configs` PATCH via `CoreCommandBackend::set_mode`,
  admitted by the daemon, exposed as `caly -c mode rule|global|direct`. It now publishes **both a
  Desired delta and an Applied delta** via a shared desired-state cell, so `status` reflects the new mode.
- **ApplyConfig** (M4): wired through the ports/backends architecture — a `ConfigActor` command owner
  drives `MihomoConfigBackend` (parse+render → commit) and publishes `config_generation`; exposed as
  `caly -g apply`. Config is published owner-only (`0600`) under `$XDG_CONFIG_HOME/caly`.
- **Subscription-driven Mihomo config loop** (M5): `-s refresh` indexes each representable node as a
  `RegisteredProxy` (group/tag/rendered YAML) into the shared registry; `MihomoConfigBackend` now
  renders `proxies`/`proxy-groups`/`rules` from that registry, validates the candidate against the real
  `mihomo -t` binary **before** commit (rejected configs never publish), and rolls back to the previous
  generation on failure. A configured `CALY_SUBSCRIPTION_URL` is now shared by every core's refresh.
  Verified by unit tests plus real-binary E2E (`config_apply_real_e2e`, `mihomo_render_e2e`) and the
  daemon E2E (`config apply` commits an owner-only generation).
- **Layered daemon configuration** (M5): daemon boot now loads and validates `$XDG_CONFIG_HOME/caly/config.yaml`
  (base + `CALY_PROFILE` profile + `config.d/*` fragments) via the bounded layered loader and drives the managed
  core selection from the validated `AppConfig`. `CALY_CORE` remains an explicit per-process override, and a
  broken config fails boot instead of silently running on stale env defaults.
- **Handshake capability advertisement** (M5): a single `all_features()` source of truth in the protocol.
  The daemon now advertises every feature it implements (operations, cancellation, event replay, full
  snapshot recovery, unknown-enum preservation) and the thin clients (CLI/TUI) request them, so a
  handshake's `enabled_features` truthfully reflects real capabilities instead of being empty.
- **TCP transport** (M5): the validated `daemon.listen` address now binds a loopback TCP gRPC transport
  (`caly-server::tcp`) in parallel with the owner-only UDS, sharing one session registry. Absent a
  config file the daemon remains UDS-only. Verified by a Tonic-over-TCP handshake E2E and a live boot.
- **TUN owner** (M5): `SetTun` is no longer admission fail-fast. It routes to `PlatformActor`, which owns
  a `LinuxTunCommandBackend` (reusing `caly-platform::tun`'s shell-free `ip tuntap`/`ip link` engage and
  recoverable `OwnedTun::restore`) and returns a structured failure when privileges are unavailable. The
  validated `tun.mtu` from `AppConfig` drives the configured MTU.
- **TUI daemon-operation execution** (M5): `caly-tui` now emits `ControlAction`s (select node / set mode /
  restart core / close connections) into an outbox that the binary's interactive loop forwards through a
  fresh UDS connection on a background thread, so the render loop never blocks. Keys: Enter selects the
  highlighted node, `g` cycles rule→global→direct, `r` restarts the core, `c` closes connections.
- **Naming cleanup** (M5): the stale saga `CommandTarget::Coordinator` (and its mailbox/task) is renamed to
  `CoreLifecycle`, matching the actual core-lifecycle owner it hosts.
- **TUN durable crash-restore** (M5): the recovery store is generalized to `FileRecoveryStore<R>` over the
  record type (removing duplication and adding a `TunRecoveryRecord`), and a new `DurableTunBackend` persists
  a recovery record when the TUN side effect engages and restores it on startup (`restore_first`), mirroring
  the system-proxy recovery transaction. Graceful shutdown clears the pending TUN record. The daemon boots
  cleanly with restore-first wired in.
- **Structured logging + correlation** (M5): `tracing`/`tracing-subscriber` with an env filter
  (`CALY_LOG`/`RUST_LOG`) writes structured, timestamped log lines to stderr with correlation fields (daemon
  id, socket, listen address). The daemon startup path's `eprintln!` calls are replaced with `tracing`
  events, and `reporting.rs` emits a structured terminal event per operation (operation id + outcome), giving
  operation-level correlation across the daemon.
- **Fragmented-responsibility consolidation** (M5):
  - The legacy, unused-in-prod recovery machinery (`RecoveryRecord`/`RecoveryStore`/`RecoveryAction`/`restore_first`)
    and the whole dead `system_proxy` module (`engage_proxy`/`SystemProxyBackend`/`PlatformProxySnapshot`) are removed,
    converging on the single generic `FileRecoveryStore<R>`.
  - The dead `config_handler.rs` (`ConfigActorHandler`/`ConfigActorRequest`) is removed.
  - `ActorFailure::infrastructure` and `KernelFailure::new` become the single shared clamped constructors, collapsing
    the duplicated per-module `failure()`/`bounded()` helpers across backends, application, and kernel.
  - The no-op shutdown phases `StopSupervisor`/`SettleCoordinators` (leftovers from the removed saga supervisor/
    coordinator) are removed; the shutdown sequence drops from 12 to 10 phases.
  - **Xray is abandoned**: the `caly-kernel::xray` stub module and three dead `API_FAMILY` constants are removed;
    `CoreKind::Xray` remains only for wire/protocol compatibility and always resolves to Unsupported.
- **Data-structure consolidation** (M5): a single canonical `caly_domain::to_hex` now encodes 16-byte identities
  (lookup-table based, no per-byte `format!` allocation), and seven duplicated `byte:02x` loops / helpers
  (`hex_id`, `hex_token`, `hex`, lock `owner_token`, sing-box proxy tag, TUI hex, tonic hex) delegate to it.
  Reviewed the TUI `NodeList`/`NodeTree` hot path (already clones-free, sorts refs by deref) and the
  subscription diff/dedupe (already O(n log n) set operations) — no further change needed.
- **Debug / quality fixes** (M5):
  - **Clash-YAML ingest bug**: `decode_document` detected `ClashYaml`, but the display ingest path
    (`parse_uri_body_to_display_lossy`) only accepted `UriLines` and returned `UnsupportedDocument`, leaving
    `parse_clash_yaml` dead code and making `subscription-check` report `clash-yaml` yet fail to parse.
    The display/registry/mihomo/sing-box rendering paths now share a `dialable_nodes` helper that handles
    both URI-line and Clash-YAML documents; `subscription-check` on a Clash-YAML file now succeeds
    (format, node count, rejected=0), and Clash-YAML nodes are indexed/rendered consistently.
  - The controller `secret` in `composition/handlers.rs` now clamps a runtime value instead of aborting.
- **CLI wiring + robustness** (M5):
  - `sys tun on|off` wired: `SetTun` was fully implemented in the daemon (TUN owner) but had no CLI leaf; the
    new `-p tun on|off` leaf executes it and returns a structured failure when privileges are absent.
  - `config-check` now uses `load_config_file`, which auto-detects YAML or JSON — previously it only accepted
    JSON (`load_json_file`), so it wrongly rejected the YAML configuration the daemon actually loads.
  - An invalid `--core` value (not `mihomo`/`sing-box`) is now rejected with exit code 2 before any daemon
    connection instead of silently mapping to mihomo.
- **Subscription connection robustness** (M5): the HTTP subscription fetch now retries transient failures
  (connect/request timeout) with a short backoff, while non-transient policy failures (bad URL, unexpected
  status, body too large) surface immediately. The retry loop is extracted into a pure `retry_fetch` helper
  with three unit tests. Reviewed and confirmed intact: DNS pinning/SSRF filtering, redirects disabled, body
  ceilings, multi-protocol URI parsing, and cache persistence.
- **Handler reporting consolidation** (M5): a new `reporting::report_outcome` centralizes the completed/failed
  dispatch tail that every owner handler (core, core-lifecycle, config, subscription, platform) previously
  repeated. All five `handle` implementations now report through the single shared tail, keeping reporting
  semantics and structured logging in one place.
- **Reality handshake parsing fix** (M5): line-by-line review found `uri.rs::tls()` set only the SNI for
  `security=reality` nodes and never parsed the Reality handshake identity (`pbk`→public key, `sid`→short id,
  `spx`→spider). Reality nodes now parse their identity (rejecting a missing `pbk`), so their canonical
  identity no longer collides with equivalent plain-TLS nodes. Two unit tests added.
- **Renderer completeness for vless flow/TLS/reality/transport** (M5):
  - `TlsConfig`/`RealityConfig` read-only accessors are now `pub` (secrets still only exposed via
    `SecretText::with_exposed`, so no credential leakage).
  - Fixed `uri.rs::parse_proxy_uri` never parsing transport: `type=ws/grpc/httpupgrade/quic` and
    `path`/`host`/`serviceName` are now parsed for URL-shaped URIs (vless/trojan/etc.), not just vmess.
  - The sing-box renderer now emits `flow`, `tls` (server_name/insecure), `reality` (public_key/short_id/
    spider_x) and `transport` (ws/grpc/httpupgrade/quic) for vless outbounds.
  - The mihomo renderer now emits `flow`, `tls`/`servername`, `reality-opts` and `network`/`ws-opts` for vless.
  - Verified against the real kernels (`mihomo -t`, `sing-box check`) and a new vless-ws-reality render unit test.
- **Renderer completeness for trojan/vmess TLS/transport** (M5): the sing-box and mihomo renderers' trojan
  branch only emitted the password and the vmess branch only the uuid, dropping TLS (trojan is almost always
  TLS) and transport, and vmess also dropped `alterId`/cipher. Now both renderers emit tls/transport for
  trojan and vmess, and sing-box emits `alter_id`/`security` for vmess (via a new `vmess_cipher` mapping).
  Verified against the real kernels and two new render unit tests.
- **Reality `short_id` made optional** (M5): Reality's short id is optional, but the parser forced `sid`
  non-empty, so real Reality subscription nodes without a `sid` failed to parse. `RealityConfig::new` now
  takes `Option<SecretText>`, `short_id()` returns `Option`, the parser uses an optional secret reader, and
  the canonical-identity encoder plus both renderers (sing-box `short_id`, mihomo `short-id`) handle the
  optional field. A test confirms a Reality node without `sid` now parses.
- **TUN stack / auto-route / strict-route configuration** (M5):
  - New core-agnostic `caly_domain::TunConfig` (`TunStack` gvisor/mixed/system, `auto_route`, `strict_route`,
    `mtu`) mirroring the `DnsSettings` value-type pattern.
  - The Mihomo renderer emits a `tun:` block (`enable`/`stack`/`auto-route`/`strict-route`/`mtu`); the
    sing-box renderer emits a tun inbound. Both are accepted by the real `mihomo -t` and `sing-box check`
    for all three stacks.
  - The config schema `TunConfig` gains `stack`/`auto_route`/`strict_route`, and `daemon_config::tun_config()`
    maps them onto the domain type.
  - The TUN config is threaded through composition to the config backend (`MihomoConfigBackend::with_tun`),
    so a config-driven daemon's `config apply` renders a full `tun:` block (verified end-to-end with the real
    mihomo binary).
- **Offline Clash API queries** (M5): new `core proxy-groups` (groups + current selection), `core
  list-connections` (connection summary), and `core traffic` (download/upload totals) leaves run directly
  against the running core's controller, without a daemon mutation operation. The daemon persists its
  generated controller secret to an owner-only `$XDG_RUNTIME_DIR/caly/controller.secret` so offline queries
  authenticate; `CALY_CONTROLLER_SECRET` overrides. Verified end-to-end against a real mihomo daemon.
- **Subscription quota detection** (M5): a new `userinfo` parser reads the Clash `subscription-userinfo`
  response header (upload/download/total/expire); `fetch_pinned` carries it in `FetchResult::Updated` and the
  cached backend stores it. `sub check <file> --userinfo <header>` reports remaining quota in JSON and human
  form.
- **DNS A-record resolution** (M5): `dns_probe` now parses the answer section and returns the resolved A-record
  address (`DnsProbeOutcome::Resolved(Option<IpAddr>)`), so `caly dns example.com` shows the actual IP
  (verified: 104.20.23.154) instead of a generic "Resolved".
- **Subscription fetch retry made structural** (M5 debug): `fetch_once` now returns an explicit transient flag
  (`Result<(), (bool, ActorFailure)>`) instead of string-matching the failure message, and `is_transient_fetch`
  classifies connect/request timeouts **and 5xx server statuses** as retryable (server 5xx is a common
  transient subscription failure) while policy rejections are not. A classification unit test was added.
- **Controller secret lifecycle** (M5 debug): `finish_daemon` now removes the owner-only
  `$XDG_RUNTIME_DIR/caly/controller.secret` on shutdown so a stopped daemon no longer leaves a stale secret
  for offline queries. Verified end-to-end (created mode 600 on start, removed on stop).
- **Doc-verified TUN/outbound completeness** (M5): after checking the Mihomo and sing-box docs,
  - the sing-box tun inbound now emits the required `address` (`172.18.0.1/30`, `fdfe:dcba:9876::1/126`);
  - the Mihomo `tun:` block now emits `auto-detect-interface` and `dns-hijack: [any:53]`;
  - both renderers now support **hysteria2** and **tuic** outbounds (up/down/obfs for hysteria2, congestion
    control for tuic) instead of skipping them. Verified against the real kernels and two new render tests;
    the Mihomo render logic was split into `mod.rs`/`render.rs` to stay under the file-size limit.
- **Redundancy consolidation** (M5): shared plumbing for the durable side-effect backends and a single
  process-lifecycle failure helper.
  - New `caly-backends::platform::durable_support` consolidates the `bounded`/`actor_to_platform`/
    `durable_failure` helpers that were duplicated verbatim between `DurableSystemProxyBackend` and
    `DurableTunBackend`, so the two backends no longer drift on error mapping.
  - The per-module `failure` wrappers in `mihomo/runtime.rs` and `sing_box/runtime.rs` now delegate to a
    single `caly_kernel::common::failure` (was `kernel_failure`), collapsing three identical process-lifecycle
    constructors onto `KernelFailure::new`. The redundant `failure` re-export in `platform/niri.rs` was
    removed in favor of the crate-level `failure`.
  - The stale `scripts/check-infrastructure-invariants.py` reference to the deleted
    `caly-platform/src/system_proxy/transaction.rs` was repointed to the real durable backends.

### Added

- **TUI filter/sort/tree key bindings** (M5): wired the existing `set_filter`/`toggle_sort`/`toggle_tree_view`
  presentation APIs to keys. `/` enters a filter-typing mode (new `Key::Backspace` parses `0x7f`/`0x08`; while
  filtering, printable keys edit the filter buffer, Backspace deletes, Esc/Enter exit — and no global action
  fires); `s` cycles the sort key Name → Protocol → Latency; `t` toggles between the flat node list and the
  protocol tree view. The four `TuiApp` boolean flags were collapsed into a `Flags(u8)` bitfield to keep
  `clippy::struct_excessive_bools` green.

### Fixed

- **Kernel binary CPU compatibility** (M5): the default `mihomo-linux-amd64` release is an x86-64-v3 build
  (requires AVX2) and fails on baseline amd64 CPUs with "This program can only be run on AMD64 processors
  with v3 microarchitecture support." `kernels.lock.toml` now pins the official `mihomo-linux-amd64-compatible`
  (baseline x86-64) build with matching archive/binary sha256, so `scripts/fetch-test-kernels.sh` fetches a
  kernel that runs on any amd64 CPU. sing-box's `-linux-amd64` is already a baseline Go build.
- **Daemon boot failure diagnostic** (M5 debug): `./caly -d` failed with an opaque `BackendUnavailable`
  when the core binary was missing or not executable — `boot_auto_start` → `CoreLifecycleCommandBackend::
  start` failed and the underlying error was swallowed. The auto-start and lifecycle-build failure points
  now log the real cause via `tracing::error!`, and a new `caly_kernel::common::ensure_executable` check at
  core `start` time reports a clear "Mihomo/sing-box binary is missing or not executable: <path>" message
  with remediation (chmod +x, set the `CALY_*_BIN` override, or run `scripts/fetch-test-kernels.sh`). The
  check lives at start-time (not build-time) so the daemon can still build backends and the hermetic
  composition test (`start_runtime(false)`) passes without an executable binary. The default relative
  `vendor/bin/*` path depends on the working directory; `CALY_*_BIN` selects an absolute one.
- **Truthful capability coverage + traffic parse bug** (M5 debug):
  - `core_capability_set` (the boot-time projection) previously assessed only `DnsConfiguration`; it now
    covers the full nine wired system capabilities (TUN, DNS, runtime mode switch, proxy groups,
    proxy selection, URL test, connections, connection close, traffic), so the daemon advertises a
    complete, truthful capability set on start. Mihomo/sing-box report `Supported`, sing-box reports
    `Partial` for connections/traffic (subset of the Clash API), and Xray reports `Unsupported`.
  - Kernel capability sets corrected: Mihomo no longer advertises the unwired `Rules`/`Logs` and now
    advertises `ConnectionClose`; sing-box now advertises `ProxySelection` and `ConnectionClose`.
  - **`traffic_bytes` bug**: `/traffic` field names differ per kernel — Mihomo returns `upTotal`/`downTotal`
    and sing-box returns `up`/`down` — but the parser only read `downloadTotal`/`uploadTotal`, so traffic
    always reported `0`. It now accepts all historical field names and strips any SSE `data: ` prefix.
    Verified against the real Mihomo and sing-box binaries; new `traffic_field`/`parse_traffic_frame`
    unit tests. No `unwrap`/`expect`/`panic` remains in production code (clippy enforces).

### Added

- **Config generation + broader config surface** (M5): `caly config generate` writes a documented, commented
  default `config.yaml` under `$XDG_CONFIG_HOME/caly` (usually `~/.config/caly`), owner-only (`0600`), and
  refuses to overwrite an existing file. The schema gained three more sections — `controllers`
  (`mihomo`/`sing_box` Clash-compatible endpoints), `log.level`, and `telemetry.interval_ms` — each with
  defaults and validation (`controllers` addresses must be `host:port`, `log.level` must be
  error/warn/info/debug/trace, `telemetry.interval_ms` ≥ 100). These are wired through the daemon: the
  `controllers` precedence is now config > `CALY_*_CONTROLLER` env > built-in defaults, driving the
  command/telemetry control clients and the CLI offline queries; `telemetry.interval_ms` drives the
  telemetry sampling cadence; `log.level` is the fallback filter for `logging::init`. Structure was
  consolidated to keep files under the size limit (`main.rs` → 228, `schema/mod.rs` → 377, `client/mod.rs`
  → 377) by moving the daemon runtime to `daemon.rs`, `generate_config` to `client/config_generate.rs`, the
  new settings to `schema/settings.rs`, and tests to `client/client_tests.rs`.

### Added

- **CLI proxy latency test** (M5): `caly core delay <proxy-name>` runs the Clash `GET /proxies/{name}/delay`
  probe as an offline query against the running controller. `KernelControl` gained `test_delay(name, timeout)`
  (returns `Ok(Some(ms))` on success, `Ok(None)` when the probe fails — e.g. the host is unreachable — and
  `Err` only on a transport-level failure), implemented for both Mihomo and sing-box (same endpoint). The
  proxy name is percent-encoded and the socket timeout is kept above the probe timeout. Output supports
  human and `--json` forms; sing-box's capability set now advertises `UrlTest`. Includes a CLI parse test
  and a real-kernel sing-box E2E delay assertion.

### Changed

- **sing-box runtime mode switching** (M5): after reading the sing-box docs, mode is implemented by
  `clash_mode` route rules and set at config load via `default_mode`; runtime switching needs the rules
  present or `/configs` reports `mode-list: ["rule"]`. The sing-box renderer now emits a `GLOBAL` selector
  plus `clash_mode: Global → GLOBAL` / `clash_mode: Direct → direct` route rules (accepted by the real
  `sing-box check`), `SingBoxHttpControl` gained `set_mode` (`PATCH /configs`), and `SingBoxCoreBackend::
  set_mode` now drives the live kernel instead of returning Unsupported — so `caly -c mode` works on
  sing-box. Both kernels now advertise `Capability::RuntimeModeSwitch`. New render unit test and a
  real-kernel E2E (`sing_box_real_binary_mode_switch_and_select`) verify mode switching and `PUT /proxies`
  selection (383 tests total).
- **File-structure consolidation** (M5): renames/combines/moves across the workspace while keeping
  dependency discipline and all gates green.
  - `caly-domain`: `dns_server.rs` → `nameserver.rs` (it holds the `Nameserver`/`FakeIpRange` value types,
    not a server); `node/canonical/protocol.rs` → `protocol_encode.rs` (resolves the duplicate `protocol.rs`
    filename against `node/protocol.rs`).
  - `caly-kernel`: merged `mihomo/http_transport.rs` into `mihomo/http.rs` (the bounded transport is an
    `impl` block on `MihomoHttpControl`; file stays under the 400-line limit).
  - `caly-application`: renamed the actor command-enum modules `actors/{platform,subscription,telemetry}.rs`
    → `actors/*_command.rs` (consistent with the `*_handler.rs` convention); renamed `service/runtime.rs` →
    `service/runtime_service.rs` (module `runtime` now unambiguously the actor runtime) and moved its tests
    to `service/runtime_service/runtime_service_tests.rs`.
  - `caly-protocol`: removed the empty `auth/`, `compat/`, `server/` placeholder dirs (only `.gitkeep`).
  - `docs/project-layout.md` rewritten from the stale "planned" layout to the actual current structure;
    `docs/verification.md` and `scripts/check-integration-invariants.py` updated for the renames.
- The previous append-only TODO moved to `docs/archive/TODO-legacy-2026-08-04.md`; historical roadmaps,
  refactor log, capability map and refactor plan consolidated under `docs/archive/historical/`.
- Daemon admission (`CommandSupportPolicy::lifecycle_and_platform`) now exposes lifecycle +
  `SetSystemProxy` + `CloseAllConnections` + `SelectProxy` + `RefreshSubscription`; contract-only
  commands still fail before Operation reservation.
- Every active operation owns an atomic cancellation/commit token propagated with `RoutedCommand`.
- sing-box and Mihomo configuration publication are owner-only atomic (`0600`).
- Runtime socket/lock/workdir moved to `$XDG_RUNTIME_DIR/caly`; durable state to `$XDG_STATE_HOME`.

### Fixed

- Split `caly-application` into ports-and-adapters: new `caly-ports` (shared port traits + error) and
  `caly-backends` (concrete adapters) crates; `caly-application` now holds only use-cases and projection.
- Removed the dead ApplyConfig saga network (coordinator/commit_barrier/service-commit, CoreActorPort,
  FatalFault::CommitOwner) — model code never called in production; `ApplyConfig` stays fail-fast with the
  `ConfigActorPort` surface retained.
- Core command backend is now selected by the active core (`CoreBackend { Mihomo, SingBox }`), so
  `select-proxy` / `close-connections` hit the running kernel instead of always the Mihomo controller.
- Removed the redundant SupervisorActor (crash recovery is owned by the single exit-monitor), the
  unused parallel `runtime/mailboxes.rs`, the never-imported `caly-cli` crate, and the dead ConfigActor
  runtime wiring (spawned but never messaged, with a hardcoded `/tmp` path); the actor wait-graph is
  validated at startup.
- Unsupported coordinator/Xray commands report terminal Unsupported instead of terminating the actor.
- Cancel/commit races have exactly one atomic winner; late owner results cannot overwrite Cancelled.
- Task failures are no longer silently discarded during shutdown; first-cause fatal faults stop the transport.
- Core crash restart no longer masks a crash-loop and retries with backoff until stable.
- sing-box lifecycle and Clash-API E2E no longer collide on a shared controller port.

### Known limitations

- Xray, `ApplyConfig`/`SetMode`/`SetTun`, TUI daemon-operation execution and real PTY E2E remain open.
  See `STATUS.md` and `TODO.md`; the project is not production-ready.

[Unreleased]: https://github.com/MMiku14/Caly/compare/HEAD...HEAD
