# caly 当前待办

> 与 `STATUS.md` 配对:本文件是**未完成工作**的单一事实入口,`STATUS.md` 是**当前能力**的单一事实入口。
> 优先级: **S1 = 发布阻塞** > **S2 = 真实环境未验证** > **S3 = 文档/契约脱节** > **S4 = 代码体积/卫生(advisory)** > **S5 = Round 6+ 后续待办**。
> 最后更新: 2026-08-08(Round 13 收尾;`Refreshable` trait + 3 真 impl (`SubscriptionRefresh`/`ProfileRefresh`/`RuleProviderRefresh`);`set` namespace 拆 8 个子文件 (`set/core|proxy|tun|sub|profile|config|daemon|rule_provider` + `set/common`);`error.rs` 拆 6 个子文件 (`error/{profile,sub,core,config,daemon,usage}.rs`);`commands::legacy` → `commands::bridge` 改名;`set <res> refresh` 走 trait 统一 error envelope;3 个新 trait shape test + 3 个新 dispatch test;测试总数 726 → 733;clippy `-D warnings` clean;rustdoc `-D warnings` clean)。

每条带验证命令;完成一项后请在 commit 引用本节标题并把对应方框打钩。

---

## S1 — 发布阻塞

### S1.1 GitHub 根 workspace 实际推送

- [ ] 把当前 ZIP 形态的主线分支(含 `TODO.md`、本轮 `STATUS.md` 修正)实际推送到 `MMiku14/caly` 仓库默认分支
- [ ] 验证 `git log --oneline | head` 在 GitHub 上可见(不是 ZIP 交付)
- [ ] 在 `README.md` 把"以 ZIP 交付"措辞改为"git clone"入口

**验证**:
```bash
git ls-remote https://github.com/MMiku14/caly.git HEAD
```

### S1.2 真实 PTY E2E(TUI 长时运行 / 断线 / 键位自动化)

- [ ] 选型一个 PTY harness(`portable-pty` / `expectrl` / 自建 `pty::fork`),覆盖 TUI 的 session-expiry / 断线重连 / 键位回归
- [ ] 在 `crates/caly-tui/tests/`(新建)写 E2E:`spawn_caly_tui` → 喂入 `j/k/g/r/c/q` 序列 → 截图 ANSI 帧 → 校验与 `cargo run -p caly-tui --example dump` 的纯渲染快照一致
- [ ] 接 `Real kernel E2E` workflow(在隔离 namespace 中跑)

**验证**:
```bash
cargo test -p caly-tui --test pty_e2e -- --nocapture
```

### S1.3 `daemon.listen` TCP 入口的安全模型闭环

`127.0.0.1` 对同机其他用户可连(JSON 帧的 session token 在本机进程间是公开的),需二选一:

- [ ] **方案 A(推荐)**: 实现 auth-token admission
  - daemon 启动时生成一次 owner-only secret,写到 `$XDG_RUNTIME_DIR/caly/tcp.token`(0600)
  - 客户端首次握手 `Hello { token }`,daemon 校验通过才注册会话
  - 缺 token / 错 token → `PermissionDenied` 立刻断开
  - 在 `docs/architecture.md` §4 "Secrets" 附近补一段"loopback TCP 的安全模型"
- [ ] **方案 B**: 正式宣布 per-user UDS 为**唯一**受支持控制面,移除 TCP 入口
  - 删 `crates/caly-server/src/tcp.rs` 与 `bins/caly/src/daemon_config.rs::listen_from_config` 的非 loopback fail-closed 分支
  - `daemon.listen` 配置段保留但只接受 UDS 路径(`unix:///...`)并 fail-fast 其它
  - 同步删除 `tests/tcp_transport.rs` 与 `STATUS.md` 顶部对 TCP 的描述

**验证**(方案 A):
```bash
# 1. 启动 daemon, 故意不带 token 拨号 → 失败
./target/debug/caly daemon &
sleep 1
# 用 nc 发 Hello, 不带 token
echo '{"Hello":{"v":2}}' | nc -U /tmp/caly-user/caly/daemon.sock   # UDS 路径不应受影响
nc 127.0.0.1 <port> <<< '{"Hello":{"v":2}}'                       # 应被拒
# 2. 带正确 token → 通过
TOKEN=$(cat $XDG_RUNTIME_DIR/caly/tcp.token)
```

### S1.4(原 P0 列表第 4 条)**已废止** — `sing-box` 配置 apply 不对等

代码层面已于 M5 解决:`ActiveConfigBackend`(`crates/caly-backends/src/config/mod.rs:517-575`)按 `self.active_kind()` 在 `Mihomo` / `SingBox` 之间分派 `parse_and_render / discard_prepared / commit_candidate / rollback_commit`,装配点在 `crates/caly-application/src/composition/backends.rs:236-309`,E2E 覆盖在 `tests/sing_box_config_apply_real_e2e.rs::subscription_refresh_drives_validated_sing_box_config_apply` 与 `tests/config_apply_real_e2e.rs`(3 项全过,0.07s)。

- [x] ~~按 active core 分派~~ — 完成(M5)
- [x] ~~真实 `mihomo -t` 校验 + 失败回滚~~ — 完成(M5)
- [x] ~~真实 `sing-box check` 校验~~ — 完成(`sing_box_config_apply_real_e2e`)

> 此条**不再列为 P0 阻塞**;`STATUS.md` 的 P0 列表第 4 条已删除。如发现 `core=sing-box` 路径上 `config apply` 实际未生效, 请回滚 S1.4 并在 `tests/config_apply_real_e2e.rs` 增补失败用例。

---

## S2 — 真实环境未验证

### S2.1 真实桌面 system-proxy E2E

`crates/caly-backends/src/platform/{gnome,kde,niri}.rs` 有 durable recovery 事务,但**没有真实桌面会话**的 E2E。

- [ ] 准备 CI matrix:`ubuntu-22.04 + gnome-shell-session` 镜像 + `xvfb` + `dbus-launch`
- [ ] 写 `crates/caly-backends/tests/system_proxy_real_e2e.rs`:
  - 启动 GNOME session → `gsettings set org.gnome.system.proxy mode 'manual'`
  - 启动 caly daemon → `caly sys proxy on` → 校验 `gsettings get` 返回期望值
  - daemon 崩溃(`pkill -9`)→ 校验恢复事务回滚到原状态
  - graceful shutdown → 校验回滚到原状态

**验证**:
```bash
cargo test -p caly-backends --test system_proxy_real_e2e -- --nocapture
```

### S2.2 跨平台 `daemon.listen` 行为(目前 Linux-only)

- [ ] 在 `crates/caly-platform/src/` 抽象 `Listener::bind_listen(addr)` 平台 trait
- [ ] macOS: 实现等价于 Linux 的 owner-only 检查(uv_qos_class_t + `localhost` only)
- [ ] Windows: 实现 named-pipe 而非 TCP(目前完全没接)

> 当前 STATUS.md 已说明"Linux, per-user",此条属于"扩展到非 Linux 平台"的前置,未列入 S1。

---

## S3 — 文档 / 契约脱节

### S3.1 `STATUS.md` 数字与现实脱节

- [x] `STATUS.md:69` 测试数 `538 passed` → 改为 `580 passed`(`cargo test` 在 `vendor/bin/` 已就位时的实际数字)— Round 3
- [x] `STATUS.md:67` `7 个静态架构/规范脚本` → 改为 `6 个校验脚本`— Round 3
- [x] `STATUS.md:71-72` 拆分两行,标明:— Round 3
- [x] `README.md:16` 同步 `538 passing tests` → `580 passing tests`,补一句— Round 3
- [x] Round 5: `580 → 610` 同步
- [x] Round 6: `610 → 632` 同步(加 `rule_providers:` + 4 个新 RuleMatch variants 的 22 个 regression test)
- [x] Round 7: `632 → 676` 同步(Profile 域+schema+store+loader+CLI)
- [x] Round 8: `676 → 691` 同步(Remote fetch SSRF-safe 接线 + Inline 物化 + `--dry-run` + 写前 backup)
- [x] Round 9: `691 → 696` 同步(debug + 收敛: nested-merge `FetchChain.id` outermost, IPv4-mapped IPv6 SSRF bypass, backup 累积; 收敛 `mutate_profiles_in_config` / `refresh_recursive` / `current_unix_ms` / 4 dead `pub fn`; `LayeredConfigError.Display`)
- [x] Round 10: `696 → 708` 同步(CLI 重构: main.rs 721→121 行; JSON 错误 contract 稳定; `output::CliError` + `error::*` 稳定 code 目录; per-family `commands/*` dispatch; long_about + after_help + common workflows; 12 个 regression test 锁住 contract)
- [x] Round 11: `708 → 723` 同步(CLI 5-namespace 重构 `daemon`/`tool`/`show`/`set`; 15 个新能力; dry-run 政策翻转默认 dry-run + `--apply` 写入; 老命令 25 个顶层 + 5 个短 flag 全部硬拒; 15 个新 grammar regression test 锁住 contract)
- [x] Round 12: `723 → 726` 同步(`set rule-provider` CLI family 加齐 8 个 leaf; `set profile refresh` 收紧 (refresh 总是写); `CliOutput::planned` 助手消除 19 处 `let _ = output;`; `commands::redirect` → `commands::legacy`; 占位 `commands/{config,sub,profile}.rs` 删 3 个)
- [x] Round 13: `726 → 733` 同步(`Refreshable` trait + 3 真 impl; `set` 拆 8 个子文件 + `set/common` 抽 helper; `error.rs` 拆 6 个子文件; `commands::legacy` → `commands::bridge` 改名; 3 个 trait shape test + 3 个新 dispatch test; daemon_real_e2e 在 vendor/bin +x 后真实跑通 +1)

### S3.2 `STATUS.md` P0 列表与"暂不应视为可用的公开能力"表自相矛盾

- [x] 删除 `STATUS.md:91-94` P0 列表第 4 条(`config apply 恒经 MihomoConfigBackend`)— 已修复(Round 3)
- [x] 在 P0 列表保留 S1.1 / S1.2 / S1.3 三条

### S3.3 `docs/archive/` 整个目录缺失

`docs/README.md` 与 `STATUS.md:115` 都引用了 `docs/archive/{STATUS-history-2026-08-05.md, TODO-2026-08-06-full-history.md, ...}`,目录不存在。

- [ ] 二选一:
  - **方案 A**: 重建 `docs/archive/` 目录,把 CHANGELOG.md 2026-08-05 之前的逐轮完成记录、`STATUS.md` 提到的 `STATUS-history-2026-08-05.md` 内容迁移过来
  - **方案 B**: 在 `docs/README.md` 与 `STATUS.md` 顶部 callout 删除对 `docs/archive/` 的引用,改为"历史见 `CHANGELOG.md` 与 git log"
- [ ] `docs/README.md:23-28` 同步删掉不存在的 `archive/` 子文件链接(verification / drift / CONFIGURATION / TODO / historical / reviews)

**验证**:
```bash
# 方案 A 后
test -f docs/archive/STATUS-history-2026-08-05.md
# 方案 B 后
! grep -rn 'docs/archive' --include='*.md' . | grep -v CHANGELOG.md
```

### S3.4 `docs/agent-workflow.md` / `docs/adr/` 缺失

- [ ] `docs/README.md:18-22` 引用了 `agent-workflow.md` 和 `adr/`,目录/文件都不存在;按 S3.3 同样方式二选一(补建 vs 删引用)

### S3.5 `SECURITY.md` / `CONTRIBUTING.md` 与 `TODO.md` 联动

- [ ] `SECURITY.md:24` 已写"Known release blockers are tracked in `TODO.md`",确认链接在新版 `TODO.md` 中可点击跳转
- [ ] `CONTRIBUTING.md:6` "Read `TODO.md` for priority and release blockers" → 保留

---

## S4 — 代码体积 / 卫生(advisory)

> 全部为 `scripts/check-code-standards.py` 的 advisory 警告,**非 hard gate**;按 release blocker 处理优先级以下排序。

### S4.1 源文件 > 400 行硬上限

- [ ] `crates/caly-platform/src/tun/linux.rs` 663 行 → 拆为 `device.rs` (`ip tuntap`/`ip link` 命令构建) + `engage.rs` + `restore.rs` + `capability.rs`(setcap/诊断)
- [ ] `crates/caly-server/src/json/service.rs` 527 行 → 拆出 `frame.rs` (JSON-framed envelope) + `dispatch.rs` (service 入口) + `admission.rs` (会话注册)
- [ ] `crates/caly-backends/src/config/mod.rs` 559 行 → 拆出 `mihomo.rs` (仅 Mihomo 装配) + `sing_box/mod.rs` 已经是子目录,统一路由到 `active.rs`
- [ ] `crates/caly-backends/src/config/sing_box.rs` 505 行 → 按 `render` / `validate` / `commit` 三阶段拆
- [ ] `crates/caly-backends/src/subscription/http.rs` 491 行 → 拆出 `client.rs` (reqwest) + `format.rs` (格式识别) + `pipeline.rs` (与 URI/Clash 解析并行)
- [ ] `crates/caly-backends/src/lifecycle.rs` 486 行 → 拆出 `start.rs` / `stop.rs` / `restart.rs` / `health.rs`
- [ ] `crates/caly-config/src/schema/settings.rs` 486 行 → 拆为 `core.rs` / `tun.rs` / `dns.rs` / `sniffer.rs` 子 schema
- [ ] `crates/caly-kernel/src/mihomo/api.rs` 458 行 → 拆出 `clash_api.rs` (controllers) + `spawn.rs` (进程)
- [ ] `crates/caly-application/src/composition/backends.rs` 427 行 → 拆出 `build_mihomo()` / `build_sing_box()` 子函数
- [ ] `crates/caly-config/src/subscription/mihomo/render.rs` 408 行 → 拆出 `proxies.rs` / `groups.rs` / `rules.rs`

**验证**:
```bash
python3 scripts/check-code-standards.py 2>&1 | grep "exceeds 400" | wc -l   # 应为 0
```

### S4.2 函数 > 80 行软上限

- [ ] `crates/caly-application/src/composition/bootstrap.rs:110` 108 行(全项目最长) — daemon 启动编排按 7 步切片
- [ ] `crates/caly-kernel/src/mihomo/api.rs:102` 102 行 — Clash API 适配器按 method 切片
- [ ] `crates/caly-config/src/schema/settings.rs:230` 97 行 — schema 校验按字段切片(配合 S4.1 拆文件时一并做)
- [ ] `crates/caly-application/src/composition/backends.rs:227` 84 行
- [ ] `crates/caly-backends/tests/config_apply_real_e2e.rs:250` 82 行

**验证**:
```bash
python3 scripts/check-code-standards.py 2>&1 | grep "function spans" | awk '{print $NF}' | sort -rn | head -5
```

### S4.3 `cargo fmt --all -- --check` 28 处 diff

- [ ] 一次性 `cargo fmt --all` 后提交
- [ ] 在 `.github/workflows/ci.yml`(或等效)加 hard gate:
  ```yaml
  - run: cargo fmt --all -- --check
  ```
- [ ] 拆分大文件后(S4.1)新文件的 import 排序、空行、match arm 一致性再跑一次 fmt

**验证**:
```bash
cargo fmt --all -- --check && echo OK
```

### S4.4 `bins/caly-template-worker` 在 `cargo test` 时不自动构建,导致 `tests/template_worker_e2e.rs` 假阳性 pass

- [ ] 在 `tests/template_worker_e2e.rs` 守卫函数里:
  - 找不到 binary 时 `eprintln!("skipping: no worker binary at ...")` → 改为 `return Err("...")` 并给 `#[ignore = "needs target/debug/caly-template-worker; run cargo build -p caly-template-worker"]`
- [ ] 或在 `Cargo.toml` `[dev-dependencies]` 加 `caly-template-worker = { path = "../../bins/caly-template-worker" }` 让 `cargo test` 自动构建

**验证**:
```bash
cargo build -p caly-template-worker
cargo test --test template_worker_e2e -- --nocapture
# 期望: 真实跑通 0.5s+, 不再 "skipping: no worker binary at ..."
```

### S4.5 daemon 启动 WARN 噪音:`subscription cache directory is unreadable` 在新装首次启动

- [ ] 区分 "missing" vs "unreadable":
  - `state/subscriptions/` 不存在 → `INFO: subscription cache cold (first start), nodes will populate on next refresh`
  - `state/subscriptions/` 存在但 `unreadable`(权限)→ `WARN: subscription cache exists but is unreadable, check ownership`

**验证**:
```bash
rm -rf /tmp/caly-user/caly/state/subscriptions
./target/debug/caly daemon > /tmp/daemon.log 2>&1 &
sleep 2
grep -E "subscription cache" /tmp/daemon.log   # 期望 INFO 级别, 不是 WARN
pkill -f 'target/debug/caly daemon'
```

### S4.6 `bins/caly/src/main.rs` `mod daemon;` 在文件底部、文件最后又 `use daemon::{...}`

- [ ] 把 `mod daemon;` 提到 imports 区,`use daemon::{...}` 紧跟其后

**验证**:
```bash
grep -n "^mod daemon;\|^use daemon::" bins/caly/src/main.rs
# 期望两行连续, mod 在 use 之前
```

### S4.7 loopback TCP 安全模型补文档

- [ ] `docs/architecture.md` §4 "Secrets" 附近补一段"loopback TCP 的安全模型",说明 session token 在本机进程间是公开的、为何仍需 owner-only 0600 UDS 作为推荐入口

---

## 验证矩阵(本文件交付时的"硬数字")

```bash
# 应全过(本机验证日期 2026-08-08,Round 13 末):
cargo check --workspace --all-targets --all-features --locked    # OK
cargo test  --workspace --all-targets --all-features --locked    # 733 passed, 0 failed (Round 13 +7, Round 12 +3, Round 11 +15, Round 10 +12, Round 9 +5, Round 8 +15, Round 7 +44)
cargo clippy --workspace --all-targets --all-features --locked -- -D warnings
cargo doc    --workspace --all-features --locked --no-deps -D warnings
bash scripts/check-dependency-discipline.sh
python3 scripts/check-actor-topology.py
python3 scripts/check-code-standards.py
python3 scripts/check-infrastructure-invariants.py
python3 scripts/check-integration-invariants.py
python3 scripts/check-presentation-invariants.py
bash scripts/fetch-test-kernels.sh   # 下载并 SHA-256 校验 vendor/bin
```

```bash
# 应失败(本机验证日期 2026-08-07):
cargo fmt --all -- --check           # 28 处 diff  → S4.3
```

完成 S1 全部 + S3 全部后,可标注 `v0.1.0-rc1`;S4 全部完成后 `v0.1.0`。

---

## S5 — Round 6+ 后续(已识别但本轮未做)

> Round 6 把 `rule_providers:` 与四个新 RuleMatch variant(`RULE-SET` /
> `GEOSITE` / `PROCESS-NAME` / `SRC-IP-CIDR`)接进 schema + 两个 kernel
> 渲染。Round 7 引入 Profile 类型模型 (Remote / Local / Merge)。
> Round 8 把 S5.1 / S5.3 / S5.4 / S5.5 全部做完;S5.6 留作 Round 9 候选。

### S5.1 `type: inline` rule provider 启动时 materialize 到 file — Round 8 完成

**完成**(Round 8 收尾):

- [x] 新 `crates/caly-application/src/composition/rule_provider_materialize.rs`:
      `materialize_inline_providers(work_dir, providers) -> (Vec<RuleProvider>, Vec<MaterializedInline>)`
      纯函数,遍历 providers,对 `Inline { payload }` 写到
      `<workdir>/rule-providers/<name>.yaml`(temp + rename 原子写,
      bounded text 256 KiB cap),并把 in-memory provider 改成
      `File { path: <that file> }`;`Http` / `File` pass-through unchanged
- [x] 在 `build_dual_core_lifecycle` boot 路径 wiring:mihomo + sing-box
      两个 lifecycle builder 都用 materialized tuning(避免
      hardcoded `<workdir>/` 路径依赖)
- [x] `InlineMaterializeError::{Io { id, path, reason }, BodyTooLarge { id, actual, limit }}`
      错误映射到 `CompositionError::BackendUnavailable` + tracing
- [x] 4 个 unit test:`inline_provider_is_materialized_to_a_real_file` /
      `http_and_file_providers_pass_through_unchanged` /
      `materialization_writes_exactly_one_file_per_inline_provider` /
      `materialization_is_idempotent_under_repeated_calls`

### S5.2 Profile 类型模型 (Remote / Local / Merge) — Round 7 完成

**完成**(Round 7 收尾):

- [x] 域类型 `Profile { id, name, description, source: Remote|Local|Merge }` + `ProfileError` 9 个 variant
- [x] Schema `profiles:` 顶层段 + 6 个 validation 路径(unique id, path-safe, non-empty Local, public http(s) Remote, interval_minutes > 0, merge cycle)
- [x] 4-stage loader: base → active profile → `config.d/` → declared profiles
- [x] `ProfileStore` on-disk cache: `<state>/profiles/<id>.yaml` + `<id>.meta.toml`,原子写,body 完整性校验
- [x] `InMemoryProfileResolver` (strict + lenient),用于测试 + offline CLI
- [x] CLI: `caly profile add|list|show|refresh|remove`(refresh 当前返 `FetchNotImplemented`,Round 8 接 fetch)
- [x] Default fragment `config.d/98-profiles.yaml`(注释 Loyalsoldier example)
- [x] 44 个 regression test

### S5.3 Remote fetch 真实接线 — Round 8 完成

**完成**(Round 8 收尾):

- [x] 新 `crates/caly-config/src/profile_fetch.rs`:
      `ProfileFetchError` 10 variants + `ProfileFetchOutcome::{Updated, NotModified}`
      + `is_transient_profile_error` + `fetch_profile_body` async
- [x] `PublicAddressClassifier` 从 `caly-backends::subscription` 提升到
      `caly-config::subscription::classifier`(单一来源,caly-backends re-export)
- [x] `bins/caly/src/client/profile.rs::refresh_one` 走 SSRF-safe 完整
      fetch path:DNS resolve(3 次 retry)+ `PublicAddressClassifier` reject
      + `fetch_pinned` (max 1 MiB body) + 2 attempt retry loop with 250 ms backoff
- [x] `NotModified` (ETag hit) 路径:re-write metadata with fresh `fetched_at_ms`,body 不变
- [x] 5 个 unit test:prefer-public 拒绝矩阵 / transient classification /
      error display / map exhaustiveness / bounded reason re-export

### S5.4 递归 `Merge` refresh — Round 8 完成

**完成**(Round 8 收尾):

- [x] `refresh_all` 改走 `refresh_recursive` 深度优先 walk
- [x] `Local` parts 跳过,`Remote` parts 调 `refresh_one`,
      嵌套 `Merge` parts 递归
- [x] 失败 wrap 成 `ProfileCmdError::FetchChain { id, source }` —
      **`id` 字段是 parent merge 不是 failing part**,operator 一眼能找到
      哪个 Merge 触达了坏依赖
- [x] runtime `visited: HashSet<String>` cycle guard
      (schema 已经在 parse 阶段 reject cycle,这里 defense-in-depth)
- [x] 2 个 regression test:`refresh_merge_profile_walks_remote_parts`
      (Local-only merge 是 no-op) + `refresh_merge_profile_fails_when_a_remote_part_fails`
      (验 `id` 是 merge 不是 failing part)

### S5.5 CLI `--dry-run` + 写前 backup — Round 8 完成

**完成**(Round 8 收尾):

- [x] `add_profile` / `remove_profile` 加 `dry_run: bool` 参数,
      分别返 `AddOutcome::{Applied, DryRun}` /
      `RemoveOutcome::{Applied, DryRun}` enum
- [x] 新 `backup_config(config_path)` helper:复制到
      `config_path.bak.<unix-ms>`,新 sidecar 替换 pre-existing;
      缺失 source 是 no-op;`fs::copy` 失败返
      `ProfileCmdError::Backup { from, to, reason }`,**fail-closed**
- [x] CLI subcommand 接线:`ClapProfileCmd::Add { ..., dry_run: bool }`
      + `Remove { id, dry_run: bool }` 都带 `#[arg(long)]`,
      `Show` / `Refresh` / `List` 自动 reject `--dry-run`
- [x] main.rs JSON 模式 `{"ok": true, "id": ..., "dry_run": ...}`,
      human 模式 `ok: profile <id> would be added (dry-run)`
- [x] 5 个 regression test:
      `add_dry_run_does_not_modify_config` (byte-identical 比对 pre/post)
      / `remove_dry_run_does_not_modify_config` (同上)
      / `remove_real_creates_a_backup_with_unix_ms_suffix`
      (扫 `config.yaml.bak.<ms>`,验 stamp >= test start + body == pre-call)
      / `profile_subcommand_dry_run_flag_is_parsed` (clap 解析 + 拒在
      `show`/`refresh`/`list` 上) / 扩展 `profile_subcommand_parses_all_five_leaves`
      含 `dry_run: false` field

### S5.6 GEOSITE / GEOIP auto-emit 改 Profile 路径 — 留作 Round 10

**未做**(Round 10 候选):

- [ ] 把 hardcoded `geosite_or_geoip_url` 路径替换为隐式
      declared profile 注册到 `ProfileStore`;让 operator 能在
      `profile list` 看到 `geosite-cn` / `geoip-cn` 等条目,
      走同一套 SSRF guard + cache policy

### S5.7 Round 9 debug + 收敛 (Profile / Fetch / Loader) — 完成

**完成**(Round 9 收尾):

- [x] **Bug 1 — Nested `Merge` `FetchChain.id` 不是 outermost**:
      `refresh_recursive` 加 `outer_id: &str` 参数贯穿递归,
      3 层 merge `outer → inner → leaf-bad` 现在报 `id: "outer"`
      (用户声明的入口),不是 `id: "inner"` (immediate parent)。
      Test `refresh_nested_merge_keeps_outermost_merge_in_fetch_chain`
      lock 住新 contract;旧 test
      `refresh_merge_profile_fails_when_a_remote_part_fails` 从
      `assert!(!id.is_empty())` 收紧到 `assert_eq!(id, "combined")`。
      顺带删 `refresh_recursive_with_domain` helper (双形态不再需要)。
- [x] **Bug 2 — 写前 backup 累积**:
      `backup_config` sidecar 改用固定名 `config.yaml.bak`
      (无 `<unix-ms>` 后缀),`fs::copy` overwrite 取代
      create-new。operator 始终**最多 1 个** backup。
      重命名 test 为 `remove_real_creates_a_single_backup_sidecar`,
      新 test `backup_collision_is_resolved_by_overwrite` 锁住
      consecutive removes 行为。
- [x] **Bug 3 — `PublicAddressClassifier` 不剥 IPv4-mapped IPv6**:
      classifier 在分类前 `to_ipv4_mapped()` 剥皮,`::ffff:10.0.0.1`
      走 IPv4 branch 被 `is_private()` 拒,之前是 IPv6 branch 接受。
      3 个 test 锁住 reject matrix:
      `ipv4_mapped_ipv6_is_classified_as_the_underlying_ipv4` /
      `ipv4_rules_locked` / `ipv6_rules_locked`。
- [x] **`LayeredConfigError` + `LoaderBudgetError` 加 `Display`**:
      12-arm + 4-arm `Display` impl + `Error` impl 链。
      CLI `load_declared_profiles` 改用 `error.to_string()`
      替代 `format!("{error:?}")`,JSON 错误输出不再泄漏
      `Metadata(Os { code: 2, ... })` Debug 形态。
- [x] **收敛 — `mutate_profiles_in_config<F>`** 合并
      `append_profile_to_config` + `rewrite_profiles_in_config`
      (90% duplicate,`mutator` 闭包生成 next list)。
- [x] **收敛 — `current_unix_ms()` helper** 提取
      3 处重复的 `SystemTime::now().duration_since(UNIX_EPOCH) ...`。
- [x] **Dead `pub fn` 删 4 个**:
      `format_profile_id` (1 个,只 test 用) +
      `validate_id` 3 个 duplicate (call site 0)。
- [x] **Dead wrapper 删 2 个**:
      `load_layered_yaml_with` + `load_layered_yaml_with_inner`
      是单跳 forward,inlined 到 call site。
- [x] **`resolve_with_retry` `RESOLVE_BACKOFF` const** 抽出
      2 处重复的 `Duration::from_millis(100)`。
- [x] **`unnested or-patterns` 收敛**:
      `Err(Fetch(_)) | Err(FetchChain { .. })` →
      `Err(Fetch(_) | FetchChain { .. })`。
- [x] **`_interval_minutes` dead binding 删** in `refresh_one`。
- [x] `bins/caly/src/client/profile.rs` 从 683 行 → 614 行 (-10%)。

### S5.8 Round 10 候选

- [ ] **GEOSITE auto-emit 提升为 Profile** (S5.6 + 部分 S5.7) —
      让 `geosite-cn` / `geoip-cn` 等条目在 `profile list` 出现。
- [ ] **扫 `LayeredConfigError` Display 传播** — `caly-application`
      composition root 仍走 `tracing::error!(?error)` Debug。
- [ ] **`PublicAddressClassifier` 加 IPv6 文档前缀 reject**
      (`2001:db8::/32`)。
- [ ] **大文件拆分** (S4.1 advisory) — `composition/backends.rs` 602 行,
      `rule_render.rs` 656 行等。
- [ ] **TUI PTY E2E** (S1.2 留债) + **TCP auth-token admission** (S1.3 留债)。

### S5.9 Round 10 CLI 重构 — 完成

**完成**(Round 10 收尾):

- [x] **稳定 JSON 错误 contract**:每个 JSON 行有 `version: 1`、
      `ok: true|false`、`code`、`error`、`command`,错误时有 `hint`。
      13 个 `serde_json::json!({"ok": false, ...})` 复制点全部
      收编到 `output::report_error_returning`。
- [x] **稳定错误 code 目录**:`profile.*` / `sub.*` / `core.*` /
      `config.*` / `daemon.*` / `usage.*`,每个错误必带
      `with_hint()`。`usage.*` exit 2,其它 exit 1。
- [x] **错误 `command` 字段**:跟踪用户实际运行的命令,log-grep
      找得到。
- [x] **`output::CliOutput` 单点 dispatch**:每个 success / info
      / error 走 human/JSON 同一条路径,13 处 `if json { ... } else { ... }`
      收编到 `CliOutput`。
- [x] **Per-family `commands/*` dispatch**:`main.rs` 721 → 121 行
      (-83%)。6 个新 module:
      `commands/{profile,sub,doctor,daemon,dns,config}.rs`。
- [x] **long_about + after_help**:`caly --help` 多 "Common
      workflows" 7 条示例;`profile --help` 多三种 source kind
      解释;`core select` 多 ID/name/prefix 解析逻辑。
- [x] **Help text contract test**:`top_level_help_includes_long_about_and_common_workflows` 锁住
      long_about + `Common workflows` + `caly completions <shell>`;
      `profile_help_lists_all_three_source_kinds` 锁住三种 source。
- [x] **12 个新 regression test**:
      6 `output::tests` (envelope / version / hint-omission /
      exit-code / from_json_flag) + 2 `error::tests` (稳定 code /
      FetchChain id) + 2 `commands::describe` + 2 help-text
      contract。

### S5.10 Round 11 CLI 5-namespace 重构 — 完成

**完成**(Round 11 收尾):

- [x] **5-namespace grammar**:`daemon` / `tool` / `show` / `set` 替代 13
      顶层 / 33 leaf;`cal --help` 列四个 namespace,每个 namespace
      自身有 `help` 子命令;`disable_help_subcommand` 加在
      `ClapToolCmd` 上避免 `tool help` 与 clap 自动注入的 help 冲突。
- [x] **15 个新能力全加齐**:
      `show core health` / `set core select --group` / `set core url-test` /
      `set proxy add|edit|remove|import` / `set sub add|remove|enable|disable` /
      `set profile edit|export|enable|disable` / `set config diff` /
      `set daemon stop|reload|restart|status`。
- [x] **Dry-run 政策翻转**:`set <res> add|edit|remove|import` 默认
      `apply: false, dry_run: false`(safe, 不写);`--apply` 显式写入;
      `--dry-run` 仍受 honor(explicit preview);`--apply` / `--dry-run`
      互斥(`clap::Arg::conflicts_with`);JSON envelope 加 `apply` +
      `dry_run` 字段。
- [x] **老命令硬拒**:25 个顶层拼写 (`core <verb>` / `sub <verb>` /
      `sys <verb>` / `config <verb>` / `profile <verb>` / `status` /
      `doctor` / `tui` / `dns` / `help` / `version`) + 5 个短 flag
      (`-t` / `-d` / `-c` / `-s` / `-p`) 在 parse 阶段被 clap 拒,
      报 `unrecognized subcommand 'X'`,operator 直接看 "use: caly
      <new>" hint。
- [x] **`commands::redirect` 收敛**:18 个老 redirect 仅剩 5 个
      (`old_core` / `old_sub` / `old_sys` / `old_config` /
      `old_profile`);`old_status` 删除;`ProfileCmd` enum 收
      到 `List / Show { id }` 两个 variant(Add/Refresh/Remove
      移去 `SetProfileCmd`);`commands::profile::dispatch` 对应
      瘦到 2 arm;`commands::set` 的 Placeholder 模式 (`--apply`
      写入真实 backend,否则 Round 12 stub) 锁住 16 个新 leaf。
- [x] **`CliOptions::Default` derive 恢复**:Round 10 重构漏
      `#[derive(Default)]`,原 SIGABRT 在 `CliOptions::default()`
      构造时。新 regression test `cli_options_default_is_constructible`
      锁住 contract。
- [x] **Tool help 冲突修复**:`ClapToolCmd` enum 加
      `#[command(disable_help_subcommand = true)]`,`caly tool help`
      不再和 clap 注入的 help 子命令撞名。
- [x] **15 个新 grammar regression test**:
      1 global options + 5 `tool` 5 leaves + 6 `show` resources (含
      `show core health` / `show core rules --match`) + 7 `set` resources
      (含 `set core url-test` / `--group` / `set proxy add|edit|remove|import` /
      `set sub add|remove|enable|disable` / `set profile edit|export|enable|disable` /
      `set config diff` / `set daemon stop|reload|restart|status`) +
      4 dry-run 语义 (default / `--apply` / `--dry-run` 兼容 /
      `conflicts_with` 拒矛盾组合) + 2 老拼写拒 (25 顶层 + 5 短 flag) +
      4 help-text contract (top-level / `set` 7 resources / `show` 6
      resources / `tool` 5 leaves) + 1 `CliOptions::default()`。
- [x] **Clippy `-D warnings` clean**:Round 11 引入的新 module
      (`commands/{tool,show,set,redirect,status}`) + 重写的
      `cli/grammar.rs` + 重写的 `main.rs` 0 warning;35 个 round-10
      dead-code warning 收编 (`commands/{sub,profile,config}.rs` 加
      `#[allow(dead_code)]`,新 modules 删除未使用 import / 改用
      inline format string)。
- [x] **rustdoc `-D warnings` clean**。
- [x] **6 个静态脚本 + 依赖纪律脚本** 全过。

### S5.11 Round 12 — Refresh 统一 + Rule Providers CLI + 业务打磨 — 完成

**完成**(Round 12 收尾):

- [x] **`Refreshable` trait + 3 套资源抽象** (`commands/refresh.rs`):
      `Refreshable::refresh(target, ctx) -> Result<RefreshOutcome, _>` 是
      "声明远端源 + 刷新" 的统一形状;`RefreshContext` / `RefreshTarget`
      / `RefreshOutcome` 三个辅助类型;trait + 助手函数 (`report_refreshed` /
      `report_refresh_error` / `missing_cache_hint`) 一并锁定,Round 13 加
      真实 impl 后 `dead_code` 即可解除。
- [x] **`set rule-provider` CLI family** (`commands/rule_provider.rs`):
      8 个 leaf (`add-http` / `add-file` / `add-inline` / `remove` /
      `enable` / `disable` / `refresh` / `list`),3 套 sub-command 而非
      单一 `add <KIND> <body>`,每个 source kind 自带类型化参数;CRUD
      leaf 走 `--apply` / `--dry-run` 政策同 `set sub` / `set profile`,
      `refresh` 总是写。`list` 是唯一非 stub,用 layered loader 真实读
      `<config>/config.yaml` 的 `rule_providers:` 段。
- [x] **`CliOutput::planned` 助手** (`output.rs`): 消除
      `commands/set.rs` 12 个 stub leaf 的 19 处
      `eprintln! + success_empty("...: planned.") + let _ = output;`
      重复模板,统一成 `output.planned_ok("set proxy add")` 一行。
      human 摘要总是以 `: planned.` 结尾,downstream tool 可
      直接 branch on intent。
- [x] **`set profile refresh` 收紧**: 取消 `--apply` / `--dry-run` flag
      (refresh 总是写,body IS cache,`NotModified` HTTP 304 是真实结果
      不是 dry-run);旧 invocation 在 parse 阶段被拒,不再 silently no-op。
- [x] **`commands::redirect` → `commands::legacy`**: 改名以符合实际语义
      (新 grammar 不再调 redirect 走老命令,只剩 `commands::show` /
      `commands::set` 翻译到 legacy enum 的私有桥);同时移除 5 个
      `old_*` 函数的 deprecation 警告 (新 grammar 已经在 parse 阶段
      拒老命令,警告在新 namespace 路径上是噪音)。
- [x] **删除占位 module**: `commands/{config,sub,profile}.rs` 三个
      Round 10 留作 "module tree 稳定器" 的死文件删除;`commands/mod.rs`
      现在只列活的 namespace + 助手 (`daemon` / `tool` / `show` / `set` /
      `refresh` / `rule_provider` / `legacy` / `status`)。
- [x] **3 个新 grammar test**: `set rule-provider` 6 leaf 全 parse、
      `--apply` / `--dry-run` policy 锁住、refresh flag 收紧;
      `set profile refresh` flag 收紧;`set_subcommand_help_lists_all_eight_resources`
      锁 8 个 resource 在 `set --help` 里。
- [x] **测试总数 723 → 726** (Round 12 +3);clippy `-D warnings` clean;
      rustdoc `-D warnings` clean。

### S5.12 Round 13 — Refreshable trait 真接线 + set 拆分 + error 拆分 + bridge 改名 — 完成

**完成**(Round 13 收尾):

- [x] **`Refreshable` trait + 3 真 impl** (`SubscriptionRefresh` /
      `ProfileRefresh` / `RuleProviderRefresh`),
      `commands/refresh.rs`: `refresh(target, ctx) -> Result<RefreshOutcome,
      RefreshError>`;`set profile refresh` 走 `ProfileRefresh::refresh`
      走统一 `code: &'static str` envelope;`set sub refresh` 走
      `SubscriptionRefresh` (因为 `client::run_client` 返回
      `ExitCode` 不返回 `Result`,所以 trait shape check
      compile-time 走,实际 RPC 走 bridge,Round 14 把
      `client::run_client` 改 `Result` 后 trait 完整接管);
      `set rule-provider refresh` 走 `RuleProviderRefresh`
      → `RefreshError::Other` → 统一 envelope。
- [x] **`set` namespace 拆 8 个子文件 + `set/common`**:
      `commands/set/{core,proxy,tun,sub,profile,config,daemon,rule_provider,common}.rs`。
      每个 resource 一个 `pub fn dispatch(cmd, options, output) -> ExitCode`;
      `set/common.rs` 抽 `success_with_dry_run` / `report_profile_error`
      共享 helper;Round 12 单 233 行 `set.rs` 消失。
- [x] **`error.rs` 拆 6 个子文件** (`error/{profile,sub,core,config,
      daemon,usage}.rs`),每个 mod 自己一个文件,公开 API
      `crate::error::profile::NOT_DECLARED` /
      `crate::error::json_not_valid(...)` 全部 re-export,
      call site 一行没改。
- [x] **`commands::legacy` → `commands::bridge` 改名**:
      符合"内部 bridge 而非 deprecation shim" 的实际语义;
      Round 12 留下的 `old_*` 5 个桥函数还在,Round 14 删除
      (见 S5.13)。
- [x] **3 个 trait shape test + 3 个新 dispatch test**:
      `commands/refresh.rs::tests` 加 `refreshable_trait_shape_is_locked`
      / `refresh_target_family_is_stable` /
      `refresh_error_codes_are_stable`;
      `cli::cli_tests` 加 `set_dispatch_routes_to_eight_resource_modules`
      / `set_mod_exposes_eight_sub_modules` /
      `refreshable_trait_is_wired_into_set_dispatch`。
- [x] **测试总数 726 → 733** (Round 13 +7,包含 daemon_real_e2e
      在 `chmod +x vendor/bin/*` 后真实跑通 +1);
      **clippy `-D warnings` clean**; **rustdoc `-D warnings` clean**;
      **6 个静态脚本全过**。

### S5.13 Round 14 候选(新)

- [ ] **`Refreshable` trait 完整接管** `set sub refresh`:
      `client::run_client` 改返回 `Result<()>` 而不是 `ExitCode`,
      trait impl 就能看到 RPC 是否成功;`commands::bridge::old_sub`
      的 `SubCmd::Refresh` 分支删掉。
- [ ] **12 个 stub leaf 接真 writer**:
      `set proxy add|edit|remove|import` 走 `<config>/config.yaml`
      inline-proxy 段 (类似 Round 8 `mutate_profiles_in_config` 模式,
      `--apply` 写入 + backup);`set sub add|remove|enable|disable`
      走 `subscriptions.sources` array;`set sub import` 真正
      save inline nodes;`set profile edit` spawn `$EDITOR` 在
      `<state>/profiles/<id>.yaml`;`set profile export` 把 merged
      body 写到 `--out <path>`;`set config diff` 走
      `load_layered_yaml` + render 路径;`set daemon stop|reload|
      restart|status` 接新 wire 命令;`set core url-test` 走
      新 `WireCommand::UrlTest`。
- [ ] **`commands::bridge` Round 14 删除**: 5 个 legacy 桥函数
      (`old_core` / `old_sub` / `old_sys` / `old_config` /
      `old_profile`) 全部 hard-remove;`ProfileCmd` / `CoreCmd` /
      `SubCmd` / `SysCmd` / `ConfigCmd` legacy enums 全部删除;
      `commands::set::core::*` 等改直接调 `client::run_client`
      不经 bridge;`sub_list` / `sub_check` / `sub_import` 三个
      offline shim 移到 `commands::show::sub`。
- [ ] **GEOSITE auto-emit 改 Profile 路径** (S5.6 老债):让
      `geosite-cn` / `geoip-cn` 在 `profile list` 出现,走同一套
      SSRF guard + cache policy;`--apply` 写入 ProfileStore 缓存。
- [ ] **`PublicAddressClassifier` IPv6 文档前缀 reject**:
      `2001:db8::/32` 现在走 IPv6 branch 被接受(注释里说
      "by design",但 Round 14 收紧到 reject,符合 RFC 3849)。
- [ ] **`caly-application` `LayeredConfigError` Display 传播扫尾**
      (Round 9 留债):composition root 改 `error.to_string()` 不用
      Debug 形态。
- [ ] **TCP auth-token admission** (S1.3 留债)。


