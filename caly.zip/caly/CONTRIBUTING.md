# Contributing to caly

## Before changing code

1. Read `STATUS.md` for current capability truth.
2. Read `TODO.md` for priority and release blockers (S1–S4).
3. Read `docs/architecture.md` and `docs/coding-standards.md` (no `docs/adr/` exists yet; see `TODO.md` §S3.4).
4. Do not expose a new RPC/CLI command until admission, owner execution, terminal reporting, cancellation, and integration tests exist.

## Required local gates

Use Rust 1.88.0 and run:

```bash
cargo metadata --locked --no-deps --format-version 1 > /dev/null
cargo fmt --all -- --check
cargo check --workspace --all-targets --all-features --locked
cargo test --workspace --all-targets --all-features --locked
cargo clippy --workspace --all-targets --all-features --locked -- -D warnings
RUSTDOCFLAGS="-D warnings" cargo doc --workspace --no-deps --document-private-items --locked
python3 scripts/check-actor-topology.py
python3 scripts/check-code-standards.py
python3 scripts/check-infrastructure-invariants.py
python3 scripts/check-integration-invariants.py
python3 scripts/check-presentation-invariants.py
bash scripts/check-dependency-discipline.sh
```

> The 6 checks above are the actual static gates in the current repository (see
> `STATUS.md` "6 个静态架构/规范脚本"). `scripts/check-proto-standards.py` referenced
> in earlier revisions of this file no longer exists.

## Verification language

Use precise labels:

- source implemented;
- wired into composition;
- compiled;
- unit tested;
- integration tested;
- real binary/platform E2E tested.

Do not call an environment-gated test “passed E2E” when its prerequisite was missing and the body returned early.

## Architecture constraints

- Domain remains free of I/O/runtime/platform types.
- Thin clients depend only on Domain and Protocol.
- Every mutable aggregate has one owner.
- Channels and collections remain bounded.
- Client timeout is not operation cancellation.
- Platform effects require explicit ownership and durable recovery.
- Secrets never enter presentation snapshots or diagnostics.

## Pull requests

Keep changes scoped to one remediation item when practical. Include:

- problem and risk;
- behavior before/after;
- tests added;
- verification commands and actual result;
- any intentionally deferred work linked to `TODO.md`.
