# Caly

`caly` is a **daemon-first manager for the Mihomo and sing-box proxy cores** — a “btop++ for proxies”. One background daemon owns both kernels, so you can **hot-switch cores, refresh subscriptions and drive traffic without a GUI**; the same control plane is available as a TUI, a human CLI, or stable `--json` for scripts.

## Current status

**Advanced Linux architecture prototype / runnable MVP; not yet production-ready.** The owner-only
UDS daemon, instance lock, Mihomo/sing-box lifecycle and Clash-API adapters, live watch, telemetry,
durable system-proxy recovery, config generation/validation/apply (Mihomo **and** sing-box via
`ActiveConfigBackend`), subscription refresh with a full format matrix, rule/DNS/TUN rendering,
`caly status`/`core`/`sub`/`sys`/`config`/`doctor`, snapshot projection and a live-watch-driven
TUI are implemented. Xray has been dropped (`CoreKind::Xray` stays wire-compatible but is always
Unsupported). See [`STATUS.md`](STATUS.md) for the authoritative capability matrix and
[`TODO.md`](TODO.md) for release blockers.

The current workspace compiles on Rust 1.88 and reports **733 passing tests** (verified
2026-08-08; Round 13 added 7 tests for the `Refreshable` trait + 3 real
impls (`SubscriptionRefresh` / `ProfileRefresh` / `RuleProviderRefresh`),
`set` namespace split into 8 resource sub-modules, `error.rs` split
into 6 sub-files, `commands::legacy` → `commands::bridge` rename, and 3
new dispatch / trait-wiring regressions. Round 12 added 3 tests for
the `set rule-provider` CLI family + `set profile refresh` flag tightening,
Round 11 added 15 tests for the 5-namespace CLI refactor + 15 new capabilities
+ dry-run policy flip + 25+ old top-level spellings rejected at parse time, Round 10 added
12 tests for the JSON error contract and per-family `commands/*` dispatch,
Round 9 added 5 tests for bug fixes (nested-merge `FetchChain.id`;
`PublicAddressClassifier` IPv4-mapped IPv6; backup-collision), Round 8
added 15 tests for the SSRF-safe `profile refresh` fetch + recursive
`Merge` refresh + `Inline` rule provider materialisation at boot, Round 7
added 44 tests for the new `profiles:` schema segment, the `Profile`
domain type (Remote / Local / Merge), the on-disk `ProfileStore`, the
4-stage layered loader, and the `caly profile` CLI subcommand).
Pinned Mihomo v1.19.29 and sing-box v1.13.14 artifacts have been checksum-verified
and exercised through real kernel, Clash-API, daemon and UDS lifecycle E2E (including a
`mihomo -t` validation matrix whose `geoip.metadb` dependency is pre-provisioned via the system
toolchain); TUN address/route/restore passes in an isolated CAP_NET_ADMIN namespace. Install
test binaries with `scripts/fetch-test-kernels.sh`.

> **Note**: the "733 passing tests" count includes real-kernel E2E that, on a fresh clone without
> `vendor/bin/`, **silently skip** the inner assertions (the test reports `ok` without
> `#[ignore]`). To reproduce the full E2E path, run `bash scripts/fetch-test-kernels.sh` and
> `cargo build -p caly-template-worker` first. See `STATUS.md` "真实内核 E2E 口径" and
> `TODO.md` §S4.4.

## Layering

```text
Presentation → Transport → Application → Infrastructure → Domain
```

| Layer | Crates |
|---|---|
| Domain | `caly-domain` |
| Infrastructure | `caly-ports`, `caly-backends`, `caly-kernel`, `caly-config`, `caly-platform` |
| Application | `caly-application` |
| Transport | `caly-protocol`, `caly-server` |
| Presentation | `caly-tui` |

`caly-ports` defines the shared actor-port traits and the common error type; `caly-backends` holds the
concrete adapters (Mihomo/sing-box lifecycle & command, subscription, system-proxy, telemetry). Splitting
them out of `caly-application` keeps use-cases free of concrete infrastructure.

| Composition root | `bins/caly` |

`caly-protocol` contains contracts and the thin-client connection boundary (length-prefixed JSON over
UDS, no gRPC/protobuf). `caly-server` is separate so the TUI client does not pull daemon application
code into the client dependency graph. The CLI lives in the `bins/caly` composition root.

## Quick start

```bash
rustup toolchain install 1.88.0
bash scripts/fetch-test-kernels.sh        # download + verify Mihomo/sing-box into vendor/bin/
cargo build -p caly

# Start a daemon (default core mihomo; use CALY_CORE=sing-box for sing-box)
./target/debug/caly daemon

# Client commands: 5-namespace grammar (Round 11 + Round 12).
# Every write command defaults to dry-run; pass `--apply` to
# actually mutate. `refresh` always writes (the body IS the cache).
./target/debug/caly show status --json
./target/debug/caly show core nodes
./target/debug/caly set core start|stop|restart --core sing-box
./target/debug/caly set core mode rule|global|direct
./target/debug/caly set core select <node-id-or-name>
./target/debug/caly set core close-connections
./target/debug/caly set sub refresh                    # daemon mutation
./target/debug/caly show sub parse ./my-sub.txt        # offline subscription parse
./target/debug/caly set proxy on|off                   # system proxy
./target/debug/caly set tun on|off                     # TUN (needs CAP_NET_ADMIN)
./target/debug/caly set config generate                # documented default config
./target/debug/caly set profile add team remote:https://x/y --apply
./target/debug/caly set sub add https://provider.example/sub --name team --apply
./target/debug/caly set rule-provider add-http geosite-cn https://g/y --apply
./target/debug/caly set rule-provider list             # real; reads config.yaml
./target/debug/caly set rule-provider refresh          # always writes
./target/debug/caly tool doctor
./target/debug/caly tool tui
```

### Core executable locations

`caly` resolves a managed core executable in this order: an explicit daemon
flag, `~/.config/caly/config.yaml`, the legacy environment override, then the
bundled `vendor/bin` fallback. The explicit form is convenient for a one-off
run:

```bash
caly daemon --mihomo-bin /opt/mihomo/mihomo
caly daemon --sing-box-bin /opt/sing-box/sing-box --core sing-box
```

For a persistent setup, run `caly config generate` and set:

```yaml
core_binaries:
  mihomo: /opt/mihomo/mihomo
  sing_box: /opt/sing-box/sing-box
```

The binary is checked only when the core starts; an invalid or non-executable
path returns a remediation hint instead of silently falling back to another
binary. `caly doctor` reports whether both managed core executables resolve to
an existing, executable file. Every capability has exactly one canonical tree
spelling (`core start`, `sub refresh`, `sys proxy on`, `sys tun on`); flat
shortcuts and dash-prefixed aliases were removed to keep the surface small.

The command syntax and help are generated by `clap`. Generate shell completion
scripts with `caly completions bash|zsh|fish|elvish|powershell`. Configuration
helpers include `caly config generate`, the backup-preserving reset
`caly config default`, and `caly config vim` / `caly config nvim` to open the
config directory in an installed terminal editor. `caly config check <file>`
validates a single file; `caly config validate` validates the merged config.

## Design commitments

- Desired, Applied, Observed, Platform Effect and Presentation states are distinct.
- Every mutable aggregate has one owner actor.
- Cross-owner mutations use an acyclic OperationCoordinator/Saga.
- Every mutation has a queryable Operation ID; timeout is not cancellation.
- A single EventSequencer orders replay and projection events.
- Concrete platform/process handles never enter Domain.
- Process trees and platform side effects have explicit ownership and recovery.
- Thin clients directly depend only on Domain and Protocol.

See [`docs/architecture.md`](docs/architecture.md) and [`docs/project-layout.md`](docs/project-layout.md).

## Verification

The current workspace baseline has been independently checked with Rust 1.88:

- `cargo metadata --locked --no-deps`
- `cargo fmt --all -- --check`
- `cargo check --workspace --all-targets --all-features --locked`
- `cargo test --workspace --all-targets --all-features --locked` — **733 tests** (with `vendor/bin/`; without it, real-kernel E2E silently skip)
- Clippy and rustdoc with `-D warnings`
- all architecture/dependency invariant scripts
- CLI/TUI smoke and template-worker E2E
- checksum-pinned Mihomo/sing-box kernel and daemon+UDS E2E
- namespace-gated real TUN address/routing/restore E2E

Run `scripts/fetch-test-kernels.sh` to install verified test binaries. The separate
`Real kernel E2E` workflow reproduces kernel, daemon and namespace-TUN evidence and fails
when required artifacts or privileges are unavailable. See
[`STATUS.md`](STATUS.md), [`TODO.md`](TODO.md) and [`docs/README.md`](docs/README.md).
