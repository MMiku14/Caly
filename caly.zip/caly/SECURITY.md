# Security Policy

## Supported versions

Caly is currently pre-release (`0.1.0`). Security fixes are applied only to the current `main` branch until the first supported release line is declared.

## Reporting a vulnerability

Do not open a public issue for a suspected vulnerability involving credentials, local privilege boundaries, controller authentication, path ownership, subscription SSRF, process ownership, or recovery records.

Use GitHub private vulnerability reporting for `MMiku14/Caly`. If private reporting is unavailable, contact the repository owner privately and include:

- affected commit/version;
- threat model and required privileges;
- minimal reproduction;
- expected and actual behavior;
- whether credentials or platform state may be exposed;
- a suggested mitigation, if known.

Please do not include live subscription URLs, tokens, UUIDs, passwords, private configuration, or personally identifying logs.

## Current security posture

Caly is not yet production-ready. Known release blockers are tracked in `TODO.md`, including:

- controller authentication;
- owner-only sing-box configuration files;
- XDG runtime path ownership;
- durable system-proxy/TUN recovery;
- cancellation and task-failure correctness.

A successful unit-test run does not override these known limitations.
