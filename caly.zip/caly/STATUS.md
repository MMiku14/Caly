# caly 当前状态

> 更新时间：2026-08-06（项目状态盘点；待办见重写后的 `TODO.md`，历史归档 `docs/archive/`）
> 本文件是当前能力与验证状态的唯一事实入口。历史过程见 `docs/archive/`，未完成工作见 `TODO.md`。
> 架构设计见 `docs/architecture.md`，工作区结构见 `docs/project-layout.md`。

## 定位

caly 是 Linux、per-user、daemon-first 的代理内核管理器，目标是“btop++ for proxies”的终端体验。

当前阶段：**高级架构原型 / 可运行 MVP，尚未达到 production-ready。** 核心生命周期、控制面、
订阅解析、live watch、telemetry 与 TUI 已闭环并通过真实内核 E2E；`SetTun` 已接
`PlatformActor` owner（真实 `LinuxTunCommandBackend`，缺权限时结构化失败）；Xray 已放弃（移除 stub）。

## 当前可用主路径

- owner-only UDS daemon（JSON-framed），daemon epoch 与 stale instance-lock reclaim；`daemon.listen` 配置可再绑定回环 TCP gRPC 传输（与 UDS 并行共享会话注册表）；
- **TUN owner + crash-restore（M5）**：`SetTun` → `PlatformActor`，经 `LinuxTunCommandBackend`（`ip tuntap`/`ip link`，shell-free bounded 命令）engage/restore；`tun.mtu` 配置驱动；缺权限时返回结构化失败；`DurableTunBackend` 接入持久化恢复（boot `restore_first` 重放、graceful shutdown 清记录），恢复存储泛化为 `FileRecoveryStore<R>` 复用；
- **结构化日志 + correlation（M5）**：`tracing`/`tracing-subscriber`（env-filter，`CALY_LOG`/`RUST_LOG`），daemon 结构化日志写 stderr 带 daemon id/socket/listen 字段；`reporting.rs` 在每个 operation terminal 发结构化事件（operation id + outcome）；daemon 启动路径的 `eprintln!` 全部改 structured；
- **Mihomo / sing-box** 进程生命周期（start/stop/restart）、健康检查、异常退出自愈（backoff）；
- **Mihomo / sing-box Clash API**：proxy groups / connections / traffic / select / close-all，共享 controller secret；
- **telemetry**：按 active core 选择 Mihomo/sing-box adapter，1s 采样并投影 `ObservedState`；
- **live watch**：server 持续 stream + 客户端惰性迭代器 + lag 重同步；
- **TUI**：`LiveWatchSource`+`WatchDriver` 驱动、断线/session 自动重连、mouse capture；daemon-operation 执行（Enter 选择节点 / `g` 循环模式 / `r` 重启核心 / `c` 关闭连接，后台线程经独立连接执行）；
- **system-proxy**：durable recovery 事务（GNOME/KDE/niri），daemon crash 后 restore-first 恢复；engage 前捕获桌面原状态（mode + endpoint），graceful shutdown 保真恢复到原状态（失败保留记录、无记录不触碰桌面）；
- **sniffer（域名嗅探/恢复）**：顶层 `sniffer:` 配置段（加载期端口规格校验）；Mihomo 渲染完整 `sniffer:` 块（真实 `mihomo -t` E2E 接受），sing-box 渲染 inbound `sniff`/`sniff_override_destination`（基础 + 订阅渲染器同源）；
- **规则引擎双内核对等**：config `rules:` 同时渲染进 Mihomo `rules:` 与 sing-box `route.rules`（单一纯映射 `rule_render`；MATCH→route.final、REJECT→block outbound、组名→PROXY selector）；GEOIP 映射 sing-box 1.12+ 的远程 rule-set 机制（真实 `sing-box check` E2E 接受）；
- **订阅**：SSRF-safe fetch、格式识别、URI/Clash 解析、dedupe/normalize、节点注册表索引；
- **订阅→Mihomo 配置渲染→校验→应用→回滚**：`-s refresh` 把可表示节点索引为 `RegisteredProxy`，`MihomoConfigRenderer` 渲染 proxies/proxy-groups/rules，`config apply` 用真实 `mihomo -t` 校验（失败即回滚不发布）后原子提交 owner-only 配置，生成号追加在文件尾；真实内核 E2E 通过；
- **CLI（树状指令集，单一拼写）**：每个能力只有一个规范入口，顶层快捷命令与 dash 别名已移除；
  `core start|stop|restart|select|close-connections|mode|list-nodes|proxy-groups|list-connections|traffic|delay [--core]`、
  `sub refresh|check|import|list`、`sys proxy on|off`、`sys tun on|off`、`config apply|generate|validate|check|path|files|default|vim|nvim`、
  `status`、`doctor`、`tui`、`dns`、`completions`；变更命令成功输出 `ok: <语义摘要>`；`core select` 支持节点名；
- **分层配置启动（M5）**：daemon 启动读取 `$XDG_CONFIG_HOME/caly/config.yaml`（base + `CALY_PROFILE` profile + `config.d/*` 分层合并、bounded budget），经校验的 `AppConfig` 驱动 core 选择；`CALY_CORE` env 优先，坏配置 fail-fast，无配置文件则回退 env；
- **handshake 能力通告（M5）**：协议 `all_features()` 单一真源，daemon 广而告之 operations/cancellation/replay/full-snapshot-recovery/unknown-enum-preservation，薄客户端（CLI/TUI）请求之；协商后 `enabled_features` 如实非空；
- `--json` / `--socket` / `--core` 全局选项，human / JSON 输出。

## 暂不应视为可用的公开能力

| 能力 | 当前状态 | 原因 |
|---|---|---|
| Xray | 已放弃（M5） | 移除 stub 模块与死 `API_FAMILY`；`CoreKind::Xray` 保留但恒为 Unsupported（wire 兼容） |
| ApplyConfig RPC | ✅ 已接线（M5） | `caly config apply`，经 ConfigActor 提交新 config generation 并投影 config_generation；订阅驱动的 proxies/groups/rules 渲染 + 真实 `mihomo -t` 校验 + 失败回滚 |
| SetMode RPC | ✅ 已接线 | `caly core mode rule|global|direct`，Mihomo `/configs` PATCH；sing-box 亦支持（需渲染器输出 `clash_mode` 规则，否则 `mode-list` 仅 `["rule"]`，真实内核 E2E 验证模式切换） |
| SetTun RPC | ✅ 已接线（M5） | `SetTun` → `PlatformActor` owner，经 `LinuxTunCommandBackend`（`ip tuntap`/`ip link`）engage/restore；`tun.mtu` 配置驱动；缺权限时返回结构化失败 |
| TUI filter/sort/tree 键位 | ✅ 已接通 | `/` 过滤输入（Backspace/Esc/Enter 编辑）、`s` 循环排序键（Name→Protocol→Latency）、`t` 切换列表/树视图；过滤模式下按键不再触发动作 |
| TUI daemon-operation 执行 | ✅ 已接通（M5） | Enter 选择高亮节点、g 循环模式、r 重启核心、c 关闭连接；`caly-tui::ControlAction` outbox → binary `run_control_action` 后台线程执行 |
| 真实 TTY 长时运行 / PTY E2E | 未验证 | 无 PTY/session-expiry/断线 E2E |
| System proxy 真实 GNOME E2E | 阻塞 | 需要真实桌面会话 |

## 已闭环（相对早期基线）

- restore-first 启动门 + durable 平台副作用恢复（system-proxy）；
- ordered shutdown（`DaemonShutdownActions`，10 相，每相 10s 有界超时、保留各相失败；平台副作用先恢复后清记录）；
- 本地安全：controller 随机 secret（fail-closed）、`$XDG_RUNTIME_DIR/caly`、UDS path 校验、0600 配置；
- Operation cancellation / commit 竞争、pending-cancel 丢弃、迟到结果抑制；
- 核心崩溃自愈 `CrashLoopPolicy`（指数退避 + 稳定窗口）；
- live watch 持续 stream、telemetry 投影、TUI WatchDriver 驱动。

## 独立验证基线

Rust：1.88.0（MSRV，由 ratatui 0.30 钉住）。

| Gate | 结果 |
|---|---|
| `cargo metadata --locked --no-deps` | 通过 |
| `cargo fmt --all -- --check` | 通过 |
| `cargo check --workspace --all-targets --all-features --locked` | 通过 |
| `cargo test --workspace --all-targets --all-features --locked` | **538 passed，0 failed**（含真实内核 E2E；2026-08-06 核实） |
| Clippy `-D warnings` | 通过 |
| rustdoc `-D warnings` | 通过 |
| 7 个静态架构/规范脚本 | 通过，0 error |
| 依赖纪律脚本 | 通过 |
| `caly version/help` | 通过 |
| TUI dump example | 通过 |
| template-worker E2E | 通过 |
| Mihomo v1.19.29 real kernel | config/DNS/API/lifecycle/daemon+UDS E2E 全通过 |
| sing-box v1.13.14 real kernel | config/DNS/Clash-API/lifecycle/daemon+UDS E2E 全通过 |
| 双内核 daemon + UDS | status/restart/stop/start/crash-recovery/cleanup 全通过 |
| namespace TUN E2E | 通过（`sudo unshare -Urn` 隔离 namespace） |

### 真实内核 E2E 口径

测试内核不提交到 Git；`scripts/fetch-test-kernels.sh` 按 `vendor/kernels.lock.toml`
下载并校验官方 release SHA-256 到 `vendor/bin/`。已执行的 sing-box v1.13.14 / mihomo v1.19.29
用例包括：渲染配置 `check` 校验、真实进程 start/readiness/health/restart/stop/reap、Clash API
适配器（proxy groups / connections / traffic）、双内核 daemon+UDS 生命周期。普通 workspace run
中 TUN 用例因宿主无 CAP_NET_ADMIN 提前返回；隔离 namespace 中真实执行并通过。

GitHub `Real kernel E2E` workflow 下载固定版本、运行双内核/daemon E2E，并在独立 namespace 中运行 TUN；依赖缺失时直接失败。

> 注意：workspace 快照恢复可能重置 `vendor/bin/` 二进制可执行位；若 `caly` 报告
> `BackendUnavailable` 或内核 E2E 找不到二进制，请重新 `chmod +x vendor/bin/*` 或重跑
> `scripts/fetch-test-kernels.sh`。

## 当前 P0 / 发布阻塞

1. GitHub 根 workspace 仍需将已准备的主线迁移提交实际推送，不能继续以 ZIP 交付；
2. 真实 PTY E2E（TUI 长时运行/断线/键位自动化）未完成；
3. 远端 `daemon.listen` 目前启动即拒绝（fail-closed）：回环 TCP 在共享机器上并非
   owner-only（`127.0.0.1` 对同机其他用户可连）；支持前需实现 auth-token admission
   （JSON 帧信封已带 session token，但回环 TCP 的 token 注册对同机进程开放），
   或正式宣布 per-user UDS 为唯一受支持控制面形态并移除 TCP 入口。
4. **sing-box 配置 apply 不对等**（2026-08-06 核实）：`config apply` 恒经 `MihomoConfigBackend`
   渲染发布 mihomo.yaml，core=sing-box 时对运行内核无效——待按 active core 分派或显式 fail-fast。

`SetTun`/TUN crash-restore 已接真实 owner（M5）；`ApplyConfig`/`SetMode`/Mihomo 订阅→apply→rollback/AppConfig/FeatureList/TCP 传输/结构化 tracing 均已接线。**Xray 已放弃**：移除 stub 模块，`CoreKind::Xray` 保留但恒为 Unsupported（wire 兼容）。


---

## 历史轮次记录（已归档）

2026-08-05 之前的逐轮完成记录（CLI 收敛、配置生成、TUN 提权、订阅格式矩阵、质量大重构、规则引擎等）已归档至
[`docs/archive/STATUS-history-2026-08-05.md`](docs/archive/STATUS-history-2026-08-05.md)；最新轮次记录见
[`CHANGELOG.md`](CHANGELOG.md) 与提交历史。
