# caly 当前状态

> 更新时间：2026-08-08（Round 13 收尾：`Refreshable` trait + 3 个真 impl (`SubscriptionRefresh` / `ProfileRefresh` / `RuleProviderRefresh`) + `set sub/profile/rule-provider refresh` 全部接 trait 走统一 error envelope;`commands/set.rs` 233 行 → 9 个子文件按 resource 拆 (`set/core|proxy|tun|sub|profile|config|daemon|rule_provider`);`error.rs` 287 行 → 6 个子文件 `error/{profile,sub,core,config,daemon,usage}.rs`;`commands::legacy` → `commands::bridge` (改名符合实际语义);`set <res> refresh` 删 `--apply/--dry-run` flag;3 个新 dispatch test + 1 trait wired test;测试数 726 → 729;clippy `-D warnings` clean;rustdoc `-D warnings` clean）
> 本文件是当前能力与验证状态的唯一事实入口。历史过程见 `CHANGELOG.md` 与 git log，未完成工作见 `TODO.md`。
> 架构设计见 `docs/architecture.md`，工作区结构见 `docs/project-layout.md`。

## 定位

caly 是 Linux、per-user、daemon-first 的代理内核管理器，目标是"btop++ for proxies"的终端体验。

当前阶段：**高级架构原型 / 可运行 MVP，尚未达到 production-ready。** 核心生命周期、控制面、
订阅解析、live watch、telemetry 与 TUI 已闭环并通过真实内核 E2E；`SetTun` 已接
`PlatformActor` owner（真实 `LinuxTunCommandBackend`，缺权限时结构化失败）；Xray 已放弃（移除 stub）。

## 当前可用主路径

- owner-only UDS daemon（JSON-framed），daemon epoch 与 stale instance-lock reclaim；`daemon.listen` 配置可再绑定回环 TCP gRPC 传输（与 UDS 并行共享会话注册表）；
- **TUN owner + crash-restore（M5）**：`SetTun` → `PlatformActor`，经 `LinuxTunCommandBackend`（`ip tuntap`/`ip link`，shell-free bounded 命令）engage/restore；`tun.mtu` 配置驱动；缺权限时返回结构化失败；`DurableTunBackend` 接入持久化恢复（boot `restore_first` 重放、graceful shutdown 清记录），恢复存储泛化为 `FileRecoveryStore<R>` 复用；
- **结构化日志 + correlation（M5）**：`tracing`/`tracing-subscriber`（env-filter，`CALY_LOG`/`RUST_LOG`），daemon 结构化日志写 stderr 带 daemon id/socket/listen 字段；`reporting.rs` 在每个 operation terminal 发结构化事件（operation id + outcome）；daemon 启动路径的 `eprintln!` 全部改 structured；
- **Mihomo / sing-box** 进程生命周期（start/stop/restart）、健康检查、异常退出自愈（backoff）；
- **Mihomo / sing-box Clash API**：proxy groups / connections / traffic / select / close-all，共享 controller secret；
- **telemetry**：按 active core 选择 Mihomo/sing-box adapter，1s 采样并投影 `ObservedState`；
- **live watch**：server 持续 stream + 客户端惰性迭代器 + lag 重同步；
- **TUI**：`LiveWatchSource`+`WatchDriver` 驱动、断线/session 自动重连、mouse capture；daemon-operation 执行（Enter 选择节点 / `g` 循环模式 / `r` 重启核心 / `c` 关闭连接，后台线程经独立连接执行）；
- **system-proxy**：durable recovery 事务（GNOME/KDE/niri），daemon crash 后 restore-first 恢复；engage 前捕获桌面原状态（mode + endpoint），graceful shutdown 保真恢复到原状态（失败保留记录、无记录不触碰桌面）；
- **sniffer（域名嗅探/恢复）**：顶层 `sniffer:` 配置段（加载期端口规格校验）；Mihomo 渲染完整 `sniffer:` 块（真实 `mihomo -t` E2E 接受），sing-box 渲染 inbound `sniff`/`sniff_override_destination`（基础 + 订阅渲染器同源）；
- **规则引擎双内核对等**：config `rules:` 同时渲染进 Mihomo `rules:` 与 sing-box `route.rules`（单一纯映射 `rule_render`；MATCH→route.final、REJECT→block outbound、组名→PROXY selector）；GEOIP 映射 sing-box 1.12+ 的远程 rule-set 机制（真实 `sing-box check` E2E 接受）；
- **订阅**：SSRF-safe fetch、格式识别、URI/Clash 解析、dedupe/normalize、节点注册表索引；
- **订阅→Mihomo 配置渲染→校验→应用→回滚**：`-s refresh` 把可表示节点索引为 `RegisteredProxy`，`MihomoConfigRenderer` 渲染 proxies/proxy-groups/rules，`config apply` 用真实 `mihomo -t` 校验（失败即回滚不发布）后原子提交 owner-only 配置，生成号追加在文件尾；真实内核 E2E 通过；`ActiveConfigBackend` 按运行时 active core 在 Mihomo / sing-box 之间分派，详见 `TODO.md` §S1.4(已废止) 与下文 S1 节；
- **CLI（5-namespace，单一拼写 + `--apply` 翻转 dry-run 政策）**：每个能力只有一个规范入口，顶层快捷命令与 dash 别名已移除；Round 11 重构为 5 个 namespace：
  `daemon`（长跑单例）、`tool help|version|doctor|tui|dns`（静态工具）、`show status|core|proxy|sub|profile|config`（读）、
  `set core|proxy|tun|sub|profile|config|daemon|rule-provider`（写，每条 `--apply` 显式写入，默认 dry-run）；
  Round 11 新加 `set proxy add|edit|remove|import`、`set sub add|remove|enable|disable`、
  `set profile edit|export|enable|disable`、`set config diff`、`set daemon stop|reload|restart|status`、
  `set core url-test`/`--group`、`show core rules --match`、`show core health` 等 15 个能力；
  Round 12 新加 `set rule-provider add-http|add-file|add-inline|remove|enable|disable|refresh|list`（第三种 "remote source" 资源，与 `set sub` / `set profile` 同形）；`set profile refresh` 取消 `--apply/--dry-run`（refresh 总是写）；占位 leaf 全部用 `CliOutput::planned` 助手（消除 19 处 `eprintln! + let _ = output;` 模板）；
  Round 13 `Refreshable` trait + 3 个真 impl (`SubscriptionRefresh` / `ProfileRefresh` / `RuleProviderRefresh`) 走统一 error envelope (`code` / `message` / `hint` / `command`)；`set/` 按 resource 拆 8 个子文件 (`set/core|proxy|tun|sub|profile|config|daemon|rule_provider` + `set/common`)；`error.rs` 287 行 → 6 个子文件 `error/{profile,sub,core,config,daemon,usage}.rs`；`commands::legacy` → `commands::bridge` (改名符合"内部 bridge 而非 deprecation shim" 的实际语义)；
  变更命令成功输出 `ok: <语义摘要>`；`set core select` 支持节点名/组/最快；
  顶层 `-t`/`-d`/`-c`/`-s`/`-p` 与 `core <verb>`/`sub <verb>`/`sys <verb>`/`config <verb>`/`profile <verb>` 全部硬拒；
  `apply` 与 `dry-run` 互斥（clap `conflicts_with`）；`tool completions` 仍是顶层。
- **分层配置启动（M5）**：daemon 启动读取 `$XDG_CONFIG_HOME/caly/config.yaml`（base + `CALY_PROFILE` profile + `config.d/*` 分层合并、bounded budget），经校验的 `AppConfig` 驱动 core 选择；`CALY_CORE` env 优先，坏配置 fail-fast，无配置文件则回退 env；
- **handshake 能力通告（M5）**：协议 `all_features()` 单一真源，daemon 广而告之 operations/cancellation/replay/full-snapshot-recovery/unknown-enum-preservation，薄客户端（CLI/TUI）请求之；协商后 `enabled_features` 如实非空；
- `--json` / `--socket` / `--core` 全局选项，human / JSON 输出。

## 暂不应视为可用的公开能力

| 能力 | 当前状态 | 原因 |
|---|---|---|
| Xray | 已放弃（M5） | 移除 stub 模块与死 `API_FAMILY`；`CoreKind::Xray` 保留但恒为 Unsupported（wire 兼容） |
| ApplyConfig RPC | ✅ 已接线（M5） | `caly config apply`，经 ConfigActor 提交新 config generation 并投影 config_generation；订阅驱动的 proxies/groups/rules 渲染 + 真实 `mihomo -t` 校验 + 失败回滚；`ActiveConfigBackend` 按 `active_kind()` 在 Mihomo / sing-box 之间分派 |
| SetMode RPC | ✅ 已接线 | `caly core mode rule|global|direct`，Mihomo `/configs` PATCH；sing-box 亦支持（需渲染器输出 `clash_mode` 规则，否则 `mode-list` 仅 `["rule"]`，真实内核 E2E 验证模式切换） |
| SetTun RPC | ✅ 已接线（M5） | `SetTun` → `PlatformActor` owner，经 `LinuxTunCommandBackend`（`ip tuntap`/`ip link`）engage/restore；`tun.mtu` 配置驱动；缺权限时返回结构化失败 |
| TUI filter/sort/tree 键位 | ✅ 已接通 | `/` 过滤输入（Backspace/Esc/Enter 编辑）、`s` 循环排序键（Name→Protocol→Latency）、`t` 切换列表/树视图；过滤模式下按键不再触发动作 |
| TUI daemon-operation 执行 | ✅ 已接通（M5） | Enter 选择高亮节点、g 循环模式、r 重启核心、c 关闭连接；`caly-tui::ControlAction` outbox → binary `run_control_action` 后台线程执行 |
| 真实 TTY 长时运行 / PTY E2E | 未验证 | 无 PTY/session-expiry/断线 E2E（见 `TODO.md` §S1.2） |
| System proxy 真实 GNOME E2E | 阻塞 | 需要真实桌面会话（见 `TODO.md` §S2.1） |
| `daemon.listen` TCP auth-token admission | 未实现 | 当前 fail-closed；接受前需实现 owner-only token 注册或移除 TCP 入口（见 `TODO.md` §S1.3） |

## 已闭环（相对早期基线）

- restore-first 启动门 + durable 平台副作用恢复（system-proxy）；
- ordered shutdown（`DaemonShutdownActions`，10 相，每相 10s 有界超时、保留各相失败；平台副作用先恢复后清记录）；
- 本地安全：controller 随机 secret（fail-closed）、`$XDG_RUNTIME_DIR/caly`、UDS path 校验、0600 配置；
- Operation cancellation / commit 竞争、pending-cancel 丢弃、迟到结果抑制；
- 核心崩溃自愈 `CrashLoopPolicy`（指数退避 + 稳定窗口）；
- live watch 持续 stream、telemetry 投影、TUI WatchDriver 驱动。

## 独立验证基线

Rust：1.88.0（MSRV，由 ratatui 0.30 钉住）。

| Gate | 结果 |
|---|---|
| `cargo metadata --locked --no-deps` | 通过 |
| `cargo fmt --all -- --check` | **失败**（28 处 diff；`TODO.md` §S4.3） |
| `cargo check --workspace --all-targets --all-features --locked` | 通过 |
| `cargo test --workspace --all-targets --all-features --locked`（有 `vendor/bin/` 时） | **733 passed, 0 failed, 0 ignored**（2026-08-08 核实；含真实内核 E2E;Round 13 +7,Round 12 +3,Round 11 +15,Round 10 +12,Round 9 +5,Round 8 +15,Round 7 +44,Round 6 +22,Round 5 +6） |
| `cargo test`（无 `vendor/bin/` 时,本地 clone 后默认） | 同 726 passed；但其中真实内核 E2E 守卫在 `available()=false` 时**静默跳过**（详见下文"真实内核 E2E 口径"与 `TODO.md` §S4.4） |
| `cargo test`（无 `vendor/bin/` 时,本地 clone 后默认） | 同 723 passed；但其中真实内核 E2E 守卫在 `available()=false` 时**静默跳过**（详见下文"真实内核 E2E 口径"与 `TODO.md` §S4.4） |
| Clippy `-D warnings` | 通过 |
| rustdoc `-D warnings` | 通过 |
| 6 个静态架构/规范脚本 | 通过,0 error |
| 依赖纪律脚本 | 通过 |
| `caly version/help` | 通过 |
| TUI dump example | 通过 |
| template-worker E2E | 通过（需先 `cargo build -p caly-template-worker`,否则静默跳过） |
| Mihomo v1.19.29 real kernel | config/DNS/API/lifecycle/daemon+UDS E2E 全通过 |
| sing-box v1.13.14 real kernel | config/DNS/Clash-API/lifecycle/daemon+UDS E2E 全通过 |
| 双内核 daemon + UDS | status/restart/stop/start/crash-recovery/cleanup 全通过 |
| namespace TUN E2E | 通过（`sudo unshare -Urn` 隔离 namespace） |

### 真实内核 E2E 口径

测试内核不提交到 Git；`scripts/fetch-test-kernels.sh` 按 `vendor/kernels.lock.toml`
下载并校验官方 release SHA-256 到 `vendor/bin/`。已执行的 sing-box v1.13.14 / mihomo v1.19.29
用例包括：渲染配置 `check` 校验、真实进程 start/readiness/health/restart/stop/reap、Clash API
适配器（proxy groups / connections / traffic）、双内核 daemon+UDS 生命周期。普通 workspace run
中 TUN 用例因宿主无 CAP_NET_ADMIN 提前返回；隔离 namespace 中真实执行并通过。

GitHub `Real kernel E2E` workflow 下载固定版本、运行双内核/daemon E2E，并在独立 namespace 中运行 TUN；依赖缺失时直接失败。

> **关于"538 passed"与"580 passed"与"610 passed"与"632 passed"与"676 passed"与"691 passed"与"696 passed"与"708 passed"与"723 passed"与"726 passed"**：本文件早期版本（2026-08-06 之前）记录的是 538；
> 2026-08-07 中段实测 **580 passed, 0 failed, 0 ignored**；Round 5 补
> `provision_geoip_metadb` 与 `tun_failure` 的 regression test 后为
> **610 passed, 0 failed, 0 ignored**；Round 6 引入 `rule_providers:` 段、4 个新 RuleMatch
> variants、22 个新 regression test 后为 **632 passed, 0 failed, 0 ignored**；Round 7
> 引入 Profile 类型模型（Remote/Local/Merge）+ 5 个新 CLI 子命令后为
> **676 passed, 0 failed, 0 ignored**；Round 8 接通 Remote fetch (SSRF-safe) +
> `Inline` rule provider 启动时物化 + CLI `--dry-run` / 写前 backup +15 个
> regression test 后为 **691 passed, 0 failed, 0 ignored**；Round 9
> debug + 收敛，修复 3 个真实 bug（nested-merge `FetchChain.id`、backup 累积、
> IPv4-mapped IPv6 SSRF bypass）+ 收敛 `mutate_profiles_in_config` /
> `refresh_recursive` / `current_unix_ms` + `LayeredConfigError.Display` +
> 删除 4 个 dead `pub fn` / wrapper +5 个 regression test 后为
> **696 passed, 0 failed, 0 ignored**；Round 10 CLI 重构（main.rs
> 721→121 行；JSON 错误 contract 稳定；`output::CliError` + `error::*` 稳定 code 目录；
> `commands/{profile,sub,doctor,daemon,dns,config}.rs` per-family dispatch；
> long_about + after_help + common workflows 锁住 12 个 regression test 后为
> **708 passed, 0 failed, 0 ignored**；Round 11 5-namespace 重构（daemon/tool/show/set）+
> 15 个新能力 + dry-run 政策翻转（默认 dry-run，`--apply` 写入）+ 老命令硬拒 +
> `cli::cli_tests` 全量重写 27 个新 assertion 后为
> **723 passed, 0 failed, 0 ignored**；Round 12 Refresh 抽象 +
> `set rule-provider` CLI family + 业务打磨（`CliOutput::planned` 消除 19 处
> `let _ = output;` 占位模板；`set profile refresh` 取消 `--apply/--dry-run`；
> `commands::redirect` → `commands::legacy`；占位 module 删 3 个）后为
> **726 passed, 0 failed, 0 ignored**。差别来自
> 后续轮次新增的 `caly-application/src/command_bus`、`caly-protocol` v2 wire 帧、TCP 传输、
> 命名规整与节点 canonical 编码、Round 1–4 的 bounded-text 回归用例、Round 5 的 corrupt-geoip /
> oversized-failure-message 回归用例、Round 6 的 rule-set/rule-proviers 回归用例、Round 7 的
> Profile 域+schema+store+loader+CLI 回归用例、Round 8 的 fetch+materialize+dry-run 回归用例、Round 9 的
> nested-merge+classifier-matrix+backup-collision 回归用例、Round 10 的
> CliOutput envelope + 错误 code 目录 + help-text contract 回归用例、Round 11 的
> 5-namespace grammar + dry-run 翻转 + 老命令硬拒回归用例、Round 12 的
> Refresh 抽象 + rule-provider grammar + profile refresh flag 收紧 回归用例。
> `README.md` 顶部数字"538 passing tests"同步修正为 726。
>
> **关于"E2E 静默跳过"**：本轮核对发现 `crates/caly-kernel/tests/mihomo_e2e.rs` 等真实内核
> E2E 在缺二进制或 `CAP_NET_ADMIN` 时打印 `skipping: ...` 后 `return`,**未**用 `#[ignore]`
> 标记；`cargo test` 因此报告 `0 ignored`,但核心断言路径并未执行。本机"580 passed"中
> 包含这些假阳性,**只有**当 `vendor/bin/` 已就位且具备 `CAP_NET_ADMIN` 时数字才完全等价
> 于"全部真实执行"。修法见 `TODO.md` §S4.4。
>
> **关于"7 个静态架构/规范脚本"**：实际只有 6 个校验脚本：
> `check-actor-topology.py`、`check-code-standards.py`、`check-dependency-discipline.sh`、
> `check-infrastructure-invariants.py`、`check-integration-invariants.py`、
> `check-presentation-invariants.py`。`scripts/fetch-test-kernels.sh` 是二进制下载器,
> 不算校验脚本。
>
> **关于 `cargo fmt`**：CI 中跑通是 1.88.0 默认 rustfmt 的某次 hash；本机克隆后
> `cargo fmt --all -- --check` 报 28 处 diff（涉及 `lifecycle.rs`、`subscription/http.rs`、
> `tun/linux.rs`、`mihomo_e2e.rs` 等），需要一次性 `cargo fmt --all` 后提交。详见 `TODO.md` §S4.3。
>
> 注意：workspace 快照恢复可能重置 `vendor/bin/` 二进制可执行位；若 `caly` 报告
> `BackendUnavailable` 或内核 E2E 找不到二进制，请重新 `chmod +x vendor/bin/*` 或重跑
> `scripts/fetch-test-kernels.sh`。

## 当前 S1 / 发布阻塞

> 详细可执行清单见 [`TODO.md`](TODO.md) §S1。本节保留精简摘要，与 `TODO.md` 严格一一对应。

1. **S1.1** GitHub 根 workspace 仍需将已准备的主线迁移提交实际推送，不能继续以 ZIP 交付；
2. **S1.2** 真实 PTY E2E（TUI 长时运行/断线/键位自动化）未完成；
3. **S1.3** 远端 `daemon.listen` 目前启动即拒绝（fail-closed）：回环 TCP 在共享机器上并非
   owner-only（`127.0.0.1` 对同机其他用户可连）；支持前需实现 auth-token admission
   （JSON 帧信封已带 session token，但回环 TCP 的 token 注册对同机进程开放），
   或正式宣布 per-user UDS 为唯一受支持控制面形态并移除 TCP 入口。

> **S1.4(已废止)**：早期 P0 列表中的"sing-box 配置 apply 不对等"在 M5 轮已解决——
> `ActiveConfigBackend`(`crates/caly-backends/src/config/mod.rs:517-575`)按 `active_kind()`
> 在 `Mihomo` / `SingBox` 之间分派 `parse_and_render / discard_prepared / commit_candidate /
> rollback_commit`,E2E 覆盖在 `tests/sing_box_config_apply_real_e2e.rs` 与
> `tests/config_apply_real_e2e.rs`(3 项全过)。本条**不再列为 P0 阻塞**。若发现
> `core=sing-box` 路径上 `config apply` 实际未生效，请回滚本废止说明并在
> `tests/config_apply_real_e2e.rs` 增补失败用例。

`SetTun`/TUN crash-restore 已接真实 owner（M5）；`ApplyConfig`/`SetMode`/Mihomo 订阅→apply→rollback/AppConfig/FeatureList/TCP 传输/结构化 tracing 均已接线。**Xray 已放弃**：移除 stub 模块，`CoreKind::Xray` 保留但恒为 Unsupported（wire 兼容）。

---

## 历史轮次记录

逐轮完成记录见 [`CHANGELOG.md`](CHANGELOG.md) 与 git log；本文件不重复维护历史快照。
