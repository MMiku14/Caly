#!/usr/bin/env python3
"""Non-compiling checks for thin-client and truthful-UX invariants."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []
TUI = ROOT / "crates/caly-tui"


def require(path: Path, token: str) -> None:
    if token not in path.read_text(encoding="utf-8"):
        ERRORS.append(f"{path.relative_to(ROOT)}: missing {token}")


def main() -> int:
    forbidden_dependencies = (
        "caly-application", "caly-config", "caly-kernel", "caly-platform", "caly-server",
    )
    for manifest in (TUI / "Cargo.toml",):
        source = manifest.read_text(encoding="utf-8")
        for dependency in forbidden_dependencies:
            if dependency in source:
                ERRORS.append(f"{manifest.relative_to(ROOT)}: forbidden {dependency}")
    for crate in (TUI,):
        for path in crate.rglob("*.rs"):
            source = path.read_text(encoding="utf-8")
            for token in ("std::fs", "std::process", "std::net", "PathBuf", "cfg(target_os"):
                if token in source:
                    ERRORS.append(f"{path.relative_to(ROOT)}: forbidden thin-client token {token}")
    require(TUI / "src/client/supervisor.rs", "ApplyingEvent")
    require(TUI / "src/client/supervisor.rs", "EventDecodeFailed")
    require(TUI / "src/operation/tracker.rs", "WaitTimedOutQueryStatus")
    require(TUI / "src/model/session.rs", "NodeId")
    require(TUI / "src/client/watch_driver.rs", "event_from_wire")
    require(TUI / "src/client/watch_driver.rs", "DecodeBudget::new(self.limits)")
    require(TUI / "src/client/watch_driver.rs", "EventApplied")
    for error in ERRORS:
        print(f"error: {error}", file=sys.stderr)
    print(f"presentation invariant scan: {len(ERRORS)} error(s)")
    return 1 if ERRORS else 0


if __name__ == "__main__":
    raise SystemExit(main())
