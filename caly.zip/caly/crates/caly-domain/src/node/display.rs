//! Redacted node projection for presentation and wire boundaries.

use crate::{BoundedText, NodeId};

/// Maximum node display-name length in UTF-8 bytes.
pub const NODE_DISPLAY_NAME_MAX_BYTES: usize = 256;
/// Maximum protocol-label length in UTF-8 bytes.
pub const NODE_PROTOCOL_LABEL_MAX_BYTES: usize = 32;

/// Validated user-facing node name.
pub type NodeDisplayName = BoundedText<NODE_DISPLAY_NAME_MAX_BYTES>;
/// Stable safe protocol label, such as `vmess` or `shadowsocks`.
pub type NodeProtocolLabel = BoundedText<NODE_PROTOCOL_LABEL_MAX_BYTES>;

/// Credential-free node data allowed in snapshots and thin clients.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DisplayNode {
    id: NodeId,
    name: NodeDisplayName,
    protocol: NodeProtocolLabel,
    available: bool,
    latency_ms: Option<u32>,
}

impl DisplayNode {
    /// Constructs a redacted display projection.
    pub const fn new(
        id: NodeId,
        name: NodeDisplayName,
        protocol: NodeProtocolLabel,
        available: bool,
        latency_ms: Option<u32>,
    ) -> Self {
        Self {
            id,
            name,
            protocol,
            available,
            latency_ms,
        }
    }

    /// Returns the stable selection identity.
    pub const fn id(&self) -> NodeId {
        self.id
    }
    /// Returns the user-facing name.
    pub const fn name(&self) -> &NodeDisplayName {
        &self.name
    }
    /// Returns a safe protocol label.
    pub const fn protocol(&self) -> &NodeProtocolLabel {
        &self.protocol
    }
    /// Returns observed availability, not configured capability.
    pub const fn is_available(&self) -> bool {
        self.available
    }
    /// Returns the latest successful latency when one exists.
    pub const fn latency_ms(&self) -> Option<u32> {
        self.latency_ms
    }
}
