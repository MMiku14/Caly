//! Pure domain model for caly.
//!
//! This crate contains no async runtime, filesystem, network, process,
//! platform, path, RPC, wall-clock acquisition or random-number generation.
//! Outer owners supply timestamps and generated/hash-derived identities.

#![forbid(unsafe_code)]

mod capability;
mod collection;
mod dns;
mod dns_filter;
mod event;
mod identity;
mod nameserver;
mod node;
mod operation;
mod rule;
mod secret;
mod settings;
mod state;
mod text;
mod tun;

pub use capability::{
    Capability, CapabilitySet, CapabilityStatus, ConfiguredSupport, DuplicateCapability,
    RuntimeAvailability,
};
pub use collection::{BoundedExtendError, BoundedPushError, BoundedVec, CapacityError};
pub use dns::{DnsError, DnsMode, DnsSettings, DnsSettingsBuilder, MAX_DNS_SERVERS};
pub use dns_filter::{
    DNS_LISTEN_MAX_BYTES, DNS_PATTERN_MAX_BYTES, DnsFilterError, DnsPattern, FallbackFilter,
    MAX_DNS_FILTER_ENTRIES,
};
pub use event::{
    CursorDisposition, EventCursor, EventSequence, SequenceExhausted, classify_cursor,
};
pub use identity::{
    DaemonInstanceId, IdentityParseError, NodeId, OperationId, SubscriptionId, to_hex,
};
pub use nameserver::{
    DNS_TEXT_MAX_BYTES, FAKE_IP_RANGE_MAX_BYTES, FakeIpRange, FakeIpRangeError, Nameserver,
    NameserverError,
};
pub use node::{
    CongestionControl, Credential, DialableNode, DisplayNode, Endpoint, EndpointHost, HostError,
    NodeBuilder, NodeDisplayName, NodeProtocolLabel, NodeSource, NodeTag, NodeTags,
    NodeValidationError, Protocol, ProtocolText, RealityConfig, ShadowsocksCipher,
    ShadowsocksPlugin, TlsConfig, Transport, TransportText, TransportTextList, VmessCipher,
};
pub use operation::{
    OperationFailure, OperationFailureCode, OperationState, OperationStatus, OperationStatusError,
    UnixMillis,
};
pub use rule::{
    GeoipCode, MAX_RULES, RULE_TEXT_MAX_BYTES, RoutingRule, RuleError, RuleMatch, RulePolicy,
    RuleText, match_host,
};
pub use secret::{SecretError, SecretText};
pub use settings::Controllers;
pub use state::{
    AppliedState, AppliedStateError, CoreKind, CoreRunState, DesiredState, ObservedState,
    PlatformEffectView, PresentationDelta, PresentationSnapshot, ProxyMode, SnapshotNodes,
    SnapshotRevision,
};
pub use text::{BoundedText, TextError};
pub use tun::{MAX_TUN_MTU, MIN_TUN_MTU, TunConfig, TunError, TunStack};
