//! Pure domain model for caly.
//!
//! This crate contains no async runtime, filesystem, network, process,
//! platform, path, RPC, wall-clock acquisition or random-number generation.
//! Outer owners supply timestamps and generated/hash-derived identities.

#![forbid(unsafe_code)]

mod capability;
mod collection;
mod dns;
mod dns_filter;
mod event;
mod identity;
mod nameserver;
mod node;
mod operation;
mod profile;
mod rule;
mod secret;
mod settings;
mod state;
mod text;
mod tun;

pub use capability::{
    Capability, CapabilitySet, CapabilityStatus, ConfiguredSupport, DuplicateCapability,
    RuntimeAvailability,
};
pub use collection::{BoundedExtendError, BoundedPushError, BoundedVec, CapacityError};
pub use dns::{DnsError, DnsMode, DnsSettings, DnsSettingsBuilder, MAX_DNS_SERVERS};
pub use dns_filter::{
    DNS_LISTEN_MAX_BYTES, DNS_PATTERN_MAX_BYTES, DnsFilterError, DnsPattern, FallbackFilter,
    MAX_DNS_FILTER_ENTRIES,
};
pub use event::{
    CursorDisposition, EventCursor, EventSequence, SequenceExhausted, classify_cursor,
};
pub use identity::{
    DaemonInstanceId, IdentityParseError, NodeId, OperationId, SubscriptionId, to_hex,
};
pub use nameserver::{
    DNS_TEXT_MAX_BYTES, FAKE_IP_RANGE_MAX_BYTES, FakeIpRange, FakeIpRangeError, Nameserver,
    NameserverError,
};
pub use node::{
    CongestionControl, Credential, DialableNode, DisplayNode, Endpoint, EndpointHost, HostError,
    NodeBuilder, NodeDisplayName, NodeProtocolLabel, NodeSource, NodeTag, NodeTags,
    NodeValidationError, Protocol, ProtocolText, RealityConfig, ShadowsocksCipher,
    ShadowsocksPlugin, TlsConfig, Transport, TransportText, TransportTextList, VmessCipher,
};
pub use operation::{
    OperationFailure, OperationFailureCode, OperationState, OperationStatus, OperationStatusError,
    UnixMillis,
};
pub use profile::{
    PROFILE_BODY_MAX_BYTES, PROFILE_DESCRIPTION_MAX_BYTES, PROFILE_ID_MAX_BYTES,
    PROFILE_NAME_MAX_BYTES, MAX_PROFILES, Profile, ProfileBody, ProfileDescription, ProfileError,
    ProfileId, ProfileName, ProfileSource, is_path_safe_component, validate_id,
};
pub use rule::{
    GEOSITE_NAME_MAX_BYTES, GeoipCode, GeositeName, INLINE_RULE_PAYLOAD_MAX_BYTES,
    MAX_RULE_PROVIDERS, MAX_RULES, PROCESS_NAME_MAX_BYTES, RULE_PROVIDER_NAME_MAX_BYTES,
    RULE_TEXT_MAX_BYTES, RoutingRule, RuleError, RuleMatch, RulePolicy, RuleProvider,
    RuleProviderBehavior, RuleProviderFormat, RuleProviderName, RuleProviderSource, RuleText,
    match_host,
};
pub use secret::{SecretError, SecretText};
pub use settings::Controllers;
pub use state::{
    AppliedState, AppliedStateError, CoreKind, CoreRunState, DesiredState, ObservedState,
    PlatformEffectView, PresentationDelta, PresentationSnapshot, ProxyMode, SnapshotNodes,
    SnapshotRevision,
};
pub use text::{BoundedText, TextError};
pub use tun::{MAX_TUN_MTU, MIN_TUN_MTU, TunConfig, TunError, TunStack};
