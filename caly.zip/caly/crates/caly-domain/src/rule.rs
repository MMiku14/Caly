//! Core-agnostic routing rule model plus a pure, offline host matcher.
//!
//! Rules describe how traffic is steered: a matcher (domain / domain-suffix /
//! domain-keyword / ip-cidr / geoip / catch-all) and a policy (DIRECT / REJECT
//! / a named proxy group). The model renders into Mihomo `rules:` entries and
//! sing-box `route.rules`. Host matching is pure string logic and lives here;
//! IP/CIDR matching needs address arithmetic and lives in the infrastructure
//! layer (`caly-config::rule_match`) to keep the domain free of `std::net`.

use crate::BoundedText;

/// Maximum bytes in one rule text field (domain, keyword, CIDR, group name).
pub const RULE_TEXT_MAX_BYTES: usize = 256;
/// Maximum bytes in a GEOIP country code.
pub const GEOIP_CODE_MAX_BYTES: usize = 8;
/// Maximum rules in one ordered rule set.
pub const MAX_RULES: usize = 1024;

pub type RuleText = BoundedText<RULE_TEXT_MAX_BYTES>;
pub type GeoipCode = BoundedText<GEOIP_CODE_MAX_BYTES>;

/// How a rule matches traffic.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuleMatch {
    /// Exact full hostname match.
    Domain(RuleText),
    /// Hostname ends with the suffix (`.example.com` semantics).
    DomainSuffix(RuleText),
    /// Hostname contains the keyword anywhere.
    DomainKeyword(RuleText),
    /// IP within a CIDR block, stored as CIDR text (`addr/prefix`). Full
    /// address validation happens in the infrastructure matcher.
    IpCidr(RuleText),
    /// GeoIP country code. Rendering-only: evaluating needs a GeoIP database,
    /// which the offline engine does not carry.
    Geoip(GeoipCode),
    /// Catch-all; conventionally the last rule.
    Match,
}

/// Where matched traffic is steered.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RulePolicy {
    /// Bypass the proxy.
    Direct,
    /// Drop the connection.
    Reject,
    /// Route through a named proxy or proxy group.
    Proxy(RuleText),
}

/// One routing rule: matcher plus policy.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RoutingRule {
    pub matcher: RuleMatch,
    pub policy: RulePolicy,
}

/// Validation/parsing failure for a routing rule.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RuleError {
    Empty,
    /// Wrong field count for the rule type.
    Malformed,
    UnknownType,
    UnknownPolicy,
    TextTooLong,
    InvalidCidr,
}

impl core::fmt::Display for RuleError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Empty => formatter.write_str("rule must not be empty"),
            Self::Malformed => formatter.write_str("rule has the wrong number of fields"),
            Self::UnknownType => formatter.write_str("unknown rule type"),
            Self::UnknownPolicy => {
                formatter.write_str("rule policy must be DIRECT, REJECT, or a group")
            }
            Self::TextTooLong => formatter.write_str("rule field exceeds the bounded length"),
            Self::InvalidCidr => formatter.write_str("IP-CIDR value is not a valid CIDR block"),
        }
    }
}

impl std::error::Error for RuleError {}

impl RulePolicy {
    /// Parses a Clash policy token (`DIRECT`/`REJECT`/group name).
    fn parse(token: &str) -> Result<Self, RuleError> {
        match token {
            "DIRECT" => Ok(Self::Direct),
            "REJECT" => Ok(Self::Reject),
            name if !name.is_empty() => Ok(Self::Proxy(
                RuleText::new(name.to_owned()).map_err(|_| RuleError::TextTooLong)?,
            )),
            _ => Err(RuleError::UnknownPolicy),
        }
    }

    /// Renders the policy token back to Clash form.
    pub fn to_clash(&self) -> String {
        match self {
            Self::Direct => "DIRECT".to_owned(),
            Self::Reject => "REJECT".to_owned(),
            Self::Proxy(name) => name.as_str().to_owned(),
        }
    }
}

impl RuleMatch {
    /// Renders the matcher to its Clash `TYPE[,VALUE]` prefix.
    pub fn to_clash(&self) -> String {
        match self {
            Self::Domain(value) => format!("DOMAIN,{}", value.as_str()),
            Self::DomainSuffix(value) => format!("DOMAIN-SUFFIX,{}", value.as_str()),
            Self::DomainKeyword(value) => format!("DOMAIN-KEYWORD,{}", value.as_str()),
            Self::IpCidr(value) => format!("IP-CIDR,{}", value.as_str()),
            Self::Geoip(code) => format!("GEOIP,{}", code.as_str()),
            Self::Match => "MATCH".to_owned(),
        }
    }
}

impl RoutingRule {
    /// Builds a rule from validated parts.
    pub const fn new(matcher: RuleMatch, policy: RulePolicy) -> Self {
        Self { matcher, policy }
    }

    /// Parses one Clash rule line (`TYPE,VALUE,POLICY`; `MATCH,POLICY`).
    pub fn from_clash_line(line: &str) -> Result<Self, RuleError> {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            return Err(RuleError::Empty);
        }
        let fields: Vec<&str> = line.split(',').map(str::trim).collect();
        let kind = *fields.first().ok_or(RuleError::Malformed)?;
        match kind {
            "MATCH" => {
                let policy_token = fields.get(1).ok_or(RuleError::Malformed)?;
                Ok(Self::new(
                    RuleMatch::Match,
                    RulePolicy::parse(policy_token)?,
                ))
            }
            "DOMAIN" | "DOMAIN-SUFFIX" | "DOMAIN-KEYWORD" | "IP-CIDR" | "IP-CIDR6" | "GEOIP" => {
                if fields.len() < 3 {
                    return Err(RuleError::Malformed);
                }
                let value = fields[1];
                let policy_token = fields.last().ok_or(RuleError::Malformed)?;
                let policy = RulePolicy::parse(policy_token)?;
                let matcher = match kind {
                    "DOMAIN" => RuleMatch::Domain(text(value)?),
                    "DOMAIN-SUFFIX" => RuleMatch::DomainSuffix(text(value)?),
                    "DOMAIN-KEYWORD" => RuleMatch::DomainKeyword(text(value)?),
                    "IP-CIDR" | "IP-CIDR6" => RuleMatch::IpCidr(cidr_text(value)?),
                    _ => RuleMatch::Geoip(
                        GeoipCode::new(value.to_owned()).map_err(|_| RuleError::TextTooLong)?,
                    ),
                };
                Ok(Self::new(matcher, policy))
            }
            _ => Err(RuleError::UnknownType),
        }
    }

    /// Renders the full Clash rule line.
    pub fn to_clash_line(&self) -> String {
        format!("{},{}", self.matcher.to_clash(), self.policy.to_clash())
    }

    /// Whether this rule matches a hostname. GEOIP/IP rules never match a host.
    pub fn matches_host(&self, host: &str) -> bool {
        let host = host.to_ascii_lowercase();
        match &self.matcher {
            RuleMatch::Domain(value) => host == value.as_str().to_ascii_lowercase(),
            RuleMatch::DomainSuffix(value) => {
                let suffix = value.as_str().to_ascii_lowercase();
                host == suffix || host.ends_with(&format!(".{suffix}"))
            }
            RuleMatch::DomainKeyword(value) => host.contains(&value.as_str().to_ascii_lowercase()),
            RuleMatch::Match => true,
            RuleMatch::IpCidr(_) | RuleMatch::Geoip(_) => false,
        }
    }
}

fn text(value: &str) -> Result<RuleText, RuleError> {
    if value.is_empty() {
        return Err(RuleError::Malformed);
    }
    RuleText::new(value.to_owned()).map_err(|_| RuleError::TextTooLong)
}

/// Structural CIDR check kept in the domain (no address arithmetic): a CIDR
/// must be `address/prefix` with non-empty halves. Full IP validation happens
/// in the infrastructure matcher.
fn cidr_text(value: &str) -> Result<RuleText, RuleError> {
    let (address, prefix) = value.split_once('/').ok_or(RuleError::InvalidCidr)?;
    if address.is_empty() || prefix.is_empty() {
        return Err(RuleError::InvalidCidr);
    }
    RuleText::new(value.to_owned()).map_err(|_| RuleError::TextTooLong)
}

/// Returns the first rule whose matcher hits the hostname (order-sensitive).
pub fn match_host<'a>(rules: &'a [RoutingRule], host: &str) -> Option<&'a RoutingRule> {
    rules.iter().find(|rule| rule.matches_host(host))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rule(line: &str) -> Result<RoutingRule, RuleError> {
        RoutingRule::from_clash_line(line)
    }

    #[test]
    fn parses_all_rule_types() -> Result<(), RuleError> {
        assert!(matches!(
            rule("DOMAIN,example.com,DIRECT")?.matcher,
            RuleMatch::Domain(_)
        ));
        assert!(matches!(
            rule("DOMAIN-SUFFIX,google.com,PROXY")?.matcher,
            RuleMatch::DomainSuffix(_)
        ));
        assert!(matches!(
            rule("DOMAIN-KEYWORD,ad,REJECT")?.matcher,
            RuleMatch::DomainKeyword(_)
        ));
        assert!(matches!(
            rule("IP-CIDR,192.168.0.0/16,DIRECT")?.matcher,
            RuleMatch::IpCidr(_)
        ));
        assert!(matches!(
            rule("GEOIP,CN,DIRECT")?.matcher,
            RuleMatch::Geoip(_)
        ));
        assert!(matches!(rule("MATCH,PROXY")?.matcher, RuleMatch::Match));
        Ok(())
    }

    #[test]
    fn policy_parses_direct_reject_and_group() -> Result<(), RuleError> {
        assert_eq!(rule("DOMAIN,a.com,DIRECT")?.policy, RulePolicy::Direct);
        assert_eq!(rule("DOMAIN,a.com,REJECT")?.policy, RulePolicy::Reject);
        assert_eq!(rule("DOMAIN,a.com,Auto")?.policy.to_clash(), "Auto");
        Ok(())
    }

    #[test]
    fn rejects_malformed_rules() {
        assert!(matches!(
            RoutingRule::from_clash_line(""),
            Err(RuleError::Empty)
        ));
        assert!(matches!(
            RoutingRule::from_clash_line("BOGUS,foo,DIRECT"),
            Err(RuleError::UnknownType)
        ));
        assert!(matches!(
            RoutingRule::from_clash_line("DOMAIN,foo"),
            Err(RuleError::Malformed)
        ));
        assert!(matches!(
            RoutingRule::from_clash_line("IP-CIDR,no-slash,DIRECT"),
            Err(RuleError::InvalidCidr)
        ));
    }

    #[test]
    fn domain_matching_is_exact_and_case_insensitive() -> Result<(), RuleError> {
        let r = rule("DOMAIN,Example.COM,DIRECT")?;
        assert!(r.matches_host("example.com"));
        assert!(r.matches_host("EXAMPLE.com"));
        assert!(!r.matches_host("sub.example.com"));
        Ok(())
    }

    #[test]
    fn suffix_matching_covers_apex_and_subdomains() -> Result<(), RuleError> {
        let r = rule("DOMAIN-SUFFIX,example.com,DIRECT")?;
        assert!(r.matches_host("example.com"));
        assert!(r.matches_host("a.b.example.com"));
        assert!(!r.matches_host("notexample.com"));
        Ok(())
    }

    #[test]
    fn keyword_matching_finds_substrings() -> Result<(), RuleError> {
        let r = rule("DOMAIN-KEYWORD,ad,REJECT")?;
        assert!(r.matches_host("ads.example.com"));
        assert!(r.matches_host("example.adroll.net"));
        assert!(!r.matches_host("example.com"));
        Ok(())
    }

    #[test]
    fn first_host_match_wins_and_match_is_catch_all() -> Result<(), RuleError> {
        let rules = vec![
            rule("DOMAIN-SUFFIX,example.com,DIRECT")?,
            rule("DOMAIN-KEYWORD,ad,REJECT")?,
            rule("MATCH,PROXY")?,
        ];
        assert_eq!(
            match_host(&rules, "example.com").map(|r| r.policy.clone()),
            Some(RulePolicy::Direct)
        );
        assert_eq!(
            match_host(&rules, "ads.example.com").map(|r| r.policy.clone()),
            Some(RulePolicy::Direct)
        );
        let catch_all = rule("MATCH,PROXY")?;
        assert_eq!(
            match_host(&rules, "other.org").map(|r| r.policy.clone()),
            Some(catch_all.policy.clone())
        );
        Ok(())
    }

    #[test]
    fn geoip_does_not_match_hosts() -> Result<(), RuleError> {
        assert!(!rule("GEOIP,CN,DIRECT")?.matches_host("example.cn"));
        Ok(())
    }

    #[test]
    fn clash_line_round_trips() -> Result<(), RuleError> {
        for line in [
            "DOMAIN,example.com,DIRECT",
            "DOMAIN-SUFFIX,google.com,PROXY",
            "IP-CIDR,10.0.0.0/8,DIRECT",
            "GEOIP,CN,DIRECT",
            "MATCH,Auto",
        ] {
            assert_eq!(rule(line)?.to_clash_line(), line);
        }
        Ok(())
    }
}
