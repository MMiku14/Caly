//! PlatformActor system-side-effect command port.

use caly_domain::PlatformEffectView;

use super::error::ActorFailure;

/// Nonblocking PlatformActor backend owning recovery transactions.
pub trait PlatformCommandBackend {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure>;
}
