//! Shared actor ports and the common bounded error type.
//!
//! This crate sits at the bottom of the product layer (above `caly-domain`) and
//! defines the trait boundaries that owner actors depend on and that concrete
//! adapters implement. Neither the application use-case crate nor the backend
//! adapters need to know each other's concrete types.

#![forbid(unsafe_code)]

pub mod config;
pub mod core;
pub mod error;
pub mod lifecycle;
pub mod platform;
pub mod subscription;
pub mod telemetry;
pub mod tun;

pub use config::{CommittedConfig, ConfigActorPort, ConfigCandidate, PreparedConfig};
pub use core::CoreCommandBackend;
pub use error::{ActorFailure, ActorFailureKind, FailureMessage};
pub use lifecycle::CoreLifecycleCommandBackend;
pub use platform::PlatformCommandBackend;
pub use subscription::SubscriptionCommandBackend;
pub use telemetry::TelemetryCommandBackend;
pub use tun::TunCommandBackend;
