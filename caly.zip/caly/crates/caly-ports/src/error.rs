//! Shared bounded application error type used across actor ports and adapters.

use caly_domain::BoundedText;

/// Bounded safe application failure context.
pub type FailureMessage = BoundedText<512>;

/// Failure category returned across actor ownership boundaries.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ActorFailure {
    pub kind: ActorFailureKind,
    pub message: FailureMessage,
    pub suggested_action: FailureMessage,
}

impl core::fmt::Display for ActorFailure {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(formatter, "{} ({})", self.message, self.suggested_action)
    }
}

impl ActorFailure {
    /// Constructs bounded safe failure context.
    pub fn new(
        kind: ActorFailureKind,
        message: impl Into<String>,
        suggested_action: impl Into<String>,
    ) -> Result<Self, caly_domain::TextError> {
        Ok(Self {
            kind,
            message: FailureMessage::new(message)?,
            suggested_action: FailureMessage::new(suggested_action)?,
        })
    }

    /// Constructs an `Infrastructure` failure, UTF-8-safely clamping long or
    /// empty text to the bounded field. This is the single shared constructor
    /// for backends/application `failure` helpers, so the duplicated local
    /// helpers collapse onto one responsibility and never abort the daemon on
    /// an oversized dynamic message.
    pub fn infrastructure(message: &str, suggested_action: &str) -> Self {
        Self {
            kind: ActorFailureKind::Infrastructure,
            // `clamp_failure` guarantees the bound, so construction cannot fail.
            message: FailureMessage::from_nonempty_clamped(
                clamp_failure(message),
                "infrastructure failure",
            ),
            suggested_action: FailureMessage::from_nonempty_clamped(
                clamp_failure(suggested_action),
                "inspect configuration",
            ),
        }
    }
}

/// Clamps text to the failure-message byte bound without splitting UTF-8.
/// Returns a stable fallback for empty input.
fn clamp_failure(value: &str) -> String {
    const MAX: usize = 512;
    if value.is_empty() {
        return "operation failed".to_owned();
    }
    let mut out = String::new();
    for ch in value.chars() {
        if out.len() + ch.len_utf8() > MAX {
            break;
        }
        out.push(ch);
    }
    out
}

/// Stable failure category; concrete I/O errors remain in Infrastructure.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ActorFailureKind {
    InvalidCandidate,
    Unsupported,
    ResourceExhausted,
    DeadlineExceeded,
    Infrastructure,
    GenerationConflict,
    RecoveryRequired,
}
