//! Minimal bounded Mihomo REST control probe (HTTP transport + adapters).

use std::{
    fmt::Write as FmtWrite,
    io::{Read, Write},
    net::{TcpStream, ToSocketAddrs},
    time::{Duration, Instant},
};

use caly_domain::{BoundedText, CapabilitySet, NodeId};

use crate::ports::{
    ConnectionSummary, KernelControl, KernelFailure, KernelFailureKind, ProxyGroup,
};

/// Synchronous, bounded HTTP probe for Mihomo's local controller.
pub struct MihomoHttpControl {
    pub(crate) address: String,
    pub(crate) secret: Option<BoundedText<4_096>>,
}

impl MihomoHttpControl {
    /// Creates a controller for a host:port endpoint.
    pub fn new(address: String, secret: Option<BoundedText<4_096>>) -> Result<Self, KernelFailure> {
        if address.is_empty() {
            return Err(crate::common::failure_with_kind(
                KernelFailureKind::InvalidConfig,
                "Mihomo controller address is empty",
                "configure host:port",
            ));
        }
        Ok(Self { address, secret })
    }

    pub(crate) fn request(&self, path: &str, timeout: Duration) -> Result<Vec<u8>, KernelFailure> {
        self.request_method("GET", path, "", timeout)
    }

    /// Selects a named Mihomo proxy inside a named proxy group.
    pub fn select_proxy(
        &self,
        group: &str,
        node: &str,
        timeout: Duration,
    ) -> Result<(), KernelFailure> {
        let body = format!(
            "{{\"name\":\"{}\"}}",
            node.replace('\\', "\\\\").replace('"', "\\\"")
        );
        self.request_method("PUT", &format!("/proxies/{group}"), &body, timeout)
            .map(|_| ())
    }

    /// Closes all active Mihomo connections.
    pub fn close_all_connections(&self, timeout: Duration) -> Result<(), KernelFailure> {
        self.request_method("DELETE", "/connections", "", timeout)
            .map(|_| ())
    }

    /// Sets the Mihomo routing mode via `PATCH /configs`.
    ///
    /// `mode` is one of `rule`, `global`, or `direct`; it is validated against
    /// the Clash-compatible set before being sent.
    pub fn set_mode(&self, mode: &str, timeout: Duration) -> Result<(), KernelFailure> {
        if !matches!(mode, "rule" | "global" | "direct") {
            return Err(crate::common::failure_with_kind(
                KernelFailureKind::InvalidConfig,
                "unsupported Mihomo routing mode",
                "use rule, global, or direct",
            ));
        }
        let body = format!("{{\"mode\":\"{mode}\"}}");
        self.request_method("PATCH", "/configs", &body, timeout)
            .map(|_| ())
    }

    pub(crate) fn request_method(
        &self,
        method: &str,
        path: &str,
        body: &str,
        timeout: Duration,
    ) -> Result<Vec<u8>, KernelFailure> {
        let address = self.resolve_address()?;
        let mut stream = Self::connect(address, timeout)?;
        self.write_request(&mut stream, method, path, body)?;
        Self::read_response(&mut stream, timeout)
    }
}

impl MihomoHttpControl {
    /// Resolves the controller `host:port` into a socket address.
    pub(crate) fn resolve_address(&self) -> Result<std::net::SocketAddr, KernelFailure> {
        self.address
            .to_socket_addrs()
            .map_err(|error| {
                crate::common::failure_with_kind(
                    KernelFailureKind::ApiUnavailable,
                    &format!("cannot resolve Mihomo controller: {error}"),
                    "check the controller address",
                )
            })?
            .next()
            .ok_or_else(|| {
                crate::common::failure_with_kind(
                    KernelFailureKind::ApiUnavailable,
                    "Mihomo controller resolved to no address",
                    "check the controller address",
                )
            })
    }

    /// Connects to the controller with bounded read/write timeouts.
    pub(crate) fn connect(
        address: std::net::SocketAddr,
        timeout: Duration,
    ) -> Result<TcpStream, KernelFailure> {
        let stream = TcpStream::connect_timeout(&address, timeout).map_err(|error| {
            crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                &format!("cannot connect to Mihomo controller: {error}"),
                "start Mihomo and verify its controller",
            )
        })?;
        stream.set_read_timeout(Some(timeout)).map_err(|error| {
            crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                &format!("cannot set controller read timeout: {error}"),
                "inspect process permissions",
            )
        })?;
        stream.set_write_timeout(Some(timeout)).map_err(|error| {
            crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                &format!("cannot set controller write timeout: {error}"),
                "inspect process permissions",
            )
        })?;
        Ok(stream)
    }

    /// Writes an HTTP/1.1 request with optional bearer auth and JSON body.
    pub(crate) fn write_request(
        &self,
        stream: &mut TcpStream,
        method: &str,
        path: &str,
        body: &str,
    ) -> Result<(), KernelFailure> {
        let mut request = format!(
            "{method} {path} HTTP/1.1\r\nHost: {}\r\nConnection: close\r\n",
            self.address
        );
        if let Some(secret) = &self.secret {
            let _ = writeln!(request, "Authorization: Bearer {}\r", secret.as_str());
        }
        if !body.is_empty() {
            let _ = writeln!(request, "Content-Type: application/json\r");
            let _ = writeln!(request, "Content-Length: {}\r", body.len());
        }
        request.push_str("\r\n");
        request.push_str(body);
        stream.write_all(request.as_bytes()).map_err(|error| {
            crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                &format!("cannot write Mihomo request: {error}"),
                "inspect controller permissions",
            )
        })
    }

    /// Reads a bounded response and rejects non-2xx status lines.
    pub(crate) fn read_response(
        stream: &mut TcpStream,
        _timeout: Duration,
    ) -> Result<Vec<u8>, KernelFailure> {
        let mut body = Vec::new();
        // A 267-node subscription yields a ~100 KB `/proxies` document; the
        // old 64 KB cap truncated it into invalid JSON. 32 MB matches the
        // subscription body ceiling while still bounding a hostile kernel.
        stream
            .take(32 * 1_024 * 1_024)
            .read_to_end(&mut body)
            .map_err(|error| {
                crate::common::failure_with_kind(
                    KernelFailureKind::ApiUnavailable,
                    &format!("cannot read Mihomo response: {error}"),
                    "inspect Mihomo controller health",
                )
            })?;
        let success = body.starts_with(b"HTTP/1.1 2") || body.starts_with(b"HTTP/1.0 2");
        if !success {
            return Err(crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                "Mihomo controller returned a non-success response",
                "inspect Mihomo API configuration",
            ));
        }
        Ok(body)
    }
}

impl KernelControl for MihomoHttpControl {
    fn capabilities(&self) -> CapabilitySet {
        mihomo_capabilities()
    }

    fn wait_ready(&mut self, timeout: Duration) -> Result<(), KernelFailure> {
        let deadline = Instant::now() + timeout;
        loop {
            match self.health_check(Duration::from_millis(100)) {
                Ok(()) => return Ok(()),
                Err(error) if Instant::now() < deadline => {
                    let _ = error;
                    std::thread::sleep(Duration::from_millis(20));
                }
                Err(error) => return Err(error),
            }
        }
    }

    fn select_proxy(&mut self, _node: NodeId, _timeout: Duration) -> Result<(), KernelFailure> {
        Err(crate::common::failure_with_kind(
            KernelFailureKind::Unsupported,
            "Mihomo proxy selection is not connected",
            "use the application actor adapter",
        ))
    }

    fn health_check(&mut self, timeout: Duration) -> Result<(), KernelFailure> {
        self.request("/version", timeout).map(|_| ())
    }

    fn proxy_groups(&mut self, timeout: Duration) -> Result<Vec<ProxyGroup>, KernelFailure> {
        self.list_proxy_groups(timeout)
    }

    fn proxy_names(&mut self, timeout: Duration) -> Result<Vec<String>, KernelFailure> {
        self.list_proxy_names(timeout)
    }

    fn connections(&mut self, timeout: Duration) -> Result<ConnectionSummary, KernelFailure> {
        self.connection_summary(timeout)
    }

    fn traffic(&mut self, timeout: Duration) -> Result<(u64, u64), KernelFailure> {
        self.traffic_bytes(timeout)
    }

    fn test_delay(&mut self, name: &str, timeout: Duration) -> Result<Option<u32>, KernelFailure> {
        self.probe_delay(name, crate::ports::DEFAULT_DELAY_URL, timeout)
    }

    fn test_delay_url(
        &mut self,
        name: &str,
        url: &str,
        timeout: Duration,
    ) -> Result<Option<u32>, KernelFailure> {
        self.probe_delay(name, url, timeout)
    }
}

/// Parses the JSON body from an HTTP response (strips headers at the first
/// blank line, decodes a chunked transfer body, then parses the remainder).
pub(crate) fn response_json(body: &[u8]) -> Result<serde_json::Value, KernelFailure> {
    let text = core::str::from_utf8(body).map_err(|_| {
        crate::common::failure_with_kind(
            KernelFailureKind::DecodeRejected,
            "Mihomo response is not UTF-8",
            "inspect controller output",
        )
    })?;
    let json_text = match text.split_once("\r\n\r\n") {
        Some((headers, body)) => {
            if headers
                .to_ascii_lowercase()
                .contains("transfer-encoding: chunked")
            {
                decode_chunked_body(body.as_bytes()).map_err(|()| {
                    crate::common::failure_with_kind(
                        KernelFailureKind::DecodeRejected,
                        "Mihomo response uses an invalid chunked encoding",
                        "inspect controller output",
                    )
                })?
            } else {
                body.to_owned()
            }
        }
        None => text.to_owned(),
    };
    serde_json::from_str(&json_text).map_err(|_| {
        crate::common::failure_with_kind(
            KernelFailureKind::DecodeRejected,
            "Mihomo API returned invalid JSON",
            "inspect controller output",
        )
    })
}

/// Decodes an HTTP/1.1 chunked transfer body (hex size lines + data blocks).
fn decode_chunked_body(body: &[u8]) -> Result<String, ()> {
    let mut decoded = Vec::new();
    let mut rest = body;
    loop {
        let line_end = rest.windows(2).position(|pair| pair == b"\r\n").ok_or(())?;
        let size_line = core::str::from_utf8(&rest[..line_end]).map_err(|_| ())?;
        let size = usize::from_str_radix(size_line.trim().split(';').next().unwrap_or(""), 16)
            .map_err(|_| ())?;
        rest = &rest[line_end + 2..];
        if size == 0 {
            return String::from_utf8(decoded).map_err(|_| ());
        }
        if rest.len() < size + 2 {
            return Err(());
        }
        decoded.extend_from_slice(&rest[..size]);
        rest = &rest[size + 2..];
    }
}

/// Mihomo's Clash-compatible API supports proxy groups, selection, connections,
/// traffic, rules and URL-testing. Reflect that as a truthful capability set.
pub(crate) fn mihomo_capabilities() -> CapabilitySet {
    use caly_domain::{
        BoundedVec, Capability, CapabilityStatus, ConfiguredSupport, RuntimeAvailability,
    };
    let supported = |capability| {
        CapabilityStatus::new(
            capability,
            ConfiguredSupport::Supported,
            RuntimeAvailability::NotRequired,
            None,
        )
    };
    let statuses = vec![
        supported(Capability::DnsConfiguration),
        supported(Capability::RuntimeModeSwitch),
        supported(Capability::ProxyGroups),
        supported(Capability::ProxySelection),
        supported(Capability::Connections),
        supported(Capability::ConnectionClose),
        supported(Capability::Traffic),
        supported(Capability::UrlTest),
    ];
    let values = BoundedVec::try_from_vec(statuses).unwrap_or_else(|_| std::process::abort());
    CapabilitySet::new(values).unwrap_or_else(|_| std::process::abort())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{Read, Write};
    use std::{net::TcpListener, thread};

    #[test]
    fn health_probe_accepts_bounded_success_response() -> Result<(), KernelFailure> {
        let listener = TcpListener::bind("127.0.0.1:0").map_err(|_| {
            crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                "test listener failed",
                "retry test",
            )
        })?;
        let address = listener.local_addr().map_err(|_| {
            crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                "test address failed",
                "retry test",
            )
        })?;
        let worker = thread::spawn(move || {
            if let Ok((mut stream, _)) = listener.accept() {
                let mut request = [0_u8; 512];
                let _ = stream.read(&mut request);
                let _ = stream.write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok");
            }
        });
        let mut control = MihomoHttpControl::new(address.to_string(), None)?;
        control.health_check(Duration::from_secs(1))?;
        worker.join().map_err(|_| {
            crate::common::failure_with_kind(
                KernelFailureKind::ApiUnavailable,
                "test worker failed",
                "retry test",
            )
        })?;
        Ok(())
    }
}
