//! Proxy-kernel infrastructure for Mihomo and sing-box.
//!
//! `SpawnSpecFactory` and `KernelControl` are deliberately separate. The
//! Application `CoreActor` owns the process tree returned by `caly-platform`.

#![forbid(unsafe_code)]

pub mod common;
pub mod mihomo;
pub mod ports;
pub mod sing_box;
pub mod telemetry;
pub mod validation;
