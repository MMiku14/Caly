//! sing-box-specific adapter boundary.

mod dns_render;
mod http;
mod registry;
mod runtime;

pub use http::SingBoxHttpControl;
pub use registry::SingBoxNodeRegistry;
pub use runtime::{SingBoxRuntime, SingBoxRuntimeEvent};

use std::path::{Path, PathBuf};

use caly_domain::{CoreKind, DnsSettings, TunConfig};
use caly_platform::process::{ProcessArgument, ProcessArguments, SpawnSpec};

use crate::ports::{KernelFailure, RenderedConfigRef, SpawnSpecFactory};

/// Builds bounded sing-box run/check process specifications.
#[derive(Clone, Debug)]
pub struct SingBoxSpawnSpecFactory {
    binary: PathBuf,
    working_directory: PathBuf,
}

impl SingBoxSpawnSpecFactory {
    pub fn new(binary: PathBuf, working_directory: PathBuf) -> Result<Self, KernelFailure> {
        if binary.as_os_str().is_empty() || working_directory.as_os_str().is_empty() {
            return Err(crate::common::config_failure(
                "sing-box binary and working directory must not be empty",
                "provide owned paths",
            ));
        }
        Ok(Self {
            binary,
            working_directory,
        })
    }

    /// Returns the configured sing-box binary path.
    pub fn binary(&self) -> &Path {
        &self.binary
    }
}

impl SpawnSpecFactory for SingBoxSpawnSpecFactory {
    fn core_kind(&self) -> CoreKind {
        CoreKind::SingBox
    }

    fn build_spawn_spec(&self, config: &RenderedConfigRef) -> Result<SpawnSpec, KernelFailure> {
        self.build(config, false)
    }

    fn build_validation_spec(
        &self,
        config: &RenderedConfigRef,
    ) -> Result<SpawnSpec, KernelFailure> {
        self.build(config, true)
    }
}

impl SingBoxSpawnSpecFactory {
    fn build(
        &self,
        config: &RenderedConfigRef,
        validation: bool,
    ) -> Result<SpawnSpec, KernelFailure> {
        let mut args = ProcessArguments::new();
        if validation {
            push(&mut args, "check")?;
        } else {
            push(&mut args, "run")?;
        }
        push(&mut args, "-c")?;
        push(&mut args, &config.path.display().to_string())?;
        Ok(SpawnSpec {
            executable: self.binary.clone(),
            arguments: args,
            working_directory: self.working_directory.clone(),
            kill_on_owner_drop: true,
        })
    }
}

/// Inbound sniffing options (domain recovery for bare-IP traffic).
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct SniffOptions {
    /// Render `sniff: true` on the mixed/transparent inbounds.
    pub enabled: bool,
    /// Render `sniff_override_destination: true` alongside it.
    pub override_destination: bool,
}

impl SniffOptions {
    /// The inbound JSON suffix for these options (empty when disabled).
    fn inbound_suffix(self) -> &'static str {
        if !self.enabled {
            ""
        } else if self.override_destination {
            ",\"sniff\":true,\"sniff_override_destination\":true"
        } else {
            ",\"sniff\":true"
        }
    }
}

/// Config-driven tuning for the subscription-less sing-box renderer. One
/// struct replaces a telescoping parameter list so new tuning (sniffing,
/// route rules, ...) no longer grows the signature.
#[derive(Clone, Debug)]
pub struct SingBoxBaseTuning {
    /// `experimental.clash_api.external_controller` (host:port).
    pub controller: String,
    /// Optional bounded DNS block rendered into the document.
    pub dns: Option<DnsSettings>,
    /// Clash API secret; `None` omits it, an empty string is rejected.
    pub secret: Option<String>,
    /// Kernel log level (trace|debug|info|warn|error).
    pub log_level: String,
    /// Mixed inbound port; 0 renders no inbound.
    pub mixed_port: u16,
    /// Bind the mixed inbound to LAN instead of loopback only.
    pub allow_lan: bool,
    /// LAN bind address when `allow_lan` is true (`"*"` = all interfaces).
    pub bind_address: String,
    /// Optional TUN inbound (stack/auto-route/strict-route).
    pub tun: Option<TunConfig>,
    /// Interface name for the TUN inbound.
    pub tun_interface: String,
    /// Transparent inbound port; 0 disables.
    pub transparent_port: u16,
    /// Use a tproxy inbound instead of redirect.
    pub transparent_tproxy: bool,
    /// Inbound sniffing options.
    pub sniff: SniffOptions,
    /// Pre-rendered `route.rules` JSON array; `None` omits the key.
    pub route_rules_json: Option<String>,
    /// Pre-rendered `route.rule_set` source array (remote geo rule-sets);
    /// `None` omits the key.
    pub rule_sets_json: Option<String>,
    /// Outbound tag for `route.final`.
    pub route_final: String,
    /// Add the built-in `block` outbound (required by REJECT rules).
    pub block_outbound: bool,
}

impl Default for SingBoxBaseTuning {
    fn default() -> Self {
        Self {
            controller: "127.0.0.1:9091".to_owned(),
            dns: None,
            secret: None,
            log_level: "error".to_owned(),
            mixed_port: 0,
            allow_lan: false,
            bind_address: "*".to_owned(),
            tun: None,
            tun_interface: String::new(),
            transparent_port: 0,
            transparent_tproxy: false,
            sniff: SniffOptions::default(),
            route_rules_json: None,
            rule_sets_json: None,
            route_final: "direct".to_owned(),
            block_outbound: false,
        }
    }
}

/// Minimal JSON config renderer for sing-box validation and lifecycle smoke.
#[derive(Default)]
pub struct SingBoxConfigRenderer;

impl SingBoxConfigRenderer {
    /// Renders a config from the full tuning struct: controller/DNS/secret,
    /// log level, the local mixed inbound, an optional transparent
    /// redirect/tproxy inbound, optional inbound sniffing, an optional TUN
    /// inbound, and config-driven `route.rules`/`route.final` (both
    /// pre-rendered by the shared rule renderer so this renderer stays free of
    /// rule semantics). This is the single rendering entry point; convenience
    /// variants were collapsed into it (convergence, 2026-08-06).
    pub fn render_tuned(&self, tuning: &SingBoxBaseTuning) -> Result<Vec<u8>, KernelFailure> {
        let (dns_block, route_extra) = dns_block_parts(tuning.dns.as_ref());
        let secret_field = secret_field(tuning.secret.as_deref());
        let level = sing_box_level(&tuning.log_level);
        let inbounds = render_inbounds(
            tuning.tun.as_ref(),
            &tuning.tun_interface,
            tuning.mixed_port,
            tuning.allow_lan,
            &tuning.bind_address,
            tuning.transparent_port,
            tuning.transparent_tproxy,
            tuning.sniff,
        );
        let block_outbound = if tuning.block_outbound {
            ",{\"type\":\"block\",\"tag\":\"block\"}"
        } else {
            ""
        };
        let rules_block = match &tuning.route_rules_json {
            Some(rules) if !rules.is_empty() => format!(",\"rules\":{rules}"),
            _ => String::new(),
        };
        let rule_set_block = match &tuning.rule_sets_json {
            Some(sources) if !sources.is_empty() => format!(",\"rule_set\":{sources}"),
            _ => String::new(),
        };
        let final_outbound = tuning.route_final.as_str();
        let controller = tuning.controller.as_str();
        let value = format!(
            "{{\"log\":{{\"level\":\"{level}\"}},\"inbounds\":{inbounds},\"outbounds\":[{{\"type\":\"direct\",\"tag\":\"direct\"}}{block_outbound}],\"route\":{{\"final\":\"{final_outbound}\"{rules_block}{rule_set_block}{route_extra}}}{dns_block},\"experimental\":{{\"clash_api\":{{\"external_controller\":\"{controller}\"{secret_field}}}}}}}",
        );
        Ok(value.into_bytes())
    }

    pub fn validate_bytes(&self, bytes: &[u8]) -> Result<(), KernelFailure> {
        serde_json::from_slice::<serde_json::Value>(bytes)
            .map(|_| ())
            .map_err(|_| {
                crate::common::config_failure(
                    "sing-box JSON config is invalid",
                    "regenerate the configuration",
                )
            })
    }
}

fn push(args: &mut ProcessArguments, value: &str) -> Result<(), KernelFailure> {
    let value = ProcessArgument::new(value.to_owned()).map_err(|_| {
        crate::common::config_failure("sing-box argument is too long", "shorten the path")
    })?;
    args.try_push(value).map_err(|_| {
        crate::common::config_failure("sing-box argument list is full", "reduce process arguments")
    })
}

/// Renders the `inbounds` JSON array. With a TUN config it emits a single tun
/// inbound (stack/auto-route/strict-route plus the required `address` so the
/// interface owns an IP); otherwise an empty array.
/// Renders bounded DNS settings as a sing-box `dns` JSON object fragment plus
/// the resolver tag the caller must wire into `route.default_domain_resolver`.
/// Exposed for renderers outside this crate (the subscription document).
pub fn render_dns_fragment(dns: &DnsSettings) -> (String, Option<String>) {
    let rendered = dns_render::render_dns_object(dns);
    (rendered.json, rendered.domain_resolver)
}

/// Renders the optional bounded DNS block and its `route` resolver wiring.
fn dns_block_parts(dns: Option<&DnsSettings>) -> (String, String) {
    match dns {
        Some(dns) => {
            let rendered = dns_render::render_dns_object(dns);
            let route_extra = match &rendered.domain_resolver {
                Some(tag) => format!(",\"default_domain_resolver\":\"{tag}\""),
                None => String::new(),
            };
            (format!(",\"dns\":{}", rendered.json), route_extra)
        }
        None => (String::new(), String::new()),
    }
}

/// Renders the optional Clash API `secret` field; empty values are omitted.
fn secret_field(secret: Option<&str>) -> String {
    match secret {
        Some("") | None => String::new(),
        Some(value) => format!(",\"secret\":\"{value}\""),
    }
}

/// Accepts the generic kernel levels; anything unknown falls back to error.
fn sing_box_level(level: &str) -> &'static str {
    match level {
        "trace" | "debug" | "info" | "warn" | "error" => match level {
            "trace" => "trace",
            "debug" => "debug",
            "info" => "info",
            "warn" => "warn",
            _ => "error",
        },
        _ => "error",
    }
}

fn render_inbounds(
    tun: Option<&TunConfig>,
    interface: &str,
    mixed_port: u16,
    allow_lan: bool,
    bind_address: &str,
    transparent_port: u16,
    transparent_tproxy: bool,
    sniff: SniffOptions,
) -> String {
    let sniff_suffix = sniff.inbound_suffix();
    let mut entries = Vec::new();
    if mixed_port != 0 {
        // allow-lan off pins loopback; on binds `bind_address` ("*" = all).
        let listen = if !allow_lan {
            "127.0.0.1"
        } else if bind_address == "*" || bind_address.is_empty() {
            "0.0.0.0"
        } else {
            bind_address
        };
        entries.push(format!(
            "{{\"type\":\"mixed\",\"tag\":\"caly-mixed-in\",\"listen\":\"{listen}\",\"listen_port\":{mixed_port}{sniff_suffix}}}"
        ));
    }
    if transparent_port != 0 {
        let kind = if transparent_tproxy {
            "tproxy"
        } else {
            "redirect"
        };
        entries.push(format!(
            "{{\"type\":\"{kind}\",\"tag\":\"caly-transparent-in\",\"listen\":\"0.0.0.0\",\"listen_port\":{transparent_port}{sniff_suffix}}}"
        ));
    }
    if let Some(tun) = tun {
        entries.push(format!(
            "{{\"type\":\"tun\",\"tag\":\"tun-in\",\"interface_name\":\"{interface}\",\"address\":[\"172.18.0.1/30\",\"fdfe:dcba:9876::1/126\"],\"mtu\":{},\"auto_route\":{},\"strict_route\":{},\"stack\":\"{}\"}}",
            tun.mtu(),
            tun.auto_route(),
            tun.strict_route(),
            tun.stack().label()
        ));
    }
    format!("[{}]", entries.join(","))
}

#[cfg(test)]
mod config_tests;
