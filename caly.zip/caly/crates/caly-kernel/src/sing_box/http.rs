//! sing-box Clash-compatible API probe.
//!
//! sing-box ships an optional Clash-compatible controller (`external_controller`
//! in the `experimental` block). Its REST surface is a subset of Mihomo's, so we
//! delegate to the shared `MihomoHttpControl` transport and adapters for proxy
//! groups, connections, traffic and selection. A shared controller secret is
//! carried through to authenticate every request.

use std::time::Duration;

use crate::{
    mihomo::MihomoHttpControl,
    ports::{ConnectionSummary, KernelControl, KernelFailure, ProxyGroup},
};
use caly_domain::{BoundedText, CapabilitySet, NodeId};

/// sing-box's Clash-compatible API is partial: groups and proxy listing work,
/// but connection/traffic streaming and full URL-test semantics may be limited.
fn sing_box_capabilities() -> CapabilitySet {
    use caly_domain::{
        BoundedVec, Capability, CapabilityStatus, ConfiguredSupport, RuntimeAvailability,
    };
    let supported = |capability| {
        CapabilityStatus::new(
            capability,
            ConfiguredSupport::Supported,
            RuntimeAvailability::NotRequired,
            None,
        )
    };
    let partial = |capability| {
        CapabilityStatus::new(
            capability,
            ConfiguredSupport::Partial,
            RuntimeAvailability::NotRequired,
            None,
        )
    };
    let statuses = vec![
        supported(Capability::DnsConfiguration),
        supported(Capability::RuntimeModeSwitch),
        supported(Capability::ProxyGroups),
        supported(Capability::ProxySelection),
        supported(Capability::UrlTest),
        supported(Capability::ConnectionClose),
        partial(Capability::Connections),
        partial(Capability::Traffic),
    ];
    let values = BoundedVec::try_from_vec(statuses).unwrap_or_else(|_| std::process::abort());
    CapabilitySet::new(values).unwrap_or_else(|_| std::process::abort())
}

/// sing-box's optional Clash-compatible controller.
pub struct SingBoxHttpControl {
    inner: MihomoHttpControl,
}

impl SingBoxHttpControl {
    /// Creates a controller for a host:port endpoint with an optional shared
    /// auth secret.
    pub fn new(address: String, secret: Option<BoundedText<4_096>>) -> Result<Self, KernelFailure> {
        Ok(Self {
            inner: MihomoHttpControl::new(address, secret)?,
        })
    }

    /// Selects a named sing-box proxy inside a named proxy group (Clash API).
    pub fn select_proxy(
        &self,
        group: &str,
        node: &str,
        timeout: Duration,
    ) -> Result<(), KernelFailure> {
        self.inner.select_proxy(group, node, timeout)
    }

    /// Closes all active sing-box connections (Clash API).
    pub fn close_all_connections(&self, timeout: Duration) -> Result<(), KernelFailure> {
        self.inner.close_all_connections(timeout)
    }

    /// Sets the sing-box routing mode via `PATCH /configs`.
    ///
    /// sing-box exposes mode switching only when the rendered config contains
    /// the `clash_mode` route rules (`Global` → `GLOBAL`, `Direct` → `direct`);
    /// otherwise `mode-list` is `["rule"]` and the request is a no-op.
    pub fn set_mode(&self, mode: &str, timeout: Duration) -> Result<(), KernelFailure> {
        self.inner.set_mode(mode, timeout)
    }

    /// Tests the latency of a named proxy via `GET /proxies/{name}/delay`
    /// (same endpoint and semantics as Mihomo's Clash API).
    pub fn probe_delay(
        &self,
        name: &str,
        url: &str,
        timeout: Duration,
    ) -> Result<Option<u32>, KernelFailure> {
        self.inner.probe_delay(name, url, timeout)
    }
}

impl KernelControl for SingBoxHttpControl {
    fn capabilities(&self) -> CapabilitySet {
        sing_box_capabilities()
    }
    fn wait_ready(&mut self, timeout: Duration) -> Result<(), KernelFailure> {
        self.inner.wait_ready(timeout)
    }
    fn health_check(&mut self, timeout: Duration) -> Result<(), KernelFailure> {
        self.inner.health_check(timeout)
    }
    fn select_proxy(&mut self, _node: NodeId, _timeout: Duration) -> Result<(), KernelFailure> {
        Err(KernelFailure {
            kind: crate::ports::KernelFailureKind::Unsupported,
            message: BoundedText::new("sing-box proxy selection requires group mapping".to_owned())
                .unwrap_or_else(|_| std::process::abort()),
            suggested_action: BoundedText::new(
                "select via the application actor with group mapping".to_owned(),
            )
            .unwrap_or_else(|_| std::process::abort()),
            platform: None,
        })
    }
    fn proxy_groups(&mut self, timeout: Duration) -> Result<Vec<ProxyGroup>, KernelFailure> {
        self.inner.list_proxy_groups(timeout)
    }

    fn proxy_names(&mut self, timeout: Duration) -> Result<Vec<String>, KernelFailure> {
        self.inner.list_proxy_names(timeout)
    }
    fn connections(&mut self, timeout: Duration) -> Result<ConnectionSummary, KernelFailure> {
        self.inner.connection_summary(timeout)
    }
    fn traffic(&mut self, timeout: Duration) -> Result<(u64, u64), KernelFailure> {
        self.inner.traffic_bytes(timeout)
    }

    fn test_delay(&mut self, name: &str, timeout: Duration) -> Result<Option<u32>, KernelFailure> {
        self.probe_delay(name, crate::ports::DEFAULT_DELAY_URL, timeout)
    }

    fn test_delay_url(
        &mut self,
        name: &str,
        url: &str,
        timeout: Duration,
    ) -> Result<Option<u32>, KernelFailure> {
        self.probe_delay(name, url, timeout)
    }
}
