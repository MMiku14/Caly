//! Real-kernel E2E for Mihomo's rich Clash API (proxies/connections/traffic).

use std::{
    io::{Read, Write},
    net::TcpStream,
    path::PathBuf,
    process::Command,
    time::Duration,
};

use caly_kernel::{
    mihomo::{
        MihomoConfigRenderer, MihomoConfigSettings, MihomoHttpControl, MihomoRuntime,
        MihomoSpawnSpecFactory,
    },
    ports::RenderedConfigRef,
};
use caly_platform::{fs::LinuxAtomicFileBackend, process::LinuxProcessSpawner};

fn binary() -> PathBuf {
    if let Some(value) = std::env::var_os("CALY_MIHOMO_BIN") {
        return PathBuf::from(value);
    }
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../vendor/bin/mihomo")
}

fn available() -> bool {
    let binary = binary();
    if !binary.is_file() {
        eprintln!("skipping: no mihomo binary at {}", binary.display());
        return false;
    }
    matches!(Command::new(&binary).arg("-v").output(), Ok(output) if output.status.success())
}

fn test_settings() -> (MihomoConfigSettings, String) {
    let base = 22_000 + (std::process::id() % 4_000) as u16;
    let settings = MihomoConfigSettings {
        mixed_port: base,
        external_controller_port: base + 1,
        allow_lan: false,
        ..MihomoConfigSettings::default()
    };
    (settings, format!("127.0.0.1:{}", base + 1))
}

fn working_directory(tag: &str) -> PathBuf {
    caly_platform::paths::test_helpers::unique_path_under("caly-e2e-mihomo-api", tag)
}

type E2eResult = Result<(), Box<dyn std::error::Error>>;

fn e2e_error(value: impl std::fmt::Debug) -> Box<dyn std::error::Error> {
    Box::<dyn std::error::Error>::from(format!("{value:?}"))
}

fn fetch_version(controller_port: u16) -> Option<String> {
    let mut stream = TcpStream::connect(("127.0.0.1", controller_port)).ok()?;
    stream.set_read_timeout(Some(Duration::from_secs(2))).ok()?;
    stream
        .write_all(
            format!("GET /version HTTP/1.1\r\nHost: 127.0.0.1:{controller_port}\r\nConnection: close\r\n\r\n")
                .as_bytes(),
        )
        .ok()?;
    let mut body = String::new();
    stream.read_to_string(&mut body).ok()?;
    Some(body)
}

#[test]
fn mihomo_real_binary_exposes_rich_clash_api() -> E2eResult {
    use caly_kernel::ports::KernelControl;
    if !available() {
        return Ok(());
    }
    let (settings, controller) = test_settings();
    let controller_port = settings.external_controller_port;
    let dir = working_directory("api");
    let config = dir.join("config.yaml");
    std::fs::create_dir_all(&dir)?;
    MihomoConfigRenderer
        .publish(&mut LinuxAtomicFileBackend, config.clone(), 1, &settings)
        .map_err(e2e_error)?;
    let factory = MihomoSpawnSpecFactory::new(binary(), dir.clone()).map_err(e2e_error)?;
    let control = MihomoHttpControl::new(controller.clone(), None).map_err(e2e_error)?;
    let mut runtime = MihomoRuntime::new(factory, LinuxProcessSpawner, control);
    let rendered = RenderedConfigRef {
        generation: 1,
        path: config.clone(),
    };
    start_and_verify(&mut runtime, &rendered, controller_port, "api-start")?;

    let mut api = MihomoHttpControl::new(controller, None).map_err(e2e_error)?;
    // capabilities reflect the Clash API surface.
    let caps = api.capabilities();
    assert!(caps.is_usable(caly_domain::Capability::Connections));
    assert!(caps.is_usable(caly_domain::Capability::Traffic));

    // /proxies returns the default groups even with no nodes configured.
    let groups = api
        .proxy_groups(Duration::from_secs(2))
        .map_err(e2e_error)?;
    assert!(
        groups
            .iter()
            .any(|g| g.name == "GLOBAL" || g.name == "DIRECT")
    );

    // /connections and /traffic respond with a valid summary.
    let connections = api.connections(Duration::from_secs(2)).map_err(e2e_error)?;
    assert_eq!(connections.active, 0);
    let traffic = api.traffic(Duration::from_secs(2)).map_err(e2e_error)?;
    let _ = (traffic.0, traffic.1);

    stop_and_verify(&mut runtime, controller_port)?;
    let _ = std::fs::remove_dir_all(&dir);
    Ok(())
}

type TestRuntime = MihomoRuntime<LinuxProcessSpawner, MihomoHttpControl>;

fn start_and_verify(
    runtime: &mut TestRuntime,
    rendered: &RenderedConfigRef,
    controller_port: u16,
    _phase: &str,
) -> E2eResult {
    runtime
        .start(rendered, 1, Duration::from_secs(20))
        .map_err(e2e_error)?;
    let version =
        fetch_version(controller_port).ok_or("version endpoint unreachable after start")?;
    assert!(
        version.contains("\"version\""),
        "unexpected /version: {version}"
    );
    runtime
        .health_check(Duration::from_secs(3))
        .map_err(e2e_error)
}

fn stop_and_verify(runtime: &mut TestRuntime, controller_port: u16) -> E2eResult {
    let exit = runtime.stop(Duration::from_secs(5)).map_err(e2e_error)?;
    assert!(
        exit.code.is_some() || exit.signalled,
        "unexpected stop: {exit:?}"
    );
    assert!(
        fetch_version(controller_port).is_none(),
        "controller still reachable after stop"
    );
    Ok(())
}
