//! Synchronous thin client over a Linux Unix-domain socket.
//!
//! The transport is length-prefixed compact JSON (see `framing`): one
//! synchronous request/response exchange per frame on the main connection,
//! plus a dedicated connection for the continuous watch stream. No gRPC or
//! protobuf machinery is involved; the wire is directly inspectable.

use std::{path::PathBuf, sync::Arc};

use tokio::{net::UnixStream, runtime::Runtime};

use super::{ClientContract, ClientError};
use crate::{
    framing::{FrameError, decode_json, encode_json, read_frame, write_frame},
    protocol::v2::{
        CancelOperationRequest, CancelOperationResponse, DecodeLimits, ExecuteRequest,
        ExecuteResponse, GetOperationStatusRequest, HandshakeRequest, HandshakeResponse,
        WatchEventsRequest, WatchResponse, WireId, WireOperationStatus, WirePresentationSnapshot,
    },
    wire_frames::{ClientFrame, JsonRequest, JsonResponse, ServerFrame, WireError, WireErrorCode},
};

/// Thin JSON-framed UDS client with one runtime and one session-scoped socket.
pub struct UdsClient {
    runtime: Runtime,
    stream: UnixStream,
    socket: Arc<PathBuf>,
    session_token: Option<WireId>,
    message_ceiling: usize,
}

impl UdsClient {
    /// Connects to an owner-only Linux UDS.
    pub fn connect(socket: PathBuf) -> Result<Self, ClientError> {
        let runtime = Runtime::new().map_err(|_| ClientError::TransportUnavailable)?;
        let socket_ref = Arc::new(socket);
        let stream = runtime
            .block_on(UnixStream::connect((*socket_ref).clone()))
            .map_err(|_| ClientError::TransportUnavailable)?;
        // Transport message ceiling derived from the negotiated decode limits.
        let ceiling = DecodeLimits::v2_default().max_message_bytes;
        Ok(Self {
            runtime,
            stream,
            socket: socket_ref,
            session_token: None,
            message_ceiling: ceiling,
        })
    }

    /// Returns the configured socket path.
    pub fn socket(&self) -> &PathBuf {
        &self.socket
    }

    /// Sends one request frame and reads one response frame.
    fn exchange(&mut self, request: JsonRequest) -> Result<JsonResponse, ClientError> {
        let frame = ClientFrame {
            session: self.session_token.map(hex_token),
            request,
        };
        let payload = encode_json(&frame).map_err(decode_rejected)?;
        self.runtime
            .block_on(write_frame(&mut self.stream, &payload))
            .map_err(map_frame)?;
        let payload = self
            .runtime
            .block_on(read_frame(&mut self.stream, self.message_ceiling))
            .map_err(map_frame)?;
        let server = decode_json::<ServerFrame>(&payload).map_err(decode_rejected)?;
        match server {
            ServerFrame::Result(response) => Ok(*response),
            ServerFrame::Error(error) => Err(map_wire_error(error)),
        }
    }
}

impl ClientContract for UdsClient {
    type Watch = UdsWatchIter;

    fn handshake(&mut self, request: HandshakeRequest) -> Result<HandshakeResponse, ClientError> {
        let response = self.exchange(JsonRequest::Handshake(request))?;
        match response {
            JsonResponse::Handshake(value) => {
                self.session_token = Some(value.session_token);
                Ok(value)
            }
            other => Err(unexpected("handshake", other)),
        }
    }

    fn execute(&mut self, request: ExecuteRequest) -> Result<ExecuteResponse, ClientError> {
        let response = self.exchange(JsonRequest::Execute(request))?;
        match response {
            JsonResponse::Execute(value) => Ok(value),
            other => Err(unexpected("execute", other)),
        }
    }

    fn cancel(
        &mut self,
        request: CancelOperationRequest,
    ) -> Result<CancelOperationResponse, ClientError> {
        let response = self.exchange(JsonRequest::CancelOperation(request))?;
        match response {
            JsonResponse::CancelOperation(value) => Ok(value),
            other => Err(unexpected("cancel", other)),
        }
    }

    fn operation_status(
        &mut self,
        request: GetOperationStatusRequest,
    ) -> Result<WireOperationStatus, ClientError> {
        let response = self.exchange(JsonRequest::GetOperationStatus(request))?;
        match response {
            JsonResponse::GetOperationStatus(value) => Ok(value),
            other => Err(unexpected("operation status", other)),
        }
    }

    fn snapshot(&mut self) -> Result<WirePresentationSnapshot, ClientError> {
        let response = self.exchange(JsonRequest::GetSnapshot(
            crate::protocol::v2::GetSnapshotRequest,
        ))?;
        match response {
            JsonResponse::GetSnapshot(value) => Ok(value),
            other => Err(unexpected("snapshot", other)),
        }
    }

    fn watch(&mut self, request: WatchEventsRequest) -> Result<Self::Watch, ClientError> {
        // A watch is a continuous stream: it owns a dedicated connection so
        // the request/response connection stays available for later calls.
        let mut stream = self
            .runtime
            .block_on(UnixStream::connect((*self.socket).clone()))
            .map_err(|_| ClientError::TransportUnavailable)?;
        let frame = ClientFrame {
            session: self.session_token.map(hex_token),
            request: JsonRequest::WatchEvents(request),
        };
        let payload = encode_json(&frame).map_err(decode_rejected)?;
        self.runtime
            .block_on(write_frame(&mut stream, &payload))
            .map_err(map_frame)?;
        Ok(UdsWatchIter {
            handle: self.runtime.handle().clone(),
            stream,
            message_ceiling: self.message_ceiling,
            finished: false,
        })
    }
}

/// Lazy incremental watch iterator over the daemon's continuous live stream.
pub struct UdsWatchIter {
    handle: tokio::runtime::Handle,
    stream: UnixStream,
    message_ceiling: usize,
    finished: bool,
}

impl Iterator for UdsWatchIter {
    type Item = Result<WatchResponse, ClientError>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.finished {
            return None;
        }
        let payload = self
            .handle
            .block_on(read_frame(&mut self.stream, self.message_ceiling));
        let payload = match payload {
            Ok(payload) => payload,
            Err(FrameError::Closed) => {
                self.finished = true;
                return None;
            }
            Err(error) => {
                self.finished = true;
                return Some(Err(map_frame(error)));
            }
        };
        let server = match decode_json::<ServerFrame>(&payload) {
            Ok(server) => server,
            Err(error) => {
                self.finished = true;
                return Some(Err(decode_rejected(error)));
            }
        };
        match server {
            ServerFrame::Result(boxed) => match *boxed {
                JsonResponse::WatchEvent(value) => Some(Ok(value)),
                other => {
                    self.finished = true;
                    Some(Err(ClientError::DecodeRejected {
                        reason: format!("watch stream received an unexpected frame: {other:?}"),
                        suggested_action: "the daemon and client protocol versions may differ"
                            .to_owned(),
                    }))
                }
            },
            ServerFrame::Error(error) => {
                self.finished = true;
                Some(Err(map_wire_error(error)))
            }
        }
    }
}

fn hex_token(token: WireId) -> String {
    caly_domain::to_hex(token)
}

fn map_frame(error: FrameError) -> ClientError {
    match error {
        FrameError::Closed | FrameError::Io => ClientError::TransportUnavailable,
        FrameError::Oversized { .. } => ClientError::ResourceExhausted,
    }
}

fn map_wire_error(error: WireError) -> ClientError {
    match WireErrorCode::from_code(error.code) {
        Some(WireErrorCode::Unauthenticated | WireErrorCode::HandshakeRequired) => {
            ClientError::AuthenticationRejected
        }
        Some(WireErrorCode::ResourceExhausted) => ClientError::ResourceExhausted,
        Some(WireErrorCode::IncompatibleVersion) => ClientError::IncompatibleVersion,
        Some(WireErrorCode::PermissionDenied | WireErrorCode::ApplicationUnavailable) => {
            ClientError::TransportUnavailable
        }
        Some(WireErrorCode::InvalidArgument) | None => ClientError::DecodeRejected {
            reason: error.message,
            suggested_action: error.suggested_action.unwrap_or_else(|| {
                "upgrade the client or inspect daemon protocol diagnostics".to_owned()
            }),
        },
    }
}

fn decode_rejected(error: serde_json::Error) -> ClientError {
    ClientError::DecodeRejected {
        reason: format!("wire decode failed: {error}"),
        suggested_action: "upgrade the client or inspect daemon protocol diagnostics".to_owned(),
    }
}

fn unexpected(method: &str, response: JsonResponse) -> ClientError {
    ClientError::DecodeRejected {
        reason: format!("{method} received an unexpected response frame: {response:?}"),
        suggested_action: "the daemon and client protocol versions may differ".to_owned(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn wire_error_codes_map_to_client_errors() {
        let unauthenticated = map_wire_error(WireError {
            code: WireErrorCode::Unauthenticated.code(),
            message: "token rejected".to_owned(),
            suggested_action: None,
        });
        assert_eq!(unauthenticated, ClientError::AuthenticationRejected);
        let exhausted = map_wire_error(WireError {
            code: WireErrorCode::ResourceExhausted.code(),
            message: "full".to_owned(),
            suggested_action: None,
        });
        assert_eq!(exhausted, ClientError::ResourceExhausted);
        let version = map_wire_error(WireError {
            code: WireErrorCode::IncompatibleVersion.code(),
            message: "old".to_owned(),
            suggested_action: None,
        });
        assert_eq!(version, ClientError::IncompatibleVersion);
        let invalid = map_wire_error(WireError {
            code: WireErrorCode::InvalidArgument.code(),
            message: "bad command".to_owned(),
            suggested_action: Some("fix the command".to_owned()),
        });
        assert!(matches!(invalid, ClientError::DecodeRejected { .. }));
        let unknown = map_wire_error(WireError {
            code: 999,
            message: "?".to_owned(),
            suggested_action: None,
        });
        assert!(matches!(unknown, ClientError::DecodeRejected { .. }));
    }
}
