//! Layered YAML loading: base, active profile, then lexical fragments.

use std::{
    fs, io,
    path::{Path, PathBuf},
};

use caly_domain::BoundedText;
use caly_platform::paths::SafeName;
use serde_norway::Value;

use crate::{
    loader::{LoaderBudget, LoaderBudgetError, LoaderLimits},
    schema::{AppConfig, ConfigError, validate},
};

use super::file::{ConfigFileError, read_bounded_regular_file};

/// Resolved layered configuration locations.
pub struct LayeredConfigPaths {
    root: PathBuf,
    active_profile: Option<SafeName>,
}

impl LayeredConfigPaths {
    pub fn new(root: PathBuf, active_profile: Option<SafeName>) -> Self {
        Self {
            root,
            active_profile,
        }
    }

    fn base(&self) -> PathBuf {
        self.root.join("config.yaml")
    }
    fn profile(&self) -> Option<PathBuf> {
        self.active_profile.as_ref().map(|name| {
            self.root
                .join("profiles")
                .join(format!("{}.yaml", name.as_str()))
        })
    }
    fn fragments(&self) -> PathBuf {
        self.root.join("config.d")
    }
}

/// Layered load failure retaining the failing boundary.
#[derive(Debug)]
pub enum LayeredConfigError {
    File(ConfigFileError),
    FragmentDirectory(io::Error),
    FragmentEntry(io::Error),
    TooManyFragments { limit: usize },
    Budget(LoaderBudgetError),
    Yaml(BoundedText<512>),
    YamlDetailsUnavailable,
    MergeTypeConflict { depth: usize },
    Config(ConfigError),
}

/// Loads and merges all configured layers without following symlinks.
pub fn load_layered_yaml(
    paths: &LayeredConfigPaths,
    limits: LoaderLimits,
) -> Result<AppConfig, LayeredConfigError> {
    let mut budget = LoaderBudget::new(limits);
    let mut merged = load_value(&paths.base(), &mut budget, limits)?;
    if let Some(profile) = paths.profile() {
        let value = load_value(&profile, &mut budget, limits)?;
        deep_merge(&mut merged, value, 0, limits.max_merge_depth)?;
    }
    for fragment in fragment_paths(&paths.fragments(), limits.max_fragment_files)? {
        let value = load_value(&fragment, &mut budget, limits)?;
        deep_merge(&mut merged, value, 0, limits.max_merge_depth)?;
    }
    let config: AppConfig =
        serde_norway::from_value(merged).map_err(|error| yaml_error(error.to_string()))?;
    validate(&config).map_err(LayeredConfigError::Config)?;
    Ok(config)
}

fn load_value(
    path: &Path,
    budget: &mut LoaderBudget,
    limits: LoaderLimits,
) -> Result<Value, LayeredConfigError> {
    let bytes = read_bounded_regular_file(path, limits.max_total_bytes)
        .map_err(LayeredConfigError::File)?;
    budget
        .charge_file(bytes.len())
        .map_err(LayeredConfigError::Budget)?;
    let source = core::str::from_utf8(&bytes)
        .map_err(|_| yaml_error("configuration is not UTF-8".to_owned()))?;
    serde_norway::from_str(source).map_err(|error| yaml_error(error.to_string()))
}

fn fragment_paths(directory: &Path, limit: usize) -> Result<Vec<PathBuf>, LayeredConfigError> {
    if !directory.exists() {
        return Ok(Vec::new());
    }
    let mut paths = Vec::new();
    let entries = fs::read_dir(directory).map_err(LayeredConfigError::FragmentDirectory)?;
    for entry in entries {
        let entry = entry.map_err(LayeredConfigError::FragmentEntry)?;
        let path = entry.path();
        if matches!(
            path.extension().and_then(|value| value.to_str()),
            Some("yaml" | "yml")
        ) {
            paths.push(path);
            if paths.len() > limit {
                return Err(LayeredConfigError::TooManyFragments { limit });
            }
        }
    }
    paths.sort();
    Ok(paths)
}

fn deep_merge(
    base: &mut Value,
    overlay: Value,
    depth: usize,
    max_depth: usize,
) -> Result<(), LayeredConfigError> {
    if depth > max_depth {
        return Err(LayeredConfigError::Budget(LoaderBudgetError::MergeTooDeep));
    }
    match (base, overlay) {
        (Value::Mapping(base), Value::Mapping(overlay)) => {
            for (key, value) in overlay {
                if let Some(existing) = base.get_mut(&key) {
                    deep_merge(existing, value, depth + 1, max_depth)?;
                } else {
                    base.insert(key, value);
                }
            }
            Ok(())
        }
        (Value::Mapping(_), _) | (_, Value::Mapping(_)) => {
            Err(LayeredConfigError::MergeTypeConflict { depth })
        }
        (base, overlay) => {
            *base = overlay;
            Ok(())
        }
    }
}

fn yaml_error(message: String) -> LayeredConfigError {
    match BoundedText::new(message) {
        Ok(message) => LayeredConfigError::Yaml(message),
        Err(_) => LayeredConfigError::YamlDetailsUnavailable,
    }
}
