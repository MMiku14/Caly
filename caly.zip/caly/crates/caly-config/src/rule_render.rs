//! Config-driven routing rules rendered as sing-box `route.rules`.
//!
//! Mihomo consumes Clash-format rule lines directly; sing-box needs structured
//! route rule objects instead. This module is the single mapping between the
//! domain `RoutingRule` model and sing-box route semantics, shared by the
//! subscription document renderer and the subscription-less base renderer.

use caly_domain::{RoutingRule, RuleMatch, RulePolicy};
use serde_json::Value;
use std::collections::BTreeSet;

/// Rendered routing rules ready to embed into a sing-box document.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SingBoxRules {
    /// Pre-rendered JSON array of route rule objects; `None` when no rule is
    /// representable (the document should omit the `rules` key).
    pub rules_json: Option<String>,
    /// Pre-rendered JSON array of `route.rule_set` sources (remote geo
    /// rule-sets referenced by GEOIP rules); `None` when not needed.
    pub rule_sets_json: Option<String>,
    /// The outbound tag for `route.final` (derived from the MATCH rule, or a
    /// sensible default when absent).
    pub final_outbound: String,
    /// Whether the document must add the built-in `block` outbound (any rule
    /// steers to REJECT).
    pub block_outbound: bool,
    /// Rules skipped because their policy has no outbound in the document.
    pub skipped: usize,
}

/// Maps the config rules onto sing-box route semantics.
///
/// `proxy_representable` states whether the document carries proxy outbounds
/// (a subscription renders a `PROXY` selector; the subscription-less base
/// config only carries `direct`). Unrepresentable proxy/group policies are
/// skipped and counted instead of fabricating outbounds.
pub fn render_sing_box_rules(rules: &[RoutingRule], proxy_representable: bool) -> SingBoxRules {
    let mut objects: Vec<Value> = Vec::new();
    // BTreeSet keeps source registration deduplicated (O(log n) per insert) and
    // emits a deterministic sorted order into the document.
    let mut rule_set_tags: BTreeSet<String> = BTreeSet::new();
    let mut final_outbound: Option<String> = None;
    let mut block_outbound = false;
    let mut skipped = 0usize;
    for rule in rules {
        if let RuleMatch::Match = &rule.matcher {
            // Clash semantics: the first MATCH wins; later catch-alls are dead.
            if final_outbound.is_none() {
                match policy_outbound(&rule.policy, proxy_representable) {
                    Some(outbound) => final_outbound = Some(outbound),
                    None => skipped += 1,
                }
            }
            continue;
        }
        let Some(outbound) = policy_outbound(&rule.policy, proxy_representable) else {
            skipped += 1;
            continue;
        };
        if outbound == "block" {
            block_outbound = true;
        }
        if let Some(object) = matcher_object(&rule.matcher, &outbound) {
            if let RuleMatch::Geoip(code) = &rule.matcher {
                rule_set_tags.insert(geoip_rule_set_tag(code.as_str()));
            }
            objects.push(object);
        }
    }
    let final_outbound = final_outbound.unwrap_or_else(|| {
        if proxy_representable {
            "PROXY".to_owned()
        } else {
            "direct".to_owned()
        }
    });
    if final_outbound == "block" {
        block_outbound = true;
    }
    let rules_json = if objects.is_empty() {
        None
    } else {
        serde_json::to_string(&objects).ok()
    };
    let rule_sets_json = if rule_set_tags.is_empty() {
        None
    } else {
        let sources: Vec<Value> = rule_set_tags
            .iter()
            .map(|tag| {
                serde_json::json!({
                    "tag": tag,
                    "type": "remote",
                    "format": "binary",
                    "url": geoip_rule_set_url(tag),
                })
            })
            .collect();
        serde_json::to_string(&sources).ok()
    };
    SingBoxRules {
        rules_json,
        rule_sets_json,
        final_outbound,
        block_outbound,
        skipped,
    }
}

/// Maps one rule policy onto a sing-box outbound tag, or `None` when the
/// document cannot represent it. Group names fold into the `PROXY` selector
/// (the subscription document exposes every node through it); a literal
/// `GLOBAL` group keeps its dedicated selector.
fn policy_outbound(policy: &RulePolicy, proxy_representable: bool) -> Option<String> {
    match policy {
        RulePolicy::Direct => Some("direct".to_owned()),
        RulePolicy::Reject => Some("block".to_owned()),
        RulePolicy::Proxy(group) if proxy_representable => {
            if group.as_str() == "GLOBAL" {
                Some("GLOBAL".to_owned())
            } else {
                Some("PROXY".to_owned())
            }
        }
        RulePolicy::Proxy(_) => None,
    }
}

/// Builds one sing-box route rule object for a non-catch-all matcher.
fn matcher_object(matcher: &RuleMatch, outbound: &str) -> Option<Value> {
    let mut object = serde_json::Map::new();
    match matcher {
        RuleMatch::Domain(text) => {
            object.insert("domain".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::DomainSuffix(text) => {
            object.insert("domain_suffix".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::DomainKeyword(text) => {
            object.insert("domain_keyword".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::IpCidr(text) => {
            object.insert("ip_cidr".to_owned(), list_value(text.as_str()));
        }
        RuleMatch::Geoip(code) => {
            // The plain `geoip` rule key was removed in sing-box 1.12; modern
            // kernels match through a (remote) rule-set source instead.
            object.insert(
                "rule_set".to_owned(),
                Value::String(geoip_rule_set_tag(code.as_str())),
            );
        }
        RuleMatch::Match => return None,
    }
    object.insert("outbound".to_owned(), Value::String(outbound.to_owned()));
    Some(Value::Object(object))
}

/// Rule-set tag for one GEOIP country code (`geoip-cn` style).
fn geoip_rule_set_tag(code: &str) -> String {
    format!("geoip-{}", code.to_lowercase())
}

/// Official SagerNet rule-set source URL for one geoip tag.
fn geoip_rule_set_url(tag: &str) -> String {
    format!("https://raw.githubusercontent.com/SagerNet/sing-geoip/rule-set/{tag}.srs")
}

fn list_value(value: &str) -> Value {
    Value::Array(vec![Value::String(value.to_owned())])
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{RoutingRule, RuleError};

    fn parse(line: &str) -> RoutingRule {
        RoutingRule::from_clash_line(line).unwrap_or_else(|_: RuleError| std::process::abort())
    }

    #[test]
    fn maps_matchers_onto_sing_box_route_rule_keys() {
        let rules = vec![
            parse("DOMAIN,a.example,PROXY"),
            parse("DOMAIN-SUFFIX,b.example,DIRECT"),
            parse("DOMAIN-KEYWORD,ads,REJECT"),
            parse("IP-CIDR,192.168.0.0/16,DIRECT"),
            parse("GEOIP,CN,DIRECT"),
        ];
        let rendered = render_sing_box_rules(&rules, true);
        let json = rendered.rules_json.unwrap_or_default();
        assert!(json.contains("\"domain\":[\"a.example\"]"));
        assert!(json.contains("\"domain_suffix\":[\"b.example\"]"));
        assert!(json.contains("\"domain_keyword\":[\"ads\"]"));
        assert!(json.contains("\"ip_cidr\":[\"192.168.0.0/16\"]"));
        assert!(json.contains("\"rule_set\":\"geoip-cn\""));
        let sources = rendered.rule_sets_json.unwrap_or_default();
        assert!(sources.contains("\"tag\":\"geoip-cn\""));
        assert!(sources.contains("sing-geoip/rule-set/geoip-cn.srs"));
        assert!(rendered.block_outbound);
        assert_eq!(rendered.skipped, 0);
        assert_eq!(rendered.final_outbound, "PROXY");
    }

    #[test]
    fn match_rule_sets_route_final_and_first_wins() {
        let rules = vec![parse("MATCH,DIRECT"), parse("MATCH,PROXY")];
        let rendered = render_sing_box_rules(&rules, true);
        assert_eq!(rendered.final_outbound, "direct");
        assert_eq!(rendered.rules_json, None);
    }

    #[test]
    fn default_final_depends_on_proxy_presence() {
        assert_eq!(render_sing_box_rules(&[], true).final_outbound, "PROXY");
        assert_eq!(render_sing_box_rules(&[], false).final_outbound, "direct");
    }

    #[test]
    fn proxy_policies_skip_without_proxy_outbounds() {
        let rules = vec![
            parse("DOMAIN-SUFFIX,example.com,PROXY"),
            parse("MATCH,DIRECT"),
        ];
        let rendered = render_sing_box_rules(&rules, false);
        assert_eq!(rendered.skipped, 1);
        assert_eq!(rendered.rules_json, None);
        assert_eq!(rendered.final_outbound, "direct");
    }

    #[test]
    fn group_names_fold_into_proxy_and_global_keeps_its_selector() {
        let rules = vec![
            parse("DOMAIN,a.example,MyGroup"),
            parse("DOMAIN,b.example,GLOBAL"),
        ];
        let rendered = render_sing_box_rules(&rules, true);
        let json = rendered.rules_json.unwrap_or_default();
        assert!(json.contains("\"outbound\":\"PROXY\""));
        assert!(json.contains("\"outbound\":\"GLOBAL\""));
    }

    #[test]
    fn reject_final_requires_the_block_outbound() {
        let rules = vec![parse("MATCH,REJECT")];
        let rendered = render_sing_box_rules(&rules, true);
        assert_eq!(rendered.final_outbound, "block");
        assert!(rendered.block_outbound);
    }
}
