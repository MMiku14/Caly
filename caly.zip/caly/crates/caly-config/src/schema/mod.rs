//! Versioned application configuration parsing and safety validation.

use caly_domain::{BoundedText, SecretText};
use serde::Deserialize;

mod dns;
mod error;
mod fragments_dns;
mod kernel;
mod settings;
mod validate;

pub use dns::{DnsSchemaConfig, DnsSchemaError, FallbackFilterConfig, validated_dns_settings};
pub use kernel::{KernelConfig, RestartConfig, SnifferConfig, TransparentConfig, TransparentMode};
pub use validate::validate;

pub use settings::{
    ControllersConfig, CoreBinariesConfig, LogConfig, ProviderConfig, ProviderKind,
    SubscriptionConfig, TelemetryConfig, render_default_base, render_default_config,
    render_default_config_files,
};

/// Maximum accepted source configuration size.
pub const MAX_CONFIG_BYTES: usize = 16 * 1_024 * 1_024;

/// Complete validated bootstrap configuration.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AppConfig {
    pub schema_version: u32,
    pub core: CoreConfig,
    #[serde(default)]
    pub daemon: DaemonConfig,
    #[serde(default)]
    pub controllers: ControllersConfig,
    #[serde(default)]
    pub core_binaries: CoreBinariesConfig,
    #[serde(default)]
    pub subscriptions: SubscriptionConfig,
    #[serde(default)]
    pub log: LogConfig,
    #[serde(default)]
    pub telemetry: TelemetryConfig,
    #[serde(default)]
    pub tun: TunConfig,
    #[serde(default)]
    pub system_proxy: SystemProxyConfig,
    #[serde(default)]
    pub kernel: KernelConfig,
    #[serde(default)]
    pub dns: DnsSchemaConfig,
    /// Ordered Clash-format routing rules (`TYPE,VALUE,POLICY`); first match
    /// wins. Rendered into Mihomo `rules:` and sing-box `route.rules`.
    #[serde(default)]
    pub rules: Vec<String>,
    /// Traffic sniffing (domain recovery) rendered into the core config.
    #[serde(default)]
    pub sniffer: SnifferConfig,
    /// Explicit providers. Unset derives a `default` 枚举型 provider containing
    /// every enabled subscription source (see [`Self::resolved_providers`]).
    #[serde(default)]
    pub providers: Vec<ProviderConfig>,
}

impl AppConfig {
    /// Effective provider set: explicit `providers:` entries when present,
    /// otherwise the auto `default` 枚举型 provider containing every enabled
    /// subscription source. A config with only inline node content (no URL
    /// source) resolves to an empty set — node-only imports stay preview-only.
    pub fn resolved_providers(&self) -> Vec<ProviderConfig> {
        if !self.providers.is_empty() {
            return self.providers.clone();
        }
        self.subscriptions.default_provider().into_iter().collect()
    }
}

/// Managed proxy-core selection.
#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
#[serde(rename_all = "kebab-case")]
pub enum CoreConfig {
    Mihomo,
    SingBox,
    Xray,
}

/// Daemon transport security settings.
#[derive(Debug, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct DaemonConfig {
    pub listen: String,
    pub tls_enabled: bool,
    pub auth_token: Option<SecretText<4_096>>,
    /// Whether the daemon engages the configured core during boot. A failed
    /// auto-start never aborts the daemon: it serves with a stopped core and
    /// `caly core start` retries on demand.
    pub auto_start_core: bool,
}

impl Default for DaemonConfig {
    fn default() -> Self {
        Self {
            listen: "127.0.0.1:17890".to_owned(),
            tls_enabled: false,
            auth_token: None,
            auto_start_core: true,
        }
    }
}

/// TUN protocol stack; `deny_unknown_fields` keeps the enum closed.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq)]
#[serde(rename_all = "kebab-case")]
pub enum TunStack {
    #[default]
    Gvisor,
    Mixed,
    System,
}

/// TUN intent; runtime engagement remains platform-owned.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(default, deny_unknown_fields)]
pub struct TunConfig {
    pub enabled: bool,
    pub mtu: u16,
    /// User-space packet-stack implementation (gvisor/mixed/system).
    pub stack: TunStack,
    /// Whether the daemon installs routes automatically.
    pub auto_route: bool,
    /// Whether routing is strict (force all traffic through TUN).
    pub strict_route: bool,
    /// Privilege escalation for the privileged `ip` commands when the daemon
    /// lacks CAP_NET_ADMIN: `auto|pkexec|sudo|none`.
    pub escalation: String,
}

impl Default for TunConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            mtu: 1_500,
            stack: TunStack::default(),
            auto_route: true,
            strict_route: true,
            escalation: "auto".to_owned(),
        }
    }
}

/// System-proxy intent; original platform state is not represented here.
///
/// `host`/`port` describe the local proxy endpoint the desktop environment
/// should use. The port defaults to `kernel.mixed_port` at resolution time.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(default, deny_unknown_fields)]
pub struct SystemProxyConfig {
    pub enabled: bool,
    /// Address the desktop proxy settings point at.
    pub host: String,
    /// Port the desktop proxy settings point at; `None` resolves to
    /// `kernel.mixed_port`.
    pub port: Option<u16>,
}

impl Default for SystemProxyConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            host: "127.0.0.1".to_owned(),
            port: None,
        }
    }
}

/// Safe configuration rejection with user remediation.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ConfigError {
    TooLarge {
        limit: usize,
        actual: usize,
    },
    Parse {
        line: usize,
        column: usize,
        message: BoundedText<512>,
    },
    ParseDetailsUnavailable,
    UnsupportedSchemaVersion(u32),
    InvalidListenAddress,
    RemoteListenRequiresTls,
    RemoteListenRequiresAuth,
    InvalidControllerAddress {
        core: String,
        address: String,
    },
    InvalidLogLevel,
    InvalidTelemetryInterval,
    InvalidSubscriptionUrl,
    InvalidTunMtu,
    /// `kernel.mixed_port` must be a non-zero port.
    InvalidKernelPort,
    /// `kernel.log_level` is not a level both kernels understand.
    InvalidKernelLogLevel,
    /// `kernel.restart` bounds are invalid.
    InvalidKernelRestart,
    /// `kernel.start_timeout_ms`/`stop_timeout_ms` are invalid.
    InvalidKernelTimeout,
    /// Transparent proxy is enabled with a zero port.
    InvalidTransparentPort,
    /// An enabled `dns` section violates a domain invariant.
    InvalidDns(DnsSchemaError),
    /// A DNS filter entry is structurally invalid (listen address or
    /// fallback-filter CIDR block).
    InvalidDnsFilter,
    /// Subscription fetch policy bounds are invalid.
    InvalidFetchPolicy,
    /// System proxy host/port are invalid.
    InvalidSystemProxy,
    /// `tun.escalation` is not one of auto/pkexec/sudo/none.
    InvalidTunEscalation,
    /// A routing rule failed to parse; carries the rule index and reason.
    InvalidRule {
        index: usize,
        reason: String,
    },
    /// A sniffer port spec is not `N` or `N-M` within 1..=65535.
    InvalidSnifferPort {
        spec: String,
    },
}

/// Parses YAML and validates all cross-field bootstrap invariants.
pub fn parse_and_validate_yaml(bytes: &[u8]) -> Result<AppConfig, ConfigError> {
    if bytes.len() > MAX_CONFIG_BYTES {
        return Err(ConfigError::TooLarge {
            limit: MAX_CONFIG_BYTES,
            actual: bytes.len(),
        });
    }
    let source = core::str::from_utf8(bytes).map_err(|_| ConfigError::ParseDetailsUnavailable)?;
    let config: AppConfig = serde_norway::from_str(source)
        .map_err(|error| validate::parse_message(error.to_string()))?;
    validate(&config)?;
    Ok(config)
}

/// Parses JSON for compatibility and validates all cross-field invariants.
pub fn parse_and_validate_json(bytes: &[u8]) -> Result<AppConfig, ConfigError> {
    if bytes.len() > MAX_CONFIG_BYTES {
        return Err(ConfigError::TooLarge {
            limit: MAX_CONFIG_BYTES,
            actual: bytes.len(),
        });
    }
    let config: AppConfig = serde_json::from_slice(bytes).map_err(validate::parse_error)?;
    validate(&config)?;
    Ok(config)
}

/// Validates an already decoded configuration.
#[cfg(test)]
mod tests;

#[cfg(test)]
mod kernel_validation_tests;
