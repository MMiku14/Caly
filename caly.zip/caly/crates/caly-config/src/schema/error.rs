//! User-facing rendering of configuration failures.

use super::ConfigError;

impl core::fmt::Display for ConfigError {
    fn fmt(&self, formatter: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::TooLarge { limit, actual } => {
                write!(
                    formatter,
                    "configuration is {actual} bytes; reduce it to at most {limit} bytes"
                )
            }
            Self::Parse {
                line,
                column,
                message,
            } => {
                write!(
                    formatter,
                    "configuration parse failed at {line}:{column}: {message}"
                )
            }
            Self::UnsupportedSchemaVersion(version) => {
                write!(
                    formatter,
                    "schema version {version} is unsupported; use version 1"
                )
            }
            Self::InvalidControllerAddress { core, address } => {
                write!(
                    formatter,
                    "{core} controller address `{address}` is invalid; use host:port"
                )
            }
            Self::InvalidRule { index, reason } => {
                write!(formatter, "rules[{index}] is invalid: {reason}")
            }
            Self::InvalidSnifferPort { spec } => write!(
                formatter,
                "sniffer port spec `{spec}` is invalid; use `N` or `N-M` within 1-65535"
            ),
            Self::InvalidDns(error) => write!(formatter, "{error}"),
            _ => formatter.write_str(self.static_message()),
        }
    }
}

impl ConfigError {
    /// Fixed-message variants, kept in one table so `fmt` stays small.
    fn static_message(&self) -> &'static str {
        match self {
            Self::ParseDetailsUnavailable => "configuration parse failed; inspect JSON syntax",
            Self::InvalidListenAddress => "daemon listen address is invalid; use IP:PORT",
            Self::RemoteListenRequiresTls => "non-loopback daemon listen requires TLS",
            Self::RemoteListenRequiresAuth => {
                "non-loopback daemon listen requires an authentication token"
            }
            Self::InvalidTunMtu => "TUN MTU must be between 576 and 9000",
            Self::InvalidLogLevel => "log.level must be error, warn, info, debug, or trace",
            Self::InvalidTelemetryInterval => "telemetry.interval_ms must be at least 100",
            Self::InvalidSubscriptionUrl => "subscriptions.url must be a public HTTP(S) URL",
            Self::InvalidKernelPort => "kernel.mixed_port must be between 1 and 65535",
            Self::InvalidKernelLogLevel => {
                "kernel.log_level must be trace, debug, info, warn, or error"
            }
            Self::InvalidKernelRestart => {
                "kernel.restart requires initial_backoff_ms >= 100 and max >= initial"
            }
            Self::InvalidKernelTimeout => {
                "kernel.start_timeout_ms and kernel.stop_timeout_ms must be >= 100"
            }
            Self::InvalidTransparentPort => {
                "kernel.transparent.port must be non-zero when transparent is enabled"
            }
            Self::InvalidDnsFilter => {
                "dns.listen must be host:port; fallback_filter.ipcidr must be CIDR blocks"
            }
            Self::InvalidFetchPolicy => {
                "subscriptions fetch policy is invalid: connect >= 100ms, request >= 1000ms, body 1..=256MB"
            }
            Self::InvalidSystemProxy => {
                "system_proxy.host must be non-empty and system_proxy.port a valid port"
            }
            Self::InvalidTunEscalation => "tun.escalation must be auto, pkexec, sudo, or none",
            Self::TooLarge { .. }
            | Self::Parse { .. }
            | Self::UnsupportedSchemaVersion(_)
            | Self::InvalidControllerAddress { .. }
            | Self::InvalidRule { .. }
            | Self::InvalidSnifferPort { .. }
            | Self::InvalidDns(_) => "parameterized error",
        }
    }
}

impl std::error::Error for ConfigError {}
