//! Typed Clash YAML proxy conversion into complete Domain nodes.

use core::num::NonZeroU16;

use caly_domain::{
    CongestionControl, Credential, DialableNode, Endpoint, EndpointHost, NodeBuilder,
    NodeDisplayName, NodeSource, Protocol, ProtocolText, ShadowsocksCipher, SubscriptionId,
    TlsConfig, Transport, TransportText, TransportTextList, VmessCipher,
};
use serde::Deserialize;

use super::pipeline::MAX_SUBSCRIPTION_NODES;

#[derive(Deserialize)]
struct ClashDocument {
    proxies: Vec<ClashProxy>,
}

#[derive(Deserialize)]
#[serde(rename_all = "kebab-case")]
struct ClashProxy {
    name: String,
    #[serde(rename = "type")]
    kind: String,
    server: String,
    port: u16,
    uuid: Option<String>,
    password: Option<String>,
    username: Option<String>,
    cipher: Option<String>,
    #[serde(default)]
    alter_id: u16,
    flow: Option<String>,
    network: Option<String>,
    #[serde(default)]
    tls: bool,
    servername: Option<String>,
    sni: Option<String>,
    #[serde(rename = "ws-opts")]
    ws_opts: Option<ClashWsOptions>,
    #[serde(rename = "grpc-opts")]
    grpc_opts: Option<ClashGrpcOptions>,
    up: Option<u32>,
    down: Option<u32>,
    obfs_password: Option<String>,
    congestion_controller: Option<String>,
    private_key: Option<String>,
    public_key: Option<String>,
    reserved: Option<Vec<u8>>,
}

#[derive(Deserialize)]
struct ClashWsOptions {
    path: Option<String>,
    headers: Option<ClashWsHeaders>,
}

#[derive(Deserialize)]
struct ClashWsHeaders {
    #[serde(rename = "Host")]
    host: Option<String>,
}

#[derive(Deserialize)]
struct ClashGrpcOptions {
    #[serde(rename = "grpc-service-name")]
    service_name: Option<String>,
}

/// Indexed Clash conversion failure.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ClashParseError {
    YamlRejected,
    TooManyNodes,
    InvalidName(usize),
    InvalidEndpoint(usize),
    MissingField { index: usize, field: &'static str },
    UnsupportedProtocol { index: usize },
    UnsupportedCipher { index: usize },
    InvalidTransport { index: usize },
    InvalidTls { index: usize },
    NodeRejected(usize),
}

/// Parses the `proxies` list and rejects the entire document on any bad node.
pub fn parse_clash_yaml(
    source: &str,
    subscription: SubscriptionId,
) -> Result<Vec<DialableNode>, ClashParseError> {
    let document: ClashDocument =
        serde_norway::from_str(source).map_err(|_| ClashParseError::YamlRejected)?;
    if document.proxies.len() > MAX_SUBSCRIPTION_NODES {
        return Err(ClashParseError::TooManyNodes);
    }
    document
        .proxies
        .into_iter()
        .enumerate()
        .map(|(index, proxy)| convert_proxy(index, proxy, subscription))
        .collect()
}

fn convert_proxy(
    index: usize,
    proxy: ClashProxy,
    subscription: SubscriptionId,
) -> Result<DialableNode, ClashParseError> {
    let name = NodeDisplayName::new(proxy.name.clone())
        .map_err(|_| ClashParseError::InvalidName(index))?;
    let host = EndpointHost::new(proxy.server.clone())
        .map_err(|_| ClashParseError::InvalidEndpoint(index))?;
    let port = NonZeroU16::new(proxy.port).ok_or(ClashParseError::InvalidEndpoint(index))?;
    let protocol = clash_protocol(index, &proxy)?;
    let mut builder = NodeBuilder::new(
        name,
        Endpoint::new(host, port),
        protocol,
        NodeSource::Subscription(subscription),
    );
    if let Some(transport) = clash_transport(index, &proxy)? {
        builder = builder.with_transport(transport);
    }
    if proxy.tls {
        builder = builder.with_tls(clash_tls(index, &proxy)?);
    }
    builder
        .build()
        .map_err(|_| ClashParseError::NodeRejected(index))
}

fn clash_protocol(index: usize, proxy: &ClashProxy) -> Result<Protocol, ClashParseError> {
    match proxy.kind.to_ascii_lowercase().as_str() {
        "vmess" => Ok(Protocol::Vmess {
            user_id: required_secret(index, "uuid", proxy.uuid.as_deref())?,
            alter_id: proxy.alter_id,
            security: VmessCipher::Auto,
        }),
        "vless" => Ok(Protocol::Vless {
            user_id: required_secret(index, "uuid", proxy.uuid.as_deref())?,
            flow: optional_text(proxy.flow.as_deref())?,
        }),
        "trojan" => Ok(Protocol::Trojan {
            password: required_secret(index, "password", proxy.password.as_deref())?,
        }),
        "ss" | "shadowsocks" => Ok(Protocol::Shadowsocks {
            method: clash_cipher(index, proxy.cipher.as_deref())?,
            password: required_secret(index, "password", proxy.password.as_deref())?,
            plugin: None,
        }),
        "hysteria2" | "hy2" => Ok(Protocol::Hysteria2 {
            password: required_secret(index, "password", proxy.password.as_deref())?,
            up_mbps: proxy.up,
            down_mbps: proxy.down,
            obfuscation: optional_secret(proxy.obfs_password.as_deref())?,
        }),
        "tuic" => Ok(Protocol::Tuic {
            user_id: required_secret(index, "uuid", proxy.uuid.as_deref())?,
            password: required_secret(index, "password", proxy.password.as_deref())?,
            congestion: congestion(index, proxy.congestion_controller.as_deref())?,
        }),
        "wireguard" => Ok(Protocol::WireGuard {
            private_key: required_secret(index, "private-key", proxy.private_key.as_deref())?,
            peer_public_key: required_secret(index, "public-key", proxy.public_key.as_deref())?,
            reserved: reserved(index, proxy.reserved.as_deref())?,
        }),
        "http" => Ok(Protocol::Http {
            username: optional_secret(proxy.username.as_deref())?,
            password: optional_secret(proxy.password.as_deref())?,
        }),
        "socks5" | "socks" => Ok(Protocol::Socks5 {
            username: optional_secret(proxy.username.as_deref())?,
            password: optional_secret(proxy.password.as_deref())?,
        }),
        _ => Err(ClashParseError::UnsupportedProtocol { index }),
    }
}

fn clash_transport(index: usize, proxy: &ClashProxy) -> Result<Option<Transport>, ClashParseError> {
    match proxy.network.as_deref().unwrap_or("tcp") {
        "tcp" => Ok(Some(Transport::Tcp)),
        "ws" => {
            let options = proxy.ws_opts.as_ref();
            let path = options
                .and_then(|value| value.path.as_deref())
                .unwrap_or("/");
            let host = options
                .and_then(|value| value.headers.as_ref())
                .and_then(|value| value.host.as_deref());
            Ok(Some(Transport::WebSocket {
                path: transport_text(index, path)?,
                host: host.map(|value| transport_text(index, value)).transpose()?,
            }))
        }
        "grpc" => {
            let service = proxy
                .grpc_opts
                .as_ref()
                .and_then(|value| value.service_name.as_deref())
                .unwrap_or("grpc");
            Ok(Some(Transport::Grpc {
                service_name: transport_text(index, service)?,
            }))
        }
        "quic" => Ok(Some(Transport::Quic)),
        _ => Err(ClashParseError::InvalidTransport { index }),
    }
}

fn clash_tls(index: usize, proxy: &ClashProxy) -> Result<TlsConfig, ClashParseError> {
    let sni = proxy.servername.as_deref().or(proxy.sni.as_deref());
    let sni = sni
        .map(|value| transport_text(index, value))
        .transpose()
        .map_err(|_| ClashParseError::InvalidTls { index })?;
    Ok(TlsConfig::new(
        sni,
        TransportTextList::new(),
        false,
        None,
        None,
    ))
}

fn required_secret(
    index: usize,
    field: &'static str,
    value: Option<&str>,
) -> Result<Credential, ClashParseError> {
    optional_secret(value)?.ok_or(ClashParseError::MissingField { index, field })
}

fn optional_secret(value: Option<&str>) -> Result<Option<Credential>, ClashParseError> {
    value
        .map(|value| Credential::new(value.to_owned()).map_err(|_| ClashParseError::YamlRejected))
        .transpose()
}

fn optional_text(value: Option<&str>) -> Result<Option<ProtocolText>, ClashParseError> {
    value
        .map(|value| ProtocolText::new(value.to_owned()).map_err(|_| ClashParseError::YamlRejected))
        .transpose()
}

fn transport_text(index: usize, value: &str) -> Result<TransportText, ClashParseError> {
    TransportText::new(value.to_owned()).map_err(|_| ClashParseError::InvalidTransport { index })
}

fn clash_cipher(index: usize, value: Option<&str>) -> Result<ShadowsocksCipher, ClashParseError> {
    match value {
        Some("aes-128-gcm") => Ok(ShadowsocksCipher::Aes128Gcm),
        Some("aes-256-gcm") => Ok(ShadowsocksCipher::Aes256Gcm),
        Some("chacha20-ietf-poly1305") => Ok(ShadowsocksCipher::Chacha20IetfPoly1305),
        Some("xchacha20-ietf-poly1305") => Ok(ShadowsocksCipher::Xchacha20IetfPoly1305),
        Some("aes-128-cfb") => Ok(ShadowsocksCipher::Aes128Cfb),
        Some("aes-256-cfb") => Ok(ShadowsocksCipher::Aes256Cfb),
        Some("none") => Ok(ShadowsocksCipher::None),
        _ => Err(ClashParseError::UnsupportedCipher { index }),
    }
}

fn congestion(_index: usize, value: Option<&str>) -> Result<CongestionControl, ClashParseError> {
    match value.unwrap_or("bbr") {
        "bbr" => Ok(CongestionControl::Bbr),
        "cubic" => Ok(CongestionControl::Cubic),
        "new_reno" | "new-reno" => Ok(CongestionControl::NewReno),
        _ => Err(ClashParseError::YamlRejected),
    }
}

fn reserved(index: usize, value: Option<&[u8]>) -> Result<Option<[u8; 3]>, ClashParseError> {
    let Some(value) = value else { return Ok(None) };
    if value.len() != 3 {
        return Err(ClashParseError::MissingField {
            index,
            field: "reserved[3]",
        });
    }
    Ok(Some([value[0], value[1], value[2]]))
}
