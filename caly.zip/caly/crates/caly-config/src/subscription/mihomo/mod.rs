//! Mihomo proxy rendering from subscription URI lines.
//!
//! Mirrors [`super::sing_box`] but emits Clash/Mihomo `proxies`/`proxy-groups`/
//! `rules` YAML instead of sing-box outbound JSON. Each dialable node is
//! rendered into a bounded YAML block; unsupported protocols are skipped so a
//! mixed real subscription degrades to its representable subset rather than
//! failing the whole render. The final document is assembled by the kernel
//! `MihomoConfigRenderer` from this proxy section.

use std::fmt::Write as FmtWrite;

use caly_domain::{BoundedText, BoundedVec, DialableNode, NodeId, SubscriptionId, TextError};

use super::{
    clash::parse_clash_yaml, decode_document, format::SubscriptionDocument,
    uri::parse_any_proxy_uri,
};

/// Maximum number of representable Mihomo proxies in one section.
pub const MAX_MIHOMO_PROXIES: usize = 10_000;
/// Maximum rendered YAML bytes for a single proxy block.
pub const MIHOMO_PROXY_YAML_MAX_BYTES: usize = 4_096;
/// Maximum proxy-group name length in bytes.
pub const MIHOMO_GROUP_MAX_BYTES: usize = 128;
/// Maximum proxy display-name (tag) length in bytes.
pub const MIHOMO_TAG_MAX_BYTES: usize = 256;

/// Bounded rendered Mihomo proxy block.
pub type MihomoProxyYaml = BoundedText<MIHOMO_PROXY_YAML_MAX_BYTES>;
/// Bounded proxy-group name.
pub type MihomoGroupName = BoundedText<MIHOMO_GROUP_MAX_BYTES>;
/// Bounded proxy display-name used as the Clash tag.
pub type MihomoProxyTag = BoundedText<MIHOMO_TAG_MAX_BYTES>;

/// One representable subscription node plus its rendered YAML block.
#[derive(Clone, Debug)]
pub struct MihomoProxyEntry {
    /// Stable selection identity; equals the dialable node identity.
    pub id: NodeId,
    /// Clash tag, also used by core selection and group membership.
    pub tag: MihomoProxyTag,
    /// Rendered `- name: ...` YAML block (already indented two spaces).
    pub yaml: MihomoProxyYaml,
}

/// Bounded ordered set of Mihomo proxies from one subscription body.
#[derive(Clone, Debug)]
pub struct MihomoProxySet {
    entries: BoundedVec<MihomoProxyEntry, MAX_MIHOMO_PROXIES>,
    group: MihomoGroupName,
}

impl MihomoProxySet {
    /// Returns the proxy-group name this set feeds.
    pub fn group(&self) -> &str {
        self.group.as_str()
    }
    /// Returns the ordered entries as a slice.
    pub fn entries(&self) -> &[MihomoProxyEntry] {
        self.entries.as_slice()
    }
    /// Returns the number of representable proxies.
    pub fn len(&self) -> usize {
        self.entries.len()
    }
    /// Returns whether no representable proxy exists.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

/// Subscription-to-Mihomo rendering failure.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum MihomoProxyError {
    /// The body could not be decoded as a supported subscription format.
    InvalidFormat,
    /// The decoded document is not a URI-line subscription.
    UnsupportedDocument,
    /// More representable nodes than the bounded capacity.
    TooManyProxies,
    /// No parseable node was representable as a Mihomo proxy.
    NoUsableNodes,
    /// A bounded field failed validation.
    Text(TextError),
}

impl From<TextError> for MihomoProxyError {
    fn from(value: TextError) -> Self {
        Self::Text(value)
    }
}

/// Renders a Mihomo proxy section (proxies/groups/rules) from a subscription
/// body, reusing the same dialable pipeline as the sing-box renderer.
pub fn uri_body_to_mihomo_proxy_set(
    body: Vec<u8>,
    subscription: SubscriptionId,
) -> Result<MihomoProxySet, MihomoProxyError> {
    let document = decode_document(body).map_err(|_| MihomoProxyError::InvalidFormat)?;
    // Dedupe by NodeId with the same first-seen order the projection uses, so
    // the `#N` suffix numbering assigned below matches what list UIs show.
    let deduped = super::pipeline::dedupe(dialable_nodes(document, subscription)?)
        .map_err(|_| MihomoProxyError::InvalidFormat)?;
    let names = deduped
        .nodes
        .iter()
        .filter_map(|node| node.display(true, None).ok())
        .map(|display| display.name().as_str().to_owned())
        .collect::<Vec<_>>();
    let tags = super::pipeline::dedupe_name_tags(names.iter().map(String::as_str));
    let mut entries: Vec<MihomoProxyEntry> = Vec::new();
    for (node, tag_text) in deduped.nodes.iter().zip(tags) {
        let Ok(tag) = MihomoProxyTag::new(tag_text) else {
            continue;
        };
        match proxy_to_entry(node, tag) {
            Ok(entry) => entries.push(entry),
            Err(MihomoProxyError::NoUsableNodes) => {}
            Err(error) => return Err(error),
        }
    }
    if entries.is_empty() {
        return Err(MihomoProxyError::NoUsableNodes);
    }
    let entries =
        BoundedVec::try_from_vec(entries).map_err(|_| MihomoProxyError::TooManyProxies)?;
    let group = MihomoGroupName::new(group_name())?;
    Ok(MihomoProxySet { entries, group })
}

/// Extracts dialable nodes from a decoded document, tolerating unparseable URI
/// lines and parsing Clash-YAML bodies atomically. An unusable body is empty.
fn dialable_nodes(
    document: SubscriptionDocument,
    subscription: SubscriptionId,
) -> Result<Vec<DialableNode>, MihomoProxyError> {
    match document {
        SubscriptionDocument::UriLines { lines, .. } => Ok(lines
            .iter()
            .filter_map(|line| parse_any_proxy_uri(line.as_str(), subscription).ok())
            .collect()),
        SubscriptionDocument::ClashYaml(body) => {
            let source = core::str::from_utf8(body.as_slice())
                .map_err(|_| MihomoProxyError::InvalidFormat)?;
            parse_clash_yaml(source, subscription)
                .map_err(|_| MihomoProxyError::UnsupportedDocument)
        }
        SubscriptionDocument::Sip008(body) => {
            let source = core::str::from_utf8(body.as_slice())
                .map_err(|_| MihomoProxyError::InvalidFormat)?;
            Ok(super::parse_sip008(source, subscription).0)
        }
        // URL lists are expanded by the daemon fetch path before rendering.
        SubscriptionDocument::UrlList(_) => Err(MihomoProxyError::UnsupportedDocument),
    }
}

/// Emits `proxies:`, `proxy-groups:` and `rules:` YAML from a proxy set.
pub fn render_proxy_sections(set: &MihomoProxySet) -> String {
    let proxies = set
        .entries()
        .iter()
        .map(|entry| (entry.tag.as_str(), entry.yaml.as_str()))
        .collect::<Vec<_>>();
    render_proxy_sections_from(set.group(), &proxies)
}

/// Assembles `proxies:`, `proxy-groups:` and `rules:` YAML from `(tag, yaml)`
/// pairs. Shared by the subscription renderer and the config backend so the
/// proxy-group/rule template stays in one place.
pub fn render_proxy_sections_from<'a>(group: &str, proxies: &[(&'a str, &'a str)]) -> String {
    render_proxy_sections_with_rules(group, proxies, &[])
}

/// Renders proxies, proxy-groups and the routing `rules:` section. Configured
/// rules are emitted in order (first match wins); a `MATCH` catch-all for the
/// active group is appended only when the rule set does not already end one.
pub fn render_proxy_sections_with_rules<'a>(
    group: &str,
    proxies: &[(&'a str, &'a str)],
    rules: &[caly_domain::RoutingRule],
) -> String {
    let mut out = String::from("proxies:\n");
    for (_, yaml) in proxies {
        let _ = writeln!(out, "{yaml}");
    }
    let _ = write!(
        out,
        "proxy-groups:\n  - name: {}\n    type: url-test\n",
        yaml_quote(group)
    );
    out.push_str("    url: \"http://www.gstatic.com/generate_204\"\n");
    out.push_str("    interval: 300\n");
    out.push_str("    tolerance: 50\n");
    out.push_str("    proxies:\n");
    for (tag, _) in proxies {
        let _ = writeln!(out, "      - {}", yaml_quote(tag));
    }
    out.push_str("      - \"DIRECT\"\n");
    let _ = writeln!(out, "rules:");
    let mut has_match = false;
    for rule in rules {
        let _ = writeln!(out, "  - {}", rule.to_clash_line());
        if matches!(rule.matcher, caly_domain::RuleMatch::Match) {
            has_match = true;
        }
    }
    if !has_match {
        let _ = writeln!(out, "  - MATCH,{group}");
    }
    out
}

use render::{proxy_to_entry, yaml_quote};

/// Selects the configured Clash proxy-group name with a safe default.
fn group_name() -> String {
    match std::env::var("CALY_MIHOMO_PROXY_GROUP").as_deref() {
        Ok(value) if !value.trim().is_empty() => value.trim().to_owned(),
        _ => "AUTO".to_owned(),
    }
}

mod render;

#[cfg(test)]
mod mihomo_tests;
