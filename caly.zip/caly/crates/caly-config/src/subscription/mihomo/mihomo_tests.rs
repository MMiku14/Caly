use super::*;

/// A mixed, minimal, deterministic subscription body.
fn mini_body() -> Vec<u8> {
    let ss = "ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTpzZWNyZXRwYXNz@example.com:8443#ss-node";
    format!(
        "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=tls#vless-node\n\
         trojan://secret-pass@example.com:443?security=tls#trojan-node\n{ss}\n"
    )
    .into_bytes()
}

#[test]
fn clash_yaml_renders_a_proxy_set() -> Result<(), String> {
    let body = br#"proxies:
  - name: "hk-ss"
    type: ss
    server: example.com
    port: 8388
    cipher: aes-128-gcm
    password: secret
  - name: "jp-trojan"
    type: trojan
    server: example.org
    port: 443
    password: pass
"#
    .to_vec();
    let id = SubscriptionId::from_bytes([6; 16]);
    let set = uri_body_to_mihomo_proxy_set(body, id).map_err(|e| format!("{e:?}"))?;
    assert_eq!(set.len(), 2, "clash yaml must render both proxies");
    let section = render_proxy_sections(&set);
    assert!(section.contains("type: ss"));
    assert!(section.contains("type: trojan"));
    Ok(())
}

#[test]
fn vless_ws_reality_renders_flow_tls_reality_and_transport() -> Result<(), String> {
    let body = "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=reality&flow=xtls-rprx-vision&sni=example.com&pbk=zT7a-PnmIWP4c-G1EDUT3KZ7URi1kc8EppAWPr3h5lk&sid=afeed89ae23b36ed&type=ws&path=%2Fstream&host=example.com#reality-ws\n"
        .as_bytes()
        .to_vec();
    let id = SubscriptionId::from_bytes([7; 16]);
    let set = uri_body_to_mihomo_proxy_set(body, id).map_err(|e| format!("{e:?}"))?;
    assert_eq!(set.len(), 1);
    let section = render_proxy_sections(&set);
    // XTLS flow, Reality public key, and WS transport must all survive into
    // the rendered config, otherwise the outbound is incomplete.
    assert!(
        section.contains("flow: xtls-rprx-vision"),
        "flow must render"
    );
    assert!(section.contains("tls: true"), "TLS must render");
    assert!(section.contains("reality-opts:"), "reality must render");
    assert!(
        section.contains("public-key:"),
        "reality public key must render"
    );
    assert!(section.contains("network: ws"), "ws transport must render");
    assert!(section.contains("path:"), "ws path must render");
    Ok(())
}

#[test]
fn renders_representable_proxies_and_group() -> Result<(), String> {
    let id = SubscriptionId::from_bytes([3; 16]);
    let set = uri_body_to_mihomo_proxy_set(mini_body(), id).map_err(|e| format!("{e:?}"))?;
    assert_eq!(set.len(), 3, "vless, trojan and ss must all render");
    assert_eq!(set.group(), "AUTO");
    let section = render_proxy_sections(&set);
    assert!(section.contains("type: vless"));
    assert!(section.contains("type: trojan"));
    assert!(section.contains("type: ss"));
    assert!(section.contains("proxy-groups:"));
    assert!(section.contains("rules:"));
    assert!(section.contains("MATCH,AUTO"));
    Ok(())
}

#[test]
fn unsupported_document_is_rejected() {
    let id = SubscriptionId::from_bytes([4; 16]);
    let body = b"this is not a subscription format".to_vec();
    let result = uri_body_to_mihomo_proxy_set(body, id);
    assert!(matches!(result, Err(MihomoProxyError::InvalidFormat)));
}

#[test]
fn http_proxy_uri_now_renders() {
    let id = SubscriptionId::from_bytes([5; 16]);
    // An HTTP proxy URI maps to `Protocol::Http`, which Mihomo can dial.
    let body = b"http://user:pass@example.com:8080#http-node\n".to_vec();
    let result = uri_body_to_mihomo_proxy_set(body, id);
    assert!(result.is_ok(), "http proxy nodes must render: {result:?}");
}

#[test]
fn no_representable_nodes_reports_no_usable() {
    let id = SubscriptionId::from_bytes([6; 16]);
    // A WireGuard URI has no Mihomo outbound representation here.
    let body = b"wireguard://abcdef0123456789abcdef0123456789@example.com:51820?public-key=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=#wg\n".to_vec();
    let result = uri_body_to_mihomo_proxy_set(body, id);
    assert!(matches!(result, Err(MihomoProxyError::NoUsableNodes)));
}

#[test]
fn trojan_and_vmess_render_tls_and_transport() -> Result<(), String> {
    // Trojan over TLS with a ws transport, and a vmess with alterId/cipher/tls.
    let body = "trojan://secret-pass@example.com:443?security=tls&sni=example.com&type=ws&path=%2Fstream#trojan-ws\n\
                vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOjQ0MywiaWQiOiI2YTg5YTIxNS0yMmJmLTRiZDctOTY0Mi1iOTViMmUwOTU4M2EiLCJhaWQiOjAsIm5ldCI6IndzIiwicGF0aCI6Ii9zIiwiaG9zdCI6ImV4YW1wbGUuY29tIiwidGxzIjoidGxzIiwicHMiOiJ2bWVzLW5vZGUifQ==\n"
        .as_bytes()
        .to_vec();
    let id = SubscriptionId::from_bytes([8; 16]);
    let set = uri_body_to_mihomo_proxy_set(body, id).map_err(|e| format!("{e:?}"))?;
    assert_eq!(set.len(), 2);
    let section = render_proxy_sections(&set);
    assert!(section.contains("type: trojan"));
    assert!(section.contains("type: vmess"));
    assert!(
        section.contains("tls: true"),
        "trojan/vmess TLS must render"
    );
    assert!(section.contains("network: ws"), "ws transport must render");
    assert!(section.contains("alterId: 0"), "vmess alterId must render");
    assert!(section.contains("cipher: auto"), "vmess cipher must render");
    Ok(())
}

#[test]
fn hysteria2_and_tuic_render() -> Result<(), String> {
    let body = "hysteria2://secret@example.com:443?security=tls&sni=example.com&obfs=salamander&obfs-password=obfspass&upmbps=50&downmbps=100#hy2\n\
                tuic://2DD61D93-75D8-4DA4-AC0E-6AECE7EAC365:hello@example.com:443?congestion_control=bbr#tuic\n"
        .as_bytes()
        .to_vec();
    let id = SubscriptionId::from_bytes([9; 16]);
    let set = uri_body_to_mihomo_proxy_set(body, id).map_err(|e| format!("{e:?}"))?;
    assert_eq!(set.len(), 2, "hysteria2 and tuic must render");
    let section = render_proxy_sections(&set);
    assert!(section.contains("type: hysteria2"));
    assert!(section.contains("password: secret"));
    assert!(section.contains("obfs: salamander"));
    assert!(section.contains("type: tuic"));
    assert!(section.contains("congestion-controller: bbr"));
    Ok(())
}

#[test]
fn renders_config_rules_before_match_catch_all() {
    let rules = vec![
        caly_domain::RoutingRule::from_clash_line("DOMAIN-SUFFIX,google.com,PROXY")
            .unwrap_or_else(|_| std::process::abort()),
        caly_domain::RoutingRule::from_clash_line("GEOIP,CN,DIRECT")
            .unwrap_or_else(|_| std::process::abort()),
    ];
    let section = render_proxy_sections_with_rules(
        "AUTO",
        &[("node-a", "  - name: node-a\n    type: ss")],
        &rules,
    );
    assert!(section.contains("rules:"));
    assert!(section.contains("  - DOMAIN-SUFFIX,google.com,PROXY"));
    assert!(section.contains("  - GEOIP,CN,DIRECT"));
    // A MATCH catch-all is appended when the rules lack one.
    assert!(section.contains("  - MATCH,AUTO"));
}

#[test]
fn existing_match_rule_suppresses_extra_catch_all() {
    let rules = vec![
        caly_domain::RoutingRule::from_clash_line("MATCH,PROXY")
            .unwrap_or_else(|_| std::process::abort()),
    ];
    let section = render_proxy_sections_with_rules("AUTO", &[], &rules);
    assert!(section.contains("  - MATCH,PROXY"));
    assert!(!section.contains("MATCH,AUTO"));
}
