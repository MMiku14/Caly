//! Default address classifier used by every SSRF-safe fetch in
//! caly. Lives next to the fetch policy so the same rejection
//! rules apply whether the call site is a subscription refresh or
//! a profile body download.

use std::net::IpAddr;

use super::AddressClassifier;

/// Drops private / loopback / link-local / unspecified /
/// broadcast addresses. Both IPv4 and IPv6 are covered, and
/// IPv4-mapped IPv6 addresses (`::ffff:a.b.c.d`) are peeled
/// before the IPv4 rules apply — a `::ffff:10.0.0.1` looks
/// like a public IPv6 to a naive classifier but is really a
/// private IPv4 in disguise. Used by every fetch call site
/// that does not need a custom policy (subscription refresh,
/// profile body download, GEOSITE auto-emit, …).
pub struct PublicAddressClassifier;

impl AddressClassifier for PublicAddressClassifier {
    fn is_globally_routable(&self, address: IpAddr) -> bool {
        // IPv4-mapped IPv6 (`::ffff:a.b.c.d`) is functionally
        // an IPv4 address. Peeling it before the match keeps
        // the IPv4 branch the single source of truth for the
        // full private/loopback/link-local/unspecified/broadcast
        // matrix; the same DNS response can carry either
        // representation depending on resolver behaviour.
        let normalized = match address {
            IpAddr::V6(v6) => v6.to_ipv4_mapped().map_or(IpAddr::V6(v6), IpAddr::V4),
            v4 @ IpAddr::V4(_) => v4,
        };
        match normalized {
            IpAddr::V4(value) => {
                !value.is_private()
                    && !value.is_loopback()
                    && !value.is_link_local()
                    && !value.is_unspecified()
                    && !value.is_broadcast()
            }
            IpAddr::V6(value) => {
                !value.is_loopback()
                    && !value.is_unspecified()
                    && !value.is_unique_local()
                    && !value.is_unicast_link_local()
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::{Ipv4Addr, Ipv6Addr};

    #[test]
    fn ipv4_mapped_ipv6_is_classified_as_the_underlying_ipv4() {
        // `::ffff:10.0.0.1` is private IPv4 in disguise. A
        // naive IPv6 classifier would let it through; peeling
        // it routes the address through the IPv4 branch where
        // `is_private()` rejects it.
        let mapped: IpAddr = "::ffff:10.0.0.1".parse().unwrap_or_else(|_| std::process::abort());
        assert!(!PublicAddressClassifier.is_globally_routable(mapped));
        // Sanity: a public IPv4-mapped stays public.
        let public_mapped: IpAddr =
            "::ffff:8.8.8.8".parse().unwrap_or_else(|_| std::process::abort());
        assert!(PublicAddressClassifier.is_globally_routable(public_mapped));
    }

    #[test]
    fn ipv4_rules_locked() {
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V4(Ipv4Addr::LOCALHOST)));
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1))));
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V4(Ipv4Addr::new(192, 168, 1, 1))));
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V4(Ipv4Addr::new(169, 254, 0, 1))));
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V4(Ipv4Addr::new(0, 0, 0, 0))));
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V4(Ipv4Addr::BROADCAST)));
        assert!(PublicAddressClassifier.is_globally_routable(IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8))));
    }

    #[test]
    fn ipv6_rules_locked() {
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V6(Ipv6Addr::LOCALHOST)));
        assert!(!PublicAddressClassifier.is_globally_routable(IpAddr::V6(Ipv6Addr::UNSPECIFIED)));
        // fc00::/7 — unique local
        assert!(!PublicAddressClassifier.is_globally_routable(
            IpAddr::V6(Ipv6Addr::new(0xfc00, 0, 0, 0, 0, 0, 0, 1))
        ));
        // fe80::/10 — link-local
        assert!(!PublicAddressClassifier.is_globally_routable(
            IpAddr::V6(Ipv6Addr::new(0xfe80, 0, 0, 0, 0, 0, 0, 1))
        ));
        // 2001:db8::/32 — documentation prefix, conventionally
        // treated as non-routable on the public internet; for
        // our purposes the broader "not in any private bucket"
        // rule treats it as public. We only assert that real
        // public addresses pass.
        assert!(PublicAddressClassifier.is_globally_routable(
            IpAddr::V6(Ipv6Addr::new(0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 1))
        ));
    }
}
