//! Subscription fetch, parse and transform infrastructure.

mod chain;
mod clash;
mod format;
mod http;
mod mihomo;
mod normalize;
mod pipeline;
mod policy;
mod sing_box;
mod special_uri;
mod transform;
mod uri;
mod userinfo;

pub use chain::{ChainError, validate_chains};
pub use clash::{ClashParseError, parse_clash_yaml};
pub use format::{
    FormatError, SubscriptionBody, SubscriptionDocument, SubscriptionFormat, SubscriptionLine,
    SubscriptionLines, decode_document,
};
pub use http::{FetchError, FetchResult, FetchValidators, fetch_pinned};
pub use mihomo::{
    MAX_MIHOMO_PROXIES, MihomoGroupName, MihomoProxyEntry, MihomoProxyError, MihomoProxySet,
    MihomoProxyTag, MihomoProxyYaml, render_proxy_sections, render_proxy_sections_from,
    render_proxy_sections_with_rules, uri_body_to_mihomo_proxy_set,
};
pub use normalize::{NormalizeError, derive_tags, normalize_display_name};
pub use pipeline::{
    DedupeResult, NodeIds, PipelineError, SubscriptionDiff, SubscriptionNodes,
    SubscriptionProjection, dedupe, diff, parse_uri_body_to_display,
    parse_uri_body_to_display_lossy,
};
pub use policy::{
    AddressClassifier, FetchPolicy, MAX_REDIRECT_DEPTH, ResolutionError, ResolvedAddresses,
    SubscriptionScheme, validate_resolved,
};
mod sip008;

pub use sing_box::{
    SingBoxOutboundError, SingBoxRenderTuning, sing_box_document, uri_body_to_sing_box_json,
    uri_body_to_sing_box_json_with, uri_body_to_sing_box_outbound_map,
};
pub use sip008::parse_sip008;
pub use transform::{
    TransformFingerprint, TransformInputs, TransformRule, TransformRules, fingerprint,
    should_retransform,
};
pub use uri::{UriParseError, parse_any_proxy_uri, parse_proxy_uri};
pub use userinfo::{SubscriptionUserInfo, parse_subscription_userinfo, render_usage_human};
