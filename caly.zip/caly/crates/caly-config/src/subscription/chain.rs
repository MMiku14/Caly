//! Iterative chained-dial dependency validation.

use std::collections::BTreeMap;

use caly_domain::NodeId;

use super::SubscriptionNodes;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ChainError {
    MissingDependency { node: NodeId, dependency: NodeId },
    Cycle { node: NodeId },
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum Visit {
    Visiting,
    Complete,
}

/// Rejects missing dialer references and cycles without recursive stack growth.
pub fn validate_chains(nodes: &SubscriptionNodes) -> Result<(), ChainError> {
    let dependencies: BTreeMap<_, _> = nodes
        .iter()
        .map(|node| (node.id(), node.dialer_proxy().copied()))
        .collect();
    for (&node, dependency) in &dependencies {
        if let Some(dependency) = dependency
            && !dependencies.contains_key(dependency)
        {
            return Err(ChainError::MissingDependency {
                node,
                dependency: *dependency,
            });
        }
    }
    let mut visits = BTreeMap::new();
    for &start in dependencies.keys() {
        walk_chain(start, &dependencies, &mut visits)?;
    }
    Ok(())
}

fn walk_chain(
    start: NodeId,
    dependencies: &BTreeMap<NodeId, Option<NodeId>>,
    visits: &mut BTreeMap<NodeId, Visit>,
) -> Result<(), ChainError> {
    if visits.get(&start) == Some(&Visit::Complete) {
        return Ok(());
    }
    let mut path = Vec::new();
    let mut current = Some(start);
    while let Some(node) = current {
        match visits.get(&node) {
            Some(Visit::Visiting) => return Err(ChainError::Cycle { node }),
            Some(Visit::Complete) => break,
            None => {
                visits.insert(node, Visit::Visiting);
                path.push(node);
                current = dependencies.get(&node).copied().flatten();
            }
        }
    }
    for node in path {
        visits.insert(node, Visit::Complete);
    }
    Ok(())
}
