//! sing-box subscription document header rendering with config-driven tuning.

use caly_domain::SubscriptionId;
use serde_json::{Map, Value, json};

use caly_domain::DialableNode;

use super::{SingBoxOutboundError, decode_document, dialable_nodes, node_to_json};

/// Runtime values rendered into the sing-box subscription document header.
/// The bools are independent render switches (inbound binding, sniffing,
/// REJECT support), kept flat to mirror the document fields they emit.
#[derive(Clone, Debug)]
#[allow(clippy::struct_excessive_bools)]
pub struct SingBoxRenderTuning {
    /// `external_controller` address (host:port).
    pub controller: String,
    /// Controller auth secret; empty omits the field.
    pub secret: String,
    /// Kernel log level (sing-box understands trace|debug|info|warn|error).
    pub log_level: String,
    /// Mixed inbound port; 0 renders no inbound.
    pub mixed_port: u16,
    /// Bind the inbound to LAN instead of loopback only.
    pub allow_lan: bool,
    /// LAN bind address when `allow_lan` is true (`"*"` = all interfaces).
    pub bind_address: String,
    /// Optional TUN inbound (stack/auto-route/strict-route from config).
    pub tun: Option<caly_domain::TunConfig>,
    /// Interface name for the TUN inbound.
    pub tun_interface: String,
    /// Pre-rendered sing-box `dns` object (JSON); `None` omits the block.
    pub dns_json: Option<String>,
    /// Resolver tag to wire into `route.default_domain_resolver` when the DNS
    /// block references a domain-hosted server.
    pub dns_resolver_tag: Option<String>,
    /// Render `sniff: true` on the mixed inbound (domain recovery).
    pub sniff: bool,
    /// Render `sniff_override_destination: true` alongside sniffing.
    pub sniff_override_destination: bool,
    /// Pre-rendered `route.rules` JSON array appended after the `clash_mode`
    /// rules; `None` adds nothing (shared rule renderer output).
    pub route_rules_json: Option<String>,
    /// Pre-rendered `route.rule_set` source array (remote geo rule-sets);
    /// `None` omits the key.
    pub rule_sets_json: Option<String>,
    /// Outbound tag for `route.final` (MATCH semantics; defaults to `PROXY`).
    pub route_final: String,
    /// Add the built-in `block` outbound (required by REJECT rules).
    pub block_outbound: bool,
}

impl SingBoxRenderTuning {
    /// Document-header defaults matching historical behavior.
    pub fn standard() -> Self {
        Self {
            controller: "127.0.0.1:9091".to_owned(),
            secret: String::new(),
            log_level: "error".to_owned(),
            mixed_port: 7890,
            allow_lan: false,
            bind_address: "*".to_owned(),
            tun: None,
            tun_interface: String::new(),
            dns_json: None,
            dns_resolver_tag: None,
            sniff: false,
            sniff_override_destination: false,
            route_rules_json: None,
            rule_sets_json: None,
            route_final: "PROXY".to_owned(),
            block_outbound: false,
        }
    }
}

/// Accepts the generic kernel levels; anything unknown falls back to error.
fn sing_box_log_level(level: &str) -> &'static str {
    match level {
        "trace" | "debug" | "info" | "warn" | "error" => match level {
            "trace" => "trace",
            "debug" => "debug",
            "info" => "info",
            "warn" => "warn",
            _ => "error",
        },
        _ => "error",
    }
}

/// Generates a bounded sing-box JSON document from URI subscription lines.
pub fn uri_body_to_sing_box_json(
    body: Vec<u8>,
    subscription: SubscriptionId,
) -> Result<Vec<u8>, SingBoxOutboundError> {
    uri_body_to_sing_box_json_with(body, subscription, &SingBoxRenderTuning::standard())
}

/// Generates the document with config-driven header tuning (controller, secret,
/// log level, mixed inbound).
pub fn uri_body_to_sing_box_json_with(
    body: Vec<u8>,
    subscription: SubscriptionId,
    tuning: &SingBoxRenderTuning,
) -> Result<Vec<u8>, SingBoxOutboundError> {
    let document = decode_document(body).map_err(|_| SingBoxOutboundError::InvalidFormat)?;
    let nodes = dialable_nodes(document, subscription)?;
    let outbounds = nodes_to_outbounds(nodes)?;
    sing_box_document(tuning, outbounds)
}

/// Assembles the full sing-box document around a caller-supplied outbound
/// list: adds the direct/block outbounds, the PROXY/GLOBAL selectors, and the
/// config-driven route/inbounds/clash_api/DNS blocks. Shared by the
/// subscription-document renderer and the config backend (which rebuilds the
/// outbound list from the shared registry instead of re-parsing a body).
pub fn sing_box_document(
    tuning: &SingBoxRenderTuning,
    subscription_outbounds: Vec<Value>,
) -> Result<Vec<u8>, SingBoxOutboundError> {
    let mut outbounds = subscription_outbounds;
    let tags: Vec<String> = outbounds
        .iter()
        .filter_map(|value| value.get("tag").and_then(Value::as_str).map(str::to_owned))
        .collect();
    outbounds.push(json!({ "type": "direct", "tag": "direct" }));
    if tuning.block_outbound {
        outbounds.push(json!({ "type": "block", "tag": "block" }));
    }
    append_selectors(&mut outbounds, &tags);
    let route = build_route(tuning);
    let inbounds = render_document_inbounds(tuning);
    let mut clash_api = Map::new();
    clash_api.insert(
        "external_controller".to_owned(),
        Value::String(tuning.controller.clone()),
    );
    if !tuning.secret.is_empty() {
        clash_api.insert("secret".to_owned(), Value::String(tuning.secret.clone()));
    }
    let mut value = json!({
        "log": { "level": sing_box_log_level(&tuning.log_level) },
        "inbounds": inbounds,
        "outbounds": outbounds,
        "route": route,
        "experimental": { "clash_api": Value::Object(clash_api) }
    });
    // The DNS block arrives pre-rendered (bounded domain model → sing-box
    // object); a fragment that fails to re-parse is dropped, never fatal.
    if let Some(dns_json) = &tuning.dns_json
        && let Ok(dns_value) = serde_json::from_str::<Value>(dns_json)
    {
        value["dns"] = dns_value;
    }
    serde_json::to_vec(&value).map_err(|_| SingBoxOutboundError::Serialization)
}

/// Renders deduplicated outbounds from parsed dialable nodes, skipping nodes
/// the strict sing-box renderer cannot represent.
fn nodes_to_outbounds(nodes: Vec<DialableNode>) -> Result<Vec<Value>, SingBoxOutboundError> {
    let mut outbounds = Vec::new();
    // Deduplicate by canonical node identity: a subscription can carry two
    // lines that normalize to the same NodeId, and sing-box rejects duplicate
    // outbound tags (`proxy-<id>`). This mirrors the Mihomo registry path.
    let mut seen = std::collections::HashSet::new();
    for node in nodes {
        if !seen.insert(node.id()) {
            continue;
        }
        // A real subscription mixes protocols; skip nodes the strict sing-box
        // renderer cannot represent rather than failing the whole render.
        match node_to_json(&node) {
            Ok(outbound) => outbounds.push(outbound),
            Err(SingBoxOutboundError::UnsupportedNode) => {}
            Err(error) => return Err(error),
        }
    }
    Ok(outbounds)
}

/// Appends the standard PROXY/GLOBAL selector outbounds over the node tags.
fn append_selectors(outbounds: &mut Vec<Value>, tags: &[String]) {
    let members = tags
        .iter()
        .chain(std::iter::once(&"direct".to_owned()))
        .cloned()
        .collect::<Vec<_>>();
    outbounds.push(json!({ "type": "selector", "tag": "PROXY", "outbounds": members }));
    outbounds.push(json!({ "type": "selector", "tag": "GLOBAL", "outbounds": members }));
}

/// Builds the `route` block: clash_mode rules plus config-driven extras.
fn build_route(tuning: &SingBoxRenderTuning) -> Value {
    // Emit the standard Clash `clash_mode` routing rules so the runtime
    // `mode` switch (rule/global/direct) is available through the Clash API.
    // Without them sing-box's `/configs` reports `mode-list: ["rule"]` only.
    let mut route_rules = vec![
        json!({ "clash_mode": "Global", "outbound": "GLOBAL" }),
        json!({ "clash_mode": "Direct", "outbound": "direct" }),
    ];
    if let Some(rules_json) = &tuning.route_rules_json
        && let Ok(Value::Array(extra)) = serde_json::from_str::<Value>(rules_json)
    {
        route_rules.extend(extra);
    }
    let mut route = json!({
        "rules": route_rules,
        "final": tuning.route_final
    });
    if let Some(rule_sets_json) = &tuning.rule_sets_json
        && let Ok(Value::Array(sources)) = serde_json::from_str::<Value>(rule_sets_json)
        && !sources.is_empty()
    {
        route["rule_set"] = Value::Array(sources);
    }
    if let Some(tag) = &tuning.dns_resolver_tag {
        route["default_domain_resolver"] = Value::String(tag.clone());
    }
    route
}

/// Renders the document inbounds: the config-driven mixed listener and the
/// optional TUN inbound.
fn render_document_inbounds(tuning: &SingBoxRenderTuning) -> Vec<Value> {
    let mut inbounds: Vec<Value> = Vec::new();
    if tuning.mixed_port != 0 {
        let listen = if !tuning.allow_lan {
            "127.0.0.1"
        } else if tuning.bind_address == "*" || tuning.bind_address.is_empty() {
            "0.0.0.0"
        } else {
            tuning.bind_address.as_str()
        };
        let mut inbound = json!({
            "type": "mixed",
            "tag": "caly-mixed-in",
            "listen": listen,
            "listen_port": tuning.mixed_port
        });
        if tuning.sniff {
            inbound["sniff"] = Value::Bool(true);
            if tuning.sniff_override_destination {
                inbound["sniff_override_destination"] = Value::Bool(true);
            }
        }
        inbounds.push(inbound);
    }
    if let Some(tun) = &tuning.tun {
        inbounds.push(json!({
            "type": "tun",
            "tag": "tun-in",
            "interface_name": tuning.tun_interface,
            "address": ["172.18.0.1/30", "fdfe:dcba:9876::1/126"],
            "mtu": tun.mtu(),
            "auto_route": tun.auto_route(),
            "strict_route": tun.strict_route(),
            "stack": tun.stack().label()
        }));
    }
    inbounds
}

#[cfg(test)]
mod document_tests {
    use super::*;

    fn ss_uri(name: &str) -> String {
        use base64::{Engine as _, engine::general_purpose};
        let credentials = general_purpose::STANDARD.encode("aes-256-gcm:pw");
        format!("ss://{credentials}@example.com:8388#{name}")
    }

    #[test]
    fn document_renders_tun_inbound_and_dns_block() {
        use caly_domain::{TunConfig, TunStack};
        // A pre-rendered `dns` object fragment as the kernel renderer emits it;
        // the document embeds it verbatim (caly-config cannot depend on
        // caly-kernel, so the test supplies the fragment directly).
        let dns_json = r#"{"servers":[{"type":"udp","tag":"nameserver-0","server":"8.8.8.8"}],"final":"nameserver-0"}"#.to_owned();
        let resolver = Some("nameserver-0".to_owned());
        let tun = TunConfig::new(TunStack::Gvisor, true, true, 1400)
            .unwrap_or_else(|_| std::process::abort());
        let tuning = SingBoxRenderTuning {
            controller: "127.0.0.1:9291".to_owned(),
            secret: "topsecret".to_owned(),
            log_level: "warn".to_owned(),
            mixed_port: 8899,
            allow_lan: false,
            bind_address: "*".to_owned(),
            tun: Some(tun),
            tun_interface: "caly0".to_owned(),
            dns_json: Some(dns_json),
            dns_resolver_tag: resolver,
            sniff: true,
            sniff_override_destination: true,
            route_rules_json: Some(
                r#"[{"domain_suffix":["example.com"],"outbound":"block"}]"#.to_owned(),
            ),
            rule_sets_json: None,
            route_final: "block".to_owned(),
            block_outbound: true,
        };
        let body = ss_uri("node-a").into_bytes();
        let json =
            uri_body_to_sing_box_json_with(body, SubscriptionId::from_bytes([1; 16]), &tuning)
                .unwrap_or_else(|error| {
                    eprintln!("render failed: {error:?}");
                    std::process::abort()
                });
        let value: Value = serde_json::from_slice(&json).unwrap_or_else(|_| std::process::abort());
        let inbounds = value["inbounds"]
            .as_array()
            .unwrap_or_else(|| std::process::abort());
        assert_eq!(inbounds.len(), 2, "mixed + tun inbounds expected");
        assert_eq!(inbounds[0]["listen_port"], 8899);
        assert_eq!(inbounds[0]["sniff"], true);
        assert_eq!(inbounds[0]["sniff_override_destination"], true);
        assert_eq!(inbounds[1]["type"], "tun");
        assert_eq!(inbounds[1]["interface_name"], "caly0");
        assert_eq!(inbounds[1]["mtu"], 1400);
        assert!(value["dns"]["servers"].is_array());
        assert_eq!(value["route"]["default_domain_resolver"], "nameserver-0");
        assert_eq!(value["experimental"]["clash_api"]["secret"], "topsecret");
        assert_eq!(value["log"]["level"], "warn");
        // Route rules: clash_mode entries first, then config-driven rules.
        let rules = value["route"]["rules"]
            .as_array()
            .unwrap_or_else(|| std::process::abort());
        assert_eq!(rules.len(), 3);
        assert_eq!(rules[2]["domain_suffix"][0], "example.com");
        assert_eq!(rules[2]["outbound"], "block");
        assert_eq!(value["route"]["final"], "block");
        let outbound_tags: Vec<&str> = value["outbounds"]
            .as_array()
            .unwrap_or_else(|| std::process::abort())
            .iter()
            .filter_map(|outbound| outbound["tag"].as_str())
            .collect();
        assert!(outbound_tags.contains(&"block"));
    }

    #[test]
    fn standard_tuning_keeps_historical_defaults() {
        let tuning = SingBoxRenderTuning::standard();
        assert_eq!(tuning.controller, "127.0.0.1:9091");
        assert_eq!(tuning.mixed_port, 7890);
        assert!(tuning.dns_json.is_none());
    }
}
