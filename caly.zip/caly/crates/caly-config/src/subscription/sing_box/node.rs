//! sing-box node outbound rendering: protocol fields, TLS, reality, transport.
//!
//! Kept separate from `document.rs` (document assembly) so each file stays
//! within the project's line limits.

use caly_domain::{DialableNode, Protocol, ShadowsocksCipher, VmessCipher};
use serde_json::{Map, Value, json};

use super::SingBoxOutboundError;

pub fn node_to_json(node: &DialableNode) -> Result<Value, SingBoxOutboundError> {
    let id_text = caly_domain::to_hex(node.id().into_bytes());
    let tag = format!("proxy-{id_text}");
    let mut map = Map::new();
    map.insert("tag".to_owned(), Value::String(tag));
    map.insert(
        "server".to_owned(),
        Value::String(node.endpoint().host().as_str().to_owned()),
    );
    map.insert(
        "server_port".to_owned(),
        json!(node.endpoint().port().get()),
    );
    fill_protocol_fields(node, &mut map)?;
    Ok(Value::Object(map))
}

/// Renders one node as a compact JSON object string (tag `proxy-<id>`), the
/// per-node form stored by the shared registry so config backends can rebuild
/// the outbounds array without re-parsing the subscription body.
pub fn node_to_json_string(node: &DialableNode) -> Result<String, SingBoxOutboundError> {
    serde_json::to_string(&node_to_json(node)?).map_err(|_| SingBoxOutboundError::Serialization)
}

/// Fills the protocol-specific outbound fields (type, credentials, TLS,
/// transport) into the shared `tag`/`server` map.
fn fill_protocol_fields(
    node: &DialableNode,
    map: &mut Map<String, Value>,
) -> Result<(), SingBoxOutboundError> {
    match node.protocol() {
        Protocol::Vless { user_id, flow } => fill_vless(node, user_id, flow.as_ref(), map),
        Protocol::Trojan { password } => fill_trojan(node, password, map),
        Protocol::Vmess {
            user_id,
            alter_id,
            security,
        } => fill_vmess(node, user_id, *alter_id, *security, map),
        Protocol::Shadowsocks {
            password, method, ..
        } => {
            let Some(label) = ss_method(*method) else {
                return Err(SingBoxOutboundError::UnsupportedNode);
            };
            fill_shadowsocks(password, label, map);
        }
        Protocol::Hysteria2 {
            password,
            up_mbps,
            down_mbps,
            obfuscation,
        } => render_hysteria2(
            password,
            *up_mbps,
            *down_mbps,
            obfuscation.as_ref(),
            map,
            node,
        ),
        Protocol::Tuic {
            user_id,
            password,
            congestion,
        } => render_tuic(user_id, password, *congestion, map, node),
        _ => return Err(SingBoxOutboundError::UnsupportedNode),
    }
    Ok(())
}

/// Fills a sing-box `vless` outbound (uuid, optional XTLS flow, TLS, transport).
fn fill_vless(
    node: &DialableNode,
    user_id: &caly_domain::Credential,
    flow: Option<&caly_domain::ProtocolText>,
    map: &mut Map<String, Value>,
) {
    map.insert("type".to_owned(), Value::String("vless".to_owned()));
    user_id.with_exposed(|value| {
        map.insert("uuid".to_owned(), Value::String(value.to_owned()));
    });
    // XTLS flow must be carried, otherwise the sing-box config is incomplete
    // and the outbound cannot establish the handshake.
    if let Some(flow) = flow {
        map.insert("flow".to_owned(), Value::String(flow.as_str().to_owned()));
    }
    apply_tls(node, map);
    apply_transport(node, map);
}

/// Fills a sing-box `trojan` outbound (password, TLS, transport).
fn fill_trojan(
    node: &DialableNode,
    password: &caly_domain::Credential,
    map: &mut Map<String, Value>,
) {
    map.insert("type".to_owned(), Value::String("trojan".to_owned()));
    password.with_exposed(|value| {
        map.insert("password".to_owned(), Value::String(value.to_owned()));
    });
    // Trojan almost always runs over TLS; without it the outbound is
    // incomplete. Also honour an explicit ws transport.
    apply_tls(node, map);
    apply_transport(node, map);
}

/// Fills a sing-box `vmess` outbound (uuid, alterId, security, TLS, transport).
fn fill_vmess(
    node: &DialableNode,
    user_id: &caly_domain::Credential,
    alter_id: u16,
    security: caly_domain::VmessCipher,
    map: &mut Map<String, Value>,
) {
    map.insert("type".to_owned(), Value::String("vmess".to_owned()));
    user_id.with_exposed(|value| {
        map.insert("uuid".to_owned(), Value::String(value.to_owned()));
    });
    map.insert("alter_id".to_owned(), json!(alter_id));
    map.insert(
        "security".to_owned(),
        Value::String(vmess_cipher(security).to_owned()),
    );
    apply_tls(node, map);
    apply_transport(node, map);
}

/// Fills a sing-box `shadowsocks` outbound (method label, password).
fn fill_shadowsocks(
    password: &caly_domain::Credential,
    method_label: &str,
    map: &mut Map<String, Value>,
) {
    map.insert("type".to_owned(), Value::String("shadowsocks".to_owned()));
    map.insert("method".to_owned(), Value::String(method_label.to_owned()));
    password.with_exposed(|value| {
        map.insert("password".to_owned(), Value::String(value.to_owned()));
    });
}

/// Fills a sing-box `hysteria2` outbound (type, password, optional up/down and
/// salamander obfuscation, and TLS).
fn render_hysteria2(
    password: &caly_domain::Credential,
    up_mbps: Option<u32>,
    down_mbps: Option<u32>,
    obfuscation: Option<&caly_domain::Credential>,
    map: &mut Map<String, Value>,
    node: &DialableNode,
) {
    map.insert("type".to_owned(), Value::String("hysteria2".to_owned()));
    password.with_exposed(|value| {
        map.insert("password".to_owned(), Value::String(value.to_owned()));
    });
    if let Some(up) = up_mbps {
        map.insert("up_mbps".to_owned(), json!(up));
    }
    if let Some(down) = down_mbps {
        map.insert("down_mbps".to_owned(), json!(down));
    }
    if let Some(obfs) = obfuscation {
        obfs.with_exposed(|value| {
            map.insert(
                "obfs".to_owned(),
                json!({ "type": "salamander", "password": value }),
            );
        });
    }
    apply_tls(node, map);
    ensure_tls(map, node);
}

/// hysteria2 and tuic are TLS-only transports; sing-box rejects an outbound
/// without a `tls` block even when the URI carries no explicit SNI. Emit a
/// block keyed by the SNI when present, otherwise by the server host.
fn ensure_tls(map: &mut Map<String, Value>, node: &DialableNode) {
    if map.contains_key("tls") {
        return;
    }
    let server_name = node.tls().and_then(|tls| tls.sni()).map_or_else(
        || node.endpoint().host().as_str().to_owned(),
        |sni| sni.as_str().to_owned(),
    );
    map.insert(
        "tls".to_owned(),
        json!({ "enabled": true, "server_name": server_name }),
    );
}

/// Fills a sing-box `tuic` outbound (uuid, password, congestion control, TLS).
fn render_tuic(
    user_id: &caly_domain::Credential,
    password: &caly_domain::Credential,
    congestion: caly_domain::CongestionControl,
    map: &mut Map<String, Value>,
    node: &DialableNode,
) {
    map.insert("type".to_owned(), Value::String("tuic".to_owned()));
    user_id.with_exposed(|value| {
        map.insert("uuid".to_owned(), Value::String(value.to_owned()));
    });
    password.with_exposed(|value| {
        map.insert("password".to_owned(), Value::String(value.to_owned()));
    });
    map.insert(
        "congestion_control".to_owned(),
        Value::String(congestion_label(congestion).to_owned()),
    );
    apply_tls(node, map);
    ensure_tls(map, node);
}

/// Emits sing-box `tls`/`reality` settings when the node carries TLS.
///
/// `enabled: true` is mandatory: without it this sing-box line constructs a
/// nil TLS config and every outbound TLS handshake panics with a nil pointer
/// dereference in `ClientHandshake` — the reason the same subscription works
/// in v2rayN (Xray) but every TLS node died in caly.
fn apply_tls(node: &DialableNode, map: &mut Map<String, Value>) {
    let Some(tls) = node.tls() else {
        return;
    };
    let mut tls_map = Map::new();
    tls_map.insert("enabled".to_owned(), json!(true));
    if let Some(sni) = tls.sni() {
        tls_map.insert(
            "server_name".to_owned(),
            Value::String(sni.as_str().to_owned()),
        );
    }
    if tls.allow_insecure() {
        tls_map.insert("insecure".to_owned(), json!(true));
    }
    // Reality (and browser-mimicking TLS) handshakes need a uTLS fingerprint:
    // without it sing-box dials with the Go standard-library fingerprint,
    // which Reality servers reject (and this sing-box release panics on the
    // nil uTLS config). The `fp` URI parameter is preserved end-to-end;
    // unknown labels fall back to `random` so a weird subscription value
    // can never produce an invalid outbound.
    if let Some(fingerprint) = tls.fingerprint() {
        tls_map.insert(
            "utls".to_owned(),
            json!({ "enabled": true, "fingerprint": sing_box_fingerprint(fingerprint.as_str()) }),
        );
    }
    // Reality handshake identity must be preserved, otherwise the outbound
    // cannot complete the handshake even though TLS is enabled.
    if let Some(reality) = tls.reality() {
        let mut reality_map = Map::new();
        reality.public_key().with_exposed(|key| {
            reality_map.insert("public_key".to_owned(), Value::String(key.to_owned()));
        });
        if let Some(sid) = reality.short_id() {
            sid.with_exposed(|sid| {
                reality_map.insert("short_id".to_owned(), Value::String(sid.to_owned()));
            });
        }
        // sing-box Reality has no `spider_x` field (unlike Clash Meta's
        // `spider-x`); emitting it makes `sing-box check` reject the document.
        tls_map.insert("reality".to_owned(), Value::Object(reality_map));
    }
    map.insert("tls".to_owned(), Value::Object(tls_map));
}

/// Emits sing-box `transport` settings when the node uses a pluggable framing.
fn apply_transport(node: &DialableNode, map: &mut Map<String, Value>) {
    let Some(transport) = node.transport() else {
        return;
    };
    let mut transport_map = Map::new();
    match transport {
        caly_domain::Transport::Tcp => {}
        caly_domain::Transport::WebSocket { path, host } => {
            transport_map.insert("type".to_owned(), Value::String("ws".to_owned()));
            transport_map.insert("path".to_owned(), Value::String(path.as_str().to_owned()));
            if let Some(host) = host {
                transport_map.insert("headers".to_owned(), json!({ "Host": host.as_str() }));
            }
        }
        caly_domain::Transport::Grpc { service_name } => {
            transport_map.insert("type".to_owned(), Value::String("grpc".to_owned()));
            transport_map.insert(
                "service_name".to_owned(),
                Value::String(service_name.as_str().to_owned()),
            );
        }
        caly_domain::Transport::Http2 { path, hosts } => {
            transport_map.insert("type".to_owned(), Value::String("httpupgrade".to_owned()));
            transport_map.insert("path".to_owned(), Value::String(path.as_str().to_owned()));
            if let Some(host) = hosts.iter().next() {
                transport_map.insert("host".to_owned(), Value::String(host.as_str().to_owned()));
            }
        }
        caly_domain::Transport::Quic => {
            transport_map.insert("type".to_owned(), Value::String("quic".to_owned()));
        }
    }
    if !transport_map.is_empty() {
        map.insert("transport".to_owned(), Value::Object(transport_map));
    }
}

/// Maps a subscription fingerprint label onto the sing-box uTLS enum.
/// Known labels pass through; anything unknown falls back to `random` so an
/// exotic subscription value can never yield an invalid outbound.
fn sing_box_fingerprint(label: &str) -> &'static str {
    match label {
        "chrome" => "chrome",
        "firefox" => "firefox",
        "safari" => "safari",
        "ios" => "ios",
        "edge" => "edge",
        "random" => "random",
        "randomized" => "randomized",
        _ => "random",
    }
}

/// Maps a Domain VMess cipher to its sing-box cipher label.
fn vmess_cipher(cipher: VmessCipher) -> &'static str {
    match cipher {
        VmessCipher::Auto => "auto",
        VmessCipher::Aes128Gcm => "aes-128-gcm",
        VmessCipher::Chacha20Poly1305 => "chacha20-poly1305",
        VmessCipher::None => "none",
    }
}

/// Maps a Shadowsocks cipher to its sing-box label; `None` is returned for
/// ciphers sing-box cannot dial (e.g. legacy `aes-128-cfb`), so the node is
/// skipped instead of producing a rejected document.
fn ss_method(cipher: ShadowsocksCipher) -> Option<&'static str> {
    match cipher {
        ShadowsocksCipher::Aes128Gcm => Some("aes-128-gcm"),
        ShadowsocksCipher::Aes256Gcm => Some("aes-256-gcm"),
        ShadowsocksCipher::Chacha20IetfPoly1305 => Some("chacha20-ietf-poly1305"),
        ShadowsocksCipher::Xchacha20IetfPoly1305 => Some("xchacha20-ietf-poly1305"),
        ShadowsocksCipher::None => Some("none"),
        ShadowsocksCipher::Aes128Cfb | ShadowsocksCipher::Aes256Cfb => None,
    }
}

/// Maps a Domain congestion-control choice to its sing-box label.
fn congestion_label(congestion: caly_domain::CongestionControl) -> &'static str {
    match congestion {
        caly_domain::CongestionControl::Bbr => "bbr",
        caly_domain::CongestionControl::Cubic => "cubic",
        caly_domain::CongestionControl::NewReno => "new_reno",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{DialableNode, SubscriptionId};

    fn node_from_uri(uri: &str) -> Result<DialableNode, String> {
        let subscription = SubscriptionId::from_bytes([9; 16]);
        crate::subscription::uri::parse_any_proxy_uri(uri, subscription)
            .map_err(|e| format!("{e:?}"))
    }

    fn rendered(node: &DialableNode) -> Value {
        match node_to_json(node) {
            Ok(json) => json,
            Err(error) => {
                assert!(false, "render must succeed: {error:?}");
                Default::default()
            }
        }
    }

    #[test]
    fn reality_fingerprint_renders_utls_block() -> Result<(), String> {
        let uri = "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=reality&sni=example.com&fp=chrome&pbk=zT7a-PnmIWP4c-G1EDUT3KZ7URi1kc8EppAWPr3h5lk";
        let node = node_from_uri(uri)?;
        let json = rendered(&node);
        let utls = json["tls"]["utls"].clone();
        assert_eq!(utls["enabled"], json!(true));
        assert_eq!(utls["fingerprint"], json!("chrome"));
        assert!(json["tls"]["reality"]["public_key"].is_string());
        Ok(())
    }

    #[test]
    fn unknown_fingerprint_falls_back_to_random() -> Result<(), String> {
        let uri = "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=reality&sni=example.com&fp=qq&pbk=zT7a-PnmIWP4c-G1EDUT3KZ7URi1kc8EppAWPr3h5lk";
        let node = node_from_uri(uri)?;
        let json = rendered(&node);
        assert_eq!(json["tls"]["utls"]["fingerprint"], json!("random"));
        Ok(())
    }

    #[test]
    fn no_fp_param_renders_no_utls_block() -> Result<(), String> {
        let uri = "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=tls&sni=example.com";
        let node = node_from_uri(uri)?;
        let json = rendered(&node);
        assert!(json["tls"]["utls"].is_null(), "no fp means no utls block");
        Ok(())
    }

    #[test]
    fn fingerprint_mapping_is_total() {
        assert_eq!(sing_box_fingerprint("chrome"), "chrome");
        assert_eq!(sing_box_fingerprint("firefox"), "firefox");
        assert_eq!(sing_box_fingerprint("edge"), "edge");
        assert_eq!(sing_box_fingerprint("random"), "random");
        assert_eq!(sing_box_fingerprint("qq"), "random");
        assert_eq!(sing_box_fingerprint(""), "random");
    }
}

#[cfg(test)]
mod tls_enabled_tests {
    use super::*;
    use caly_domain::{DialableNode, SubscriptionId};

    #[test]
    fn tls_block_always_has_enabled_true() -> Result<(), String> {
        let subscription = SubscriptionId::from_bytes([11; 16]);
        for uri in [
            "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=reality&sni=example.com&fp=chrome&pbk=zT7a-PnmIWP4c-G1EDUT3KZ7URi1kc8EppAWPr3h5lk",
            "vless://a5ea9247-79f3-4655-aece-3fb51e1e669e@example.com:443?security=tls&sni=example.com",
        ] {
            let node = crate::subscription::uri::parse_any_proxy_uri(uri, subscription)
                .map_err(|e| format!("{e:?}"))?;
            let json = match node_to_json(&node) {
                Ok(json) => json,
                Err(error) => {
                    assert!(false, "render: {error:?}");
                    Default::default()
                }
            };
            assert_eq!(
                json["tls"]["enabled"],
                json!(true),
                "tls block must carry enabled:true (nil-config panic guard): {json}"
            );
        }
        Ok(())
    }
}
