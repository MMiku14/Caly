//! Configuration infrastructure for caly.
//!
//! Candidate parsing, subscription policy, generation caches and process-based
//! template rendering live here. Application coordinators own publication.

#![forbid(unsafe_code)]

pub mod cache;
pub mod loader;
pub mod profile_fetch;
pub mod profile_store;
pub mod rule_match;
pub mod rule_render;
pub mod schema;
pub mod subscription;
pub mod template_worker;
