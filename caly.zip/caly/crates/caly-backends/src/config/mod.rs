//! ConfigActor backends: Mihomo and sing-box config rendering, real-kernel
//! validation and atomic generation publication (see `mod.rs` for the shared
//! transaction shape and `sing_box.rs` for the sing-box twin).
use caly_config::loader::{LayeredConfigPaths, LoaderLimits, load_layered_yaml};
use caly_config::subscription::render_proxy_sections_with_rules_and_providers;
use caly_kernel::{
    mihomo::{MihomoConfigRenderer, MihomoConfigSettings, MihomoSpawnSpecFactory},
    ports::SpawnSpecFactory,
    validation::{CoreValidator, LinuxCommandValidator, ValidationReport},
};
use caly_platform::{
    command::LinuxCommandRunner,
    fs::{AtomicFileContents, AtomicWritePlan, LinuxAtomicFileBackend, atomic_write},
    paths::{AppPaths, SafeName},
};
use caly_ports::{ActorFailure, CommittedConfig, ConfigActorPort, ConfigCandidate, PreparedConfig};
use std::{
    collections::{BTreeMap, HashMap},
    path::PathBuf,
    time::Duration,
};

use super::failure;

/// Maximum committed generations retained in memory for rollback; older
/// generations are dropped (the on-disk current generation stays authoritative).
pub const MAX_CONFIG_HISTORY: usize = 3;

/// Maps the schema TUN settings (layered config) to the domain TUN intent,
/// or `None` when TUN is disabled. Shared by the daemon boot resolution and
/// the per-apply re-read so both stay in sync.
pub fn tun_config_from_schema(
    config: &caly_config::schema::AppConfig,
) -> Option<caly_domain::TunConfig> {
    if !config.tun.enabled {
        return None;
    }
    let stack = match config.tun.stack {
        caly_config::schema::TunStack::Gvisor => caly_domain::TunStack::Gvisor,
        caly_config::schema::TunStack::Mixed => caly_domain::TunStack::Mixed,
        caly_config::schema::TunStack::System => caly_domain::TunStack::System,
    };
    caly_domain::TunConfig::new(
        stack,
        config.tun.auto_route,
        config.tun.strict_route,
        config.tun.mtu,
    )
    .ok()
}

/// Re-reads the TUN tuning from the layered config (env profile + config.d),
/// mirroring the subscription-URL re-read on refresh. A `tun.enabled` edit
/// therefore reaches the next `config apply` without a daemon restart.
pub fn resolve_tun_from_config() -> Option<caly_domain::TunConfig> {
    let root = AppPaths::from_env().config;
    if !root.join("config.yaml").is_file() {
        return None;
    }
    let profile = std::env::var("CALY_PROFILE")
        .ok()
        .and_then(|value| SafeName::new(value).ok());
    let paths = LayeredConfigPaths::new(root, profile);
    load_layered_yaml(&paths, LoaderLimits::secure_default())
        .ok()
        .as_ref()
        .and_then(tun_config_from_schema)
}
/// ConfigActor backend publishing validated Mihomo generations atomically.
pub struct MihomoConfigBackend {
    renderer: MihomoConfigRenderer,
    filesystem: LinuxAtomicFileBackend,
    destination: PathBuf,
    generation: u64,
    prepared: HashMap<[u8; 16], (u64, AtomicFileContents)>,
    history: BTreeMap<u64, AtomicFileContents>,
    registry: Option<crate::core::CoreNodeRegistry>,
    tun: Option<caly_domain::TunConfig>,
    mixed_port: u16,
    allow_lan: bool,
    bind_address: String,
    log_level: String,
    external_controller_port: u16,
    secret: Option<String>,
    dns: Option<caly_domain::DnsSettings>,
    rules: Vec<caly_domain::RoutingRule>,
    rule_providers: Vec<caly_domain::RuleProvider>,
    transparent: caly_config::schema::TransparentConfig,
    sniffer: caly_config::schema::SnifferConfig,
    binary: Option<PathBuf>,
    workdir: PathBuf,
    validation_timeout: Duration,
}

impl MihomoConfigBackend {
    /// Creates an owner for one destination.
    pub fn new(destination: PathBuf) -> Self {
        Self {
            renderer: MihomoConfigRenderer,
            filesystem: LinuxAtomicFileBackend,
            destination,
            generation: 0,
            prepared: HashMap::new(),
            history: BTreeMap::new(),
            registry: None,
            tun: None,
            mixed_port: 7890,
            allow_lan: false,
            bind_address: "*".to_owned(),
            log_level: "info".to_owned(),
            external_controller_port: 9090,
            secret: None,
            dns: None,
            rules: Vec::new(),
            rule_providers: Vec::new(),
            transparent: caly_config::schema::TransparentConfig::default(),
            sniffer: caly_config::schema::SnifferConfig::default(),
            binary: None,
            workdir: PathBuf::from("."),
            validation_timeout: Duration::from_secs(10),
        }
    }

    /// Supplies config-driven routing rules for `rules:`.
    #[must_use]
    pub fn with_rules(mut self, rules: Vec<caly_domain::RoutingRule>) -> Self {
        self.rules = rules;
        self
    }

    /// Supplies config-driven rule providers (rendered into
    /// `rule-providers:`).
    #[must_use]
    pub fn with_rule_providers(
        mut self,
        providers: Vec<caly_domain::RuleProvider>,
    ) -> Self {
        self.rule_providers = providers;
        self
    }

    /// Supplies transparent-proxy inbound settings (redirect/tproxy).
    #[must_use]
    pub fn with_transparent(mut self, transparent: caly_config::schema::TransparentConfig) -> Self {
        self.transparent = transparent;
        self
    }

    /// Supplies sniffer tuning (domain recovery for bare-IP traffic).
    #[must_use]
    pub fn with_sniffer(mut self, sniffer: caly_config::schema::SnifferConfig) -> Self {
        self.sniffer = sniffer;
        self
    }

    /// Enables a TUN block in rendered generations.
    #[must_use]
    pub fn with_tun(mut self, tun: Option<caly_domain::TunConfig>) -> Self {
        self.tun = tun;
        self
    }

    /// Applies kernel tuning: inbound port/LAN, log level, controller, DNS.
    #[must_use]
    pub fn with_kernel(
        mut self,
        mixed_port: u16,
        allow_lan: bool,
        bind_address: String,
        log_level: String,
        external_controller_port: u16,
        dns: Option<caly_domain::DnsSettings>,
    ) -> Self {
        self.mixed_port = mixed_port;
        self.allow_lan = allow_lan;
        self.bind_address = bind_address;
        self.log_level = log_level;
        self.external_controller_port = external_controller_port;
        self.dns = dns;
        self
    }

    /// Shares the subscription-indexed proxy registry used for rendering.
    #[must_use]
    pub fn with_registry(mut self, registry: crate::core::CoreNodeRegistry) -> Self {
        self.registry = Some(registry);
        self
    }

    /// Enables real-kernel validation before commit.
    #[must_use]
    pub fn with_validation(mut self, binary: PathBuf, workdir: PathBuf, timeout: Duration) -> Self {
        self.binary = Some(binary);
        self.workdir = workdir;
        self.validation_timeout = timeout;
        self
    }

    /// Supplies the daemon's shared controller auth secret (fail-closed).
    #[must_use]
    pub fn with_secret(mut self, secret: Option<String>) -> Self {
        self.secret = secret;
        self
    }

    /// Builds settings from the subscription-indexed registry.
    fn build_settings(&self) -> Result<MihomoConfigSettings, ActorFailure> {
        let mut settings = MihomoConfigSettings {
            tun: self.tun.clone(),
            mixed_port: self.mixed_port,
            allow_lan: self.allow_lan,
            bind_address: self.bind_address.clone(),
            log_level: self.log_level.clone(),
            external_controller_port: self.external_controller_port,
            secret: self.secret.clone(),
            dns: self.dns.clone(),
            transparent_port: u16::from(self.transparent.enabled) * self.transparent.port,
            transparent_tproxy: matches!(
                self.transparent.mode,
                caly_config::schema::TransparentMode::Tproxy
            ),
            sniffer: if self.sniffer.enabled {
                Some(caly_kernel::mihomo::MihomoSniffer {
                    override_destination: self.sniffer.override_destination,
                    parse_pure_ip: self.sniffer.parse_pure_ip,
                    force_dns_mapping: self.sniffer.force_dns_mapping,
                    http_ports: self.sniffer.http_ports.clone(),
                    tls_ports: self.sniffer.tls_ports.clone(),
                    quic_ports: self.sniffer.quic_ports.clone(),
                })
            } else {
                None
            },
            ..MihomoConfigSettings::default()
        };
        let Some(registry) = &self.registry else {
            return Ok(settings);
        };
        let mapping = registry.lock().map_err(|_| {
            failure(
                "core node registry is poisoned",
                "restart the application runtime",
            )
        })?;
        if mapping.is_empty() {
            return Ok(settings);
        }
        // BTreeMap iteration ascends by NodeId: deterministic render order.
        let mut pairs: Vec<(&str, &str)> = Vec::with_capacity(mapping.len());
        let mut group = String::from("AUTO");
        for (index, registered) in mapping.values().enumerate() {
            pairs.push((registered.name.as_str(), registered.yaml.as_str()));
            if index == 0 {
                group.clone_from(&registered.group);
            }
        }
        let section = render_proxy_sections_with_rules_and_providers(
            &group,
            &pairs,
            &self.rules,
            &self.rule_providers,
        );
        settings.proxies = Some(caly_domain::BoundedText::new(section).map_err(|_| {
            failure(
                "Mihomo proxy section is too large",
                "reduce subscription size",
            )
        })?);
        Ok(settings)
    }

    /// Runs bounded `-t` validation on a rendered config.
    fn validate_config(
        &mut self,
        binary: PathBuf,
        workdir: PathBuf,
        config_path: PathBuf,
        generation: u64,
    ) -> Result<ValidationReport, ActorFailure> {
        let factory = MihomoSpawnSpecFactory::new(binary, workdir).map_err(|error| {
            failure(
                &format!("Mihomo factory failed: {error}"),
                "inspect binary path",
            )
        })?;
        let spec = factory
            .build_validation_spec(&caly_kernel::ports::RenderedConfigRef {
                generation,
                path: config_path,
            })
            .map_err(|error| {
                failure(
                    &format!("Mihomo validation spec failed: {error}"),
                    "inspect config",
                )
            })?;
        let mut validator = LinuxCommandValidator::new(LinuxCommandRunner);
        validator
            .validate(spec, self.validation_timeout)
            .map_err(|error| {
                failure(
                    &format!("Mihomo validator failed: {error}"),
                    "inspect binary",
                )
            })
    }
}

/// Removes stale `config.validate.*` staging files left by a previous apply
/// that crashed between staging and cleanup; the files are disposable copies
/// that must never be mistaken for the committed generation.
fn clean_stale_validation_files(workdir: &std::path::Path) {
    let Ok(entries) = std::fs::read_dir(workdir) else {
        return;
    };
    for entry in entries.flatten() {
        let name = entry.file_name();
        if name.to_string_lossy().starts_with("config.validate.") {
            let _ = std::fs::remove_file(entry.path());
        }
    }
}

impl ConfigActorPort for MihomoConfigBackend {
    fn parse_and_render(
        &mut self,
        candidate: ConfigCandidate,
    ) -> Result<PreparedConfig, ActorFailure> {
        // Re-read the TUN tuning per apply (like the subscription URL re-reads
        // on refresh): a `tun.enabled` edit takes effect without a restart.
        self.tun = resolve_tun_from_config();
        let settings = self.build_settings()?;
        let contents = self.renderer.render(&settings).map_err(|error| {
            failure(
                &format!("Mihomo config render failed: {error}"),
                "inspect config generation",
            )
        })?;
        let generation = self.generation.saturating_add(1);
        // Validate against the real binary before the candidate is considered
        // prepared, so a rejected config can never reach commit.
        if let Some(binary) = self.binary.clone() {
            clean_stale_validation_files(&self.workdir);
            let validation_path = self
                .workdir
                .join(format!("config.validate.{generation}.yaml"));
            let write = AtomicWritePlan {
                destination: validation_path.clone(),
                temporary: self
                    .workdir
                    .join(format!("config.validate.{generation}.tmp")),
                contents: contents.clone(),
            };
            atomic_write(&mut self.filesystem, write).map_err(|error| {
                failure(
                    &format!("Mihomo validation staging failed: {error}"),
                    "inspect working-directory ownership",
                )
            })?;
            let report = self.validate_config(
                binary,
                self.workdir.clone(),
                validation_path.clone(),
                generation,
            )?;
            let _ = std::fs::remove_file(&validation_path);
            let _ = std::fs::remove_file(
                self.workdir
                    .join(format!("config.validate.{generation}.tmp")),
            );
            if !report.accepted {
                // Surface the kernel's own rejection reason instead of a generic
                // "rejected" summary; the diagnostic is the stderr from the
                // validation executable and directly points at the bad field.
                let detail = report
                    .diagnostic
                    .as_ref()
                    .map(|d| d.as_str().trim())
                    .filter(|d| !d.is_empty())
                    .map(|d| format!(": {d}"))
                    .unwrap_or_default();
                return Err(failure(
                    &format!("generated config was rejected by the Mihomo binary{detail}"),
                    "inspect the validation diagnostic above or the base settings",
                ));
            }
        }
        self.prepared.insert(candidate.id, (generation, contents));
        Ok(PreparedConfig {
            candidate_id: candidate.id,
            generation,
        })
    }

    fn discard_prepared(&mut self, prepared: PreparedConfig) -> Result<(), ActorFailure> {
        self.prepared.remove(&prepared.candidate_id);
        Ok(())
    }

    fn commit_candidate(
        &mut self,
        prepared: PreparedConfig,
    ) -> Result<CommittedConfig, ActorFailure> {
        let (_, contents) = self
            .prepared
            .remove(&prepared.candidate_id)
            .ok_or_else(|| failure("prepared config is missing", "re-render the candidate"))?;
        // Ensure the owner-only destination directory exists before atomic publish.
        if let Some(parent) = self.destination.parent() {
            std::fs::create_dir_all(parent).map_err(|error| {
                failure(
                    &format!("cannot create config directory: {error}"),
                    "inspect config filesystem ownership",
                )
            })?;
            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                let _ = std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700));
            }
        }
        let mut bytes = contents.into_vec();
        bytes.extend_from_slice(format!("# caly-generation: {}\n", prepared.generation).as_bytes());
        let contents = AtomicFileContents::try_from_vec(bytes).map_err(|_| {
            failure(
                "Mihomo generation is too large",
                "reduce generated configuration",
            )
        })?;
        let temporary = PathBuf::from(format!(
            "{}.tmp.{}",
            self.destination.display(),
            prepared.generation
        ));
        atomic_write(
            &mut self.filesystem,
            AtomicWritePlan {
                destination: self.destination.clone(),
                temporary,
                contents: contents.clone(),
            },
        )
        .map_err(|error| {
            failure(
                &format!("Mihomo config publish failed: {error}"),
                "inspect config filesystem ownership",
            )
        })?;
        self.history.insert(prepared.generation, contents);
        while self.history.len() > MAX_CONFIG_HISTORY {
            if let Some(oldest) = self.history.keys().next().copied() {
                self.history.remove(&oldest);
            }
        }
        self.generation = prepared.generation;
        Ok(CommittedConfig {
            candidate_id: prepared.candidate_id,
            generation: prepared.generation,
        })
    }

    fn rollback_commit(&mut self, committed: CommittedConfig) -> Result<(), ActorFailure> {
        if self.generation != committed.generation {
            return Ok(());
        }
        let previous = self
            .history
            .range(..committed.generation)
            .next_back()
            .map(|(generation, contents)| (*generation, contents.clone()));
        if let Some((generation, contents)) = previous {
            let temporary = PathBuf::from(format!(
                "{}.rollback.{}",
                self.destination.display(),
                generation
            ));
            atomic_write(
                &mut self.filesystem,
                AtomicWritePlan {
                    destination: self.destination.clone(),
                    temporary,
                    contents,
                },
            )
            .map_err(|error| {
                failure(
                    &format!("config rollback failed: {error}"),
                    "inspect generation filesystem ownership",
                )
            })?;
            self.generation = generation;
        }
        Ok(())
    }
}

#[cfg(test)]
mod config_tests;

pub mod sing_box;

/// Active config backend dispatcher: renders/commits through the backend
/// matching the RUNTIME active core (the shared cell consulted by the lifecycle
/// switch), so `config apply` follows a `core switch` — a static configured
/// core would keep publishing the pre-switch kernel's file.
pub struct ActiveConfigBackend {
    active: crate::dual::SharedActiveCore,
    mihomo: MihomoConfigBackend,
    sing_box: sing_box::SingBoxConfigBackend,
}

impl ActiveConfigBackend {
    /// Wraps both backends behind the shared active-core cell.
    pub fn new(
        active: crate::dual::SharedActiveCore,
        mihomo: MihomoConfigBackend,
        sing_box: sing_box::SingBoxConfigBackend,
    ) -> Self {
        Self {
            active,
            mihomo,
            sing_box,
        }
    }

    /// The currently active core (poisoned cell degrades to Mihomo, matching
    /// the dual command backend's fallback).
    fn active_kind(&self) -> caly_domain::CoreKind {
        self.active
            .lock()
            .map_or(caly_domain::CoreKind::Mihomo, |active| *active)
    }
}

impl ConfigActorPort for ActiveConfigBackend {
    fn parse_and_render(
        &mut self,
        candidate: ConfigCandidate,
    ) -> Result<PreparedConfig, ActorFailure> {
        match self.active_kind() {
            caly_domain::CoreKind::Mihomo | caly_domain::CoreKind::Xray => {
                self.mihomo.parse_and_render(candidate)
            }
            caly_domain::CoreKind::SingBox => self.sing_box.parse_and_render(candidate),
        }
    }

    fn discard_prepared(&mut self, prepared: PreparedConfig) -> Result<(), ActorFailure> {
        match self.active_kind() {
            caly_domain::CoreKind::Mihomo | caly_domain::CoreKind::Xray => {
                self.mihomo.discard_prepared(prepared)
            }
            caly_domain::CoreKind::SingBox => self.sing_box.discard_prepared(prepared),
        }
    }

    fn commit_candidate(
        &mut self,
        prepared: PreparedConfig,
    ) -> Result<CommittedConfig, ActorFailure> {
        match self.active_kind() {
            caly_domain::CoreKind::Mihomo | caly_domain::CoreKind::Xray => {
                self.mihomo.commit_candidate(prepared)
            }
            caly_domain::CoreKind::SingBox => self.sing_box.commit_candidate(prepared),
        }
    }

    fn rollback_commit(&mut self, committed: CommittedConfig) -> Result<(), ActorFailure> {
        match self.active_kind() {
            caly_domain::CoreKind::Mihomo | caly_domain::CoreKind::Xray => {
                self.mihomo.rollback_commit(committed)
            }
            caly_domain::CoreKind::SingBox => self.sing_box.rollback_commit(committed),
        }
    }
}
