use super::*;
use std::os::unix::fs::PermissionsExt;
fn temp_dir(tag: &str) -> PathBuf {
    caly_platform::paths::test_helpers::unique_path_under("caly-config-backend", tag)
}
fn registry_with_one() -> crate::core::CoreNodeRegistry {
    let registry: crate::core::CoreNodeRegistry =
        std::sync::Arc::new(std::sync::Mutex::new(std::collections::BTreeMap::new()));
    if let Ok(mut map) = registry.lock() {
        map.insert(
                caly_domain::NodeId::from_bytes([1; 16]),
                crate::core::RegisteredProxy {
                    group: "AUTO".to_owned(),
                    name: "node-1".to_owned(),
                    yaml: "    - name: \"node-1\"\n      type: ss\n      server: 1.2.3.4\n      port: 443\n"
                        .to_owned(),
                    singbox: None,
                    subscription: caly_domain::SubscriptionId::from_bytes([1; 16]),
                },
            );
    }
    registry
}
#[test]
fn renders_subscription_driven_proxies_into_committed_config() -> Result<(), String> {
    let dir = temp_dir("render");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let destination = dir.join("mihomo.yaml");
    let mut backend =
        MihomoConfigBackend::new(destination.clone()).with_registry(registry_with_one());
    let prepared = backend
        .parse_and_render(ConfigCandidate { id: [7; 16] })
        .map_err(|e| format!("{e:?}"))?;
    assert_eq!(prepared.generation, 1);
    let committed = backend
        .commit_candidate(prepared)
        .map_err(|e| format!("{e:?}"))?;
    assert_eq!(committed.generation, 1);
    let text = std::fs::read_to_string(&destination).map_err(|e| e.to_string())?;
    assert!(text.contains("proxies:"), "missing proxies section");
    assert!(text.contains("type: ss"), "missing rendered proxy");
    assert!(
        text.contains("# caly-generation: 1"),
        "missing generation marker"
    );
    let mode = std::fs::metadata(&destination)
        .map_err(|e| e.to_string())?
        .permissions()
        .mode()
        & 0o777;
    assert_eq!(mode, 0o600, "committed config must be owner-only");
    std::fs::remove_dir_all(&dir).ok();
    Ok(())
}
#[test]
fn base_only_config_has_no_proxies_section() -> Result<(), String> {
    let dir = temp_dir("base");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let destination = dir.join("mihomo.yaml");
    let mut backend = MihomoConfigBackend::new(destination.clone());
    let prepared = backend
        .parse_and_render(ConfigCandidate { id: [8; 16] })
        .map_err(|e| format!("{e:?}"))?;
    let committed = backend
        .commit_candidate(prepared)
        .map_err(|e| format!("{e:?}"))?;
    assert_eq!(committed.generation, 1);
    let text = std::fs::read_to_string(&destination).map_err(|e| e.to_string())?;
    assert!(
        !text.contains("proxies:"),
        "base config must not add proxies"
    );
    std::fs::remove_dir_all(&dir).ok();
    Ok(())
}
#[test]
fn rollback_restores_previous_generation() -> Result<(), String> {
    let dir = temp_dir("rollback");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let destination = dir.join("mihomo.yaml");
    let registry = registry_with_one();
    let mut backend = MihomoConfigBackend::new(destination.clone()).with_registry(registry.clone());
    let first_prepared = backend
        .parse_and_render(ConfigCandidate { id: [1; 16] })
        .map_err(|e| format!("{e:?}"))?;
    let first = backend
        .commit_candidate(first_prepared)
        .map_err(|e| format!("{e:?}"))?;
    assert_eq!(first.generation, 1);
    // Clear the registry so generation two is base-only (no proxies).
    if let Ok(mut map) = registry.lock() {
        map.clear();
    }
    let second_prepared = backend
        .parse_and_render(ConfigCandidate { id: [2; 16] })
        .map_err(|e| format!("{e:?}"))?;
    let second = backend
        .commit_candidate(second_prepared)
        .map_err(|e| format!("{e:?}"))?;
    assert_eq!(second.generation, 2);
    backend
        .rollback_commit(second)
        .map_err(|e| format!("{e:?}"))?;
    let text = std::fs::read_to_string(&destination).map_err(|e| e.to_string())?;
    assert!(
        text.contains("# caly-generation: 1"),
        "rollback must restore gen 1"
    );
    std::fs::remove_dir_all(&dir).ok();
    Ok(())
}

fn registry_shuffled(entries: &[(u8, &str, &str)]) -> crate::core::CoreNodeRegistry {
    let registry: crate::core::CoreNodeRegistry =
        std::sync::Arc::new(std::sync::Mutex::new(std::collections::BTreeMap::new()));
    if let Ok(mut map) = registry.lock() {
        for (seed, name, yaml) in entries {
            map.insert(
                caly_domain::NodeId::from_bytes([*seed; 16]),
                crate::core::RegisteredProxy {
                    group: "AUTO".to_owned(),
                    name: (*name).to_owned(),
                    yaml: (*yaml).to_owned(),
                    singbox: None,
                    subscription: caly_domain::SubscriptionId::from_bytes([1; 16]),
                },
            );
        }
    }
    registry
}

#[test]
fn rendered_proxy_order_is_deterministic_and_sorted_by_node_id() -> Result<(), String> {
    // Insertion order is deliberately shuffled relative to NodeId order.
    let entries: [(u8, &str, &str); 3] = [
        (3, "node-c", "- name: node-c\n"),
        (1, "node-a", "- name: node-a\n"),
        (2, "node-b", "- name: node-b\n"),
    ];
    let dir = temp_dir("determinism");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let mut rendered: Vec<String> = Vec::new();
    for round in 0..2 {
        let backend = MihomoConfigBackend::new(dir.join(format!("mihomo-{round}.yaml")))
            .with_registry(registry_shuffled(&entries));
        let settings = backend.build_settings().map_err(|e| format!("{e:?}"))?;
        let section = settings
            .proxies
            .as_ref()
            .map(|text| text.as_str().to_owned())
            .ok_or_else(|| "no proxy section".to_owned())?;
        let a = section.find("node-a").ok_or("missing node-a")?;
        let b = section.find("node-b").ok_or("missing node-b")?;
        let c = section.find("node-c").ok_or("missing node-c")?;
        assert!(a < b && b < c, "proxy order must ascend by NodeId");
        rendered.push(section);
    }
    assert_eq!(rendered[0], rendered[1], "rendering must be reproducible");
    let _ = std::fs::remove_dir_all(&dir);
    Ok(())
}
