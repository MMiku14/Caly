//! HTTP and cached subscription backends.

mod cached;
mod http;

pub use cached::CachedSubscriptionBackend;
pub use http::HttpSubscriptionBackend;

use caly_config::subscription::AddressClassifier;
use caly_domain::SubscriptionId;
use std::net::IpAddr;

pub(crate) use caly_config::subscription::parse_uri_body_to_display_lossy;

struct PublicAddressClassifier;
impl AddressClassifier for PublicAddressClassifier {
    fn is_globally_routable(&self, address: IpAddr) -> bool {
        match address {
            IpAddr::V4(value) => {
                !value.is_private()
                    && !value.is_loopback()
                    && !value.is_link_local()
                    && !value.is_unspecified()
                    && !value.is_broadcast()
            }
            IpAddr::V6(value) => {
                !value.is_loopback()
                    && !value.is_unspecified()
                    && !value.is_unique_local()
                    && !value.is_unicast_link_local()
            }
        }
    }
}

fn hex_id(id: SubscriptionId) -> String {
    caly_domain::to_hex(id.into_bytes())
}
