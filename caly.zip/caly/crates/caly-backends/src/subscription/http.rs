//! Direct HTTP subscription backend using the repository's SSRF-safe fetch policy.

use crate::core::MihomoNodeRegistry;
use caly_config::loader::{LayeredConfigPaths, LoaderLimits, load_layered_yaml};
use caly_config::subscription::{
    AddressClassifier, FetchPolicy, FetchResult, ResolvedAddresses, fetch_pinned,
    uri_body_to_sing_box_json_with,
};
use caly_domain::{SnapshotNodes, SubscriptionId};
use caly_platform::paths::{AppPaths, SafeName};
use caly_ports::{ActorFailure, SubscriptionCommandBackend};
use std::net::{IpAddr, ToSocketAddrs};

use super::PublicAddressClassifier;

mod expansion;

/// DNS resolution retries before giving up on a transient resolver failure.
const RESOLVE_ATTEMPTS: usize = 3;
/// Inter-attempt delay in milliseconds.
const RESOLVE_RETRY_MILLIS: u64 = 100;
/// HTTP fetch attempts before surfacing a failure (absorbs transient blips).
const FETCH_ATTEMPTS: usize = 2;
/// Inter-attempt delay in milliseconds for a transient fetch failure.
const FETCH_RETRY_MILLIS: u64 = 250;

/// A fetch attempt result carrying an explicit transient flag, so retry
/// decisions are structural rather than string-matched.
type Attempt = Result<(), (bool, ActorFailure)>;

/// Runs `attempt` with up to `max_attempts` tries, retrying only transient
/// failures with `retry_millis` backoff. Non-transient failures surface
/// immediately. Pure and testable without network I/O.
fn retry_fetch<F>(
    max_attempts: usize,
    retry_millis: u64,
    mut attempt: F,
) -> Result<(), ActorFailure>
where
    F: FnMut() -> Attempt,
{
    let mut last = crate::failure("fetch failed", "retry");
    for index in 0..max_attempts {
        match attempt() {
            Ok(()) => return Ok(()),
            Err((transient, error)) if index + 1 < max_attempts && transient => {
                last = error;
                std::thread::sleep(std::time::Duration::from_millis(retry_millis));
            }
            Err((_, error)) => return Err(error),
        }
    }
    Err(last)
}

/// Direct HTTP subscription backend using the repository's SSRF-safe fetch policy.
pub struct HttpSubscriptionBackend {
    sources: std::collections::BTreeMap<SubscriptionId, String>,
    cache: super::CachedSubscriptionBackend,
    handle: tokio::runtime::Handle,
    policy: FetchPolicy,
}

impl HttpSubscriptionBackend {
    /// Creates an HTTP backend using the current application runtime handle.
    pub fn new() -> Result<Self, ActorFailure> {
        let handle = tokio::runtime::Handle::try_current().map_err(|_| {
            crate::failure(
                "subscription backend requires a Tokio runtime",
                "construct it inside daemon runtime composition",
            )
        })?;
        Ok(Self {
            sources: std::collections::BTreeMap::new(),
            cache: super::CachedSubscriptionBackend::new(),
            handle,
            policy: FetchPolicy::direct_default(),
        })
    }

    /// Overrides the SSRF-safe fetch policy bounds (timeouts, body cap,
    /// redirects, environment proxy) from configuration.
    #[must_use]
    pub fn with_policy(mut self, policy: FetchPolicy) -> Self {
        self.policy = policy;
        self
    }

    /// Shares an automatic NodeId → Mihomo group/node registry.
    #[must_use]
    pub fn with_node_registry(mut self, registry: MihomoNodeRegistry) -> Self {
        self.cache = self.cache.with_node_registry(registry);
        self
    }

    /// Enables a persistent raw-body cache directory so the node registry can
    /// be rebuilt after a daemon restart without re-fetching.
    #[must_use]
    pub fn with_cache_dir(mut self, cache_dir: std::path::PathBuf) -> Self {
        self.cache = self.cache.with_cache_dir(cache_dir);
        self
    }

    /// Restores every persisted subscription body into the node registry.
    /// Best-effort: unreadable entries are skipped with a warning. Returns
    /// the restored projection slices for seeding the presentation snapshot.
    pub fn restore_cached(&mut self) -> Result<Vec<caly_domain::SnapshotNodes>, ActorFailure> {
        self.cache.restore_from_cache()
    }

    /// Registers a source URL for a subscription id.
    pub fn put_url(&mut self, id: SubscriptionId, url: String) {
        self.sources.insert(id, url);
    }

    /// Returns the last committed generation.
    pub fn generation(&self, id: SubscriptionId) -> u64 {
        self.cache.generation(id)
    }

    /// Fetches the source and generates a sing-box JSON config from dialable
    /// nodes, rendering the document header from `tuning`.
    pub fn refresh_sing_box_config(
        &mut self,
        id: SubscriptionId,
        tuning: &caly_config::subscription::SingBoxRenderTuning,
    ) -> Result<Vec<u8>, ActorFailure> {
        self.fetch(id)?;
        let body = self.cache.raw_source(id).ok_or_else(|| {
            crate::failure(
                "sing-box raw subscription cache is missing",
                "retry the source fetch",
            )
        })?;
        uri_body_to_sing_box_json_with(body, id, tuning).map_err(|error| {
            crate::failure(
                &format!("sing-box outbound rendering failed: {error}"),
                "inspect subscription protocol support",
            )
        })
    }

    fn fetch(&mut self, id: SubscriptionId) -> Result<(), ActorFailure> {
        let source = self.sources.get(&id).cloned().ok_or_else(|| {
            crate::failure(
                "subscription URL is not configured",
                "configure a source URL",
            )
        })?;
        let addresses = resolve_addresses(&source)?;
        retry_fetch(FETCH_ATTEMPTS, FETCH_RETRY_MILLIS, || {
            self.fetch_once(&source, &addresses, id)
        })?;
        self.expand_url_list(id)
    }

    fn fetch_once(
        &mut self,
        source: &str,
        addresses: &ResolvedAddresses,
        id: SubscriptionId,
    ) -> Attempt {
        match self.request_body(source, addresses)? {
            FetchResult::Updated { body, userinfo, .. } => {
                self.cache.put_source(id, body.into_vec());
                self.cache.put_userinfo(id, userinfo);
                Ok(())
            }
            FetchResult::NotModified => Ok(()),
        }
    }

    /// One SSRF-safe pinned HTTP request shared by the primary fetch and the
    /// URL-list child fetches.
    pub(super) fn request_body(
        &mut self,
        source: &str,
        addresses: &ResolvedAddresses,
    ) -> Result<FetchResult, (bool, ActorFailure)> {
        // The backend runs inside a `spawn_blocking` actor, so a direct
        // `block_on` is safe and avoids the multi-thread-runtime dependency of
        // `block_in_place` (which would panic on a current-thread runtime).
        self.handle
            .block_on(fetch_pinned(
                source,
                addresses.clone(),
                &PublicAddressClassifier,
                self.policy,
                &caly_config::subscription::FetchValidators {
                    etag: None,
                    last_modified: None,
                },
            ))
            .map_err(|error| {
                let transient = is_transient_fetch(&error);
                let failure = crate::failure(
                    &format!("subscription fetch failed: {error}"),
                    "inspect HTTP, DNS, and source policy",
                );
                (transient, failure)
            })
    }
}

/// Whether a fetch error is transient and worth retrying: connect/request
/// timeouts and temporary (5xx) server statuses. Policy rejections (bad URL,
/// unsupported scheme, non-public address, body too large) are not retried.
fn is_transient_fetch(error: &caly_config::subscription::FetchError) -> bool {
    use caly_config::subscription::FetchError;
    match error {
        FetchError::RequestFailed(_) | FetchError::ClientBuild => true,
        FetchError::UnexpectedStatus(status) => (500..600).contains(status),
        _ => false,
    }
}

fn resolve_addresses(source: &str) -> Result<ResolvedAddresses, ActorFailure> {
    let parsed = url::Url::parse(source)
        .map_err(|_| crate::failure("subscription URL is invalid", "use an HTTP(S) URL"))?;
    let host = parsed
        .host_str()
        .ok_or_else(|| crate::failure("subscription URL has no host", "configure a valid host"))?;
    let port = parsed.port_or_known_default().ok_or_else(|| {
        crate::failure(
            "subscription URL has no port",
            "configure a valid HTTP(S) URL",
        )
    })?;
    let addresses = resolve_with_retry(host, port)?;
    let addresses = prefer_public_v4(addresses, &PublicAddressClassifier);
    if addresses.is_empty() {
        return Err(crate::failure(
            "subscription resolved only to non-public addresses",
            "use a public subscription host",
        ));
    }
    ResolvedAddresses::try_from_vec(addresses).map_err(|_| {
        crate::failure(
            "subscription has too many DNS answers",
            "use a bounded source host",
        )
    })
}

/// Deduplicates answers, drops non-public addresses, and prefers IPv4 so a
/// connection attempts the more reliable family first.
/// Resolves with retries on both errors and empty answer sets.
fn resolve_with_retry(host: &str, port: u16) -> Result<Vec<IpAddr>, ActorFailure> {
    for attempt in 0..RESOLVE_ATTEMPTS {
        let resolved = (host, port).to_socket_addrs().ok().map(|iterator| {
            iterator
                .map(|address| address.ip())
                .collect::<Vec<IpAddr>>()
        });
        let retry = attempt + 1 < RESOLVE_ATTEMPTS;
        match resolved {
            Some(values) if !values.is_empty() => return Ok(values),
            Some(_) if retry => {
                std::thread::sleep(std::time::Duration::from_millis(RESOLVE_RETRY_MILLIS));
            }
            Some(_) => {
                return Err(crate::failure(
                    "subscription DNS returned no answers",
                    "inspect DNS and source availability",
                ));
            }
            None if retry => {
                std::thread::sleep(std::time::Duration::from_millis(RESOLVE_RETRY_MILLIS));
            }
            None => {
                return Err(crate::failure(
                    "subscription DNS resolution failed",
                    "inspect DNS and source availability",
                ));
            }
        }
    }
    Err(crate::failure(
        "subscription DNS resolution failed",
        "inspect DNS and source availability",
    ))
}

fn prefer_public_v4(addresses: Vec<IpAddr>, classifier: &impl AddressClassifier) -> Vec<IpAddr> {
    let mut seen = std::collections::HashSet::new();
    let mut out = Vec::new();
    for address in addresses {
        if !classifier.is_globally_routable(address) {
            continue;
        }
        if seen.insert(address) {
            out.push(address);
        }
    }
    out.sort_by_key(|address| !matches!(address, IpAddr::V4(_)));
    out
}

impl SubscriptionCommandBackend for HttpSubscriptionBackend {
    fn refresh(&mut self, _subscription: SubscriptionId) -> Result<SnapshotNodes, ActorFailure> {
        // Re-resolve the sources each refresh: env wins, then layered config,
        // so a config edit takes effect without a daemon restart. A source
        // registered by bootstrap (e.g. sing-box document rendering) is never
        // overwritten.
        let sources = resolve_sources();
        for (id, url) in &sources {
            self.sources.insert(*id, url.clone());
        }
        // Fetch every enabled source and merge their projections into one
        // snapshot. A single failing source does not abort the rest; its
        // failure is reported and the remaining sources still land.
        let mut merged = Vec::new();
        let mut first_error: Option<ActorFailure> = None;
        for (id, _url) in &sources {
            if let Err(error) = self.fetch(*id) {
                if first_error.is_none() {
                    first_error = Some(error);
                }
                continue;
            }
            match self.cache.refresh(*id) {
                Ok(nodes) => merged.extend(nodes.into_vec()),
                Err(error) => {
                    if first_error.is_none() {
                        first_error = Some(error);
                    }
                }
            }
        }
        if merged.is_empty() {
            return Err(first_error.unwrap_or_else(|| {
                crate::failure("no subscription source is configured", "configure a source URL")
            }));
        }
        caly_domain::SnapshotNodes::try_from_vec(merged).map_err(|_| {
            crate::failure(
                "merged subscription nodes exceeded the snapshot bound",
                "reduce the number of subscription sources or their node counts",
            )
        })
    }
}

/// Resolves every enabled subscription source: `CALY_SUBSCRIPTION_URL` first
/// (single-source override), then the layered config (`subscriptions.url` plus
/// each enabled `subscriptions.sources` entry). Each URL maps to a stable
/// `SubscriptionId` derived from its SHA-256 digest, so the same URL always
/// targets the same cache entry across restarts; re-evaluated per refresh.
fn resolve_sources() -> Vec<(SubscriptionId, String)> {
    let mut urls = Vec::new();
    if let Ok(value) = std::env::var("CALY_SUBSCRIPTION_URL") {
        urls.push(value);
    } else {
        let root = AppPaths::from_env().config;
        if root.join("config.yaml").is_file() {
            let profile = std::env::var("CALY_PROFILE")
                .ok()
                .and_then(|v| SafeName::new(v).ok());
            let paths = LayeredConfigPaths::new(root, profile);
            if let Ok(config) = load_layered_yaml(&paths, LoaderLimits::secure_default()) {
                urls.extend(config.subscriptions.enabled_source_urls());
            }
        }
    }
    let mut out: Vec<(SubscriptionId, String)> = Vec::new();
    let mut seen: std::collections::BTreeSet<SubscriptionId> = std::collections::BTreeSet::new();
    for url in urls {
        let id = subscription_id_for_url(&url);
        if seen.insert(id) {
            out.push((id, url));
        }
    }
    out
}

/// Stable 16-byte `SubscriptionId` from a source URL digest.
fn subscription_id_for_url(url: &str) -> SubscriptionId {
    use sha2::{Digest, Sha256};
    let mut hasher = Sha256::new();
    hasher.update(url.as_bytes());
    let digest = hasher.finalize();
    let mut bytes = [0_u8; 16];
    bytes.copy_from_slice(&digest[..16]);
    SubscriptionId::from_bytes(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// `prefer_public_v4` filters to public IPs, drops RFC1918 / loopback
    /// / link-local addresses, deduplicates, and orders IPv4 before IPv6.
    /// The single parametric test below exercises the mixed input the
    /// function is designed for plus the all-private edge case the
    /// previous `prefer_public_v4_drops_all_private` test covered
    /// separately, ensuring the function returns an empty Vec without
    /// panicking when nothing is public.
    #[test]
    fn prefer_public_v4_dedupes_orders_and_drops_private() {
        use std::net::Ipv4Addr;
        let classifier = PublicAddressClassifier;
        // Mixed input: V6 loopback, public V4 (×2, dedup), private V4,
        // public V6 — expect deduplicated public-only output with V4
        // before V6.
        let mixed = vec![
            IpAddr::V6(std::net::Ipv6Addr::LOCALHOST),
            IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8)),
            IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1)),
            IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8)),
            IpAddr::V6(std::net::Ipv6Addr::new(0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 1)),
        ];
        assert_eq!(
            prefer_public_v4(mixed, &classifier),
            vec![
                IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8)),
                IpAddr::V6(std::net::Ipv6Addr::new(0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 1)),
            ]
        );
        // All-private edge case: function returns an empty Vec without panicking.
        let private_only = vec![IpAddr::V4(Ipv4Addr::new(192, 168, 1, 1))];
        assert!(prefer_public_v4(private_only, &classifier).is_empty());
    }

    fn transient() -> ActorFailure {
        crate::failure("subscription fetch failed: RequestFailed", "retry")
    }

    #[test]
    fn transient_failure_is_retried_then_succeeds() {
        let mut calls = 0;
        let result = retry_fetch(3, 0, || {
            calls += 1;
            if calls < 2 {
                Err((true, transient()))
            } else {
                Ok(())
            }
        });
        assert!(result.is_ok());
        assert_eq!(calls, 2, "second attempt should succeed");
    }

    #[test]
    fn persistent_transient_failure_surfaces_after_exhausting_attempts() {
        let mut calls = 0;
        let result = retry_fetch(3, 0, || {
            calls += 1;
            Err((true, transient()))
        });
        assert!(result.is_err());
        assert_eq!(calls, 3, "all attempts exhausted");
    }

    #[test]
    fn nontransient_failure_returns_immediately() {
        let mut calls = 0;
        let result = retry_fetch(3, 0, || {
            calls += 1;
            Err((false, transient()))
        });
        assert!(result.is_err());
        assert_eq!(calls, 1, "non-transient failure must not retry");
    }

    #[test]
    fn transient_classification_matches_fetch_errors() {
        use caly_config::subscription::FetchError;
        assert!(is_transient_fetch(&FetchError::RequestFailed("connect error".to_owned())));
        assert!(is_transient_fetch(&FetchError::ClientBuild));
        assert!(is_transient_fetch(&FetchError::UnexpectedStatus(503)));
        assert!(!is_transient_fetch(&FetchError::UnexpectedStatus(404)));
        assert!(!is_transient_fetch(&FetchError::UnsupportedScheme));
        assert!(!is_transient_fetch(&FetchError::BodyTooLarge));

    }

    #[test]
    fn subscription_id_for_url_is_stable_and_distinct() {
        // Same URL always maps to the same id (stable cache key across restarts),
        // and different URLs map to different ids (per-source merge/dedup).
        let a1 = subscription_id_for_url("https://provider.example/sub");
        let a2 = subscription_id_for_url("https://provider.example/sub");
        let b = subscription_id_for_url("https://second.example/sub?token=xyz");
        assert_eq!(a1, a2, "same URL must yield the same SubscriptionId");
        assert_ne!(a1, b, "different URLs must yield distinct SubscriptionIds");
        // Id is a full 16-byte value, not a zero-padded truncation.
        assert_ne!(a1.into_bytes(), [0_u8; 16]);
        // Disabled sources must not be produced: helper filters by enabled of the
        // config, exercised through the schema-level test; here just confirm the
        // id derivation tolerates whitespace/query stability is byte-exact.
        let c1 = subscription_id_for_url("https://p.example/x");
        let c2 = subscription_id_for_url("https://p.example/x ");
        assert_ne!(c1, c2, "id must be byte-exact over the URL ");
    }
}
