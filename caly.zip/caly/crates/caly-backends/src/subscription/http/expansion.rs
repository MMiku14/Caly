//! URL-list subscription expansion: a plain-text body whose lines are
//! subscription URLs is fetched child-by-child (same SSRF-safe path) and
//! merged before node parsing.

use caly_config::subscription::{FetchResult, SubscriptionDocument, decode_document};
use caly_domain::SubscriptionId;
use caly_ports::ActorFailure;

use super::{FETCH_ATTEMPTS, FETCH_RETRY_MILLIS, HttpSubscriptionBackend, resolve_addresses};

/// Maximum child subscriptions expanded from one URL-list document.
const MAX_URL_LIST_CHILDREN: usize = 32;

impl HttpSubscriptionBackend {
    /// Expands a plain-text URL-list subscription: fetches each child
    /// subscription through the same SSRF-safe path and merges the bodies so
    /// downstream parsing sees one URI-line/base64/Clash document.
    pub(super) fn expand_url_list(&mut self, id: SubscriptionId) -> Result<(), ActorFailure> {
        let Some(body) = self.cache.raw_source(id) else {
            return Ok(());
        };
        // Not a URL list (or undecodable): leave the body untouched so the
        // regular parse path reports it.
        let Ok(SubscriptionDocument::UrlList(lines)) = decode_document(body) else {
            return Ok(());
        };
        if lines.len() > MAX_URL_LIST_CHILDREN {
            return Err(crate::failure(
                "URL-list subscription has too many entries",
                "reduce the list to at most 32 URLs",
            ));
        }
        let mut merged: Vec<u8> = Vec::new();
        for line in &lines {
            let child = self.fetch_child(line.as_str())?;
            merged.extend_from_slice(&child);
            merged.push(b'\n');
        }
        if let Ok(SubscriptionDocument::UrlList(_)) = decode_document(merged.clone()) {
            return Err(crate::failure(
                "nested URL-list subscriptions are not supported",
                "point the subscription at a single URL list level",
            ));
        }
        self.cache.put_source(id, merged);
        Ok(())
    }

    /// Fetches one child subscription body with the shared retry policy.
    fn fetch_child(&mut self, source: &str) -> Result<Vec<u8>, ActorFailure> {
        let addresses = resolve_addresses(source)?;
        let mut last = crate::failure("child subscription fetch failed", "retry the refresh");
        for index in 0..FETCH_ATTEMPTS {
            match self.request_body(source, &addresses) {
                Ok(FetchResult::Updated { body, .. }) => return Ok(body.into_vec()),
                Ok(FetchResult::NotModified) => return Ok(Vec::new()),
                Err((transient, error)) => {
                    last = error;
                    if !transient || index + 1 >= FETCH_ATTEMPTS {
                        return Err(last);
                    }
                    std::thread::sleep(std::time::Duration::from_millis(FETCH_RETRY_MILLIS));
                }
            }
        }
        Err(last)
    }
}
