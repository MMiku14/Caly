//! TunActor command backend owning the Linux TUN engage/restore lifecycle.

use caly_domain::PlatformEffectView;
use caly_platform::{
    PlatformFailure,
    tun::{InterfaceName, LinuxTunBackend, OwnedTun, TunBackend, TunEscalation, TunRequest},
};
use caly_ports::{ActorFailure, ActorFailureKind, TunCommandBackend};

/// Owns the configured MTU, interface name and the currently engaged TUN.
pub struct LinuxTunCommandBackend {
    backend: LinuxTunBackend,
    interface: InterfaceName,
    mtu: u16,
    owned: Option<Box<dyn OwnedTun>>,
}

impl LinuxTunCommandBackend {
    /// Creates an owner with a fixed interface name and MTU from configuration.
    pub fn new(interface: InterfaceName, mtu: u16) -> Result<Self, ActorFailure> {
        Self::new_with_escalation(interface, mtu, TunEscalation::default())
    }

    /// Creates an owner with an explicit privilege-escalation policy for the
    /// privileged `ip` commands (pkexec/sudo when the daemon lacks
    /// `CAP_NET_ADMIN`).
    pub fn new_with_escalation(
        interface: InterfaceName,
        mtu: u16,
        escalation: TunEscalation,
    ) -> Result<Self, ActorFailure> {
        if !(576..=9_000).contains(&mtu) {
            return Err(crate::failure(
                "TUN MTU must be between 576 and 9000",
                "configure a valid TUN MTU",
            ));
        }
        Ok(Self {
            backend: LinuxTunBackend::default().with_escalation(escalation),
            interface,
            mtu,
            owned: None,
        })
    }

    /// Returns whether caly currently owns an engaged TUN interface.
    pub fn engaged(&self) -> bool {
        self.owned.is_some()
    }

    /// Returns the configured interface name (used by durable recovery).
    pub fn interface(&self) -> &str {
        self.interface.as_str()
    }

    /// Returns the configured MTU (used by durable recovery).
    pub const fn mtu(&self) -> u16 {
        self.mtu
    }
}

impl TunCommandBackend for LinuxTunCommandBackend {
    fn set_tun(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure> {
        if enabled {
            if self.owned.is_some() {
                return Ok(PlatformEffectView::tun(true));
            }
            let request = TunRequest {
                interface: self.interface.clone(),
                mtu: self.mtu,
            };
            let owned = self.backend.engage(request).map_err(tun_failure)?;
            self.owned = Some(owned);
            Ok(PlatformEffectView::tun(true))
        } else {
            if let Some(owned) = self.owned.take() {
                owned.restore().map_err(tun_failure)?;
            }
            Ok(PlatformEffectView::none())
        }
    }
}

fn tun_failure(error: PlatformFailure) -> ActorFailure {
    ActorFailure::new(
        ActorFailureKind::Infrastructure,
        error.message.as_str(),
        error.suggested_action.as_str(),
    )
    .unwrap_or_else(|_| std::process::abort())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn interface(name: &str) -> InterfaceName {
        InterfaceName::new(name.to_owned()).unwrap_or_else(|_| std::process::abort())
    }

    #[test]
    fn out_of_range_mtu_is_rejected() {
        assert!(LinuxTunCommandBackend::new(interface("caly0"), 100).is_err());
        assert!(LinuxTunCommandBackend::new(interface("caly0"), 9_001).is_err());
    }

    #[test]
    fn starts_disengaged() -> Result<(), String> {
        let backend =
            LinuxTunCommandBackend::new(interface("caly0"), 1_500).map_err(|e| format!("{e:?}"))?;
        assert!(!backend.engaged());
        Ok(())
    }
}
