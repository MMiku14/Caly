//! Durable system-proxy backend: persists a recovery record on engagement and
//! restores it on startup, so a daemon crash never leaves the desktop proxy in
//! an unknown state.

use std::sync::Arc;

use caly_domain::PlatformEffectView;
use caly_platform::{
    PlatformFailure,
    recovery::{ProxyRecoveryAction, ProxyRecoveryRecord, ProxyRecoveryStore, RecoveryPhase},
};
use caly_ports::{ActorFailure, PlatformCommandBackend};

use super::{
    LinuxSystemProxyBackend,
    durable_support::{actor_to_platform, durable_failure},
};

/// Shared durable proxy recovery store handle.
pub type SharedProxyRecoveryStore = Arc<dyn ProxyRecoveryStore + Send + Sync>;

/// The desktop proxy operations needed for durable recovery.
pub trait DesktopProxyControl {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure>;
    fn host(&self) -> &str;
    fn port(&self) -> u16;
    /// Captures the desktop's current proxy state as `(mode, endpoint)` so a
    /// graceful shutdown can restore exactly what was found before engagement.
    fn capture_original_state(&mut self) -> (String, String);
    /// Restores a previously captured state; the durable wrapper degrades
    /// `manual` with an empty endpoint to a plain disable.
    fn restore_original(
        &mut self,
        mode: &str,
        endpoint: &str,
    ) -> Result<PlatformEffectView, ActorFailure>;
}

impl DesktopProxyControl for LinuxSystemProxyBackend {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure> {
        PlatformCommandBackend::set_system_proxy(self, enabled)
    }
    fn host(&self) -> &str {
        self.host()
    }
    fn port(&self) -> u16 {
        self.port()
    }
    fn capture_original_state(&mut self) -> (String, String) {
        self.capture_original_state()
    }
    fn restore_original(
        &mut self,
        mode: &str,
        endpoint: &str,
    ) -> Result<PlatformEffectView, ActorFailure> {
        self.restore_original(mode, endpoint)
    }
}

/// Wraps a desktop proxy control with an owner-only durable recovery store.
pub struct DurableSystemProxyBackend<C> {
    inner: C,
    store: SharedProxyRecoveryStore,
    owner_token: [u8; 16],
}

impl<C: DesktopProxyControl> DurableSystemProxyBackend<C> {
    /// Wraps `inner` with `store` and a fresh owner token.
    pub fn new(inner: C, store: SharedProxyRecoveryStore) -> Self {
        let owner_token = caly_platform::entropy::random_bytes::<16>();
        Self {
            inner,
            store,
            owner_token,
        }
    }

    /// Re-applies any pending proxy recovery record (restore-first startup gate).
    pub fn restore_first(
        &mut self,
    ) -> Result<
        caly_platform::recovery::ProxyRecoveryOutcome,
        caly_platform::recovery::ProxyRecoveryFailure,
    > {
        let store = Arc::clone(&self.store);
        caly_platform::recovery::proxy_restore_first(store.as_ref(), self)
    }

    /// Persists a recovery record for an enabled proxy side effect, capturing
    /// the desktop state found before engagement. Capture is best-effort: an
    /// unreadable state degrades to `("none", "")` (restore = disable) and
    /// never blocks engagement.
    fn persist_enabled_record(&mut self) -> Result<(), ActorFailure> {
        let (original_mode, original_endpoint) = self.inner.capture_original_state();
        let record = ProxyRecoveryRecord {
            owner_token: self.owner_token,
            phase: RecoveryPhase::Applied,
            host: self.inner.host().to_owned(),
            port: self.inner.port(),
            enabled: true,
            original_mode,
            original_endpoint,
        };
        self.store
            .persist(&record)
            .map_err(|e| durable_failure(e, "proxy"))?;
        Ok(())
    }

    /// Clears the recovery record when the side effect is no longer pending.
    fn clear_record(&mut self) {
        let _ = self.store.clear_if_owner(self.owner_token);
    }
}

impl<C: DesktopProxyControl> PlatformCommandBackend for DurableSystemProxyBackend<C> {
    fn set_system_proxy(&mut self, enabled: bool) -> Result<PlatformEffectView, ActorFailure> {
        if enabled {
            // Persist the intent durably before applying, so a crash between
            // apply and the projection still leaves a recoverable record. A
            // re-engagement keeps the existing record: re-capturing would
            // overwrite the user's true original state with caly's own proxy.
            let existing = self
                .store
                .load()
                .map_err(|e| durable_failure(e, "proxy"))?
                .is_some();
            if !existing {
                self.persist_enabled_record()?;
            }
            match self.inner.set_system_proxy(true) {
                Ok(view) => Ok(view),
                Err(error) => {
                    if !existing {
                        self.clear_record();
                    }
                    Err(error)
                }
            }
        } else {
            // Retain the durable record when restoration fails: restore-first
            // on a later daemon boot must still have evidence to retry.
            match self.inner.set_system_proxy(false) {
                Ok(view) => {
                    self.clear_record();
                    Ok(view)
                }
                Err(error) => Err(error),
            }
        }
    }
}

impl<C: DesktopProxyControl> DurableSystemProxyBackend<C> {
    /// Graceful-shutdown restore: returns the desktop to the exact state
    /// captured before engagement, then clears the record. A failed restore
    /// retains the record so restore-first on the next boot can retry; a
    /// missing record is a no-op success.
    pub fn restore_original_and_clear(&mut self) -> Result<PlatformEffectView, ActorFailure> {
        let Some(record) = self.store.load().map_err(|e| durable_failure(e, "proxy"))? else {
            // No record means this daemon never engaged the proxy: touching
            // the desktop here could clobber a proxy the user configured.
            return Ok(PlatformEffectView::none());
        };
        let view = self
            .inner
            .restore_original(&record.original_mode, &record.original_endpoint)?;
        self.clear_record();
        Ok(view)
    }
}

impl<C: DesktopProxyControl> ProxyRecoveryAction for DurableSystemProxyBackend<C> {
    fn restore_proxy(&mut self, record: &ProxyRecoveryRecord) -> Result<(), PlatformFailure> {
        self.inner
            .set_system_proxy(record.enabled)
            .map(|_| ())
            .map_err(|e| actor_to_platform(e, "restore-proxy", "system-proxy"))
    }
}

#[cfg(test)]
mod durable_tests;
