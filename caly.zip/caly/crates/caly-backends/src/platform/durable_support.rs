//! Shared plumbing for the durable platform side-effect backends.
//!
//! Both `DurableSystemProxyBackend` and `DurableTunBackend` follow the same
//! "persist-before-apply, clear-on-disable" transaction shape and convert
//! errors through the same bounded-text helpers. Keeping those helpers in one
//! place avoids drift between the two concrete backends.

use caly_domain::BoundedText;
use caly_platform::{PlatformFailure, recovery::RecoveryStoreError};
use caly_ports::{ActorFailure, ActorFailureKind};

/// Builds a bounded text, aborting only if the constant cannot fit.
///
/// Every call site passes a compile-time constant, so abort here is
/// unreachable in practice; abort is preferred over silently truncating an
/// invariant-guaranteed message.
pub(crate) fn bounded<const MAX: usize>(value: &str) -> BoundedText<MAX> {
    // Over-long messages are truncated at a char boundary instead of aborting
    // the daemon (durable restore must survive hostile/malformed state).
    BoundedText::from_nonempty_clamped(value.to_owned(), "error")
}

/// Maps an [`ActorFailure`] to a [`PlatformFailure`] with a fixed operation and
/// resource label for the restore path.
pub(crate) fn actor_to_platform(
    error: ActorFailure,
    operation: &str,
    resource: &str,
) -> PlatformFailure {
    PlatformFailure {
        operation: bounded(operation),
        resource: bounded(resource),
        message: bounded(error.message.as_str()),
        suggested_action: bounded(error.suggested_action.as_str()),
    }
}

/// Maps a recovery-store error to an infrastructure [`ActorFailure`].
///
/// `kind` is a short label (e.g. "proxy" or "tun") embedded in the message.
pub(crate) fn durable_failure(error: RecoveryStoreError, kind: &str) -> ActorFailure {
    ActorFailure::new(
        ActorFailureKind::Infrastructure,
        format!("durable {kind} record failed: {error:?}"),
        "inspect the recovery store path and permissions",
    )
    .unwrap_or_else(|_| std::process::abort())
}
