use super::*;
use caly_domain::SubscriptionId;
use caly_ports::{ActorFailure, ConfigActorPort, ConfigCandidate};
use std::fs;

#[test]
fn supplied_fixture_refreshes_and_advances_generation() -> Result<(), ActorFailure> {
    let id = SubscriptionId::from_bytes([4; 16]);
    let body = fs::read("../../fixtures/subscription-20260803.txt").map_err(|_| {
        ActorFailure::new(
            caly_ports::ActorFailureKind::Infrastructure,
            "fixture read failed",
            "check fixture path",
        )
        .unwrap_or_else(|_| std::process::abort())
    })?;
    let mut backend = CachedSubscriptionBackend::new();
    backend.put_source(id, body);
    let projection = backend.refresh_projection(id)?;
    assert!(!projection.nodes.is_empty());
    // The fixture parses completely since VMess HTTP/H2 transports are
    // representable; any rejection would be a parser regression.
    assert_eq!(projection.rejected_lines, 0);
    assert_eq!(backend.generation(id), 1);
    Ok(())
}

#[test]
fn config_backend_rolls_back_to_previous_generation() -> Result<(), ActorFailure> {
    let destination = std::env::temp_dir().join(format!("caly-rollback-{}", std::process::id()));
    let mut backend = MihomoConfigBackend::new(destination.clone());
    let prepared_first = backend.parse_and_render(ConfigCandidate { id: [1; 16] })?;
    let first = backend.commit_candidate(prepared_first)?;
    let prepared_second = backend.parse_and_render(ConfigCandidate { id: [2; 16] })?;
    let second = backend.commit_candidate(prepared_second)?;
    assert!(
        std::fs::read_to_string(&destination)
            .map_err(|_| ActorFailure::new(
                caly_ports::ActorFailureKind::Infrastructure,
                "rollback test read failed",
                "retry test"
            )
            .unwrap_or_else(|_| std::process::abort()))?
            .contains("caly-generation: 2")
    );
    backend.rollback_commit(second)?;
    assert!(
        std::fs::read_to_string(&destination)
            .map_err(|_| ActorFailure::new(
                caly_ports::ActorFailureKind::Infrastructure,
                "rollback test read failed",
                "retry test"
            )
            .unwrap_or_else(|_| std::process::abort()))?
            .contains("caly-generation: 1")
    );
    let _ = backend.rollback_commit(first);
    let _ = fs::remove_file(destination);
    Ok(())
}

#[test]
fn config_backend_commits_a_generation() -> Result<(), ActorFailure> {
    let destination = std::env::temp_dir().join(format!("caly-config-{}", std::process::id()));
    let mut backend = MihomoConfigBackend::new(destination.clone());
    let prepared = backend.parse_and_render(ConfigCandidate { id: [5; 16] })?;
    let committed = backend.commit_candidate(prepared)?;
    assert_eq!(committed.generation, 1);
    assert!(destination.exists());
    let _ = fs::remove_file(destination);
    Ok(())
}

#[test]
fn failure_clamps_long_runtime_strings_without_panicking() {
    let long = "x".repeat(2000);
    let error = crate::failure(&long, &long);
    assert_eq!(error.message.len_bytes(), 512);
    assert_eq!(error.suggested_action.len_bytes(), 512);
}

#[test]
fn failure_empty_message_uses_fallback() {
    let error = crate::failure("", "do something");
    assert_eq!(error.message.as_str(), "operation failed");
    assert_eq!(error.suggested_action.as_str(), "do something");
}
