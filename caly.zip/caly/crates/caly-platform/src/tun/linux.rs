//! Linux TUN backend using shell-free `ip` commands.
//!
//! Managing TUN devices requires `CAP_NET_ADMIN`. A per-user daemon normally
//! lacks it, so every `ip` command first runs directly and, on failure, is
//! retried through the configured privilege escalation (`pkexec` for desktop
//! polkit prompts, then non-interactive `sudo -n`). A command that fails all
//! attempts reports the kernel's stderr plus actionable remediation.

use std::path::{Path, PathBuf};

use super::{OwnedTun, TunBackend, TunRequest};
use crate::{
    PlatformFailure,
    command::{CommandArguments, CommandRequest, CommandRunner, LinuxCommandRunner},
};
use caly_domain::BoundedText;

/// How the TUN backend may escalate privileged `ip` commands when the daemon
/// lacks `CAP_NET_ADMIN`.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum TunEscalation {
    /// Direct first, then `pkexec` (desktop polkit prompt), then `sudo -n`.
    #[default]
    Auto,
    /// Escalate only through `pkexec`.
    Pkexec,
    /// Escalate only through passwordless `sudo -n`.
    Sudo,
    /// Never escalate; report remediation instead.
    None,
}

/// Escalation label used in diagnostics and tests.
impl TunEscalation {
    pub const fn label(self) -> &'static str {
        match self {
            Self::Auto => "auto",
            Self::Pkexec => "pkexec",
            Self::Sudo => "sudo",
            Self::None => "none",
        }
    }
}

/// Linux TUN owner backed by `ip tuntap`/`ip link`.
pub struct LinuxTunBackend {
    runner: LinuxCommandRunner,
    escalation: TunEscalation,
}

impl Default for LinuxTunBackend {
    fn default() -> Self {
        Self {
            runner: LinuxCommandRunner,
            escalation: TunEscalation::default(),
        }
    }
}

impl LinuxTunBackend {
    /// Overrides the privilege-escalation policy for privileged `ip` commands.
    #[must_use]
    pub const fn with_escalation(mut self, escalation: TunEscalation) -> Self {
        self.escalation = escalation;
        self
    }
}

struct LinuxOwnedTun {
    interface: InterfaceName,
    runner: LinuxCommandRunner,
    escalation: TunEscalation,
}

type InterfaceName = BoundedText<64>;

impl TunBackend for LinuxTunBackend {
    fn engage(&mut self, request: TunRequest) -> Result<Box<dyn OwnedTun>, PlatformFailure> {
        engage_with(&mut self.runner, self.escalation, request)
    }
}

/// Engages a fresh TUN device through any bounded command runner (injectable
/// for tests). Drops a stale interface with the requested name first.
///
/// Every `ip` command is tried directly first; when the daemon lacks
/// `CAP_NET_ADMIN` the whole sequence is retried as ONE escalated `sh -c`
/// batch (`pkexec`, then `sudo -n`), so the user is prompted for the root
/// password at most once per engage instead of once per `ip` command.
fn engage_with(
    runner: &mut impl CommandRunner,
    escalation: TunEscalation,
    request: TunRequest,
) -> Result<Box<dyn OwnedTun>, PlatformFailure> {
    let interface = request.interface.clone();
    let mut commands: Vec<Vec<String>> = Vec::new();
    // A stale interface (left behind by a crashed daemon or an interrupted
    // earlier engage) must not block re-engagement: drop any existing
    // device with the requested name first, then create it fresh. If a
    // live process holds the same name, the delete fails with a clear
    // "in use" error instead of a confusing add-time EBUSY.
    if interface_exists(interface.as_str()) {
        commands.push(tun_command(vec![
            "tuntap",
            "del",
            "dev",
            interface.as_str(),
            "mode",
            "tun",
        ]));
    }
    commands.push(tun_command(vec![
        "tuntap",
        "add",
        "dev",
        interface.as_str(),
        "mode",
        "tun",
    ]));
    commands.push(tun_command(vec![
        "link",
        "set",
        "dev",
        interface.as_str(),
        "mtu",
        &request.mtu.to_string(),
    ]));
    commands.push(tun_command(vec![
        "link",
        "set",
        "dev",
        interface.as_str(),
        "up",
    ]));
    if let Err(error) = run_ip_sequence(runner, escalation, &commands) {
        // Best-effort cleanup of a partially applied engage; direct only,
        // never another password prompt.
        let _ = run_ip(
            runner,
            escalation,
            vec!["tuntap", "del", "dev", interface.as_str(), "mode", "tun"],
        );
        return Err(error);
    }
    Ok(Box::new(LinuxOwnedTun {
        interface,
        runner: LinuxCommandRunner,
        escalation,
    }))
}

impl OwnedTun for LinuxOwnedTun {
    fn interface(&self) -> &InterfaceName {
        &self.interface
    }

    fn restore(mut self: Box<Self>) -> Result<(), PlatformFailure> {
        run_ip(
            &mut self.runner,
            self.escalation,
            vec![
                "tuntap",
                "del",
                "dev",
                self.interface.as_str(),
                "mode",
                "tun",
            ],
        )
    }
}

/// Whether a network interface with the requested name already exists.
///
/// `/sys/class/net` reflects every interface the kernel knows about (persist
/// TUN devices included), so a leftover `caly0` from a previous run is
/// detected here and removed before a fresh one is created.
fn interface_exists(name: &str) -> bool {
    Path::new("/sys/class/net").join(name).is_dir()
}

/// Direct timeout for one `ip` command; escalation prompts may wait for the
/// user, so escalated attempts get a longer budget.
const DIRECT_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(3);
const ESCALATED_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(60);

/// Runs one `ip` command, escalating through the policy when the direct
/// attempt fails (typically a missing `CAP_NET_ADMIN`).
fn run_ip(
    runner: &mut impl CommandRunner,
    escalation: TunEscalation,
    values: Vec<&str>,
) -> Result<(), PlatformFailure> {
    let arguments = build_arguments(&values)?;
    let direct = attempt(runner, "ip", &[], &arguments, DIRECT_TIMEOUT);
    if direct.is_ok() {
        return direct;
    }
    for (executable, prefix) in escalation_prefixes(escalation) {
        if attempt(runner, executable, prefix, &arguments, ESCALATED_TIMEOUT).is_ok() {
            return Ok(());
        }
    }
    direct
}

/// Runs an ordered sequence of `ip` commands, trying every command directly
/// first and, on the first direct failure, escalating the REMAINING commands
/// as one `sh -c` batch. Batching matters: without it, an escalated engage
/// prompts for the root password once per `ip` command (up to four prompts);
/// with it the user authenticates at most once.
fn run_ip_sequence(
    runner: &mut impl CommandRunner,
    escalation: TunEscalation,
    commands: &[Vec<String>],
) -> Result<(), PlatformFailure> {
    // Phase 1: direct attempts in order; commands before the first failure
    // were applied without privileges and must not run again escalated.
    let mut pending_from = 0_usize;
    for (index, command) in commands.iter().enumerate() {
        let arguments = build_arguments_strs(command)?;
        if attempt(runner, "ip", &[], &arguments, DIRECT_TIMEOUT).is_err() {
            pending_from = index;
            break;
        }
        pending_from = index + 1;
    }
    if pending_from == commands.len() {
        return Ok(());
    }
    let script = build_batch_script(&commands[pending_from..])?;
    let mut script_argument = CommandArguments::new();
    let script_text =
        BoundedText::new(script).map_err(|_| failure("TUN escalation script is too long"))?;
    script_argument
        .try_push(script_text)
        .map_err(|_| failure("TUN escalation argument list is full"))?;
    for (executable, prefix) in escalation_prefixes(escalation) {
        if attempt_batch(
            runner,
            executable,
            prefix,
            &script_argument,
            ESCALATED_TIMEOUT,
        )
        .is_ok()
        {
            return Ok(());
        }
    }
    Err(failure_with_detail(
        "Linux ip TUN commands failed and every escalation attempt failed",
    ))
}

/// Builds one `ip` command's arguments as owned bounded strings.
fn tun_command(values: Vec<&str>) -> Vec<String> {
    values.into_iter().map(str::to_owned).collect()
}

/// Builds bounded arguments from owned strings.
fn build_arguments_strs(values: &[String]) -> Result<CommandArguments, PlatformFailure> {
    let mut arguments = CommandArguments::new();
    for value in values {
        let argument = BoundedText::new(value.clone())
            .map_err(|_| failure("TUN command argument is too long"))?;
        arguments
            .try_push(argument)
            .map_err(|_| failure("TUN command argument list is full"))?;
    }
    Ok(arguments)
}

/// Joins commands into one `ip ... && ip ...` script for `sh -c`. Only the
/// interface name and MTU are interpolated; the interface name is validated
/// as a plain kernel token so hostile input cannot escape the shell.
fn build_batch_script(commands: &[Vec<String>]) -> Result<String, PlatformFailure> {
    let mut script = String::new();
    for (index, command) in commands.iter().enumerate() {
        if index > 0 {
            script.push_str(" && ");
        }
        script.push_str("ip");
        for argument in command {
            if !argument.is_empty()
                && argument
                    .bytes()
                    .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_' || b == b'.')
            {
                script.push(' ');
                script.push_str(argument);
            } else {
                return Err(failure("TUN interface name is not a safe kernel token"));
            }
        }
    }
    Ok(script)
}

/// Ordered escalation candidates for a policy. Spawn failures (missing binary)
/// are handled by the caller skipping a failed attempt, so availability needs
/// no separate probing.
fn escalation_prefixes(policy: TunEscalation) -> Vec<(&'static str, &'static [&'static str])> {
    match policy {
        TunEscalation::Auto => vec![("pkexec", &[] as &[_]), ("sudo", &["-n"])],
        TunEscalation::Pkexec => vec![("pkexec", &[] as &[_])],
        TunEscalation::Sudo => vec![("sudo", &["-n"])],
        TunEscalation::None => Vec::new(),
    }
}

fn build_arguments(values: &[&str]) -> Result<CommandArguments, PlatformFailure> {
    let mut arguments = CommandArguments::new();
    for value in values {
        let argument = BoundedText::new((*value).to_owned())
            .map_err(|_| failure("TUN command argument is too long"))?;
        arguments
            .try_push(argument)
            .map_err(|_| failure("TUN command argument list is full"))?;
    }
    Ok(arguments)
}

/// Executes one attempt: `executable [prefix...] ip [arguments...]`.
fn attempt(
    runner: &mut impl CommandRunner,
    executable: &str,
    prefix: &[&str],
    arguments: &CommandArguments,
    timeout: std::time::Duration,
) -> Result<(), PlatformFailure> {
    let mut full = CommandArguments::new();
    for value in prefix {
        let argument = BoundedText::new((*value).to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    // The `ip` program name is the first argument once a helper (pkexec/sudo)
    // fronts the command; it is the executable for the direct attempt.
    let direct = executable == "ip" && prefix.is_empty();
    if !direct {
        let ip_argument = BoundedText::new("ip".to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(ip_argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    for argument in arguments {
        full.try_push(argument.clone())
            .map_err(|_| failure("TUN command argument list is full"))?;
    }
    let program = if direct { "ip" } else { executable };
    let result = runner.run_bounded(CommandRequest {
        executable: PathBuf::from(program),
        arguments: full,
        timeout,
    })?;
    if result.exit_code == Some(0) {
        Ok(())
    } else {
        let detail = first_line(&result.stderr);
        Err(failure_with_detail(&format!(
            "Linux ip TUN command failed{detail}"
        )))
    }
}

/// Executes one escalated `sh -c <script>` batch: the single password prompt
/// that replaces per-command escalation during a TUN engage.
fn attempt_batch(
    runner: &mut impl CommandRunner,
    executable: &str,
    prefix: &[&str],
    script: &CommandArguments,
    timeout: std::time::Duration,
) -> Result<(), PlatformFailure> {
    let mut full = CommandArguments::new();
    for value in prefix {
        let argument = BoundedText::new((*value).to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    for value in ["sh", "-c"] {
        let argument = BoundedText::new(value.to_owned())
            .map_err(|_| failure("TUN escalation argument is too long"))?;
        full.try_push(argument)
            .map_err(|_| failure("TUN escalation argument list is full"))?;
    }
    for argument in script {
        full.try_push(argument.clone())
            .map_err(|_| failure("TUN command argument list is full"))?;
    }
    let result = runner.run_bounded(CommandRequest {
        executable: PathBuf::from(executable),
        arguments: full,
        timeout,
    })?;
    if result.exit_code == Some(0) {
        Ok(())
    } else {
        let detail = first_line(&result.stderr);
        Err(failure_with_detail(&format!(
            "Linux ip TUN batch command failed{detail}"
        )))
    }
}

/// First stderr line, bounded and prefixed for embedding in the failure.
fn first_line(stderr: &[u8]) -> String {
    let text = String::from_utf8_lossy(stderr);
    let line = text.lines().next().unwrap_or("").trim();
    if line.is_empty() {
        String::new()
    } else {
        let bounded: String = line.chars().take(160).collect();
        format!(": {bounded}")
    }
}

fn failure(message: &str) -> PlatformFailure {
    failure_parts(message, "check ip command and CAP_NET_ADMIN")
}

fn failure_with_detail(message: &str) -> PlatformFailure {
    failure_parts(
        message,
        "grant CAP_NET_ADMIN once with `caly doctor --fix` (a single sudo prompt for ip and the \
         core binaries), allow passwordless sudo for ip, or run the daemon with CAP_NET_ADMIN; \
         escalation via pkexec/sudo was attempted per tun.escalation",
    )
}

fn failure_parts(message: &str, action: &str) -> PlatformFailure {
    PlatformFailure {
        operation: BoundedText::new("tun-operation".to_owned())
            .unwrap_or_else(|_| std::process::abort()),
        resource: BoundedText::new("linux-tun".to_owned())
            .unwrap_or_else(|_| std::process::abort()),
        message: BoundedText::new(message.to_owned()).unwrap_or_else(|_| std::process::abort()),
        suggested_action: BoundedText::new(action.to_owned())
            .unwrap_or_else(|_| std::process::abort()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::command::{CommandOutput, CommandResult};

    /// Records every command without executing anything, so stale-interface
    /// handling can be asserted safely (never touches a real device).
    #[derive(Clone, Default)]
    struct RecordingRunner {
        calls: std::rc::Rc<std::cell::RefCell<Vec<String>>>,
    }

    impl CommandRunner for RecordingRunner {
        fn run_bounded(
            &mut self,
            request: CommandRequest,
        ) -> Result<CommandResult, PlatformFailure> {
            let mut line = request.executable.to_string_lossy().into_owned();
            for argument in &request.arguments {
                line.push(' ');
                line.push_str(argument.as_str());
            }
            self.calls.borrow_mut().push(line);
            Ok(CommandResult {
                exit_code: Some(0),
                stdout: CommandOutput::new(),
                stderr: CommandOutput::new(),
            })
        }
    }

    fn tun_request(name: &str) -> TunRequest {
        TunRequest {
            interface: BoundedText::new(name.to_owned()).unwrap_or_else(|_| std::process::abort()),
            mtu: 1400,
        }
    }

    #[test]
    fn interface_exists_detects_real_interfaces_only() {
        // `lo` always exists on Linux; a unique name never does.
        assert!(interface_exists("lo"));
        let unique = format!("caly-test-{}", std::process::id());
        assert!(!interface_exists(&unique));
    }

    #[test]
    fn engage_drops_stale_interface_before_creating_fresh() -> Result<(), String> {
        let mut runner = RecordingRunner::default();
        // `lo` exists, so engage must delete it first (recorded only; the mock
        // never executes anything) and then recreate + configure it.
        let _owned = engage_with(&mut runner, TunEscalation::None, tun_request("lo"))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert!(
            calls
                .first()
                .is_some_and(|line| line.contains("tuntap del dev lo")),
            "stale interface must be deleted first, got {calls:?}"
        );
        assert!(
            calls.iter().any(|line| line.contains("tuntap add dev lo")),
            "a fresh interface must then be created, got {calls:?}"
        );
        assert!(calls.len() >= 3, "add + mtu + up expected: {calls:?}");
        Ok(())
    }

    #[test]
    fn engage_without_stale_interface_goes_straight_to_add() -> Result<(), String> {
        let mut runner = RecordingRunner::default();
        let unique = format!("caly-test-{}", std::process::id());
        engage_with(&mut runner, TunEscalation::None, tun_request(&unique))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert!(
            calls
                .first()
                .is_some_and(|line| line.contains("tuntap add dev")),
            "no stale interface: the first command must be add, got {calls:?}"
        );
        Ok(())
    }

    #[test]
    fn first_line_bounds_stderr_detail() {
        assert_eq!(first_line(b""), "");
        assert_eq!(
            first_line(b"Operation not permitted\nmore\n"),
            ": Operation not permitted"
        );
    }

    #[test]
    fn escalation_labels_are_stable() {
        assert_eq!(TunEscalation::Auto.label(), "auto");
        assert_eq!(TunEscalation::Pkexec.label(), "pkexec");
        assert_eq!(TunEscalation::Sudo.label(), "sudo");
        assert_eq!(TunEscalation::None.label(), "none");
    }

    #[test]
    fn batch_script_joins_commands_and_rejects_unsafe_tokens() -> Result<(), String> {
        let script = build_batch_script(&[
            vec![
                "tuntap".to_owned(),
                "add".to_owned(),
                "dev".to_owned(),
                "caly0".to_owned(),
                "mode".to_owned(),
                "tun".to_owned(),
            ],
            vec![
                "link".to_owned(),
                "set".to_owned(),
                "dev".to_owned(),
                "caly0".to_owned(),
                "up".to_owned(),
            ],
        ])
        .map_err(|e| e.to_string())?;
        assert_eq!(
            script,
            "ip tuntap add dev caly0 mode tun && ip link set dev caly0 up"
        );
        // A hostile interface name must not reach the shell.
        assert!(
            build_batch_script(&[vec![
                "link".to_owned(),
                "set".to_owned(),
                "dev".to_owned(),
                "x;rm -rf /".to_owned(),
                "up".to_owned()
            ]])
            .is_err()
        );
        Ok(())
    }

    /// A runner that fails every direct attempt (as a daemon without
    /// `CAP_NET_ADMIN` would) and records escalated calls.
    #[derive(Clone, Default)]
    struct EscalatingRunner {
        calls: std::rc::Rc<std::cell::RefCell<Vec<String>>>,
    }

    impl CommandRunner for EscalatingRunner {
        fn run_bounded(
            &mut self,
            request: CommandRequest,
        ) -> Result<CommandResult, PlatformFailure> {
            let mut line = request.executable.to_string_lossy().into_owned();
            for argument in &request.arguments {
                line.push(' ');
                line.push_str(argument.as_str());
            }
            self.calls.borrow_mut().push(line);
            let escalated = request.executable.to_string_lossy() == "pkexec";
            Ok(CommandResult {
                exit_code: Some(i32::from(!escalated)),
                stdout: CommandOutput::new(),
                stderr: CommandOutput::new(),
            })
        }
    }

    #[test]
    fn engage_without_privileges_escalates_one_batch_not_per_command() -> Result<(), String> {
        let mut runner = EscalatingRunner::default();
        let unique = format!("caly-test-{}", std::process::id());
        engage_with(&mut runner, TunEscalation::Pkexec, tun_request(&unique))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        // Every direct `ip` attempt happened (and failed), then exactly ONE
        // escalated `sh -c` batch carries the whole sequence.
        let direct: Vec<&String> = calls
            .iter()
            .filter(|line| line.starts_with("ip "))
            .collect();
        let escalated: Vec<&String> = calls
            .iter()
            .filter(|line| line.starts_with("pkexec "))
            .collect();
        assert_eq!(
            escalated.len(),
            1,
            "one password prompt expected: {calls:?}"
        );
        assert!(
            escalated[0].contains("sh -c ip tuntap add dev ")
                && escalated[0].contains(" && ip link set dev "),
            "escalated batch must chain the remaining commands: {escalated:?}"
        );
        // The direct phase stops at the first failure (add), so exactly one
        // direct attempt precedes the single escalated batch.
        assert_eq!(
            direct.len(),
            1,
            "first direct attempt then one batch: {calls:?}"
        );
        Ok(())
    }

    #[test]
    fn engage_with_direct_privileges_never_escalates() -> Result<(), String> {
        let mut runner = RecordingRunner::default();
        let unique = format!("caly-test-{}", std::process::id());
        engage_with(&mut runner, TunEscalation::Pkexec, tun_request(&unique))
            .map_err(|e| e.to_string())?;
        let calls = runner.calls.borrow();
        assert!(
            calls.iter().all(|line| line.starts_with("ip ")),
            "no escalation when direct commands succeed: {calls:?}"
        );
        assert_eq!(calls.len(), 3);
        Ok(())
    }
}
