//! Recoverable TUN side-effect contract.

pub mod linux;
pub use linux::{LinuxTunBackend, TunEscalation};

use caly_domain::BoundedText;

use crate::PlatformFailure;

/// Single validated interface component.
pub type InterfaceName = BoundedText<64>;

/// TUN ownership settings.
pub struct TunRequest {
    pub interface: InterfaceName,
    pub mtu: u16,
}

/// Sole owned TUN side effect.
pub trait OwnedTun: Send {
    fn interface(&self) -> &InterfaceName;
    fn restore(self: Box<Self>) -> Result<(), PlatformFailure>;
}

/// Platform backend that verifies conflicts before engagement.
pub trait TunBackend {
    fn engage(&mut self, request: TunRequest) -> Result<Box<dyn OwnedTun>, PlatformFailure>;
}
