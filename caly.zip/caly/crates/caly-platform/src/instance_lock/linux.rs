//! Linux-compatible owner-token instance lock backend.
//!
//! The lock is acquired with an atomic `create_new` operation. The file remains
//! owned by the process and contains a token, so release can never remove a
//! replacement lock created by another owner.

use std::{
    fs::{self, File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
};

use super::{
    InstanceLock, InstanceLockBackend, LockOwner, reclaim::owner_token, reclaim::reclaim_stale,
};
use crate::PlatformFailure;
use crate::bounded_text as bounded;

/// File-backed instance-lock backend for Linux.
#[derive(Default)]
pub struct LinuxInstanceLockBackend;

/// An acquired Linux instance lock.
pub struct LinuxInstanceLock {
    file: File,
    path: PathBuf,
    owner: LockOwner,
}

impl InstanceLockBackend for LinuxInstanceLockBackend {
    fn acquire(
        &mut self,
        path: PathBuf,
        owner: LockOwner,
    ) -> Result<Box<dyn InstanceLock>, PlatformFailure> {
        match Self::acquire_create_new(&path, owner) {
            Ok(lock) => Ok(lock),
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
                // A previous daemon may have crashed (`kill -9`) and left a
                // stale lock. Reclaim it only when its owner process is dead.
                if reclaim_stale(&path)? {
                    Self::acquire_create_new(&path, owner).map_err(|error| {
                        failure(
                            "acquire-lock",
                            &path,
                            format!("cannot create owner-only lock after reclaim: {error}"),
                            "stop the existing daemon or choose another runtime path",
                        )
                    })
                } else {
                    Err(failure(
                        "acquire-lock",
                        &path,
                        "instance lock is held by a live process".to_owned(),
                        "stop the existing daemon or choose another runtime path",
                    ))
                }
            }
            Err(error) => Err(failure(
                "acquire-lock",
                &path,
                format!("cannot create owner-only lock: {error}"),
                "stop the existing daemon or choose another runtime path",
            )),
        }
    }
}

impl LinuxInstanceLockBackend {
    fn acquire_create_new(
        path: &PathBuf,
        owner: LockOwner,
    ) -> std::io::Result<Box<dyn InstanceLock>> {
        ensure_parent_dir(path)?;
        let mut options = OpenOptions::new();
        options.read(true).write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        let mut file = options.open(path)?;
        let token = owner_token(owner);
        file.write_all(token.as_bytes())?;
        file.sync_all()?;
        Ok(Box::new(LinuxInstanceLock {
            file,
            path: path.clone(),
            owner,
        }))
    }
}

impl InstanceLock for LinuxInstanceLock {
    fn owner(&self) -> LockOwner {
        self.owner
    }

    fn release(mut self: Box<Self>) -> Result<(), PlatformFailure> {
        let mut contents = String::new();
        self.file.seek(SeekFrom::Start(0)).map_err(|error| {
            failure(
                "read-lock",
                &self.path,
                format!("cannot seek lock owner token: {error}"),
                "inspect the runtime lock file before retrying",
            )
        })?;
        self.file.read_to_string(&mut contents).map_err(|error| {
            failure(
                "read-lock",
                &self.path,
                format!("cannot read lock owner token: {error}"),
                "inspect the runtime lock file before retrying",
            )
        })?;
        if contents != owner_token(self.owner) {
            return Err(failure(
                "release-lock",
                &self.path,
                "lock owner token changed while held".to_owned(),
                "do not remove the lock manually; investigate concurrent ownership",
            ));
        }
        drop(self.file);
        fs::remove_file(&self.path).map_err(|error| {
            failure(
                "release-lock",
                &self.path,
                format!("cannot remove owner lock: {error}"),
                "remove the lock only after confirming the daemon is stopped",
            )
        })
    }
}

/// Creates the lock file's parent directory owner-only when it does not exist,
/// so a fresh XDG runtime root can host the lock without manual setup.
///
/// Permissions are tightened only for directories this function creates: a
/// pre-existing parent (e.g. the system `/tmp` or an XDG runtime root the user
/// already provisioned) is never chmod'ed, and a symlinked parent is rejected
/// outright so no path we own ever follows one.
fn ensure_parent_dir(path: &Path) -> std::io::Result<()> {
    let Some(parent) = path.parent() else {
        return Ok(());
    };
    if parent.as_os_str().is_empty() {
        return Ok(());
    }
    if parent.exists() {
        #[cfg(unix)]
        {
            let metadata = std::fs::symlink_metadata(parent)?;
            if metadata.file_type().is_symlink() {
                return Err(std::io::Error::other(
                    "refusing to use a symlinked runtime parent directory",
                ));
            }
        }
        return Ok(());
    }
    std::fs::create_dir_all(parent)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
    }
    Ok(())
}

fn failure(
    operation: &'static str,
    path: &Path,
    message: String,
    action: &'static str,
) -> PlatformFailure {
    PlatformFailure {
        operation: bounded(operation.to_owned(), "lock-operation"),
        resource: bounded(path.display().to_string(), "lock-path"),
        message: bounded(message, "platform lock operation failed"),
        suggested_action: bounded(action.to_owned(), "inspect the runtime lock"),
    }
}

#[cfg(test)]
mod tests {
    use super::super::current_process_start_id;
    use super::*;
    use std::{
        fs,
        time::{SystemTime, UNIX_EPOCH},
    };

    fn owner(seed: u8) -> LockOwner {
        LockOwner {
            pid: std::process::id(),
            process_start_id: current_process_start_id().unwrap_or(u64::from(seed)),
            owner_token: [seed; 16],
        }
    }

    fn path() -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("caly-lock-{nanos}"))
    }

    #[test]
    fn acquire_is_atomic_and_release_removes_only_owned_lock() -> Result<(), PlatformFailure> {
        let path = path();
        let mut backend = LinuxInstanceLockBackend;
        let lock = backend.acquire(path.clone(), owner(1))?;
        assert_eq!(lock.owner(), owner(1));
        assert!(backend.acquire(path.clone(), owner(2)).is_err());
        lock.release()?;
        assert!(!path.exists());
        Ok(())
    }

    #[test]
    fn release_rejects_changed_owner_token() -> Result<(), PlatformFailure> {
        let path = path();
        let mut backend = LinuxInstanceLockBackend;
        let lock = backend.acquire(path.clone(), owner(3))?;
        assert!(fs::write(&path, owner_token(owner(4))).is_ok());
        assert!(lock.release().is_err());
        let _ = fs::remove_file(path);
        Ok(())
    }

    #[test]
    fn stale_lock_from_dead_owner_is_reclaimed() -> Result<(), PlatformFailure> {
        let path = path();
        // A lock owned by a dead PID (999999 + a start id) is stale and must be
        // reclaimed so the new daemon can start.
        fs::write(&path, format!("999999:1:{}\n", "aa".repeat(16))).map_err(|_| {
            failure(
                "setup",
                &path,
                "cannot write stale lock".to_owned(),
                "inspect runtime dir",
            )
        })?;
        let mut backend = LinuxInstanceLockBackend;
        let lock = backend.acquire(path.clone(), owner(5))?;
        assert_eq!(lock.owner(), owner(5));
        lock.release()?;
        assert!(!path.exists());
        Ok(())
    }

    #[test]
    fn acquire_creates_missing_parent_directory() -> Result<(), PlatformFailure> {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        let dir = std::env::temp_dir().join(format!("caly-lock-dir-{nanos}"));
        let path = dir.join("nested/daemon.lock");
        let mut backend = LinuxInstanceLockBackend;
        let lock = backend.acquire(path.clone(), owner(9))?;
        assert!(path.exists());
        lock.release()?;
        assert!(!path.exists());
        let _ = std::fs::remove_dir_all(&dir);
        Ok(())
    }

    #[test]
    fn live_lock_is_not_reclaimed() -> Result<(), PlatformFailure> {
        let path = path();
        // Our own (live) PID with its real start identity must not be reclaimed.
        let live_start = current_process_start_id().map_err(|_| {
            failure(
                "setup",
                &path,
                "cannot read process start id".to_owned(),
                "inspect /proc",
            )
        })?;
        let token = format!("{}:{live_start}:{}\n", std::process::id(), "bb".repeat(16));
        fs::write(&path, token).map_err(|_| {
            failure(
                "setup",
                &path,
                "cannot write lock".to_owned(),
                "inspect runtime dir",
            )
        })?;
        let mut backend = LinuxInstanceLockBackend;
        let result = backend.acquire(path.clone(), owner(6));
        assert!(result.is_err(), "live lock must not be reclaimed");
        let _ = fs::remove_file(path);
        Ok(())
    }
}
