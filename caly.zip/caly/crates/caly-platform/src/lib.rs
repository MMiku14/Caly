//! Cross-platform infrastructure boundary.
//!
//! Concrete OS backends must live in this crate. Current modules define
//! truthful transaction and ownership contracts; unsupported operations must
//! return structured failure rather than empty success.

#![forbid(unsafe_code)]

pub mod command;
pub mod dns_probe;
pub mod entropy;
mod error;
pub mod fs;
pub mod instance_lock;
pub mod paths;
pub mod process;
pub mod node_selection;
pub mod recovery;
pub mod secrets;
pub mod tun;
pub mod uds;

pub use error::PlatformFailure;

/// Builds a bounded text value, falling back to a static label on overflow and
/// aborting only when even the fallback overflows (a fixed-text invariant
/// violation). Shared across platform backends to avoid per-file duplication.
pub(crate) fn bounded_text<const MAX: usize>(
    value: impl Into<String>,
    fallback: &'static str,
) -> caly_domain::BoundedText<MAX> {
    match caly_domain::BoundedText::new(value.into()) {
        Ok(value) => value,
        Err(_) => match caly_domain::BoundedText::new(fallback.to_owned()) {
            Ok(value) => value,
            Err(_) => std::process::abort(),
        },
    }
}
