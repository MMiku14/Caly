pub(super) use super::recovery::spawn_exit_monitor;

use std::time::Duration;

use crate::{
    actor_result::{ActorResultClient, ActorResultReceiver, ResultDeltas},
    actors::{
        CoreCommandHandler, CoreLifecycleCommandHandler, PlatformCommandHandler,
        SubscriptionCommandHandler,
    },
    command_bus::CommandReceiver,
    projection::ProjectionRuntime,
    routing_fanout::ActorCommandFanout,
    runtime::{ActorHandler, ActorLoopExit, TokioTaskFailure, TokioTaskGroup, run_actor},
    service::runtime_service::RuntimeService,
};

use caly_backends::HttpSubscriptionBackend;

use super::{
    CompositionError, WallClock, bounded_task_reason, bounded_task_reason_owned, task_name,
    task_name_or_abort,
};

/// Initial backoff before the first auto-restart after a crash.
/// Receivers for the five owner actor handlers.
pub(super) struct HandlerReceivers {
    pub core_lifecycle: crate::runtime::ActorReceiver<crate::routing::RoutedCommand>,
    pub config: crate::runtime::ActorReceiver<crate::routing::RoutedCommand>,
    pub core: crate::runtime::ActorReceiver<crate::routing::RoutedCommand>,
    pub subscription: crate::runtime::ActorReceiver<crate::routing::RoutedCommand>,
    pub platform: crate::runtime::ActorReceiver<crate::routing::RoutedCommand>,
}

pub(super) fn spawn_handlers<B, T>(
    tasks: &mut TokioTaskGroup,
    receivers: HandlerReceivers,
    cancellation: crate::runtime::CancellationToken,
    result_client: ActorResultClient,
    core_backend: caly_backends::dual::SwitchableCoreBackend,
    subscription_backend: HttpSubscriptionBackend,
    platform_backend: B,
    tun_backend: T,
    lifecycle_backend: caly_backends::dual::DualCoreLifecycle,
    config_backend: caly_backends::config::ActiveConfigBackend,
    active_cell: caly_backends::dual::SharedActiveCore,
) -> Result<(), CompositionError>
where
    B: caly_ports::PlatformCommandBackend + Send + 'static,
    T: caly_ports::TunCommandBackend + Send + 'static,
{
    // One shared desired-state cell across the mode and platform owners, so a
    // SetMode delta never clobbers a SetTun/SetSystemProxy flag (or vice
    // versa) when both publish DesiredReplaced.
    let desired = caly_backends::SharedDesiredState::default();
    spawn_handler_task(
        tasks,
        receivers.core_lifecycle,
        "core-lifecycle",
        cancellation.clone(),
        CoreLifecycleCommandHandler::new(lifecycle_backend.clone(), result_client.clone()),
    )?;
    spawn_handler_task(
        tasks,
        receivers.config,
        "config",
        cancellation.clone(),
        crate::actors::ConfigCommandHandler::new(
            config_backend,
            lifecycle_backend,
            active_cell,
            result_client.clone(),
        ),
    )?;
    spawn_handler_task(
        tasks,
        receivers.core,
        "core",
        cancellation.clone(),
        CoreCommandHandler::new(core_backend, result_client.clone(), desired.clone()),
    )?;
    spawn_handler_task(
        tasks,
        receivers.subscription,
        "subscription",
        cancellation.clone(),
        SubscriptionCommandHandler::new(subscription_backend, result_client.clone()),
    )?;
    spawn_handler_task(
        tasks,
        receivers.platform,
        "platform",
        cancellation,
        PlatformCommandHandler::new(platform_backend, tun_backend, desired, result_client),
    )?;
    Ok(())
}

/// Spawns the TelemetryActor handler plus the periodic telemetry scheduler that
/// produces `Sample` and publishes the refreshed observed state to the projection.
/// Builds the telemetry backend for the configured core.
///
/// The active core selects the matching kernel control (Mihomo or sing-box) and
/// controller address, sharing the daemon's controller auth secret so sampling
/// is authenticated. When the control cannot be constructed (unsupported core
/// or bad address), a control-less backend is returned that keeps the observed
/// cell authoritative without failing startup.
fn telemetry_dual(
    active_cell: caly_backends::dual::SharedActiveCore,
    secret: Option<String>,
    observed: caly_backends::SharedObservedState,
    controllers: &caly_domain::Controllers,
) -> caly_backends::TelemetryBackend {
    let clamp = |value: String| {
        let value: String = value.chars().take(4_096).collect();
        caly_domain::BoundedText::new(value).unwrap_or_else(|_| std::process::abort())
    };
    let mihomo = caly_kernel::mihomo::MihomoHttpControl::new(
        controllers.mihomo.clone(),
        secret.clone().map(clamp),
    )
    .map(|control| Box::new(control) as Box<dyn caly_kernel::ports::KernelControl + Send>);
    let sing_box = caly_kernel::sing_box::SingBoxHttpControl::new(
        controllers.sing_box.clone(),
        secret.map(clamp),
    )
    .map(|control| Box::new(control) as Box<dyn caly_kernel::ports::KernelControl + Send>);
    // A control that cannot be constructed keeps the observed cell
    // authoritative without failing startup, but the degradation must be
    // visible: an unobservable controller usually means a bad controller
    // address/secret, which would otherwise surface as silently stale
    // telemetry.
    let degraded: Vec<&str> = match (&mihomo, &sing_box) {
        (Err(_), Err(_)) => vec!["mihomo", "sing-box"],
        (Err(_), Ok(_)) => vec!["mihomo"],
        (Ok(_), Err(_)) => vec!["sing-box"],
        (Ok(_), Ok(_)) => Vec::new(),
    };
    if !degraded.is_empty() {
        tracing::warn!(
            degraded = %degraded.join(","),
            "telemetry controller construction failed for: {}; check controllers.* and the daemon controller secret (telemetry will stay stale)",
            degraded.join(", ")
        );
    }
    match (mihomo, sing_box) {
        (Ok(mihomo), Ok(sing_box)) => {
            caly_backends::TelemetryBackend::new(observed).with_controller(Box::new(
                caly_backends::dual::SwitchableKernelControl::new(active_cell, mihomo, sing_box),
            ))
        }
        _ => caly_backends::TelemetryBackend::new(observed),
    }
}

pub(super) fn spawn_supervision(
    tasks: &mut TokioTaskGroup,
    telemetry_receiver: crate::runtime::ActorReceiver<crate::actors::TelemetryActorCommand>,
    telemetry_ingress: crate::runtime::ActorIngress<crate::actors::TelemetryActorCommand>,
    lifecycle_handle: &caly_backends::dual::DualCoreLifecycle,
    result_client: ActorResultClient,
    _configured_core: caly_domain::CoreKind,
    controller_secret: Option<String>,
    controllers: &caly_domain::Controllers,
    telemetry_interval: std::time::Duration,
    cancellation: crate::runtime::CancellationToken,
) -> Result<(), CompositionError> {
    let observed = caly_backends::SharedObservedState::default();
    let telemetry = telemetry_dual(
        lifecycle_handle.active_cell(),
        controller_secret,
        observed.clone(),
        controllers,
    );
    spawn_telemetry_handler(tasks, telemetry_receiver, telemetry, cancellation.clone())?;
    spawn_telemetry_scheduler(
        tasks,
        telemetry_ingress,
        observed,
        result_client,
        telemetry_interval,
        cancellation,
    )
}

/// Spawns a periodic producer that requests a telemetry `Sample` and publishes
/// the refreshed `ObservedState` to the projection. Delivery is best-effort: a
/// full/closed mailbox or a transient delta overflow is ignored and the loop
/// continues, so telemetry can never take down the daemon.
fn spawn_telemetry_scheduler(
    tasks: &mut TokioTaskGroup,
    telemetry: crate::runtime::ActorIngress<crate::actors::TelemetryActorCommand>,
    observed: caly_backends::SharedObservedState,
    results: ActorResultClient,
    interval: std::time::Duration,
    cancellation: crate::runtime::CancellationToken,
) -> Result<(), CompositionError> {
    tasks
        .spawn_owned_with_fault(
            task_name("telemetry-scheduler")?,
            crate::runtime::FatalFault::Projection,
            async move {
                let mut interval = tokio::time::interval(interval);
                interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
                while !cancellation.is_cancelled() {
                    interval.tick().await;
                    if cancellation.is_cancelled() {
                        break;
                    }
                    let _ = telemetry.try_send(crate::actors::TelemetryActorCommand::Sample);
                    let state = observed.value();
                    let Ok(deltas) = ResultDeltas::try_from_vec(vec![
                        caly_domain::PresentationDelta::ObservedReplaced(state),
                    ]) else {
                        continue;
                    };
                    let _ =
                        results.try_report(crate::actor_result::ActorReport::Observed { deltas });
                }
                Ok(())
            },
        )
        .map_err(|_| CompositionError::TaskCapacity)
}

/// Spawns the TelemetryActor handler task (the single supervision owner).
fn spawn_telemetry_handler(
    tasks: &mut TokioTaskGroup,
    telemetry_receiver: crate::runtime::ActorReceiver<crate::actors::TelemetryActorCommand>,
    telemetry: caly_backends::TelemetryBackend,
    cancellation: crate::runtime::CancellationToken,
) -> Result<(), CompositionError> {
    spawn_handler_task(
        tasks,
        telemetry_receiver,
        "telemetry",
        cancellation,
        crate::actors::TelemetryCommandHandler(telemetry),
    )
}

fn spawn_handler_task<M, H>(
    tasks: &mut TokioTaskGroup,
    receiver: crate::runtime::ActorReceiver<M>,
    name: &'static str,
    cancellation: crate::runtime::CancellationToken,
    handler: H,
) -> Result<(), CompositionError>
where
    M: Send + 'static,
    H: ActorHandler<M> + Send + 'static,
    H::Error: core::fmt::Debug + Send,
{
    let task_name = task_name(name)?;
    tasks
        .spawn_owned(task_name.clone(), async move {
            let actor = tokio::task::spawn_blocking(move || {
                let mut handler = handler;
                run_actor(
                    receiver,
                    &cancellation,
                    Duration::from_millis(25),
                    &mut handler,
                )
            });
            match actor.await.map_err(|_| TokioTaskFailure::Join {
                name: task_name.clone(),
            })? {
                ActorLoopExit::Cancelled
                | ActorLoopExit::MailboxClosed
                | ActorLoopExit::HandlerStopped => Ok(()),
                ActorLoopExit::InvalidPollInterval => Err(TokioTaskFailure::Task {
                    name: task_name,
                    reason: bounded_task_reason("invalid actor poll interval"),
                }),
                ActorLoopExit::HandlerFailed(error) => Err(TokioTaskFailure::Task {
                    name: task_name,
                    reason: bounded_task_reason_owned(format!("actor handler failed: {error:?}")),
                }),
            }
        })
        .map_err(|_| CompositionError::TaskCapacity)
}

type SharedRuntimeService =
    std::sync::Arc<std::sync::Mutex<RuntimeService<WallClock, ProjectionRuntime>>>;
type SharedRuntimeGuard = std::sync::Arc<std::sync::Mutex<crate::runtime::RuntimeGuard>>;

fn actor_result_step(
    service: &SharedRuntimeService,
    receiver: &ActorResultReceiver,
    runtime_guard: &SharedRuntimeGuard,
) -> Result<bool, TokioTaskFailure> {
    let result = service
        .lock()
        .map_err(|_| dispatcher_failure("application service lock poisoned"))?
        .apply_actor_result_once(receiver, Duration::from_millis(1));
    match result {
        Ok(crate::service::results::ActorResultOutcome::MailboxClosed) => Ok(true),
        Ok(_) => Ok(false),
        Err(error) => {
            if let Ok(mut guard) = runtime_guard.lock() {
                guard.record_actor_result_error(&error);
            }
            Err(dispatcher_failure("actor result application failed"))
        }
    }
}

fn dispatch_step(
    service: &SharedRuntimeService,
    receiver: &CommandReceiver,
    fanout: &mut ActorCommandFanout,
    runtime_guard: &SharedRuntimeGuard,
) -> Result<(), TokioTaskFailure> {
    let result = service
        .lock()
        .map_err(|_| dispatcher_failure("application service lock poisoned"))?
        .dispatch_once(receiver, fanout, Duration::from_millis(25));
    if let Err(error) = result {
        if let Ok(mut guard) = runtime_guard.lock() {
            guard.record_dispatch_error(&error);
        }
        return Err(dispatcher_failure("command dispatch failed"));
    }
    Ok(())
}

fn dispatcher_failure(reason: &'static str) -> TokioTaskFailure {
    TokioTaskFailure::Task {
        name: task_name_or_abort("command-dispatcher"),
        reason: bounded_task_reason(reason),
    }
}

pub(super) async fn dispatch_loop(
    service: SharedRuntimeService,
    receiver: CommandReceiver,
    mut fanout: ActorCommandFanout,
    result_receiver: ActorResultReceiver,
    cancellation: crate::runtime::CancellationToken,
    runtime_guard: SharedRuntimeGuard,
) -> Result<(), TokioTaskFailure> {
    while !cancellation.is_cancelled() {
        if actor_result_step(&service, &result_receiver, &runtime_guard)? {
            break;
        }
        dispatch_step(&service, &receiver, &mut fanout, &runtime_guard)?;
        tokio::task::yield_now().await;
    }
    Ok(())
}

#[cfg(test)]
mod handler_tests;
