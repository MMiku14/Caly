//! Config publication helpers for core lifecycle builders: atomic owner-only
//! writes and controller-secret re-keying of reused generations.

use std::path::PathBuf;

use super::CompositionError;

pub(super) fn publish_owner_only_config(
    destination: &std::path::Path,
    bytes: Vec<u8>,
    generation: u64,
) -> Result<(), CompositionError> {
    let contents = caly_platform::fs::AtomicFileContents::try_from_vec(bytes)
        .map_err(|_| CompositionError::BackendUnavailable)?;
    let mut temporary = destination.as_os_str().to_os_string();
    temporary.push(format!(".tmp.{generation}"));
    caly_platform::fs::atomic_write(
        &mut caly_platform::fs::LinuxAtomicFileBackend,
        caly_platform::fs::AtomicWritePlan {
            destination: destination.to_path_buf(),
            temporary: PathBuf::from(temporary),
            contents,
        },
    )
    .map_err(|_| CompositionError::BackendUnavailable)
}

/// Rewrites the controller `secret` in a previously published config so a
/// daemon restart (which rotates the secret) keeps the running kernel
/// reachable without discarding committed subscription nodes.
pub(super) fn refresh_config_secret(
    path: &std::path::Path,
    secret: &str,
) -> Result<(), CompositionError> {
    if !path.is_file() {
        return Ok(());
    }
    let bytes = std::fs::read(path).map_err(|_| CompositionError::BackendUnavailable)?;
    let updated = if path
        .extension()
        .is_some_and(|extension| extension == "json")
    {
        refresh_json_secret(&bytes, secret)
    } else {
        refresh_yaml_secret(&bytes, secret)
    };
    publish_owner_only_config(path, updated, 1)
}

/// Replaces the sing-box `experimental.clash_api.secret` value. The document
/// is serde_json-rendered (compact `"secret":"..."`), so a targeted string
/// replacement is exact and dependency-free.
fn refresh_json_secret(bytes: &[u8], secret: &str) -> Vec<u8> {
    let text = String::from_utf8_lossy(bytes);
    let marker = "\"secret\":";
    let Some(pos) = text.find(marker) else {
        return bytes.to_vec();
    };
    let rest = &text[pos + marker.len()..];
    let Some(start) = rest.find('"') else {
        return bytes.to_vec();
    };
    let Some(end) = rest[start + 1..].find('"') else {
        return bytes.to_vec();
    };
    let mut out = text.into_owned();
    out.replace_range(
        pos + marker.len() + start + 1..pos + marker.len() + start + 1 + end,
        secret,
    );
    out.into_bytes()
}

/// Replaces the Mihomo `secret:` line, appending one when absent.
fn refresh_yaml_secret(bytes: &[u8], secret: &str) -> Vec<u8> {
    let text = String::from_utf8_lossy(bytes);
    let mut out = String::new();
    let mut replaced = false;
    for line in text.lines() {
        if line.starts_with("secret:") {
            use std::fmt::Write as _;
            let _ = writeln!(out, "secret: {secret}");
            replaced = true;
        } else {
            out.push_str(line);
            out.push('\n');
        }
    }
    if !replaced {
        use std::fmt::Write as _;
        let _ = writeln!(out, "secret: {secret}");
    }
    out.into_bytes()
}

/// Renders and publishes the first-run Mihomo base generation (no subscription
/// nodes exist yet); later generations come from `config apply`.
pub(super) fn render_mihomo_bootstrap(
    config: &std::path::Path,
    controller: &str,
    secret: Option<String>,
    tuning: &crate::composition::RuntimeTuning,
    tun: Option<caly_domain::TunConfig>,
) -> Result<(), CompositionError> {
    // The rendered `external-controller` must match the address the control
    // clients dial; derive the port from the configured controller endpoint.
    let controller_port = controller
        .parse::<std::net::SocketAddr>()
        .map_or(9090, |address| address.port());
    let mut filesystem = caly_platform::fs::LinuxAtomicFileBackend;
    let settings = caly_kernel::mihomo::MihomoConfigSettings {
        mixed_port: tuning.mixed_port,
        external_controller_port: controller_port,
        allow_lan: tuning.allow_lan,
        log_level: tuning.log_level.clone(),
        dns: tuning.dns.clone(),
        tun,
        secret,
        transparent_port: if tuning.transparent.enabled {
            tuning.transparent.port
        } else {
            0
        },
        transparent_tproxy: matches!(
            tuning.transparent.mode,
            caly_config::schema::TransparentMode::Tproxy
        ),
        ..caly_kernel::mihomo::MihomoConfigSettings::default()
    };
    caly_kernel::mihomo::MihomoConfigRenderer
        .publish(&mut filesystem, config.to_path_buf(), 1, &settings)
        .map_err(|error| {
            tracing::error!(?error, path = ?config, "cannot publish Mihomo bootstrap config");
            CompositionError::BackendUnavailable
        })
}
