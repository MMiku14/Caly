//! Free helpers for composition: bounded task naming, the boot snapshot,
//! configured-core resolution and capability publication.

use caly_domain::{
    AppliedState, BoundedText, BoundedVec, CapabilitySet, DaemonInstanceId, DesiredState,
    EventCursor, EventSequence, ObservedState, PlatformEffectView, PresentationSnapshot, ProxyMode,
    SnapshotRevision,
};

use super::{CompositionError, WallClock};
use crate::{projection::ProjectionRuntime, service::runtime_service::RuntimeService};

pub(super) fn task_name(value: &'static str) -> Result<BoundedText<64>, CompositionError> {
    BoundedText::new(value.to_owned()).map_err(|_| CompositionError::TaskCapacity)
}

/// Returns a bounded task name, aborting only on a composition invariant
/// violation (a static name can never exceed the bound).
pub(super) fn task_name_or_abort(value: &'static str) -> BoundedText<64> {
    match task_name(value) {
        Ok(value) => value,
        Err(_) => std::process::abort(),
    }
}

pub(super) fn bounded_task_reason_owned(value: String) -> BoundedText<512> {
    // The bound is in BYTES, not chars: truncating by chars could still exceed
    // the byte limit for multi-byte UTF-8 and previously hit the abort fallback.
    // from_nonempty_clamped truncates at a byte-safe char boundary.
    BoundedText::from_nonempty_clamped(value, "task failed")
}

pub(super) fn bounded_task_reason(value: &'static str) -> BoundedText<512> {
    match BoundedText::new(value.to_owned()) {
        Ok(value) => value,
        Err(_) => std::process::abort(),
    }
}

pub(super) fn initial_snapshot(daemon: DaemonInstanceId) -> Result<PresentationSnapshot, ()> {
    let cursor = EventCursor::new(daemon, EventSequence::ZERO);
    let capabilities = CapabilitySet::new(BoundedVec::new()).map_err(|_| ())?;
    Ok(PresentationSnapshot::new(
        daemon,
        SnapshotRevision::new(0),
        cursor,
        DesiredState::new(ProxyMode::Rule, None, None, false, false),
        AppliedState::stopped(),
        ObservedState::default(),
        PlatformEffectView::none(),
        capabilities,
        BoundedVec::new(),
    ))
}

/// Projects the boot-time capability set for the effective core into the
/// projection, so `snapshot`/`watch` report a truthful DNS assessment instead
/// of an empty capability set.
pub(super) fn configured_core(
    override_core: Option<caly_domain::CoreKind>,
) -> Result<caly_domain::CoreKind, CompositionError> {
    match std::env::var("CALY_CORE") {
        Ok(value) => parse_configured_core(Some(&value)),
        Err(std::env::VarError::NotPresent) => match override_core {
            Some(core) => Ok(core),
            None => parse_configured_core(None),
        },
        Err(std::env::VarError::NotUnicode(_)) => Err(CompositionError::UnsupportedCore),
    }
}

pub(super) fn parse_configured_core(
    value: Option<&str>,
) -> Result<caly_domain::CoreKind, CompositionError> {
    match value {
        None | Some("mihomo") => Ok(caly_domain::CoreKind::Mihomo),
        Some("sing-box") => Ok(caly_domain::CoreKind::SingBox),
        Some(_) => Err(CompositionError::UnsupportedCore),
    }
}

pub(super) fn publish_boot_capabilities(
    service: &std::sync::Arc<std::sync::Mutex<RuntimeService<WallClock, ProjectionRuntime>>>,
    core: caly_domain::CoreKind,
    dns_enabled: bool,
) -> Result<(), CompositionError> {
    let capabilities = caly_backends::core_capability_set(core, dns_enabled)
        .map_err(|_| CompositionError::BackendUnavailable)?;
    let mut service = service
        .lock()
        .map_err(|_| CompositionError::BackendUnavailable)?;
    if service
        .projection_mut()
        .publish(caly_domain::PresentationDelta::CapabilitiesReplaced(
            capabilities,
        ))
        .is_err()
    {
        return Err(CompositionError::BackendUnavailable);
    }
    Ok(())
}

/// Writes the generated controller secret to an owner-only file under the XDG
/// runtime root so offline CLI queries can authenticate against the running
/// core's controller. Best-effort: a failure to persist never aborts boot.
pub(super) fn publish_controller_secret(secret: &str) {
    let path = caly_platform::paths::AppPaths::from_env().controller_secret_path();
    if let Some(parent) = path.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if std::fs::write(&path, secret).is_ok() {
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600));
        }
    }
}
