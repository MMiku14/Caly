//! Daemon shutdown action driver wired to `run_shutdown`.
//!
//! Phases for subsystems that are not yet active in the current composition
//! complete as no-ops; the phases with real resources (telemetry, core process,
//! durable platform record) perform their ordered shutdown work.

use caly_domain::BoundedText;

use crate::{
    actors::{CoreLifecycleCommandBackend, TelemetryActorCommand},
    runtime::{MailboxSendError, ShutdownActions, ShutdownRunError, run_shutdown},
};
use caly_backends::dual::DualCoreLifecycle;

/// Bounded shutdown failure text.
fn bounded_shutdown(value: impl Into<String>) -> BoundedText<512> {
    BoundedText::from_nonempty_clamped(value.into(), "shutdown failed")
}

/// Concrete shutdown actions for the current daemon composition.
pub(crate) struct DaemonShutdownActions {
    pub telemetry: crate::runtime::ActorIngress<TelemetryActorCommand>,
    pub lifecycle: DualCoreLifecycle,
    pub platform: super::SharedPlatformBackend,
    pub tun: super::SharedTunBackend,
}

impl DaemonShutdownActions {
    /// Runs the ordered shutdown, returning the recorded phase failures.
    pub async fn run(self) -> Result<Vec<BoundedText<512>>, ShutdownRunError> {
        let mut actions = self;
        let failures = run_shutdown(&mut actions).await?;
        Ok(failures.iter().map(|f| f.message.clone()).collect())
    }
}

#[async_trait::async_trait]
impl ShutdownActions for DaemonShutdownActions {
    async fn reject_transport_mutations(&mut self) -> Result<(), BoundedText<512>> {
        // Transport admission already fail-stops on a fatal fault; nothing to do.
        Ok(())
    }

    async fn close_command_ingress(&mut self) -> Result<(), BoundedText<512>> {
        Ok(())
    }

    async fn stop_telemetry(&mut self) -> Result<(), BoundedText<512>> {
        send_shutdown(&self.telemetry, TelemetryActorCommand::Shutdown);
        Ok(())
    }

    async fn stop_and_reap_core(&mut self) -> Result<(), BoundedText<512>> {
        let mut lifecycle = self.lifecycle.clone();
        CoreLifecycleCommandBackend::stop(&mut lifecycle)
            .map(|_| ())
            .map_err(|error| {
                bounded_shutdown(format!(
                    "core stop failed during shutdown: {}",
                    error.message.as_str()
                ))
            })
    }

    async fn restore_platform(&mut self) -> Result<(), BoundedText<512>> {
        // Fidelity restore: return the desktop to the exact state captured
        // before engagement (not merely "proxy off"). The durable backend
        // clears its record only after a successful revert; on failure the
        // record remains for restore-first on the next boot. A missing record
        // means this daemon never engaged the proxy and nothing is touched.
        self.platform
            .restore_original_and_clear()
            .map_err(|error| {
                bounded_shutdown(format!(
                    "system proxy restore failed: {}",
                    error.message.as_str()
                ))
            })?;
        // Symmetric with the proxy branch: release the TUN device and clear
        // its durable record only on success; no record is a no-op.
        self.tun.restore_and_clear().map_err(|error| {
            bounded_shutdown(format!("TUN restore failed: {}", error.message.as_str()))
        })?;
        Ok(())
    }

    async fn stop_subscriptions(&mut self) -> Result<(), BoundedText<512>> {
        Ok(())
    }

    async fn finish_config_transactions(&mut self) -> Result<(), BoundedText<512>> {
        Ok(())
    }

    async fn flush_event_sequencer(&mut self) -> Result<(), BoundedText<512>> {
        Ok(())
    }

    async fn stop_projector(&mut self) -> Result<(), BoundedText<512>> {
        Ok(())
    }

    async fn release_transport_and_lock(&mut self) -> Result<(), BoundedText<512>> {
        Ok(())
    }
}

/// Sends a terminal `Shutdown` message to an actor ingress; a full or closed
/// mailbox is tolerated because the task group will still be awaited.
fn send_shutdown<M: Send>(ingress: &crate::runtime::ActorIngress<M>, message: M) {
    match ingress.try_send(message) {
        Ok(()) => {}
        Err(MailboxSendError::Full(_)) | Err(MailboxSendError::Closed(_)) => {}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::runtime::{ShutdownDriver, ShutdownPhase};

    struct RecordingActions {
        order: std::sync::Mutex<Vec<&'static str>>,
    }

    impl RecordingActions {
        fn record(&self, name: &'static str) {
            self.order
                .lock()
                .unwrap_or_else(|_| std::process::abort())
                .push(name);
        }
    }

    #[async_trait::async_trait]
    impl ShutdownActions for RecordingActions {
        async fn reject_transport_mutations(&mut self) -> Result<(), BoundedText<512>> {
            self.record("reject_transport");
            Ok(())
        }
        async fn close_command_ingress(&mut self) -> Result<(), BoundedText<512>> {
            self.record("close_ingress");
            Ok(())
        }
        async fn stop_telemetry(&mut self) -> Result<(), BoundedText<512>> {
            self.record("stop_telemetry");
            Ok(())
        }
        async fn stop_and_reap_core(&mut self) -> Result<(), BoundedText<512>> {
            self.record("stop_core");
            Ok(())
        }
        async fn restore_platform(&mut self) -> Result<(), BoundedText<512>> {
            self.record("restore_platform");
            Ok(())
        }
        async fn stop_subscriptions(&mut self) -> Result<(), BoundedText<512>> {
            self.record("stop_subscriptions");
            Ok(())
        }
        async fn finish_config_transactions(&mut self) -> Result<(), BoundedText<512>> {
            self.record("finish_config");
            Ok(())
        }
        async fn flush_event_sequencer(&mut self) -> Result<(), BoundedText<512>> {
            self.record("flush_sequencer");
            Ok(())
        }
        async fn stop_projector(&mut self) -> Result<(), BoundedText<512>> {
            self.record("stop_projector");
            Ok(())
        }
        async fn release_transport_and_lock(&mut self) -> Result<(), BoundedText<512>> {
            self.record("release_transport");
            Ok(())
        }
    }

    #[tokio::test]
    async fn run_shutdown_drives_all_phases_in_order() -> Result<(), ShutdownRunError> {
        let actions = RecordingActions {
            order: std::sync::Mutex::new(Vec::new()),
        };
        let mut actions = actions;
        let failures = run_shutdown(&mut actions).await?;
        assert!(failures.is_empty());
        let order = actions
            .order
            .lock()
            .unwrap_or_else(|_| std::process::abort())
            .clone();
        assert_eq!(
            order,
            vec![
                "reject_transport",
                "close_ingress",
                "stop_telemetry",
                "stop_core",
                "restore_platform",
                "stop_subscriptions",
                "finish_config",
                "flush_sequencer",
                "stop_projector",
                "release_transport",
            ]
        );
        Ok(())
    }

    #[test]
    fn shutdown_driver_advances_to_completed() {
        let mut driver = ShutdownDriver::new();
        let mut steps = 0;
        while driver.current() != ShutdownPhase::Completed {
            assert!(driver.complete_current().is_ok());
            steps += 1;
        }
        // 10 phases + Completed sentinel.
        assert_eq!(steps, 10);
    }
}
