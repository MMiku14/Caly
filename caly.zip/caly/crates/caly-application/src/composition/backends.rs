use std::path::PathBuf;

use caly_backends::{HttpSubscriptionBackend, LinuxSystemProxyBackend, TemplateRenderBackend};
use caly_platform::paths::AppPaths;

use super::CompositionError;

mod lifecycle;
mod lifecycle_support;

/// Bounds a controller secret for the core control clients. A generated hex
/// secret always fits; the clamped constructor keeps this infallible.
fn bounded_text(value: &str) -> caly_domain::BoundedText<4_096> {
    caly_domain::BoundedText::from_nonempty_clamped(value.to_owned(), "invalid")
}

/// Builds both core command adapters (Mihomo + sing-box) sharing one node
/// registry, so a runtime core switch keeps the subscription index intact.
fn build_dual_core_backend(
    controllers: &caly_domain::Controllers,
    secret: &str,
    active_cell: caly_backends::dual::SharedActiveCore,
) -> Result<
    (
        caly_backends::dual::SwitchableCoreBackend,
        caly_backends::CoreNodeRegistry,
    ),
    CompositionError,
> {
    let secret_text = bounded_text(secret);
    let mihomo_control = caly_kernel::mihomo::MihomoHttpControl::new(
        controllers.mihomo.clone(),
        Some(secret_text.clone()),
    )
    .map_err(|_| CompositionError::BackendUnavailable)?;
    let mihomo = caly_backends::MihomoCoreBackend::new(mihomo_control);
    let registry = mihomo.registry();
    let sing_box_control = caly_kernel::sing_box::SingBoxHttpControl::new(
        controllers.sing_box.clone(),
        Some(secret_text),
    )
    .map_err(|_| CompositionError::BackendUnavailable)?;
    let sing_box =
        caly_backends::SingBoxCoreBackend::new_with_registry(sing_box_control, registry.clone());
    Ok((
        caly_backends::dual::SwitchableCoreBackend::new(mihomo, sing_box, active_cell),
        registry,
    ))
}

pub(crate) struct RuntimeBackends {
    pub(crate) core: caly_backends::dual::SwitchableCoreBackend,
    pub(crate) subscription: HttpSubscriptionBackend,
    pub(crate) config: caly_backends::config::ActiveConfigBackend,
    pub(crate) platform:
        caly_backends::platform::DurableSystemProxyBackend<LinuxSystemProxyBackend>,
    pub(crate) tun:
        caly_backends::platform::DurableTunBackend<caly_backends::LinuxTunCommandBackend>,
    pub(crate) lifecycle: caly_backends::dual::DualCoreLifecycle,
    pub(crate) template: TemplateRenderBackend,
    /// Shared controller auth secret, also used by the telemetry control client.
    pub(crate) controller_secret: Option<String>,
}

pub(super) fn build_runtime_backends(
    configured_core: caly_domain::CoreKind,
    tun: Option<caly_domain::TunConfig>,
    controllers: &caly_domain::Controllers,
    binaries: &super::CoreBinaryPaths,
    subscription_url: Option<&str>,
    tuning: &super::RuntimeTuning,
) -> Result<RuntimeBackends, CompositionError> {
    // A shared, fail-closed controller auth secret. It is embedded in the core
    // config and sent by the control clients; it is never part of the
    // projection or any PresentationSnapshot.
    let secret = caly_platform::secrets::generate_secret_hex()
        .map_err(|_| CompositionError::SecretUnavailable)?;
    // The active-core cell is created here and shared by the lifecycle,
    // command and telemetry adapters so a runtime switch is atomic everywhere.
    let active_cell: caly_backends::dual::SharedActiveCore =
        std::sync::Arc::new(std::sync::Mutex::new(configured_core));
    let (core, registry) = build_dual_core_backend(controllers, &secret, active_cell.clone())
        .inspect_err(|error| tracing::error!("build_dual_core_backend failed: {error:?}"))?;
    let mut subscription = HttpSubscriptionBackend::new()
        .inspect_err(|error| tracing::error!("subscription backend failed: {error:?}"))
        .map_err(|_| CompositionError::BackendUnavailable)?
        .with_policy(tuning.fetch_policy)
        // Persist fetched bodies so the node registry survives a daemon
        // restart without a re-fetch; restored in `start_runtime`.
        .with_cache_dir(AppPaths::from_env().state.join("subscriptions"))
        .with_node_registry(registry.clone());
    register_subscription_url(&mut subscription, subscription_url);
    let proxy_backend =
        LinuxSystemProxyBackend::new(tuning.system_proxy_host.clone(), tuning.system_proxy_port)
    .map_err(|_| CompositionError::BackendUnavailable)?;
    let proxy_store = open_recovery_store()
        .inspect_err(|error| tracing::error!("proxy recovery store failed: {error:?}"))?;
    let platform =
        caly_backends::platform::DurableSystemProxyBackend::new(proxy_backend, proxy_store);
    let lifecycle = lifecycle::build_dual_core_lifecycle(
        &mut subscription,
        configured_core,
        Some(secret.clone()),
        controllers,
        binaries,
        tuning,
        tun.clone(),
        active_cell.clone(),
    )?;
    let template = TemplateRenderBackend::default();
    let config = build_config_owner(
        registry,
        active_cell.clone(),
        configured_core,
        tun.clone(),
        binaries,
        tuning,
        controllers,
        &secret,
    );
    let tun = build_tun_owner(tun, open_tun_recovery_store()?, tuning.tun_escalation)?;
    Ok(RuntimeBackends {
        core,
        subscription,
        config,
        platform,
        tun,
        lifecycle,
        template,
        controller_secret: Some(secret),
    })
}

/// Builds the durable TunActor owner with the configured MTU (or a safe default).
fn build_tun_owner(
    tun: Option<caly_domain::TunConfig>,
    store: caly_backends::platform::SharedTunRecoveryStore,
    escalation: caly_platform::tun::TunEscalation,
) -> Result<
    caly_backends::platform::DurableTunBackend<caly_backends::LinuxTunCommandBackend>,
    CompositionError,
> {
    let mtu = tun.map_or(1_500, |tun| tun.mtu());
    let interface = caly_platform::tun::InterfaceName::new(lifecycle::TUN_INTERFACE.to_owned())
    .map_err(|_| CompositionError::BackendUnavailable)?;
    let inner =
        caly_backends::LinuxTunCommandBackend::new_with_escalation(interface, mtu, escalation)
    .map_err(|_| CompositionError::BackendUnavailable)?;
    Ok(caly_backends::platform::DurableTunBackend::new(
        inner, store,
    ))
}

/// Opens the owner-only durable TUN recovery store under the XDG state root.
fn open_tun_recovery_store()
-> Result<caly_backends::platform::SharedTunRecoveryStore, CompositionError> {
    use caly_platform::recovery::{FileRecoveryStore, TunRecoveryRecord};
    let path = caly_platform::paths::AppPaths::from_env().recovery_record_path();
    let mut path = path;
    path.set_file_name("recovery-tun.json");
    let store = FileRecoveryStore::<TunRecoveryRecord>::new(path)
    .map_err(|_| CompositionError::BackendUnavailable)?;
    Ok(std::sync::Arc::new(store) as caly_backends::platform::SharedTunRecoveryStore)
}

/// Opens the owner-only durable proxy recovery store under the XDG state root.
fn open_recovery_store()
-> Result<caly_backends::platform::SharedProxyRecoveryStore, CompositionError> {
    use caly_platform::recovery::FileRecoveryStore;
    let path = caly_platform::paths::AppPaths::from_env().recovery_record_path();
    let store = FileRecoveryStore::<caly_platform::recovery::ProxyRecoveryRecord>::new(path)
    .map_err(|_| CompositionError::BackendUnavailable)?;
    Ok(std::sync::Arc::new(store) as caly_backends::platform::SharedProxyRecoveryStore)
}

/// Registers a configured source URL for the default `refresh` subscription.
fn register_subscription_url(subscription: &mut HttpSubscriptionBackend, url: Option<&str>) {
    if let Some(url) = url {
        subscription.put_url(
            caly_domain::SubscriptionId::from_bytes([0; 16]),
            url.to_owned(),
        );
    }
}

/// Locates a bundled development core relative to the executable before using
/// the historical current-working-directory fallback. This makes
/// `target/debug/caly daemon` work regardless of the shell's current directory.
pub(super) fn bundled_binary(name: &str) -> PathBuf {
    resolve_bundled_binary(
        name,
        std::env::current_dir().ok().as_deref(),
        std::env::current_exe().ok().as_deref(),
    )
}

/// Resolves a bundled kernel binary: `vendor/bin/<name>` under the working
/// directory first, then under any ancestor of the executable path (dev runs
/// from `target/debug` still find the repo's `vendor/bin`), falling back to
/// the CWD-relative path so errors show what was attempted.
pub(super) fn resolve_bundled_binary(
    name: &str,
    cwd: Option<&std::path::Path>,
    executable: Option<&std::path::Path>,
) -> PathBuf {
    if let Some(directory) = cwd {
        let candidate = directory.join("vendor").join("bin").join(name);
        if candidate.is_file() {
            return candidate;
        }
    }
    if let Some(executable) = executable {
        for directory in executable.ancestors() {
            let candidate = directory.join("vendor").join("bin").join(name);
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    PathBuf::from("vendor").join("bin").join(name)
}

/// Builds the config-apply owner under the XDG config root. It shares the
/// subscription proxy registry and validates every candidate against the
/// configured core's real binary before committing; the active backend is
/// selected by the configured core (sing-box is no longer a fail-fast).
fn build_config_owner(
    registry: caly_backends::CoreNodeRegistry,
    active: caly_backends::dual::SharedActiveCore,
    configured_core: caly_domain::CoreKind,
    tun: Option<caly_domain::TunConfig>,
    binaries: &super::CoreBinaryPaths,
    tuning: &super::RuntimeTuning,
    controllers: &caly_domain::Controllers,
    secret: &str,
) -> caly_backends::config::ActiveConfigBackend {
    let paths = caly_platform::paths::AppPaths::from_env();
    let mihomo_port = controllers
        .mihomo
        .parse::<std::net::SocketAddr>()
        .map_or(9090, |address| address.port());
    let mut mihomo = caly_backends::MihomoConfigBackend::new(paths.config.join("mihomo.yaml"))
        .with_registry(registry.clone())
        .with_tun(tun.clone())
        .with_kernel(
            tuning.mixed_port,
            tuning.allow_lan,
            tuning.bind_address.clone(),
            tuning.log_level.clone(),
            mihomo_port,
            tuning.dns.clone(),
        )
        .with_secret(Some(secret.to_owned()))
        .with_rules(tuning.rules.clone())
        .with_transparent(tuning.transparent)
        .with_sniffer(tuning.sniffer.clone());
    let sing_box_port = controllers
        .sing_box
        .parse::<std::net::SocketAddr>()
        .map_or(9091, |address| address.port());
    let mut sing_box = caly_backends::config::sing_box::SingBoxConfigBackend::new(
        paths.config.join("sing-box.json"),
    )
    .with_registry(registry)
    .with_tun(tun)
    .with_kernel(
        tuning.mixed_port,
        tuning.allow_lan,
        tuning.bind_address.clone(),
        tuning.log_level.clone(),
        sing_box_port,
        tuning.dns.clone(),
    )
    .with_secret(Some(secret.to_owned()))
    .with_rules(tuning.rules.clone())
    .with_sniffer(tuning.sniffer.clone());
    if configured_core == caly_domain::CoreKind::Mihomo {
        let binary = binaries
            .mihomo
            .clone()
            .or_else(|| std::env::var_os("CALY_MIHOMO_BIN").map(PathBuf::from))
            .unwrap_or_else(|| bundled_binary("mihomo"));
        let working_directory = std::env::var_os("CALY_MIHOMO_DIR")
            .map_or_else(|| paths.core_work_dir().join("mihomo"), PathBuf::from);
        // Best-effort: seed the kind data a `mihomo -t` may need (geoip.metadb)
        // from a known-good system database when the validator would otherwise
        // attempt a network download that can hang past its timeout. Missing
        // or unusable sources are skipped silently — validation still proceeds.
        provision_geoip_metadb(&working_directory);
        mihomo = mihomo.with_validation(
            binary,
            working_directory,
            std::time::Duration::from_secs(10),
        );
    } else {
        let binary = binaries
            .sing_box
            .clone()
            .or_else(|| std::env::var_os("CALY_SINGBOX_BIN").map(PathBuf::from))
            .unwrap_or_else(|| bundled_binary("sing-box"));
        let working_directory = std::env::var_os("CALY_SINGBOX_DIR")
            .map_or_else(|| paths.core_work_dir().join("sing-box"), PathBuf::from);
        sing_box = sing_box.with_validation(
            binary,
            working_directory,
            std::time::Duration::from_secs(10),
        );
    }
    caly_backends::config::ActiveConfigBackend::new(active, mihomo, sing_box)
}

/// Copies a usable `geoip.metadb` into the Mihomo working directory if one is
/// available (a system copy or a previously-downloaded cache) and the target
/// lacks a complete copy. Mihomo fetches this database on demand when a
/// validated config references GEOIP data; with a blocked network that fetch
/// can hang past the bounded validator timeout. Best-effort: every failure is
/// silently ignored so a missing database simply falls back to Mihomo's own
/// behavior.
///
/// A pre-existing target file that is smaller than the 1 MiB sanity bound
/// (a stub or a copy aborted mid-write) is treated as corrupt and removed
/// before the source-copy loop, so a half-written target cannot masquerade
/// as a healthy database and silently bypass a real seed.
fn provision_geoip_metadb(working_directory: &std::path::Path) -> bool {
    provision_geoip_metadb_with_sources(
        working_directory,
        default_geoip_sources(),
    )
}

/// Default source list: a system Mihomo database is preferred (verified,
/// complete) over the shared caly cache from earlier test downloads.
fn default_geoip_sources() -> [std::path::PathBuf; 2] {
    [
        std::path::PathBuf::from("/etc/mihomo/geoip.metadb"),
        std::env::temp_dir().join("caly-geoip-cache/geoip.metadb"),
    ]
}

/// The testable core of `provision_geoip_metadb`. Accepts an explicit source
/// list so tests can exercise every branch without depending on whatever
/// `/etc/mihomo/geoip.metadb` happens to exist in the test environment.
fn provision_geoip_metadb_with_sources<I>(
    working_directory: &std::path::Path,
    sources: I,
) -> bool
where
    I: IntoIterator,
    I::Item: AsRef<std::path::Path>,
{
    let target = working_directory.join("geoip.metadb");
    if let Ok(meta) = target.metadata() {
        if meta.len() >= 1_000_000 {
            return true;
        }
        // Corrupt/stub target: never reuse it, even though `is_file()` would
        // otherwise short-circuit the copy loop below. A partial file from an
        // interrupted earlier run would otherwise block the seed indefinitely.
        let _ = std::fs::remove_file(&target);
    }
    std::fs::create_dir_all(working_directory).ok();
    for source in sources {
        let source = source.as_ref();
        let Ok(meta) = source.metadata() else {
            continue;
        };
        // A stub (sub-1 MiB) copy is corrupt; never reuse it.
        if meta.len() < 1_000_000 {
            continue;
        }
        if std::fs::copy(source, &target).is_ok()
            && target.metadata().map_or(0, |m| m.len()) >= 1_000_000
        {
            return true;
        }
        let _ = std::fs::remove_file(&target);
    }
    false
}

#[cfg(test)]
mod tests {
    use std::{
        os::unix::fs::PermissionsExt,
        time::{SystemTime, UNIX_EPOCH},
    };

    #[test]
    fn sing_box_config_publication_is_owner_only() -> Result<(), String> {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|error| error.to_string())?
            .as_nanos();
        let directory = std::env::temp_dir().join(format!("caly-singbox-mode-{nonce}"));
        std::fs::create_dir_all(&directory).map_err(|error| error.to_string())?;
        let destination = directory.join("config.json");
        super::lifecycle_support::publish_owner_only_config(
            &destination,
            br#"{"secret":"credential"}"#.to_vec(),
            1,
        )
        .map_err(|error| format!("{error:?}"))?;
        let mode = std::fs::metadata(&destination)
            .map_err(|error| error.to_string())?
            .permissions()
            .mode()
            & 0o777;
        let cleanup = std::fs::remove_dir_all(directory);
        assert_eq!(mode, 0o600);
        cleanup.map_err(|error| error.to_string())
    }
}

#[cfg(test)]
mod bundled_binary_tests {
    use super::resolve_bundled_binary;
    use caly_platform::paths::test_helpers::unique_path_under;

    /// Creates an empty executable script at `path`. The script body is
    /// the standard `#!/bin/sh` shebang; tests that exercise the binary
    /// resolver never execute the contents, they only need a real file
    /// node to satisfy the `.is_file()` check.
    fn touch(path: &std::path::Path) {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).unwrap_or_else(|error| {
                eprintln!("test setup: create_dir_all({parent:?}) failed: {error}");
                std::process::abort();
            });
        }
        std::fs::write(path, b"#!/bin/sh\n").unwrap_or_else(|error| {
            eprintln!("test setup: write({path:?}) failed: {error}");
            std::process::abort();
        });
    }

    #[test]
    fn prefers_the_working_directory_vendor_bin() {
        let dir = unique_path_under("caly-bundle", "cwd");
        let binary = dir.join("vendor/bin/mihomo");
        touch(&binary);
        let resolved = resolve_bundled_binary("mihomo", Some(dir.as_path()), None);
        assert_eq!(resolved, binary);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn walks_executable_ancestors_for_dev_layouts() {
        let repo = unique_path_under("caly-bundle", "exe");
        let executable = repo.join("target/debug/caly");
        let binary = repo.join("vendor/bin/sing-box");
        touch(&executable);
        touch(&binary);
        let elsewhere = repo.join("elsewhere");
        std::fs::create_dir_all(&elsewhere).unwrap_or_else(|_| std::process::abort());
        let resolved = resolve_bundled_binary(
            "sing-box",
            Some(elsewhere.as_path()),
            Some(executable.as_path()),
        );
        assert_eq!(resolved, binary);
        let _ = std::fs::remove_dir_all(&repo);
    }

    #[test]
    fn falls_back_to_a_cwd_relative_path_for_error_messages() {
        let missing = unique_path_under("caly-bundle", "none");
        std::fs::create_dir_all(&missing).unwrap_or_else(|_| std::process::abort());
        let resolved = resolve_bundled_binary("mihomo", Some(missing.as_path()), None);
        assert_eq!(resolved, std::path::PathBuf::from("vendor/bin/mihomo"));
        let _ = std::fs::remove_dir_all(&missing);
    }
}

#[cfg(test)]
mod provision_geoip_tests {
    use super::provision_geoip_metadb_with_sources;
    use caly_platform::paths::test_helpers::unique_path_under;

    /// The 1 MiB sanity bound guarding against stub or partial copies.
    const SEED_MIN_BYTES: usize = 1_000_000;

    /// Aborts the test on a setup failure. Every test in this module needs
    /// an empty sandbox under `unique_path_under`, removed at the end of the
    /// test. Filesystem errors during setup are not what the suite is
    /// testing, so a process-kill surfaces them loudly instead of papering
    /// over them with `unwrap()` (denied by the workspace lint).
    fn must_create_dir(path: &std::path::Path) {
        std::fs::create_dir_all(path).unwrap_or_else(|error| {
            eprintln!("test setup: create_dir_all({}) failed: {error}", path.display());
            std::process::abort();
        });
    }

    fn must_write(path: &std::path::Path, bytes: &[u8]) {
        std::fs::write(path, bytes).unwrap_or_else(|error| {
            eprintln!("test setup: write({}) failed: {error}", path.display());
            std::process::abort();
        });
    }

    fn must_read(path: &std::path::Path) -> Vec<u8> {
        std::fs::read(path).unwrap_or_else(|error| {
            eprintln!("test setup: read({}) failed: {error}", path.display());
            std::process::abort();
        })
    }

    fn must_metadata(path: &std::path::Path) -> std::fs::Metadata {
        std::fs::metadata(path).unwrap_or_else(|error| {
            eprintln!("test setup: metadata({}) failed: {error}", path.display());
            std::process::abort();
        })
    }

    /// Regression: a corrupt (sub-1 MiB) `geoip.metadb` at the target path
    /// must not bypass the source-copy loop. The previous implementation
    /// short-circuited on `target.is_file()` and left a stub from an
    /// interrupted earlier run in place forever, so a real `mihomo -t`
    /// validation would then use a half-written database and fail in
    /// confusing ways.
    #[test]
    fn corrupt_target_is_replaced_when_source_is_healthy() {
        let working_dir = unique_path_under("caly-geoip", "corrupt-target");
        must_create_dir(&working_dir);
        let target = working_dir.join("geoip.metadb");
        // A stub written by a previous, interrupted run.
        must_write(&target, b"corrupt");

        // Inject a healthy (>1 MiB) source at a temp path so the test is
        // hermetic — independent of any `/etc/mihomo/geoip.metadb` that may
        // happen to exist in the test environment.
        let source = unique_path_under("caly-geoip", "source-healthy");
        must_create_dir(source.parent().unwrap_or_else(|| std::process::abort()));
        must_write(&source, &vec![0xA5_u8; SEED_MIN_BYTES]);

        let seeded = provision_geoip_metadb_with_sources(&working_dir, [source]);
        assert!(seeded, "a healthy source must seed successfully");
        let after = must_metadata(&target);
        assert!(
            after.len() >= SEED_MIN_BYTES as u64,
            "target must hold the healthy source, got {} bytes",
            after.len()
        );
        let _ = std::fs::remove_dir_all(&working_dir);
    }

    /// A complete (≥ 1 MiB) target is preserved untouched; the function must
    /// not waste time re-copying a healthy database.
    #[test]
    fn healthy_target_is_not_overwritten() {
        let working_dir = unique_path_under("caly-geoip", "healthy-target");
        must_create_dir(&working_dir);
        let target = working_dir.join("geoip.metadb");
        let healthy_bytes = vec![0xAB_u8; SEED_MIN_BYTES];
        must_write(&target, &healthy_bytes);
        let seeded = provision_geoip_metadb_with_sources(
            &working_dir,
            std::iter::empty::<std::path::PathBuf>(),
        );
        assert!(seeded, "a healthy target counts as already-seeded");
        let after = must_read(&target);
        assert_eq!(after.len(), healthy_bytes.len());
        assert!(after.iter().all(|byte| *byte == 0xAB));
        let _ = std::fs::remove_dir_all(&working_dir);
    }

    /// A missing target with no healthy source reports failure but must not
    /// panic and must not leave a half-written target behind.
    #[test]
    fn missing_target_with_no_source_is_a_clean_noop() {
        let working_dir = unique_path_under("caly-geoip", "missing-target");
        // The directory does not even exist; the function must create it
        // and return false without aborting.
        let seeded = provision_geoip_metadb_with_sources(
            &working_dir,
            std::iter::empty::<std::path::PathBuf>(),
        );
        assert!(!seeded, "no healthy source available in this test");
        assert!(working_dir.is_dir(), "function must create the working dir");
        let _ = std::fs::remove_dir_all(&working_dir);
    }

    /// A stub (sub-1 MiB) source is treated as corrupt and never copied —
    /// mirroring the existing source-side guard.
    #[test]
    fn stub_source_is_skipped_without_overwriting() {
        let working_dir = unique_path_under("caly-geoip", "stub-source");
        let stub = unique_path_under("caly-geoip", "stub-source-data");
        must_create_dir(stub.parent().unwrap_or_else(|| std::process::abort()));
        must_write(&stub, b"too-small");
        let seeded = provision_geoip_metadb_with_sources(&working_dir, [stub.clone()]);
        assert!(!seeded, "a sub-1 MiB source must not be considered healthy");
        // No target file should be created when the only source is corrupt.
        let target = working_dir.join("geoip.metadb");
        assert!(
            !target.exists(),
            "target must not be created from a stub source"
        );
        let _ = std::fs::remove_file(&stub);
        let _ = std::fs::remove_dir_all(&working_dir);
    }
}
