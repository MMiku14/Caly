use std::path::PathBuf;

use caly_backends::{HttpSubscriptionBackend, LinuxSystemProxyBackend, TemplateRenderBackend};
use caly_platform::paths::AppPaths;

use super::CompositionError;

mod lifecycle;
mod lifecycle_support;

/// Bounds a controller secret for the core control clients. A generated hex
/// secret always fits; the clamped constructor keeps this infallible.
fn bounded_text(value: &str) -> caly_domain::BoundedText<4_096> {
    caly_domain::BoundedText::from_nonempty_clamped(value.to_owned(), "invalid")
}

/// Builds both core command adapters (Mihomo + sing-box) sharing one node
/// registry, so a runtime core switch keeps the subscription index intact.
fn build_dual_core_backend(
    controllers: &caly_domain::Controllers,
    secret: &str,
    active_cell: caly_backends::dual::SharedActiveCore,
) -> Result<
    (
        caly_backends::dual::SwitchableCoreBackend,
        caly_backends::CoreNodeRegistry,
    ),
    CompositionError,
> {
    let secret_text = bounded_text(secret);
    let mihomo_control = caly_kernel::mihomo::MihomoHttpControl::new(
        controllers.mihomo.clone(),
        Some(secret_text.clone()),
    )
    .map_err(|_| CompositionError::BackendUnavailable)?;
    let mihomo = caly_backends::MihomoCoreBackend::new(mihomo_control);
    let registry = mihomo.registry();
    let sing_box_control = caly_kernel::sing_box::SingBoxHttpControl::new(
        controllers.sing_box.clone(),
        Some(secret_text),
    )
    .map_err(|_| CompositionError::BackendUnavailable)?;
    let sing_box =
        caly_backends::SingBoxCoreBackend::new_with_registry(sing_box_control, registry.clone());
    Ok((
        caly_backends::dual::SwitchableCoreBackend::new(mihomo, sing_box, active_cell),
        registry,
    ))
}

pub(crate) struct RuntimeBackends {
    pub(crate) core: caly_backends::dual::SwitchableCoreBackend,
    pub(crate) subscription: HttpSubscriptionBackend,
    pub(crate) config: caly_backends::config::ActiveConfigBackend,
    pub(crate) platform:
        caly_backends::platform::DurableSystemProxyBackend<LinuxSystemProxyBackend>,
    pub(crate) tun:
        caly_backends::platform::DurableTunBackend<caly_backends::LinuxTunCommandBackend>,
    pub(crate) lifecycle: caly_backends::dual::DualCoreLifecycle,
    pub(crate) template: TemplateRenderBackend,
    /// Shared controller auth secret, also used by the telemetry control client.
    pub(crate) controller_secret: Option<String>,
}

pub(super) fn build_runtime_backends(
    configured_core: caly_domain::CoreKind,
    tun: Option<caly_domain::TunConfig>,
    controllers: &caly_domain::Controllers,
    binaries: &super::CoreBinaryPaths,
    subscription_url: Option<&str>,
    tuning: &super::RuntimeTuning,
) -> Result<RuntimeBackends, CompositionError> {
    // A shared, fail-closed controller auth secret. It is embedded in the core
    // config and sent by the control clients; it is never part of the
    // projection or any PresentationSnapshot.
    let secret = caly_platform::secrets::generate_secret_hex()
        .map_err(|_| CompositionError::SecretUnavailable)?;
    // The active-core cell is created here and shared by the lifecycle,
    // command and telemetry adapters so a runtime switch is atomic everywhere.
    let active_cell: caly_backends::dual::SharedActiveCore =
        std::sync::Arc::new(std::sync::Mutex::new(configured_core));
    let (core, registry) = build_dual_core_backend(controllers, &secret, active_cell.clone())
        .inspect_err(|error| tracing::error!("build_dual_core_backend failed: {error:?}"))?;
    let mut subscription = HttpSubscriptionBackend::new()
        .inspect_err(|error| tracing::error!("subscription backend failed: {error:?}"))
        .map_err(|_| CompositionError::BackendUnavailable)?
        .with_policy(tuning.fetch_policy)
        // Persist fetched bodies so the node registry survives a daemon
        // restart without a re-fetch; restored in `start_runtime`.
        .with_cache_dir(AppPaths::from_env().state.join("subscriptions"))
        .with_node_registry(registry.clone());
    register_subscription_url(&mut subscription, subscription_url);
    let proxy_backend =
        LinuxSystemProxyBackend::new(tuning.system_proxy_host.clone(), tuning.system_proxy_port)
            .map_err(|_| CompositionError::BackendUnavailable)?;
    let proxy_store = open_recovery_store()
        .inspect_err(|error| tracing::error!("proxy recovery store failed: {error:?}"))?;
    let platform =
        caly_backends::platform::DurableSystemProxyBackend::new(proxy_backend, proxy_store);
    let lifecycle = lifecycle::build_dual_core_lifecycle(
        &mut subscription,
        configured_core,
        Some(secret.clone()),
        controllers,
        binaries,
        tuning,
        tun.clone(),
        active_cell.clone(),
    )?;
    let template = TemplateRenderBackend::default();
    let config = build_config_owner(
        registry,
        active_cell.clone(),
        configured_core,
        tun.clone(),
        binaries,
        tuning,
        controllers,
        &secret,
    );
    let tun = build_tun_owner(tun, open_tun_recovery_store()?, tuning.tun_escalation)?;
    Ok(RuntimeBackends {
        core,
        subscription,
        config,
        platform,
        tun,
        lifecycle,
        template,
        controller_secret: Some(secret),
    })
}

/// Builds the durable TunActor owner with the configured MTU (or a safe default).
fn build_tun_owner(
    tun: Option<caly_domain::TunConfig>,
    store: caly_backends::platform::SharedTunRecoveryStore,
    escalation: caly_platform::tun::TunEscalation,
) -> Result<
    caly_backends::platform::DurableTunBackend<caly_backends::LinuxTunCommandBackend>,
    CompositionError,
> {
    let mtu = tun.map_or(1_500, |tun| tun.mtu());
    let interface = caly_platform::tun::InterfaceName::new(lifecycle::TUN_INTERFACE.to_owned())
        .map_err(|_| CompositionError::BackendUnavailable)?;
    let inner =
        caly_backends::LinuxTunCommandBackend::new_with_escalation(interface, mtu, escalation)
            .map_err(|_| CompositionError::BackendUnavailable)?;
    Ok(caly_backends::platform::DurableTunBackend::new(
        inner, store,
    ))
}

/// Opens the owner-only durable TUN recovery store under the XDG state root.
fn open_tun_recovery_store()
-> Result<caly_backends::platform::SharedTunRecoveryStore, CompositionError> {
    use caly_platform::recovery::{FileRecoveryStore, TunRecoveryRecord};
    let path = caly_platform::paths::AppPaths::from_env().recovery_record_path();
    let mut path = path;
    path.set_file_name("recovery-tun.json");
    let store = FileRecoveryStore::<TunRecoveryRecord>::new(path)
        .map_err(|_| CompositionError::BackendUnavailable)?;
    Ok(std::sync::Arc::new(store) as caly_backends::platform::SharedTunRecoveryStore)
}

/// Opens the owner-only durable proxy recovery store under the XDG state root.
fn open_recovery_store()
-> Result<caly_backends::platform::SharedProxyRecoveryStore, CompositionError> {
    use caly_platform::recovery::FileRecoveryStore;
    let path = caly_platform::paths::AppPaths::from_env().recovery_record_path();
    let store = FileRecoveryStore::<caly_platform::recovery::ProxyRecoveryRecord>::new(path)
        .map_err(|_| CompositionError::BackendUnavailable)?;
    Ok(std::sync::Arc::new(store) as caly_backends::platform::SharedProxyRecoveryStore)
}

/// Registers a configured source URL for the default `refresh` subscription.
fn register_subscription_url(subscription: &mut HttpSubscriptionBackend, url: Option<&str>) {
    if let Some(url) = url {
        subscription.put_url(
            caly_domain::SubscriptionId::from_bytes([0; 16]),
            url.to_owned(),
        );
    }
}

/// Locates a bundled development core relative to the executable before using
/// the historical current-working-directory fallback. This makes
/// `target/debug/caly daemon` work regardless of the shell's current directory.
pub(super) fn bundled_binary(name: &str) -> PathBuf {
    resolve_bundled_binary(
        name,
        std::env::current_dir().ok().as_deref(),
        std::env::current_exe().ok().as_deref(),
    )
}

/// Resolves a bundled kernel binary: `vendor/bin/<name>` under the working
/// directory first, then under any ancestor of the executable path (dev runs
/// from `target/debug` still find the repo's `vendor/bin`), falling back to
/// the CWD-relative path so errors show what was attempted.
pub(super) fn resolve_bundled_binary(
    name: &str,
    cwd: Option<&std::path::Path>,
    executable: Option<&std::path::Path>,
) -> PathBuf {
    if let Some(directory) = cwd {
        let candidate = directory.join("vendor").join("bin").join(name);
        if candidate.is_file() {
            return candidate;
        }
    }
    if let Some(executable) = executable {
        for directory in executable.ancestors() {
            let candidate = directory.join("vendor").join("bin").join(name);
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    PathBuf::from("vendor").join("bin").join(name)
}

/// Builds the config-apply owner under the XDG config root. It shares the
/// subscription proxy registry and validates every candidate against the
/// configured core's real binary before committing; the active backend is
/// selected by the configured core (sing-box is no longer a fail-fast).
fn build_config_owner(
    registry: caly_backends::CoreNodeRegistry,
    active: caly_backends::dual::SharedActiveCore,
    configured_core: caly_domain::CoreKind,
    tun: Option<caly_domain::TunConfig>,
    binaries: &super::CoreBinaryPaths,
    tuning: &super::RuntimeTuning,
    controllers: &caly_domain::Controllers,
    secret: &str,
) -> caly_backends::config::ActiveConfigBackend {
    let paths = caly_platform::paths::AppPaths::from_env();
    let mihomo_port = controllers
        .mihomo
        .parse::<std::net::SocketAddr>()
        .map_or(9090, |address| address.port());
    let mut mihomo = caly_backends::MihomoConfigBackend::new(paths.config.join("mihomo.yaml"))
        .with_registry(registry.clone())
        .with_tun(tun.clone())
        .with_kernel(
            tuning.mixed_port,
            tuning.allow_lan,
            tuning.bind_address.clone(),
            tuning.log_level.clone(),
            mihomo_port,
            tuning.dns.clone(),
        )
        .with_secret(Some(secret.to_owned()))
        .with_rules(tuning.rules.clone())
        .with_transparent(tuning.transparent)
        .with_sniffer(tuning.sniffer.clone());
    let sing_box_port = controllers
        .sing_box
        .parse::<std::net::SocketAddr>()
        .map_or(9091, |address| address.port());
    let mut sing_box = caly_backends::config::sing_box::SingBoxConfigBackend::new(
        paths.config.join("sing-box.json"),
    )
    .with_registry(registry)
    .with_tun(tun)
    .with_kernel(
        tuning.mixed_port,
        tuning.allow_lan,
        tuning.bind_address.clone(),
        tuning.log_level.clone(),
        sing_box_port,
        tuning.dns.clone(),
    )
    .with_secret(Some(secret.to_owned()))
    .with_rules(tuning.rules.clone())
    .with_sniffer(tuning.sniffer.clone());
    if configured_core == caly_domain::CoreKind::Mihomo {
        let binary = binaries
            .mihomo
            .clone()
            .or_else(|| std::env::var_os("CALY_MIHOMO_BIN").map(PathBuf::from))
            .unwrap_or_else(|| bundled_binary("mihomo"));
        let working_directory = std::env::var_os("CALY_MIHOMO_DIR")
            .map_or_else(|| paths.core_work_dir().join("mihomo"), PathBuf::from);
        // Best-effort: seed the kind data a `mihomo -t` may need (geoip.metadb)
        // from a known-good system database when the validator would otherwise
        // attempt a network download that can hang past its timeout. Missing
        // or unusable sources are skipped silently — validation still proceeds.
        provision_geoip_metadb(&working_directory);
        mihomo = mihomo.with_validation(
            binary,
            working_directory,
            std::time::Duration::from_secs(10),
        );
    } else {
        let binary = binaries
            .sing_box
            .clone()
            .or_else(|| std::env::var_os("CALY_SINGBOX_BIN").map(PathBuf::from))
            .unwrap_or_else(|| bundled_binary("sing-box"));
        let working_directory = std::env::var_os("CALY_SINGBOX_DIR")
            .map_or_else(|| paths.core_work_dir().join("sing-box"), PathBuf::from);
        sing_box = sing_box.with_validation(
            binary,
            working_directory,
            std::time::Duration::from_secs(10),
        );
    }
    caly_backends::config::ActiveConfigBackend::new(active, mihomo, sing_box)
}

/// Copies a usable `geoip.metadb` into the Mihomo working directory if one is
/// available (a system copy or a previously-downloaded cache) and the target
/// lacks one. Mihomo fetches this database on demand when a validated config
/// references GEOIP data; with a blocked network that fetch can hang past the
/// bounded validator timeout. Best-effort: every failure is silently ignored
/// so a missing database simply falls back to Mihomo's own behavior.
fn provision_geoip_metadb(working_directory: &std::path::Path) {
    use std::path::PathBuf;
    let target = working_directory.join("geoip.metadb");
    if target.is_file() {
        return;
    }
    std::fs::create_dir_all(working_directory).ok();
    // A system Mihomo database is a verified, complete copy (preferred) —
    // larger and trusted over the shared cache from earlier test downloads.
    let candidates = [
        PathBuf::from("/etc/mihomo/geoip.metadb"),
        std::env::temp_dir().join("caly-geoip-cache/geoip.metadb"),
    ];
    for source in candidates {
        let Ok(meta) = source.metadata() else {
            continue;
        };
        // A stub (sub-1 MiB) copy is corrupt; never reuse it.
        if meta.len() < 1_000_000 {
            continue;
        }
        if std::fs::copy(&source, &target).is_ok()
            && target.metadata().map_or(0, |m| m.len()) >= 1_000_000
        {
            return;
        }
        let _ = std::fs::remove_file(&target);
    }
}

#[cfg(test)]
mod tests {
    use std::{
        os::unix::fs::PermissionsExt,
        time::{SystemTime, UNIX_EPOCH},
    };

    #[test]
    fn sing_box_config_publication_is_owner_only() -> Result<(), String> {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|error| error.to_string())?
            .as_nanos();
        let directory = std::env::temp_dir().join(format!("caly-singbox-mode-{nonce}"));
        std::fs::create_dir_all(&directory).map_err(|error| error.to_string())?;
        let destination = directory.join("config.json");
        super::lifecycle_support::publish_owner_only_config(
            &destination,
            br#"{"secret":"credential"}"#.to_vec(),
            1,
        )
        .map_err(|error| format!("{error:?}"))?;
        let mode = std::fs::metadata(&destination)
            .map_err(|error| error.to_string())?
            .permissions()
            .mode()
            & 0o777;
        let cleanup = std::fs::remove_dir_all(directory);
        assert_eq!(mode, 0o600);
        cleanup.map_err(|error| error.to_string())
    }
}

#[cfg(test)]
mod bundled_binary_tests {
    use super::resolve_bundled_binary;

    fn touch(path: &std::path::Path) {
        std::fs::create_dir_all(path.parent().unwrap_or_else(|| std::process::abort()))
            .unwrap_or_else(|_| std::process::abort());
        std::fs::write(path, b"#!/bin/sh\n").unwrap_or_else(|_| std::process::abort());
    }

    #[test]
    fn prefers_the_working_directory_vendor_bin() {
        let dir = std::env::temp_dir().join(format!("caly-bundle-cwd-{}", std::process::id()));
        let binary = dir.join("vendor/bin/mihomo");
        touch(&binary);
        let resolved = resolve_bundled_binary("mihomo", Some(dir.as_path()), None);
        assert_eq!(resolved, binary);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn walks_executable_ancestors_for_dev_layouts() {
        let repo = std::env::temp_dir().join(format!("caly-bundle-exe-{}", std::process::id()));
        let executable = repo.join("target/debug/caly");
        let binary = repo.join("vendor/bin/sing-box");
        touch(&executable);
        touch(&binary);
        let elsewhere = repo.join("elsewhere");
        std::fs::create_dir_all(&elsewhere).unwrap_or_else(|_| std::process::abort());
        let resolved = resolve_bundled_binary(
            "sing-box",
            Some(elsewhere.as_path()),
            Some(executable.as_path()),
        );
        assert_eq!(resolved, binary);
        let _ = std::fs::remove_dir_all(&repo);
    }

    #[test]
    fn falls_back_to_a_cwd_relative_path_for_error_messages() {
        let missing = std::env::temp_dir().join(format!("caly-bundle-none-{}", std::process::id()));
        std::fs::create_dir_all(&missing).unwrap_or_else(|_| std::process::abort());
        let resolved = resolve_bundled_binary("mihomo", Some(missing.as_path()), None);
        assert_eq!(resolved, std::path::PathBuf::from("vendor/bin/mihomo"));
        let _ = std::fs::remove_dir_all(&missing);
    }
}
