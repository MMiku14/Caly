//! Daemon application layer for caly.
//!
//! Mutable aggregates are owned by bounded actor mailboxes. Cross-owner work
//! is coordinated by acyclic sagas. This crate contains no transport server or
//! platform backend and starts no task without an externally supplied owner.

#![forbid(unsafe_code)]

pub mod actor_result;
pub mod actors;
pub mod command_bus;
pub mod composition;
pub mod events;
pub mod operations;
pub mod projection;
pub mod routing;
mod routing_fanout;
pub mod runtime;
pub mod service;
pub mod supervision;

pub use routing_fanout::ActorCommandFanout;
