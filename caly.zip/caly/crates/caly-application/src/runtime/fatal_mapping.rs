//! Central mapping from unrecoverable runtime errors to root cancellation.

use crate::{
    projection::ProjectionRuntimeError, service::ActorResultError,
    service::runtime_service::RuntimeDispatchError,
};

use super::{FatalFault, FatalRecordOutcome, RuntimeGuard};

impl RuntimeGuard {
    pub fn record_dispatch_error(&mut self, _error: &RuntimeDispatchError) -> FatalRecordOutcome {
        self.record_fatal(FatalFault::CommandDispatch)
    }

    pub fn record_actor_result_error(&mut self, error: &ActorResultError) -> FatalRecordOutcome {
        match error {
            ActorResultError::Projection(_) => self.record_fatal(FatalFault::Projection),
            ActorResultError::InvalidTimeout | ActorResultError::Admission(_) => {
                self.record_fatal(FatalFault::ActorResult)
            }
        }
    }

    pub fn record_projection_error(
        &mut self,
        _error: &ProjectionRuntimeError,
    ) -> FatalRecordOutcome {
        self.record_fatal(FatalFault::Projection)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        operations::{AdmissionError, StoreError},
        runtime::fatal::FatalFault,
    };

    fn admission() -> AdmissionError {
        AdmissionError::Store(StoreError::NotFound)
    }

    #[test]
    fn dispatch_error_maps_to_command_dispatch_fault() {
        let mut guard = RuntimeGuard::new();
        let error = RuntimeDispatchError::Admission(admission());
        let outcome = guard.record_dispatch_error(&error);
        assert_eq!(outcome, FatalRecordOutcome::FirstFault);
        assert_eq!(guard.first_fault(), Some(FatalFault::CommandDispatch));
        assert!(guard.cancellation().is_cancelled());
    }

    #[test]
    fn actor_result_error_maps_to_actor_result_fault() {
        let mut guard = RuntimeGuard::new();
        let error = ActorResultError::Projection(ProjectionRuntimeError::Poisoned);
        let outcome = guard.record_actor_result_error(&error);
        assert_eq!(outcome, FatalRecordOutcome::FirstFault);
        assert_eq!(guard.first_fault(), Some(FatalFault::Projection));
    }

    #[test]
    fn projection_error_maps_to_projection_fault() {
        let mut guard = RuntimeGuard::new();
        let error = ProjectionRuntimeError::ReliableChannelClosed;
        let outcome = guard.record_projection_error(&error);
        assert_eq!(outcome, FatalRecordOutcome::FirstFault);
        assert_eq!(guard.first_fault(), Some(FatalFault::Projection));
    }

    #[test]
    fn first_fault_is_retained_across_distinct_categories() {
        let mut guard = RuntimeGuard::new();
        let first = guard.record_dispatch_error(&RuntimeDispatchError::InvalidTimeout);
        assert_eq!(first, FatalRecordOutcome::FirstFault);
        let second = guard.record_actor_result_error(&ActorResultError::InvalidTimeout);
        assert_eq!(second, FatalRecordOutcome::AdditionalFault { total: 2 });
        // First cause is preserved (diagnosis anchors on the earliest fault).
        assert_eq!(guard.first_fault(), Some(FatalFault::CommandDispatch));
        assert_eq!(guard.fault_count(), 2);
    }
}
