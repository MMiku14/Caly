//! Shared terminal ActorReport construction and submission.

use caly_domain::{
    BoundedText, OperationFailure, OperationFailureCode, OperationId, PresentationDelta,
};

use crate::actor_result::{ActorReport, ActorResultClient, ActorResultSendError, ResultDeltas};

use super::{ActorFailure, ActorFailureKind};

#[derive(Debug)]
pub enum HandlerReportError {
    DeltaCapacity,
    FailureText,
    ResultMailbox(ActorResultSendError),
}

pub fn report_completed(
    client: &ActorResultClient,
    operation_id: OperationId,
    deltas: Vec<PresentationDelta>,
) -> Result<(), HandlerReportError> {
    let deltas =
        ResultDeltas::try_from_vec(deltas).map_err(|_| HandlerReportError::DeltaCapacity)?;
    tracing::debug!(operation = ?operation_id, "operation completed");
    client
        .try_report(ActorReport::Completed {
            operation_id,
            deltas,
        })
        .map_err(HandlerReportError::ResultMailbox)
}

pub fn report_failed(
    client: &ActorResultClient,
    operation_id: OperationId,
    failure: ActorFailure,
    deltas: Vec<PresentationDelta>,
) -> Result<(), HandlerReportError> {
    let deltas =
        ResultDeltas::try_from_vec(deltas).map_err(|_| HandlerReportError::DeltaCapacity)?;
    let failure = operation_failure(failure)?;
    tracing::warn!(
        operation = ?operation_id,
        code = ?failure.code(),
        "operation failed: {}",
        failure.message().as_str()
    );
    client
        .try_report(ActorReport::Failed {
            operation_id,
            failure,
            deltas,
        })
        .map_err(HandlerReportError::ResultMailbox)
}

fn operation_failure(value: ActorFailure) -> Result<OperationFailure, HandlerReportError> {
    let code = match value.kind {
        ActorFailureKind::InvalidCandidate => OperationFailureCode::InvalidInput,
        ActorFailureKind::Unsupported => OperationFailureCode::Unsupported,
        ActorFailureKind::ResourceExhausted => OperationFailureCode::ResourceExhausted,
        ActorFailureKind::DeadlineExceeded => OperationFailureCode::DeadlineExceeded,
        ActorFailureKind::Infrastructure => OperationFailureCode::Infrastructure,
        ActorFailureKind::GenerationConflict => OperationFailureCode::Conflict,
        ActorFailureKind::RecoveryRequired => OperationFailureCode::RecoveryRequired,
    };
    let message = BoundedText::new(value.message.as_str().to_owned())
        .map_err(|_| HandlerReportError::FailureText)?;
    let action = BoundedText::new(value.suggested_action.as_str().to_owned())
        .map_err(|_| HandlerReportError::FailureText)?;
    Ok(OperationFailure::new(code, message, action))
}

/// Reports a command outcome as Completed or Failed, mapping the deltas/failure
/// onto the terminal `ActorReport`. This is the shared tail every owner handler
/// repeats, so it is centralized here.
pub fn report_outcome(
    client: &ActorResultClient,
    operation_id: OperationId,
    outcome: Result<Vec<PresentationDelta>, ActorFailure>,
) -> Result<(), HandlerReportError> {
    match outcome {
        Ok(deltas) => report_completed(client, operation_id, deltas),
        Err(failure) => report_failed(client, operation_id, failure, Vec::new()),
    }
}
