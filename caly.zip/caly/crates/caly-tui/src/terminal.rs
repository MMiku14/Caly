//! Terminal port abstraction for the interactive loop.
//!
//! The TUI loop drives a `Terminal` rather than a concrete terminal so it is
//! fully testable with a recording mock and stays independent of any raw-mode
//! or ioctl backend. A real adapter (e.g. crossterm) lives in a binary layer.

use crate::render::input::Key;

/// A single event read from the terminal.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Event {
    /// A parsed key press.
    Key(Key),
    /// A mouse click at terminal `(col, row)`.
    Click { col: usize, row: usize },
    /// The terminal was resized.
    Resize { cols: usize, rows: usize },
}

/// Terminal operation failure.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TerminalError {
    /// Entering raw/alternate-screen mode failed.
    EnterFailed,
    /// Writing a frame failed.
    WriteFailed,
}

/// Abstraction over the terminal used by the interactive loop.
pub trait Terminal {
    /// Returns the current `(cols, rows)` size.
    fn size(&self) -> (usize, usize);

    /// Enters the full-screen interaction mode (raw + alternate screen).
    fn enter(&mut self) -> Result<(), TerminalError>;

    /// Leaves full-screen mode and restores the prior terminal.
    fn leave(&mut self);

    /// Writes one rendered frame.
    fn write(&mut self, frame: &str) -> Result<(), TerminalError>;

    /// Reads the next event, returning `None` when none is pending.
    fn read_event(&mut self) -> Option<Event>;
}

#[cfg(test)]
pub(crate) mod mock {
    use super::{Event, Terminal, TerminalError};

    /// A scripted mock terminal used to exercise the loop without a TTY.
    #[derive(Default)]
    pub struct MockTerminal {
        cols: usize,
        rows: usize,
        frames: Vec<String>,
        events: Vec<Event>,
    }

    impl MockTerminal {
        pub fn new(cols: usize, rows: usize) -> Self {
            Self {
                cols,
                rows,
                frames: Vec::new(),
                events: Vec::new(),
            }
        }

        pub fn queue(&mut self, event: Event) {
            self.events.push(event);
        }

        pub fn frames(&self) -> &[String] {
            &self.frames
        }

        pub fn frame_count(&self) -> usize {
            self.frames.len()
        }
    }

    impl Terminal for MockTerminal {
        fn size(&self) -> (usize, usize) {
            (self.cols, self.rows)
        }

        fn enter(&mut self) -> Result<(), TerminalError> {
            Ok(())
        }

        fn leave(&mut self) {}

        fn write(&mut self, frame: &str) -> Result<(), TerminalError> {
            self.frames.push(frame.to_owned());
            Ok(())
        }

        fn read_event(&mut self) -> Option<Event> {
            if self.events.is_empty() {
                None
            } else {
                Some(self.events.remove(0))
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::render::input::Key;
    use mock::MockTerminal;

    #[test]
    fn mock_records_frames_and_drains_events() {
        let mut terminal = MockTerminal::new(80, 24);
        terminal.queue(Event::Key(Key::Down));
        assert_eq!(terminal.read_event(), Some(Event::Key(Key::Down)));
        assert_eq!(terminal.read_event(), None);
        terminal.write("frame").ok();
        assert_eq!(terminal.frame_count(), 1);
        assert_eq!(terminal.frames()[0], "frame");
    }
}
