//! Node list widget: filtering, sorting, scrolling and selection.
//!
//! A pure presentation model over a bounded snapshot's nodes. It keeps an
//! ordered list of node ids and a `Viewport` so rendering only walks the
//! visible slice.

use core::cmp::Ordering;

use caly_domain::{DisplayNode, NodeId, SnapshotNodes};

use super::Viewport;

/// Sort key for the node list.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum NodeSortKey {
    Name,
    Protocol,
    Latency,
}

/// A sort direction keyed by a `NodeSortKey`.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SortOrder {
    key: NodeSortKey,
    ascending: bool,
}

impl SortOrder {
    /// Name ascending, the stable default.
    pub const fn name() -> Self {
        Self {
            key: NodeSortKey::Name,
            ascending: true,
        }
    }

    /// Sets a key, toggling direction when the key is already active.
    pub fn toggle(&mut self, key: NodeSortKey) {
        if self.key == key {
            self.ascending = !self.ascending;
        } else {
            self.key = key;
            self.ascending = true;
        }
    }

    /// The active sort key.
    pub const fn key(self) -> NodeSortKey {
        self.key
    }
    /// Whether the direction is ascending.
    pub const fn ascending(self) -> bool {
        self.ascending
    }
}

impl Default for SortOrder {
    fn default() -> Self {
        Self::name()
    }
}

/// Ordered, filtered, scrolled node list with a stable selection.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeList {
    ordered: Vec<NodeId>,
    sort: SortOrder,
    viewport: Viewport,
    selected: Option<NodeId>,
}

impl NodeList {
    /// Constructs an empty list with a sort order.
    pub fn new(sort: SortOrder, visible_rows: usize) -> Self {
        Self {
            ordered: Vec::new(),
            sort,
            viewport: Viewport::new(visible_rows, 0),
            selected: None,
        }
    }

    /// Rebuilds the ordered list from a snapshot, applying the filter and sort.
    pub fn rebuild(&mut self, nodes: &SnapshotNodes, filter: &str, visible_rows: usize) {
        if filter.is_empty() {
            // Fast path: no filtering. Sort references to nodes (no clone, no
            // hash), comparing by deref; then project ids.
            let mut matched: Vec<&DisplayNode> = nodes.iter().collect();
            sort_nodes(&mut matched, self.sort);
            self.ordered = matched.iter().map(|node| node.id()).collect();
        } else {
            let mut matched: Vec<&DisplayNode> =
                nodes.iter().filter(|node| matches(node, filter)).collect();
            sort_nodes(&mut matched, self.sort);
            self.ordered = matched.iter().map(|node| node.id()).collect();
        }
        self.viewport
            .update_extent(visible_rows, self.ordered.len());
        if self.selected.is_some_and(|id| !self.ordered.contains(&id)) {
            self.selected = self.ordered.first().copied();
        }
    }

    /// Sets the sort order. Callers must `rebuild` to apply it to the order.
    pub fn set_sort(&mut self, sort: SortOrder) {
        self.sort = sort;
    }

    /// Returns the ordered node ids (after filter + sort).
    pub fn ordered_ids(&self) -> &[NodeId] {
        &self.ordered
    }

    /// Returns the currently visible node-id slice.
    pub fn visible(&self) -> &[NodeId] {
        let offset = self.viewport.offset();
        let end = (offset + self.viewport.visible_rows()).min(self.ordered.len());
        if offset >= end {
            &[]
        } else {
            &self.ordered[offset..end]
        }
    }

    /// Scrolls the viewport by a signed row delta.
    pub fn scroll(&mut self, delta: isize) {
        self.viewport.scroll(delta);
    }

    /// Returns the current selection, if it still exists in the list.
    pub fn selected(&self) -> Option<NodeId> {
        self.selected
    }

    /// Selects the next or previous visible node.
    pub fn select(&mut self, delta: isize) -> Option<NodeId> {
        if self.ordered.is_empty() {
            self.selected = None;
            return None;
        }
        let current = self
            .selected
            .and_then(|id| self.ordered.iter().position(|candidate| *candidate == id))
            .unwrap_or(0);
        let len = i64::try_from(self.ordered.len()).unwrap_or(0);
        let current = i64::try_from(current).unwrap_or(0);
        let next = (current + i64::try_from(delta).unwrap_or(0)).clamp(0, len - 1);
        let index = usize::try_from(next).unwrap_or(0);
        self.selected = Some(self.ordered[index]);
        self.selected
    }

    /// Current active sort order.
    pub fn sort(&self) -> SortOrder {
        self.sort
    }
}

/// Whether a node matches the keyword filter, case-insensitively, without
/// allocating a lowercased copy.
fn matches(node: &DisplayNode, needle: &str) -> bool {
    if needle.is_empty() {
        return true;
    }
    let needle = needle.to_ascii_lowercase();
    ascii_contains(node.name().as_str(), &needle)
        || ascii_contains(node.protocol().as_str(), &needle)
}

/// Case-insensitive `haystack.contains(needle)` over ASCII without allocation.
fn ascii_contains(haystack: &str, needle: &str) -> bool {
    if needle.is_empty() {
        return true;
    }
    let hay = haystack.as_bytes();
    let needle = needle.as_bytes();
    if needle.len() > hay.len() {
        return false;
    }
    hay.windows(needle.len()).any(|window| {
        window
            .iter()
            .zip(needle.iter())
            .all(|(a, b)| a.eq_ignore_ascii_case(b))
    })
}

/// Orders two node ids by the active key and direction, tie-broken by id,
/// without cloning the display nodes.
/// Sorts a slice of node references, dereferencing once via `compare`.
fn sort_nodes(nodes: &mut [&DisplayNode], order: SortOrder) {
    nodes.sort_by(|left, right| compare(left, right, order));
}

/// Orders two nodes by the active key and direction, tie-broken by id.
// `&&DisplayNode` matches `sort_by`'s closure argument directly; the reference
// is deliberately passed by reference (it is already a reference).
#[allow(clippy::trivially_copy_pass_by_ref)]
fn compare(left: &&DisplayNode, right: &&DisplayNode, order: SortOrder) -> Ordering {
    let base = match order.key() {
        NodeSortKey::Name => left.name().as_str().cmp(right.name().as_str()),
        NodeSortKey::Protocol => left.protocol().as_str().cmp(right.protocol().as_str()),
        NodeSortKey::Latency => left
            .latency_ms()
            .unwrap_or(u32::MAX)
            .cmp(&right.latency_ms().unwrap_or(u32::MAX)),
    };
    let directed = if order.ascending() {
        base
    } else {
        base.reverse()
    };
    directed.then_with(|| left.id().cmp(&right.id()))
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{NodeDisplayName, NodeProtocolLabel};

    fn node(
        id: u8,
        name: &str,
        protocol: &str,
        latency: Option<u32>,
    ) -> Result<DisplayNode, &'static str> {
        Ok(DisplayNode::new(
            NodeId::from_bytes([id; 16]),
            NodeDisplayName::new(name.to_owned()).map_err(|_| "name")?,
            NodeProtocolLabel::new(protocol.to_owned()).map_err(|_| "protocol")?,
            true,
            latency,
        ))
    }

    fn nodes() -> Result<SnapshotNodes, &'static str> {
        let mut values = SnapshotNodes::new();
        for (id, name, proto, latency) in [
            (1u8, "hk-01", "vmess", Some(30)),
            (2, "sg-02", "shadowsocks", Some(20)),
            (3, "hk-03", "trojan", None),
        ] {
            values
                .try_push(node(id, name, proto, latency)?)
                .map_err(|_| "push")?;
        }
        Ok(values)
    }

    #[test]
    fn filters_by_keyword() -> Result<(), &'static str> {
        let snapshot = nodes()?;
        let mut list = NodeList::new(SortOrder::name(), 10);
        list.rebuild(&snapshot, "hk", 10);
        assert_eq!(list.ordered_ids().len(), 2);
        list.rebuild(&snapshot, "shadowsocks", 10);
        assert_eq!(list.ordered_ids().len(), 1);
        Ok(())
    }

    #[test]
    fn sorts_by_latency_ascending() -> Result<(), &'static str> {
        let snapshot = nodes()?;
        let mut order = SortOrder::name();
        order.toggle(NodeSortKey::Latency);
        let mut list = NodeList::new(order, 10);
        list.rebuild(&snapshot, "", 10);
        assert_eq!(list.ordered_ids()[0], NodeId::from_bytes([2; 16]));
        assert_eq!(list.ordered_ids()[2], NodeId::from_bytes([3; 16]));
        Ok(())
    }

    #[test]
    fn selection_moves_and_persists() -> Result<(), &'static str> {
        let snapshot = nodes()?;
        let mut list = NodeList::new(SortOrder::name(), 10);
        list.rebuild(&snapshot, "", 10);
        assert_eq!(list.select(1), Some(NodeId::from_bytes([3; 16])));
        assert_eq!(list.select(-1), Some(NodeId::from_bytes([1; 16])));
        list.rebuild(&snapshot, "nope", 10);
        assert_eq!(list.selected(), None);
        Ok(())
    }

    #[test]
    fn visible_slice_respects_viewport() -> Result<(), &'static str> {
        let snapshot = nodes()?;
        let mut list = NodeList::new(SortOrder::name(), 1);
        list.rebuild(&snapshot, "", 1);
        assert_eq!(list.visible().len(), 1);
        list.scroll(1);
        assert_eq!(list.visible()[0], NodeId::from_bytes([3; 16]));
        list.scroll(10);
        assert!(list.visible().len() <= 1);
        Ok(())
    }
}
