//! Overflow-safe viewport and proportional scrollbar math.

/// Logical viewport independent of wrapped rendering implementation.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct Viewport {
    offset: usize,
    visible_rows: usize,
    content_rows: usize,
}

impl Viewport {
    pub const fn new(visible_rows: usize, content_rows: usize) -> Self {
        Self {
            offset: 0,
            visible_rows,
            content_rows,
        }
    }

    pub fn update_extent(&mut self, visible_rows: usize, content_rows: usize) {
        self.visible_rows = visible_rows;
        self.content_rows = content_rows;
        self.offset = self.offset.min(self.max_offset());
    }

    pub fn scroll(&mut self, delta: isize) {
        if delta < 0 {
            self.offset = self.offset.saturating_sub(delta.unsigned_abs());
        } else {
            self.offset = self
                .offset
                .saturating_add(delta.unsigned_abs())
                .min(self.max_offset());
        }
    }

    pub const fn offset(self) -> usize {
        self.offset
    }
    /// Number of visible rows.
    pub const fn visible_rows(self) -> usize {
        self.visible_rows
    }
    pub const fn max_offset(self) -> usize {
        self.content_rows.saturating_sub(self.visible_rows)
    }

    /// Returns `(thumb_start, thumb_length)` in track cells using u128 products.
    pub fn scrollbar(self, track_cells: usize) -> (usize, usize) {
        if track_cells == 0 || self.content_rows == 0 {
            return (0, 0);
        }
        let track = track_cells as u128;
        let content = self.content_rows as u128;
        let visible = self.visible_rows.min(self.content_rows) as u128;
        let length = ((track * visible) / content).max(1).min(track);
        let travel = track.saturating_sub(length);
        let max_offset = self.max_offset() as u128;
        let start = (travel * self.offset as u128)
            .checked_div(max_offset)
            .unwrap_or(0);
        (start as usize, length as usize)
    }
}

#[cfg(test)]
mod tests {
    use super::Viewport;

    #[test]
    fn huge_scroll_and_scrollbar_are_bounded() {
        let mut viewport = Viewport::new(10, usize::MAX);
        viewport.scroll(isize::MAX);
        let (start, length) = viewport.scrollbar(20);
        assert!(start < 20);
        assert!((1..=20).contains(&length));
    }
}
