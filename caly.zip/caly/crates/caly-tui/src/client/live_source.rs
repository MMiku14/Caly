//! Watch-driven live TUI data source.
//!
//! `LiveWatchSource` owns the client `ConnectionSupervisor` + `WatchDriver` +
//! `SessionModel` and turns an incremental watch stream into authoritative
//! snapshots for the renderer. It is transport-agnostic (any `WatchTransport`
//! can back it), so it is fully testable without a daemon.

use caly_domain::{EventCursor, PresentationSnapshot};
use caly_protocol::{
    conversion::{cursor_to_wire, snapshot_to_wire},
    protocol::v2::{DecodeLimits, WatchResponse},
};

use crate::model::SessionModel;

use super::{ConnectionEvent, ConnectionSupervisor, WatchDriver, WatchOutcome};

/// A continuous watch stream the source can re-establish after it ends.
/// `Send` so a `LiveWatchSource` can run on a worker thread.
pub trait WatchTransport: Send {
    /// Returns the next watch response, or `None` when the stream ended or
    /// failed and the connection should be re-established.
    fn next(&mut self) -> Option<WatchResponse>;
    /// Re-establishes the watch stream; returns `true` on success. A freshly
    /// reconnected stream must begin with an authoritative full snapshot.
    fn reconnect(&mut self) -> bool;
}

/// Drives the watch stream and produces the latest authoritative snapshot.
pub struct LiveWatchSource {
    driver: WatchDriver,
    transport: Box<dyn WatchTransport>,
}

impl LiveWatchSource {
    /// Starts from an initial snapshot (the first full fetch) and a live
    /// transport. The supervisor is driven into a `Watching` state so the first
    /// live event applies incrementally. The transition sequence is an internal
    /// invariant and cannot fail with these constructed events.
    pub fn new(
        initial: PresentationSnapshot,
        limits: DecodeLimits,
        transport: Box<dyn WatchTransport>,
    ) -> Self {
        let cursor = initial.cursor();
        let mut supervisor = ConnectionSupervisor::new();
        // This transition sequence is an internal invariant and cannot fail
        // with these constructed events; ignore the action results.
        for event in [
            ConnectionEvent::ConnectStarted,
            ConnectionEvent::TransportConnected,
            ConnectionEvent::HandshakeAccepted,
            ConnectionEvent::SnapshotReceived { cursor },
        ] {
            let _ = supervisor.transition(event);
        }
        let session = SessionModel::new(initial);
        Self {
            driver: WatchDriver::new(supervisor, session, limits),
            transport,
        }
    }

    /// Borrows the current authoritative session.
    pub fn session(&self) -> &SessionModel {
        self.driver.session()
    }

    /// Pulls and applies watch updates, returning the latest snapshot.
    ///
    /// On an idle live stream this blocks until the next event (or a full
    /// snapshot on recovery). When the stream ends, it reconnects and returns
    /// the recovered snapshot. Returns `None` only when reconnection fails.
    pub fn refresh(&mut self) -> Option<PresentationSnapshot> {
        loop {
            match self.transport.next() {
                Some(response) => match self.driver.handle(response) {
                    Ok(WatchOutcome::SnapshotApplied(_))
                    | Ok(WatchOutcome::EventApplied { .. })
                    | Ok(WatchOutcome::IgnoredStale) => {}
                    Ok(WatchOutcome::SnapshotRequired(_)) | Err(_) => {
                        return self.recover();
                    }
                },
                // Stream ended; reconnect to keep the watch live.
                None => return self.recover(),
            }
        }
    }

    fn recover(&mut self) -> Option<PresentationSnapshot> {
        if self.transport.reconnect() {
            // The reconnected stream begins with a full snapshot; drain it.
            while let Some(response) = self.transport.next() {
                match self.driver.handle(response) {
                    Ok(WatchOutcome::SnapshotApplied(_)) => {}
                    Ok(_) | Err(_) => break,
                }
            }
            Some(self.session_snapshot())
        } else {
            None
        }
    }

    fn session_snapshot(&self) -> PresentationSnapshot {
        self.driver.session().snapshot().as_ref().clone()
    }

    /// Requests an authoritative full snapshot via the transport and applies it.
    /// Used to force a clean re-sync without waiting for a transport failure.
    pub fn resync(&mut self) -> Option<PresentationSnapshot> {
        self.recover()
    }
}

/// A mock-friendly transport that replays an owned response sequence, then
/// reconnects to a fresh sequence. Useful for tests and deterministic tools.
pub struct ReplayWatchTransport {
    pending: Vec<WatchResponse>,
    next_on_reconnect: Vec<WatchResponse>,
    reconnect_succeeds: bool,
}

impl ReplayWatchTransport {
    /// Replays `first`, then serves `reconnect` after `next()` returns `None`.
    pub fn new(first: Vec<WatchResponse>, reconnect: Vec<WatchResponse>) -> Self {
        Self {
            pending: first,
            next_on_reconnect: reconnect,
            reconnect_succeeds: true,
        }
    }

    /// Builds a full-snapshot wire response from a presentation snapshot.
    pub fn snapshot_response(snapshot: &PresentationSnapshot) -> Result<WatchResponse, String> {
        snapshot_to_wire(snapshot)
            .map(WatchResponse::FullSnapshot)
            .map_err(|_| "snapshot encode failed".to_owned())
    }

    /// Builds an observed-state event wire response with the given cursor.
    pub fn observed_event(cursor: EventCursor, state: caly_domain::ObservedState) -> WatchResponse {
        use caly_protocol::protocol::v2::{WireEvent, WireProjectionEvent};
        WatchResponse::Event(WireEvent {
            cursor: cursor_to_wire(cursor),
            event: WireProjectionEvent::ObservedReplaced(
                caly_protocol::conversion::observed_to_wire(&state),
            ),
        })
    }
}

impl WatchTransport for ReplayWatchTransport {
    fn next(&mut self) -> Option<WatchResponse> {
        if self.pending.is_empty() {
            None
        } else {
            Some(self.pending.remove(0))
        }
    }

    fn reconnect(&mut self) -> bool {
        if !self.reconnect_succeeds {
            return false;
        }
        self.pending = std::mem::take(&mut self.next_on_reconnect);
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_domain::{
        AppliedState, BoundedVec, CapabilitySet, DaemonInstanceId, DesiredState, EventSequence,
        ObservedState, PlatformEffectView, ProxyMode, SnapshotRevision,
    };

    fn snapshot() -> Result<PresentationSnapshot, String> {
        let daemon = DaemonInstanceId::from_bytes([9; 16]);
        let cursor = EventCursor::new(daemon, EventSequence::ZERO);
        let caps = CapabilitySet::new(BoundedVec::new()).map_err(|_| "caps")?;
        Ok(PresentationSnapshot::new(
            daemon,
            SnapshotRevision::new(0),
            cursor,
            DesiredState::new(ProxyMode::Rule, None, None, false, false),
            AppliedState::stopped(),
            ObservedState::default(),
            PlatformEffectView::none(),
            caps,
            BoundedVec::new(),
        ))
    }

    fn snapshot_at(sequence: u64, observed: ObservedState) -> Result<PresentationSnapshot, String> {
        let base = snapshot()?;
        Ok(PresentationSnapshot::new(
            base.daemon_instance(),
            SnapshotRevision::new(sequence),
            EventCursor::new(base.daemon_instance(), EventSequence::new(sequence)),
            base.desired().clone(),
            base.applied().clone(),
            observed,
            base.platform().clone(),
            base.capabilities().clone(),
            BoundedVec::new(),
        ))
    }

    #[test]
    fn refresh_returns_initial_snapshot_when_no_updates() -> Result<(), String> {
        let initial = snapshot()?;
        let mut source = LiveWatchSource::new(
            initial.clone(),
            DecodeLimits::v2_default(),
            Box::new(ReplayWatchTransport::new(Vec::new(), Vec::new())),
        );
        assert_eq!(source.refresh().ok_or("no snapshot")?, initial);
        Ok(())
    }

    #[test]
    fn refresh_applies_live_observed_events() -> Result<(), String> {
        let initial = snapshot()?;
        let daemon = initial.daemon_instance();
        let next_cursor = EventCursor::new(daemon, EventSequence::new(1));
        let responses = vec![ReplayWatchTransport::observed_event(
            next_cursor,
            ObservedState::new(5, 6, 1, 0),
        )];
        let mut source = LiveWatchSource::new(
            initial.clone(),
            DecodeLimits::v2_default(),
            Box::new(ReplayWatchTransport::new(responses, Vec::new())),
        );
        let snapshot = source.refresh().ok_or("no snapshot")?;
        assert_eq!(snapshot.observed(), &ObservedState::new(5, 6, 1, 0));
        Ok(())
    }

    #[test]
    fn refresh_recovers_after_stream_ends_with_full_snapshot() -> Result<(), String> {
        let initial = snapshot()?;
        let recovered_snapshot = snapshot_at(3, ObservedState::new(10, 20, 3, 0))?;
        let recovered_response = ReplayWatchTransport::snapshot_response(&recovered_snapshot)?;
        let mut source = LiveWatchSource::new(
            initial.clone(),
            DecodeLimits::v2_default(),
            Box::new(ReplayWatchTransport::new(
                Vec::new(),
                vec![recovered_response],
            )),
        );
        // Force recovery by requiring a resync (stream is considered ended).
        let snapshot = source.resync().ok_or("no snapshot")?;
        assert_eq!(snapshot.observed(), &ObservedState::new(10, 20, 3, 0));
        assert_eq!(snapshot.cursor().sequence(), EventSequence::new(3));
        Ok(())
    }

    #[test]
    fn refresh_returns_none_when_reconnect_fails() -> Result<(), String> {
        let initial = snapshot()?;
        let mut transport = ReplayWatchTransport::new(Vec::new(), Vec::new());
        transport.reconnect_succeeds = false;
        let mut source =
            LiveWatchSource::new(initial, DecodeLimits::v2_default(), Box::new(transport));
        // Force a recovery by requiring a resync.
        assert!(source.resync().is_none());
        Ok(())
    }
}
