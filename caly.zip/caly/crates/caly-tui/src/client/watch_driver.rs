//! Typed watch response decode, apply and recovery driver.

use caly_domain::EventCursor;
use caly_protocol::{
    conversion::{DecodeError, DecodedProjectionEvent, event_from_wire, snapshot_from_wire},
    protocol::v2::{DecodeBudget, DecodeLimits, WatchResponse},
};

use crate::model::{DeltaApplyError, SelectionOutcome, SessionModel};

use super::{ConnectionAction, ConnectionEvent, ConnectionSupervisor, ConnectionTransitionError};

/// Successful watch handling or explicit snapshot recovery request.
pub enum WatchOutcome {
    SnapshotApplied(SelectionOutcome),
    EventApplied {
        cursor: EventCursor,
        selection: SelectionOutcome,
    },
    IgnoredStale,
    SnapshotRequired(WatchRecoveryCause),
}

/// Why incremental state was abandoned.
pub enum WatchRecoveryCause {
    CursorGapOrEpoch,
    DecodeRejected(DecodeError),
    DeltaRejected(DeltaApplyError),
    UnknownEvent { raw_kind: i32 },
}

/// Driver-level contract failure rather than recoverable event loss.
#[derive(Debug)]
pub enum WatchDriverError {
    Transition(ConnectionTransitionError),
    SnapshotDecode(DecodeError),
}

/// Owns connection cursor decisions and immutable session replacement.
pub struct WatchDriver {
    supervisor: ConnectionSupervisor,
    session: SessionModel,
    limits: DecodeLimits,
}

impl WatchDriver {
    pub const fn new(
        supervisor: ConnectionSupervisor,
        session: SessionModel,
        limits: DecodeLimits,
    ) -> Self {
        Self {
            supervisor,
            session,
            limits,
        }
    }

    pub const fn supervisor(&self) -> &ConnectionSupervisor {
        &self.supervisor
    }
    pub const fn session(&self) -> &SessionModel {
        &self.session
    }

    /// Handles one stream response without committing cursor before apply.
    pub fn handle(&mut self, response: WatchResponse) -> Result<WatchOutcome, WatchDriverError> {
        match response {
            WatchResponse::FullSnapshot(wire) => self.apply_snapshot(wire),
            WatchResponse::Event(wire) => self.apply_event(wire),
        }
    }

    fn apply_snapshot(
        &mut self,
        wire: caly_protocol::protocol::v2::WirePresentationSnapshot,
    ) -> Result<WatchOutcome, WatchDriverError> {
        let mut budget = DecodeBudget::new(self.limits);
        let snapshot =
            snapshot_from_wire(wire, &mut budget).map_err(WatchDriverError::SnapshotDecode)?;
        let cursor = snapshot.cursor();
        self.supervisor
            .transition(ConnectionEvent::SnapshotReceived { cursor })
            .map_err(WatchDriverError::Transition)?;
        let selection = self.session.replace_snapshot(snapshot);
        Ok(WatchOutcome::SnapshotApplied(selection))
    }

    fn apply_event(
        &mut self,
        wire: caly_protocol::protocol::v2::WireEvent,
    ) -> Result<WatchOutcome, WatchDriverError> {
        let incoming = caly_protocol::conversion::cursor_from_wire(wire.cursor);
        let action = self
            .supervisor
            .transition(ConnectionEvent::EventReceived { cursor: incoming })
            .map_err(WatchDriverError::Transition)?;
        match action {
            ConnectionAction::None => Ok(WatchOutcome::IgnoredStale),
            ConnectionAction::FetchSnapshot => Ok(WatchOutcome::SnapshotRequired(
                WatchRecoveryCause::CursorGapOrEpoch,
            )),
            ConnectionAction::DecodeAndApplyEvent => self.decode_apply_event(wire),
            _ => Err(WatchDriverError::Transition(ConnectionTransitionError)),
        }
    }

    fn decode_apply_event(
        &mut self,
        wire: caly_protocol::protocol::v2::WireEvent,
    ) -> Result<WatchOutcome, WatchDriverError> {
        let mut budget = DecodeBudget::new(self.limits);
        match event_from_wire(wire, &mut budget) {
            Ok(DecodedProjectionEvent::Known { cursor, delta }) => {
                match self.session.apply_delta(cursor, delta) {
                    Ok(selection) => {
                        self.supervisor
                            .transition(ConnectionEvent::EventApplied)
                            .map_err(WatchDriverError::Transition)?;
                        Ok(WatchOutcome::EventApplied { cursor, selection })
                    }
                    Err(error) => self.recover(WatchRecoveryCause::DeltaRejected(error)),
                }
            }
            Ok(DecodedProjectionEvent::Unknown { raw_kind, .. }) => {
                self.recover(WatchRecoveryCause::UnknownEvent { raw_kind })
            }
            Err(error) => self.recover(WatchRecoveryCause::DecodeRejected(error)),
        }
    }

    fn recover(&mut self, cause: WatchRecoveryCause) -> Result<WatchOutcome, WatchDriverError> {
        self.supervisor
            .transition(ConnectionEvent::EventDecodeFailed)
            .map_err(WatchDriverError::Transition)?;
        Ok(WatchOutcome::SnapshotRequired(cause))
    }
}
