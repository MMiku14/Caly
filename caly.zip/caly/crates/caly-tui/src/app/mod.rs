//! TUI interaction state separate from daemon state.

mod notifications;
mod runner;

pub use notifications::{Notification, NotificationLevel, NotificationQueue};
pub use runner::{DEFAULT_REFRESH_MS, MAX_REFRESH_MS, MIN_REFRESH_MS, TuiApp};
