//! Bounded truthful notification queue.

use std::collections::VecDeque;

use caly_domain::BoundedText;

pub const MAX_NOTIFICATIONS: usize = 200;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum NotificationLevel {
    Info,
    Success,
    Warning,
    Error,
}

pub struct Notification {
    pub level: NotificationLevel,
    pub title: BoundedText<128>,
    pub body: BoundedText<1_024>,
}

/// Explicit oldest-first retention for transient presentation messages.
pub struct NotificationQueue(VecDeque<Notification>);

impl NotificationQueue {
    pub fn new() -> Self {
        Self(VecDeque::with_capacity(MAX_NOTIFICATIONS))
    }

    pub fn push(&mut self, value: Notification) {
        if self.0.len() == MAX_NOTIFICATIONS {
            self.0.pop_front();
        }
        self.0.push_back(value);
    }

    pub fn pop_front(&mut self) -> Option<Notification> {
        self.0.pop_front()
    }
    pub fn len(&self) -> usize {
        self.0.len()
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

impl Default for NotificationQueue {
    fn default() -> Self {
        Self::new()
    }
}
