//! Immutable snapshot session and stable selection.

use std::sync::Arc;

use caly_domain::{
    CursorDisposition, EventCursor, NodeId, PresentationDelta, PresentationSnapshot,
    SnapshotRevision, classify_cursor,
};

/// Selection reconciliation after an authoritative snapshot.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SelectionOutcome {
    Preserved,
    ClearedMissing,
    AlreadyEmpty,
}

/// Client-local interaction state; daemon state remains immutable.
pub struct SessionModel {
    snapshot: Arc<PresentationSnapshot>,
    selected_node: Option<NodeId>,
}

impl SessionModel {
    /// Starts from an authoritative snapshot.
    pub fn new(snapshot: PresentationSnapshot) -> Self {
        Self {
            snapshot: Arc::new(snapshot),
            selected_node: None,
        }
    }

    /// Atomically replaces the authoritative snapshot and reconciles stable IDs.
    pub fn replace_snapshot(&mut self, snapshot: PresentationSnapshot) -> SelectionOutcome {
        self.snapshot = Arc::new(snapshot);
        self.reconcile_selection()
    }

    /// Selects only a node currently present in the snapshot.
    pub fn select_node(&mut self, id: NodeId) -> Result<(), SelectionError> {
        if !self.snapshot.nodes().iter().any(|node| node.id() == id) {
            return Err(SelectionError::NodeMissing);
        }
        self.selected_node = Some(id);
        Ok(())
    }

    /// Applies one decoded contiguous projection delta, then commits its cursor.
    pub fn apply_delta(
        &mut self,
        cursor: EventCursor,
        delta: PresentationDelta,
    ) -> Result<SelectionOutcome, DeltaApplyError> {
        if classify_cursor(self.snapshot.cursor(), cursor) != CursorDisposition::Apply {
            return Err(DeltaApplyError::SnapshotRequired);
        }
        let revision = self
            .snapshot
            .revision()
            .value()
            .checked_add(1)
            .ok_or(DeltaApplyError::RevisionExhausted)?;
        let mut desired = self.snapshot.desired().clone();
        let mut applied = self.snapshot.applied().clone();
        let mut observed = *self.snapshot.observed();
        let mut platform = self.snapshot.platform().clone();
        let mut capabilities = self.snapshot.capabilities().clone();
        let mut nodes = self.snapshot.nodes().clone();
        match delta {
            PresentationDelta::DesiredReplaced(value) => desired = value,
            PresentationDelta::AppliedReplaced(value) => applied = value,
            PresentationDelta::ObservedReplaced(value) => observed = value,
            PresentationDelta::PlatformReplaced(value) => platform = value,
            PresentationDelta::CapabilitiesReplaced(value) => capabilities = value,
            PresentationDelta::NodesReplaced(value) => nodes = value,
        }
        self.snapshot = Arc::new(PresentationSnapshot::new(
            self.snapshot.daemon_instance(),
            SnapshotRevision::new(revision),
            cursor,
            desired,
            applied,
            observed,
            platform,
            capabilities,
            nodes,
        ));
        Ok(self.reconcile_selection())
    }

    /// Returns immutable daemon state.
    pub fn snapshot(&self) -> Arc<PresentationSnapshot> {
        Arc::clone(&self.snapshot)
    }

    /// Returns client-local stable selection.
    pub const fn selected_node(&self) -> Option<NodeId> {
        self.selected_node
    }

    fn reconcile_selection(&mut self) -> SelectionOutcome {
        let Some(selected) = self.selected_node else {
            return SelectionOutcome::AlreadyEmpty;
        };
        if self
            .snapshot
            .nodes()
            .iter()
            .any(|node| node.id() == selected)
        {
            SelectionOutcome::Preserved
        } else {
            self.selected_node = None;
            SelectionOutcome::ClearedMissing
        }
    }
}

/// Selection failure never sends a fabricated node name to daemon.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SelectionError {
    NodeMissing,
}

/// Incremental apply failure requiring authoritative recovery.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DeltaApplyError {
    SnapshotRequired,
    RevisionExhausted,
}
