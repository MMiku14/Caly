//! Terminal presentation client for caly.
//!
//! The TUI consumes immutable presentation snapshots through caly-protocol.
//! Selection, viewport, reconnect and operation wait state remain client-local.

#![forbid(unsafe_code)]

pub mod app;
pub mod client;
pub mod editor;
pub mod model;
pub mod operation;
pub mod render;
pub mod terminal;
pub mod widgets;
