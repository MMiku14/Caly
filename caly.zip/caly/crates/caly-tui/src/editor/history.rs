//! Incremental bounded editor undo/redo history.

use std::collections::VecDeque;

use caly_domain::BoundedVec;

pub const MAX_EDIT_BYTES: usize = 64 * 1_024;
pub const MAX_HISTORY_BYTES: usize = 4 * 1_024 * 1_024;
pub const MAX_HISTORY_ENTRIES: usize = 512;
pub type EditBytes = BoundedVec<u8, MAX_EDIT_BYTES>;

/// Reversible incremental text replacement.
pub struct TextEdit {
    pub byte_offset: usize,
    pub deleted: EditBytes,
    pub inserted: EditBytes,
}

impl TextEdit {
    pub fn memory_bytes(&self) -> usize {
        self.deleted.len().saturating_add(self.inserted.len())
    }
}

/// History rejection without silently discarding the submitted edit.
pub enum HistoryError {
    EditExceedsBudget(TextEdit),
}

/// Bounded incremental history; no full-document snapshots are stored.
pub struct EditHistory {
    undo: VecDeque<TextEdit>,
    redo: VecDeque<TextEdit>,
    memory_bytes: usize,
}

impl EditHistory {
    pub fn new() -> Self {
        Self {
            undo: VecDeque::new(),
            redo: VecDeque::new(),
            memory_bytes: 0,
        }
    }

    pub fn record(&mut self, edit: TextEdit) -> Result<(), HistoryError> {
        let bytes = edit.memory_bytes();
        if bytes > MAX_HISTORY_BYTES {
            return Err(HistoryError::EditExceedsBudget(edit));
        }
        let redo_bytes = self.redo.iter().fold(0_usize, |total, item| {
            total.saturating_add(item.memory_bytes())
        });
        self.redo.clear();
        self.memory_bytes = self
            .memory_bytes
            .saturating_sub(redo_bytes)
            .saturating_add(bytes);
        self.undo.push_back(edit);
        self.evict_to_budget();
        Ok(())
    }

    /// Moves one edit to redo while keeping total memory accounting unchanged.
    pub fn undo(&mut self) -> Option<&TextEdit> {
        let edit = self.undo.pop_back()?;
        self.redo.push_back(edit);
        self.redo.back()
    }

    /// Moves one edit back to undo while keeping total memory accounting unchanged.
    pub fn redo(&mut self) -> Option<&TextEdit> {
        let edit = self.redo.pop_back()?;
        self.undo.push_back(edit);
        self.undo.back()
    }

    fn evict_to_budget(&mut self) {
        while self.memory_bytes > MAX_HISTORY_BYTES || self.entry_count() > MAX_HISTORY_ENTRIES {
            let removed = self.undo.pop_front().or_else(|| self.redo.pop_front());
            let Some(edit) = removed else { break };
            self.memory_bytes = self.memory_bytes.saturating_sub(edit.memory_bytes());
        }
    }

    fn entry_count(&self) -> usize {
        self.undo.len().saturating_add(self.redo.len())
    }
}

impl Default for EditHistory {
    fn default() -> Self {
        Self::new()
    }
}
