//! UI actions resolved from keys or hot-zone clicks.
//!
//! Actions are pure, presentation-local commands. A future interaction loop
//! translates them into daemon operations or client-local state changes.

use super::input::Key;

/// A user command produced by a key press or a hot-zone click.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Action {
    /// Leave the interactive UI.
    Quit,
    /// Open the main/help menu.
    OpenMenu,
    /// Freeze or resume snapshot-driven refresh.
    TogglePause,
    /// Scroll the node list by a signed row delta.
    ScrollNodes(isize),
    /// Select the next or previous node.
    SelectNextNode,
    SelectPrevNode,
    /// Execute the selection of the highlighted node (daemon-bound).
    SelectNode,
    /// Cycle the routing mode rule → global → direct (daemon-bound).
    CycleMode,
    /// Restart the running core (daemon-bound).
    RestartCore,
    /// Close all live connections (daemon-bound).
    CloseConnections,
    /// Shift the refresh cadence by a signed number of milliseconds.
    AdjustRefresh(isize),
    /// Switch to the next or previous layout preset.
    NextPreset,
    PrevPreset,
    /// Enter node-filter typing mode (`/`).
    BeginFilter,
    /// Cycle the node sort key (`s`).
    CycleSort,
    /// Toggle between the flat node list and the protocol tree view (`t`).
    ToggleTreeView,
}

/// Maps a parsed key to an optional action.
pub fn action_from_key(key: Key) -> Option<Action> {
    match key {
        Key::Esc | Key::Char('q') => Some(Action::Quit),
        Key::Char('m') => Some(Action::OpenMenu),
        Key::Char('p') => Some(Action::TogglePause),
        Key::Down => Some(Action::ScrollNodes(1)),
        Key::Up => Some(Action::ScrollNodes(-1)),
        Key::PageDown => Some(Action::ScrollNodes(10)),
        Key::PageUp => Some(Action::ScrollNodes(-10)),
        Key::Char('n') => Some(Action::SelectNextNode),
        Key::Char('N') => Some(Action::SelectPrevNode),
        Key::Enter => Some(Action::SelectNode),
        Key::Char('g') => Some(Action::CycleMode),
        Key::Char('r') => Some(Action::RestartCore),
        Key::Char('c') => Some(Action::CloseConnections),
        Key::Char('+') => Some(Action::AdjustRefresh(100)),
        Key::Char('-') => Some(Action::AdjustRefresh(-100)),
        Key::Char('1') => Some(Action::NextPreset),
        Key::Char('2') => Some(Action::PrevPreset),
        Key::Char('/') => Some(Action::BeginFilter),
        Key::Char('s') => Some(Action::CycleSort),
        Key::Char('t') => Some(Action::ToggleTreeView),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quits_on_esc_or_q() {
        assert_eq!(action_from_key(Key::Esc), Some(Action::Quit));
        assert_eq!(action_from_key(Key::Char('q')), Some(Action::Quit));
    }

    #[test]
    fn arrows_scroll_the_node_list() {
        assert_eq!(action_from_key(Key::Down), Some(Action::ScrollNodes(1)));
        assert_eq!(action_from_key(Key::Up), Some(Action::ScrollNodes(-1)));
    }

    #[test]
    fn unknown_keys_are_ignored() {
        assert_eq!(action_from_key(Key::Tab), None);
        assert_eq!(action_from_key(Key::Char('z')), None);
    }

    #[test]
    fn filter_sort_tree_keys_map_to_actions() {
        assert_eq!(action_from_key(Key::Char('/')), Some(Action::BeginFilter));
        assert_eq!(action_from_key(Key::Char('s')), Some(Action::CycleSort));
        assert_eq!(
            action_from_key(Key::Char('t')),
            Some(Action::ToggleTreeView)
        );
    }

    #[test]
    fn control_keys_map_to_daemon_bound_actions() {
        assert_eq!(action_from_key(Key::Enter), Some(Action::SelectNode));
        assert_eq!(action_from_key(Key::Char('g')), Some(Action::CycleMode));
        assert_eq!(action_from_key(Key::Char('r')), Some(Action::RestartCore));
        assert_eq!(
            action_from_key(Key::Char('c')),
            Some(Action::CloseConnections)
        );
    }
}
