//! Formatting helpers shared by panel drawing.

use caly_domain::{Capability, CoreRunState, DisplayNode, NodeId, PresentationSnapshot};

use super::canvas::Canvas;
use super::layout::Rect;
use super::style::{Rgb, Style, Theme};

pub(super) fn kv(
    canvas: &mut Canvas,
    rect: Rect,
    row: usize,
    label: &str,
    value: &str,
    style: Style,
) {
    canvas.text(
        row,
        rect.col().saturating_add(2),
        label,
        Style::plain(MUTED),
    );
    canvas.text(
        row,
        rect.col().saturating_add(2).saturating_add(label.len()),
        value,
        style,
    );
}

/// Fallback muted gray used for labels regardless of the active theme.
const MUTED: Rgb = Rgb::new(106, 115, 130);

pub(super) fn state_label(state: CoreRunState) -> &'static str {
    match state {
        CoreRunState::Stopped => "stopped",
        CoreRunState::Starting => "starting",
        CoreRunState::Running => "running",
        CoreRunState::Stopping => "stopping",
        CoreRunState::Crashed => "crashed",
        CoreRunState::Failed => "failed",
    }
}

pub(super) fn state_style(state: CoreRunState, theme: &Theme) -> Style {
    let color = match state {
        CoreRunState::Running => theme.ok,
        CoreRunState::Starting | CoreRunState::Stopping => theme.warn,
        CoreRunState::Stopped | CoreRunState::Crashed | CoreRunState::Failed => theme.error,
    };
    Style::bold(color)
}

pub(super) fn capability_label(capability: Capability) -> &'static str {
    match capability {
        Capability::TunConfiguration => "tun",
        Capability::DnsConfiguration => "dns",
        Capability::RuntimeModeSwitch => "mode-switch",
        Capability::ProxyGroups => "groups",
        Capability::ProxySelection => "select",
        Capability::UrlTest => "url-test",
        Capability::Connections => "connections",
        Capability::ConnectionClose => "close",
        Capability::Traffic => "traffic",
        Capability::Logs => "logs",
        Capability::Rules => "rules",
    }
}

pub(super) fn format_bps(value: u64) -> String {
    const UNITS: [&str; 4] = ["B/s", "KB/s", "MB/s", "GB/s"];
    let mut scaled = value;
    let mut unit = 0;
    while scaled >= 1024 && unit < UNITS.len() - 1 {
        scaled /= 1024;
        unit += 1;
    }
    format!("{scaled} {}", UNITS[unit])
}

pub(super) fn bool_label(value: bool) -> String {
    if value {
        "on".to_owned()
    } else {
        "off".to_owned()
    }
}

pub(super) fn hex(bytes: [u8; 16]) -> String {
    caly_domain::to_hex(bytes)
}

/// Truncates a string to at most `max` characters without splitting a char.
pub(super) fn clip(value: &str, max: usize) -> &str {
    if max == 0 {
        return "";
    }
    for (count, (index, _ch)) in value.char_indices().enumerate() {
        if count >= max {
            return &value[..index];
        }
    }
    value
}

/// Yields nodes in `node_order` when given, else the snapshot's natural order.
///
/// Indexes nodes by id once (O(n)) so resolving an ordered list is O(n) total
/// instead of O(n²) linear lookups per id.
pub(super) fn ordered_nodes<'a>(
    snapshot: &'a PresentationSnapshot,
    node_order: Option<&'a [NodeId]>,
) -> Box<dyn Iterator<Item = &'a DisplayNode> + 'a> {
    match node_order {
        Some(ids) if !ids.is_empty() => {
            let by_id: std::collections::HashMap<_, _> = snapshot
                .nodes()
                .iter()
                .map(|node| (node.id(), node))
                .collect();
            Box::new(ids.iter().filter_map(move |id| by_id.get(id).copied()))
        }
        // No reordering requested (or an empty order): stream the snapshot's
        // nodes directly, so drawing only the visible rows is truly lazy.
        _ => Box::new(snapshot.nodes().iter()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bps_formatting_scales_units() {
        assert!(format_bps(100).ends_with("B/s"));
        assert_eq!(format_bps(2048), "2 KB/s");
        assert_eq!(format_bps(2 * 1024 * 1024), "2 MB/s");
    }

    #[test]
    fn clip_honors_max_columns() {
        assert_eq!(clip("hello", 3), "hel");
        assert_eq!(clip("hi", 5), "hi");
    }

    #[test]
    fn clip_never_splits_a_multibyte_char() {
        // "é" is two UTF-8 bytes; clipping to one column must keep the whole char.
        assert_eq!(clip("éx", 1), "é");
        assert_eq!(clip("éx", 0), "");
        assert_eq!(clip("你abc", 2), "你a");
    }

    #[test]
    fn hex_produces_full_width() {
        assert_eq!(
            hex([0xab, 0xcd, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]).len(),
            32
        );
    }

    #[test]
    fn ordered_nodes_follows_given_order_and_skips_missing() -> Result<(), &'static str> {
        use caly_domain::{
            AppliedState, BoundedVec, CapabilitySet, CoreKind, CoreRunState, DaemonInstanceId,
            DesiredState, DisplayNode, EventCursor, EventSequence, NodeDisplayName, NodeId,
            NodeProtocolLabel, ObservedState, PlatformEffectView, PresentationSnapshot, ProxyMode,
            SnapshotNodes, SnapshotRevision,
        };
        let mut nodes: SnapshotNodes = BoundedVec::new();
        for (id, name) in [(1u8, "a"), (2, "b"), (3, "c")] {
            nodes
                .try_push(DisplayNode::new(
                    NodeId::from_bytes([id; 16]),
                    NodeDisplayName::new(name.to_owned()).map_err(|_| "name")?,
                    NodeProtocolLabel::new("vmess".to_owned()).map_err(|_| "proto")?,
                    true,
                    None,
                ))
                .map_err(|_| "push")?;
        }
        let daemon = DaemonInstanceId::from_bytes([5; 16]);
        let snapshot = PresentationSnapshot::new(
            daemon,
            SnapshotRevision::new(1),
            EventCursor::new(daemon, EventSequence::new(1)),
            DesiredState::new(ProxyMode::Rule, None, None, false, false),
            AppliedState::new(Some(CoreKind::Mihomo), CoreRunState::Running, None, Some(1))
                .map_err(|_| "applied")?,
            ObservedState::new(0, 0, 0, 0),
            PlatformEffectView::none(),
            CapabilitySet::new(BoundedVec::new()).map_err(|_| "cap")?,
            nodes,
        );
        // Order [3, 1] plus a missing id 9 that must be skipped.
        let order = vec![
            NodeId::from_bytes([3; 16]),
            NodeId::from_bytes([9; 16]),
            NodeId::from_bytes([1; 16]),
        ];
        let names: Vec<_> = ordered_nodes(&snapshot, Some(&order))
            .map(|node| node.name().as_str())
            .collect();
        assert_eq!(names, vec!["c", "a"]);
        Ok(())
    }
}
