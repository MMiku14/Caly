//! A styled cell canvas that flushes to a 24-bit ANSI frame.

use super::layout::Rect;
use super::style::{Rgb, Style, ansi_bg, ansi_bold, ansi_fg, ansi_move, ansi_reset};

/// A single styled cell.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Cell {
    ch: char,
    style: Style,
}

impl Cell {
    /// Constructs a styled cell.
    pub const fn new(ch: char, style: Style) -> Self {
        Self { ch, style }
    }

    /// The rendered character.
    pub const fn ch(self) -> char {
        self.ch
    }
    /// The cell style.
    pub const fn style(self) -> Style {
        self.style
    }
}

/// Terminal-sized backing store of styled cells.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Canvas {
    rows: usize,
    cols: usize,
    background: Rgb,
    cells: Vec<Vec<Cell>>,
}

impl Canvas {
    /// Fills a canvas with blank cells on a base background.
    pub fn new(rows: usize, cols: usize, background: Rgb) -> Self {
        let style = Style::plain(background);
        let blank = Cell::new(' ', style);
        let cells = vec![vec![blank; cols]; rows];
        Self {
            rows,
            cols,
            background,
            cells,
        }
    }

    /// Row count.
    pub const fn rows(&self) -> usize {
        self.rows
    }
    /// Column count.
    pub const fn cols(&self) -> usize {
        self.cols
    }

    /// Reads a cell, returning the background blank when out of bounds.
    pub fn cell(&self, row: usize, col: usize) -> Cell {
        self.cells
            .get(row)
            .and_then(|line| line.get(col))
            .copied()
            .unwrap_or(Cell::new(' ', Style::plain(self.background)))
    }

    /// Writes one cell, ignoring out-of-bounds writes.
    pub fn set(&mut self, row: usize, col: usize, cell: Cell) {
        if let Some(slot) = self.cells.get_mut(row).and_then(|line| line.get_mut(col)) {
            *slot = cell;
        }
    }

    /// Fills a rectangle with a single character and style.
    pub fn fill_rect(&mut self, rect: Rect, ch: char, style: Style) {
        for row in rect.row()..rect.bottom() {
            for col in rect.col()..rect.right() {
                self.set(row, col, Cell::new(ch, style));
            }
        }
    }

    /// Writes text horizontally, truncating at the canvas edge.
    pub fn text(&mut self, row: usize, col: usize, text: &str, style: Style) {
        for (offset, ch) in text.chars().enumerate() {
            self.set(row, col.saturating_add(offset), Cell::new(ch, style));
        }
    }

    /// Draws a box-drawing border around a rectangle.
    pub fn box_frame(&mut self, rect: Rect, style: Style) {
        let right = rect.right().saturating_sub(1);
        let bottom = rect.bottom().saturating_sub(1);
        self.set(rect.row(), rect.col(), Cell::new('┌', style));
        self.set(rect.row(), right, Cell::new('┐', style));
        self.set(bottom, rect.col(), Cell::new('└', style));
        self.set(bottom, right, Cell::new('┘', style));
        for col in rect.col().saturating_add(1)..right {
            self.set(rect.row(), col, Cell::new('─', style));
            self.set(bottom, col, Cell::new('─', style));
        }
        for row in rect.row().saturating_add(1)..bottom {
            self.set(row, rect.col(), Cell::new('│', style));
            self.set(row, right, Cell::new('│', style));
        }
    }

    /// Draws a boxed panel with a bold title and a border.
    pub fn panel(&mut self, rect: Rect, title: &str, theme: &super::style::Theme) {
        let border = Style::plain(theme.border);
        self.box_frame(rect, border);
        let title_style = Style::bold(theme.accent);
        self.text(rect.row(), rect.col().saturating_add(2), title, title_style);
    }

    /// Flushes the canvas as one ANSI frame with a leading clear/home.
    pub fn to_ansi(&self) -> String {
        let mut out = String::from("\x1b[2J\x1b[H");
        for row in 0..self.rows {
            out += &ansi_move(row, 0);
            let mut active: Option<Style> = None;
            for col in 0..self.cols {
                let cell = self.cells[row][col];
                if active != Some(cell.style) {
                    out += ansi_reset();
                    out += &ansi_fg(cell.style.fg());
                    match cell.style.bg() {
                        Some(bg) => out += &ansi_bg(bg),
                        None => out += &ansi_bg(self.background),
                    }
                    if cell.style.is_bold() {
                        out += ansi_bold();
                    }
                    active = Some(cell.style);
                }
                out.push(cell.ch);
            }
            out += ansi_reset();
            if row + 1 < self.rows {
                out.push('\n');
            }
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn theme() -> super::super::style::Theme {
        super::super::style::Theme::default()
    }

    #[test]
    fn out_of_bounds_writes_are_ignored() {
        let mut canvas = Canvas::new(2, 2, Rgb::new(0, 0, 0));
        canvas.set(99, 99, Cell::new('x', Style::plain(Rgb::new(1, 1, 1))));
        canvas.set(0, 0, Cell::new('a', Style::plain(Rgb::new(1, 1, 1))));
        assert_eq!(canvas.cell(0, 0).ch(), 'a');
    }

    #[test]
    fn text_is_truncated_at_canvas_edge() {
        let mut canvas = Canvas::new(1, 3, Rgb::new(0, 0, 0));
        canvas.text(0, 0, "abcdef", Style::plain(Rgb::new(1, 1, 1)));
        assert_eq!(canvas.cell(0, 0).ch(), 'a');
        assert_eq!(canvas.cell(0, 2).ch(), 'c');
        assert_eq!(canvas.cell(0, 3).ch(), ' ');
    }

    #[test]
    fn panel_draws_title_and_border() {
        let mut canvas = Canvas::new(5, 12, Rgb::new(0, 0, 0));
        canvas.panel(Rect::new(0, 0, 12, 5), "CORE", &theme());
        assert_eq!(canvas.cell(0, 0).ch(), '┌');
        assert_eq!(canvas.cell(0, 2).ch(), 'C');
        assert_eq!(canvas.cell(4, 11).ch(), '┘');
    }

    #[test]
    fn ansi_frame_is_nonempty_and_resets() {
        let canvas = Canvas::new(2, 4, Rgb::new(0, 0, 0));
        let frame = canvas.to_ansi();
        assert!(frame.starts_with("\x1b[2J\x1b[H"));
        assert!(frame.ends_with("\x1b[0m"));
        assert!(frame.contains("\x1b[1;1H"));
    }
}
