//! Raw terminal byte sequences parsed into high-level keys.
//!
//! Parsing is a pure function over a byte slice so it is fully unit-testable
//! and independent of any real terminal. A caller feeding a streaming reader
//! accumulates bytes and calls `parse_key` on each candidate boundary.

/// A single parsed key event.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Key {
    /// A printable ASCII character.
    Char(char),
    /// Return / Enter.
    Enter,
    /// Tab.
    Tab,
    /// Escape (`\x1b` alone).
    Esc,
    /// Backspace / Delete (`0x7f` or `0x08`).
    Backspace,
    /// Arrow keys.
    Up,
    Down,
    Left,
    Right,
    /// Home / End.
    Home,
    End,
    /// Page Up / Page Down.
    PageUp,
    PageDown,
}

/// Parses one key from a raw byte sequence (CSI sequences included).
///
/// Returns `None` when the bytes do not form a recognized key or when the
/// sequence is a partial prefix (so a caller can wait for more bytes).
pub fn parse_key(bytes: &[u8]) -> Option<Key> {
    match bytes {
        [] => None,
        [0x1b] => Some(Key::Esc),
        [0x1b, b'[', b'A'] => Some(Key::Up),
        [0x1b, b'[', b'B'] => Some(Key::Down),
        [0x1b, b'[', b'C'] => Some(Key::Right),
        [0x1b, b'[', b'D'] => Some(Key::Left),
        [0x1b, b'[', b'H'] => Some(Key::Home),
        [0x1b, b'[', b'F'] => Some(Key::End),
        [0x1b, b'[', b'5', b'~'] => Some(Key::PageUp),
        [0x1b, b'[', b'6', b'~'] => Some(Key::PageDown),
        [0x7f] | [0x08] => Some(Key::Backspace),
        [0x0d] => Some(Key::Enter),
        [0x09] => Some(Key::Tab),
        [byte] if byte.is_ascii_graphic() || *byte == b' ' => Some(Key::Char(*byte as char)),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_printable_single_byte() {
        assert_eq!(parse_key(b"q"), Some(Key::Char('q')));
        assert_eq!(parse_key(b" "), Some(Key::Char(' ')));
    }

    #[test]
    fn parses_backspace_del_and_bs() {
        assert_eq!(parse_key(b"\x7f"), Some(Key::Backspace));
        assert_eq!(parse_key(b"\x08"), Some(Key::Backspace));
    }

    #[test]
    fn parses_csi_arrow_sequences() {
        assert_eq!(parse_key(b"\x1b[A"), Some(Key::Up));
        assert_eq!(parse_key(b"\x1b[B"), Some(Key::Down));
        assert_eq!(parse_key(b"\x1b[C"), Some(Key::Right));
        assert_eq!(parse_key(b"\x1b[D"), Some(Key::Left));
        assert_eq!(parse_key(b"\x1b[5~"), Some(Key::PageUp));
        assert_eq!(parse_key(b"\x1b[6~"), Some(Key::PageDown));
    }

    #[test]
    fn esc_alone_is_escape() {
        assert_eq!(parse_key(b"\x1b"), Some(Key::Esc));
    }

    #[test]
    fn unrecognized_bytes_are_none() {
        assert_eq!(parse_key(&[0x00]), None);
        assert_eq!(parse_key(&[0x1b, 0x02]), None);
    }
}
