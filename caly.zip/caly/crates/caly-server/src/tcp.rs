//! Loopback TCP transport for the configured `daemon.listen` address.

use std::{future::Future, net::SocketAddr};

use caly_application::service::ApplicationServicePort;
use tokio::net::TcpListener;

use crate::json::JsonService;
use crate::uds::shutdown_signal;

/// Serves the JSON-framed service over a TCP listener until a shutdown signal
/// or the application-owned fatal future completes.
///
/// The TCP transport is the explicitly configured `daemon.listen` endpoint;
/// it shares the same `JsonService` (and thus the daemon session registry)
/// as the owner-only UDS transport.
pub async fn serve_tcp_until<A, F>(
    listen: SocketAddr,
    service: JsonService<A>,
    application_shutdown: F,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>>
where
    A: ApplicationServicePort + Send + 'static,
    F: Future<Output = ()> + Send + 'static,
{
    let listener = TcpListener::bind(listen).await?;
    let shutdown = async move {
        tokio::select! {
            () = shutdown_signal() => {},
            () = application_shutdown => {},
        }
    };
    tokio::pin!(shutdown);
    loop {
        tokio::select! {
            () = &mut shutdown => return Ok(()),
            accepted = listener.accept() => {
                let (stream, _) = accepted?;
                let service = service.clone();
                tokio::spawn(async move {
                    service.handle_connection(stream).await;
                });
            }
        }
    }
}
