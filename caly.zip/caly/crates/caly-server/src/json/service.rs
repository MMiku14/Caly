//! Shared JSON-framed service owner, per-connection dispatch and watch stream.
//!
//! One `JsonService` owns the application adapter and the bounded session
//! registry shared by every transport connection. Each accepted connection
//! runs one task that reads length-prefixed JSON request frames and writes
//! result/error frames; a `WatchEvents` request switches the connection to a
//! continuous watch stream on a dedicated connection until the peer
//! disconnects.

use std::{
    pin::Pin,
    sync::{Arc, Mutex},
    task::{Context, Poll},
};

use caly_application::{events::SequencedEvent, service::ApplicationServicePort};
use caly_domain::UnixMillis;
use caly_protocol::{
    framing::{FrameError, decode_json, encode_json, read_frame, write_frame},
    protocol::v2::{HandshakeRequest, WatchEventsRequest, WatchResponse},
    wire_frames::{
        ClientFrame, JsonRequest, JsonResponse, ServerFrame, WireError, WireErrorCode, wire_error,
    },
};
use tokio::io::{AsyncRead, AsyncWrite};
use tokio_stream::{Stream, StreamExt, wrappers::BroadcastStream};

use super::{
    ProtocolSession, ServiceAdapter, ServiceError, ServiceV2, SessionError, SessionRegistry,
    event_to_wire, parse_session_token, unix_millis,
};
use crate::json::SESSION_TTL_MS;

/// Shared JSON-framed service owner.
pub struct JsonService<A> {
    state: Arc<Mutex<ServiceState<A>>>,
}

struct ServiceState<A> {
    adapter: ServiceAdapter<A>,
    registry: SessionRegistry,
}

impl<A> Clone for JsonService<A> {
    fn clone(&self) -> Self {
        Self {
            state: Arc::clone(&self.state),
        }
    }
}

impl<A> JsonService<A> {
    /// Wraps one application adapter in a shared service owner. The bounded
    /// session registry capacity is a compile-time constant, so construction
    /// only fails if that bound is ever violated; the error is surfaced
    /// instead of aborting the daemon.
    pub fn new(adapter: ServiceAdapter<A>) -> Result<Self, SessionError> {
        Ok(Self {
            state: Arc::new(Mutex::new(ServiceState {
                adapter,
                // Bounded; token collisions are resolved by refresh-on-handshake.
                registry: SessionRegistry::new(super::MAX_PROTOCOL_SESSIONS)?,
            })),
        })
    }

    /// Number of currently live sessions; used by tests and diagnostics.
    pub fn live_sessions(&self) -> usize {
        self.state.lock().map_or(0, |state| state.registry.len())
    }

    /// Transport message ceiling (bytes) derived from the decode limits.
    pub fn message_ceiling(&self) -> usize {
        self.state
            .lock()
            .map_or(0, |state| state.adapter.limits().max_message_bytes)
    }

    /// Serves one accepted connection until the peer disconnects or the frame
    /// stream becomes unrecoverable.
    pub async fn handle_connection<S>(&self, stream: S)
    where
        A: ApplicationServicePort + Send,
        S: AsyncRead + AsyncWrite + Unpin,
    {
        let (mut reader, mut writer) = tokio::io::split(stream);
        let ceiling = self.message_ceiling();
        loop {
            let payload = match read_frame(&mut reader, ceiling).await {
                Ok(payload) => payload,
                Err(FrameError::Closed | FrameError::Io) => break,
                Err(FrameError::Oversized { .. }) => {
                    // Framing cannot resynchronize after an oversized header.
                    let frame = ServerFrame::Error(wire_error(
                        WireErrorCode::InvalidArgument,
                        "frame exceeds the negotiated message ceiling",
                    ));
                    let _ = write_json_frame(&mut writer, &frame).await;
                    break;
                }
            };
            let client = match decode_json::<ClientFrame>(&payload) {
                Ok(client) => client,
                Err(error) => {
                    let frame = ServerFrame::Error(wire_error(
                        WireErrorCode::InvalidArgument,
                        format!("malformed request frame: {error}"),
                    ));
                    let _ = write_json_frame(&mut writer, &frame).await;
                    continue;
                }
            };
            match client.request {
                JsonRequest::Handshake(request) => match self.handshake(request) {
                    Ok(response) => {
                        let _ = write_json_frame(
                            &mut writer,
                            &ServerFrame::Result(Box::new(JsonResponse::Handshake(response))),
                        )
                        .await;
                    }
                    Err(error) => {
                        let _ = write_json_frame(&mut writer, &ServerFrame::Error(error)).await;
                    }
                },
                JsonRequest::WatchEvents(request) => {
                    if let Err(error) = self.validate_session(client.session) {
                        let _ = write_json_frame(&mut writer, &ServerFrame::Error(error)).await;
                        continue;
                    }
                    // The connection becomes a dedicated watch stream.
                    self.stream_watch(writer, request).await;
                    break;
                }
                other => {
                    let outcome = match self.validate_session(client.session) {
                        Ok(()) => self.dispatch(other),
                        Err(error) => Err(error),
                    };
                    match outcome {
                        Ok(response) => {
                            let _ = write_json_frame(
                                &mut writer,
                                &ServerFrame::Result(Box::new(response)),
                            )
                            .await;
                        }
                        Err(error) => {
                            let _ = write_json_frame(&mut writer, &ServerFrame::Error(error)).await;
                        }
                    }
                }
            }
        }
    }

    /// Registers (or refreshes) the daemon session token with a real expiry so
    /// subsequent requests are validated against the live registry.
    fn handshake(
        &self,
        request: HandshakeRequest,
    ) -> Result<caly_protocol::protocol::v2::HandshakeResponse, WireError>
    where
        A: ApplicationServicePort,
    {
        let mut state = lock_state(&self.state)?;
        let response = state.adapter.handshake(request).map_err(service_to_wire)?;
        let now = unix_millis();
        state.registry.purge_expired(now);
        let session = ProtocolSession {
            token: response.session_token,
            version: response.negotiated_version,
            features: response.enabled_features.clone(),
            expires_at: UnixMillis::new(now.value().saturating_add(SESSION_TTL_MS)),
        };
        state.registry.refresh(session).map_err(session_to_wire)?;
        Ok(response)
    }

    /// Validates the request's hex session token against the live registry.
    fn validate_session(&self, session: Option<String>) -> Result<(), WireError> {
        let value = session.ok_or_else(|| {
            wire_error(WireErrorCode::Unauthenticated, "session token is required")
        })?;
        let token = parse_session_token(&value)
            .map_err(|_| wire_error(WireErrorCode::Unauthenticated, "session token is invalid"))?;
        let mut state = lock_state(&self.state)?;
        let now = unix_millis();
        state.registry.purge_expired(now);
        state
            .registry
            .validate(token, now)
            .map(|_| ())
            .map_err(session_to_wire)
    }

    /// Dispatches one non-handshake, non-watch request to the application.
    fn dispatch(&self, request: JsonRequest) -> Result<JsonResponse, WireError>
    where
        A: ApplicationServicePort,
    {
        let mut state = lock_state(&self.state)?;
        match request {
            JsonRequest::Execute(request) => state
                .adapter
                .execute(request)
                .map(JsonResponse::Execute)
                .map_err(service_to_wire),
            JsonRequest::CancelOperation(request) => state
                .adapter
                .cancel(request)
                .map(JsonResponse::CancelOperation)
                .map_err(service_to_wire),
            JsonRequest::GetOperationStatus(request) => state
                .adapter
                .status(request)
                .map(JsonResponse::GetOperationStatus)
                .map_err(service_to_wire),
            JsonRequest::GetSnapshot(_) => state
                .adapter
                .snapshot()
                .map(JsonResponse::GetSnapshot)
                .map_err(service_to_wire),
            JsonRequest::Handshake(_) | JsonRequest::WatchEvents(_) => Err(wire_error(
                WireErrorCode::InvalidArgument,
                "method not dispatched here",
            )),
        }
    }

    /// Streams the initial replay followed by live projection events until the
    /// peer disconnects or the application broadcast closes.
    async fn stream_watch<W>(&self, mut writer: W, request: WatchEventsRequest)
    where
        A: ApplicationServicePort + Send,
        W: AsyncWrite + Unpin,
    {
        // Build the stream inside a single async step so the shared adapter
        // lock is never held across an await (the stream must stay Send).
        let built = async {
            let mut state = lock_state(&self.state)?;
            let initial = state.adapter.watch(request).map_err(service_to_wire)?;
            let live = state.adapter.subscribe_live().map_err(service_to_wire)?;
            Ok::<WatchStream<A>, WireError>(WatchStream {
                initial,
                live: BroadcastStream::new(live),
                state: Arc::clone(&self.state),
            })
        }
        .await;
        let stream = match built {
            Ok(stream) => stream,
            Err(error) => {
                let _ = write_json_frame(&mut writer, &ServerFrame::Error(error)).await;
                return;
            }
        };
        let mut stream = Box::pin(stream);
        while let Some(item) = stream.next().await {
            let frame = match item {
                Ok(wire) => ServerFrame::Result(Box::new(JsonResponse::WatchEvent(wire))),
                Err(error) => ServerFrame::Error(service_to_wire(error)),
            };
            if write_json_frame(&mut writer, &frame).await.is_err() {
                // Peer disconnected; the daemon-side stream is done.
                break;
            }
            if matches!(frame, ServerFrame::Error(_)) {
                break;
            }
        }
    }
}

/// Continuous watch stream: yields the initial replay/snapshot, then follows
/// live projection events. A slow subscriber that lags the broadcast ring is
/// sent a fresh full snapshot and re-subscribes, so a slow client only drops
/// best-effort live events and never blocks the authoritative projector.
pub struct WatchStream<A> {
    initial: std::vec::IntoIter<Result<WatchResponse, ServiceError>>,
    live: BroadcastStream<SequencedEvent>,
    state: Arc<Mutex<ServiceState<A>>>,
}

impl<A> WatchStream<A> {
    /// Fetches the current authoritative snapshot as a wire watch response.
    fn fetch_snapshot(&self) -> Option<Result<WatchResponse, ServiceError>>
    where
        A: ApplicationServicePort,
    {
        let mut state = lock_state(&self.state).ok()?;
        let wire = ServiceV2::snapshot(&mut state.adapter).ok()?;
        Some(Ok(WatchResponse::FullSnapshot(wire)))
    }

    /// Re-subscribes to the live broadcast after a lag recovery.
    fn resubscribe(&self) -> Option<BroadcastStream<SequencedEvent>>
    where
        A: ApplicationServicePort,
    {
        lock_state(&self.state)
            .ok()?
            .adapter
            .subscribe_live()
            .ok()
            .map(BroadcastStream::new)
    }
}

impl<A> Stream for WatchStream<A>
where
    A: ApplicationServicePort + Send,
{
    type Item = Result<WatchResponse, ServiceError>;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let this = self.get_mut();
        if let Some(item) = this.initial.next() {
            return Poll::Ready(Some(item));
        }
        loop {
            match Pin::new(&mut this.live).poll_next(cx) {
                Poll::Pending => return Poll::Pending,
                Poll::Ready(None) => return Poll::Ready(None),
                Poll::Ready(Some(Err(_))) => {
                    let snapshot = this.fetch_snapshot();
                    this.live = match this.resubscribe() {
                        Some(stream) => stream,
                        None => return Poll::Ready(None),
                    };
                    if let Some(snapshot) = snapshot {
                        return Poll::Ready(Some(snapshot));
                    }
                }
                Poll::Ready(Some(Ok(event))) => {
                    let Ok(wire) = event_to_wire(&event) else {
                        return Poll::Ready(Some(Err(ServiceError::ApplicationUnavailable)));
                    };
                    return Poll::Ready(Some(Ok(WatchResponse::Event(wire))));
                }
            }
        }
    }
}

/// Serializes and writes one JSON-framed server frame.
async fn write_json_frame<W>(writer: &mut W, frame: &ServerFrame) -> Result<(), FrameError>
where
    W: AsyncWrite + Unpin,
{
    let payload = encode_json(frame).map_err(|_| FrameError::Io)?;
    write_frame(writer, &payload).await
}

fn lock_state<A>(
    state: &Arc<Mutex<ServiceState<A>>>,
) -> Result<std::sync::MutexGuard<'_, ServiceState<A>>, WireError> {
    state.lock().map_err(|_| {
        wire_error(
            WireErrorCode::ApplicationUnavailable,
            "service state lock poisoned",
        )
    })
}

fn service_to_wire(error: ServiceError) -> WireError {
    match error {
        ServiceError::Unauthenticated | ServiceError::HandshakeRequired => wire_error(
            WireErrorCode::Unauthenticated,
            "handshake or session authentication required",
        ),
        ServiceError::PermissionDenied => {
            wire_error(WireErrorCode::PermissionDenied, "permission denied")
        }
        ServiceError::ResourceExhausted => wire_error(
            WireErrorCode::ResourceExhausted,
            "bounded resource exhausted",
        ),
        ServiceError::InvalidArgument { reason } => {
            wire_error(WireErrorCode::InvalidArgument, reason)
        }
        ServiceError::IncompatibleVersion => wire_error(
            WireErrorCode::IncompatibleVersion,
            "incompatible protocol version",
        ),
        ServiceError::ApplicationUnavailable => wire_error(
            WireErrorCode::ApplicationUnavailable,
            "application unavailable",
        ),
    }
}

fn session_to_wire(error: SessionError) -> WireError {
    match error {
        SessionError::CapacityReached => {
            wire_error(WireErrorCode::ResourceExhausted, "session capacity reached")
        }
        SessionError::TokenCollision | SessionError::InvalidToken => wire_error(
            WireErrorCode::Unauthenticated,
            "session token collision or invalid",
        ),
        SessionError::Missing | SessionError::Expired => wire_error(
            WireErrorCode::Unauthenticated,
            "session token is missing or expired",
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use caly_application::{
        command_bus::CommandEnvelope,
        events::SequencedEvent,
        service::{ApplicationServiceError, ApplicationWatch, CancellationResult},
    };
    use caly_domain::UnixMillis;
    use caly_domain::{EventCursor, OperationId, OperationStatus, PresentationSnapshot};
    use caly_protocol::protocol::v2::{DecodeLimits, FeatureList, ProtocolVersion};

    /// Session-only stub; the validated paths never touch the application.
    struct StubApp;

    impl ApplicationServicePort for StubApp {
        fn submit(
            &mut self,
            _envelope: CommandEnvelope,
        ) -> Result<OperationStatus, ApplicationServiceError> {
            Err(ApplicationServiceError::Unavailable)
        }
        fn cancel(
            &mut self,
            _operation_id: OperationId,
        ) -> Result<CancellationResult, ApplicationServiceError> {
            Err(ApplicationServiceError::Unavailable)
        }
        fn operation_status(
            &self,
            _operation_id: OperationId,
        ) -> Result<OperationStatus, ApplicationServiceError> {
            Err(ApplicationServiceError::Unavailable)
        }
        fn snapshot(&self) -> Result<PresentationSnapshot, ApplicationServiceError> {
            Err(ApplicationServiceError::Unavailable)
        }
        fn watch_after(
            &self,
            _cursor: Option<EventCursor>,
        ) -> Result<ApplicationWatch, ApplicationServiceError> {
            Err(ApplicationServiceError::Unavailable)
        }
        fn subscribe_live(&self) -> tokio::sync::broadcast::Receiver<SequencedEvent> {
            tokio::sync::broadcast::channel(1).0.subscribe()
        }
    }

    fn session(token: [u8; 16], expires: u64) -> ProtocolSession {
        ProtocolSession {
            token,
            version: ProtocolVersion::V2_0,
            features: FeatureList::new(),
            expires_at: UnixMillis::new(expires),
        }
    }

    fn service_with_registry(capacity: usize) -> Result<JsonService<StubApp>, SessionError> {
        let adapter = ServiceAdapter::new(
            StubApp,
            [0; 16],
            [0; 16],
            FeatureList::new(),
            DecodeLimits::v2_default(),
        );
        Ok(JsonService {
            state: Arc::new(Mutex::new(ServiceState {
                adapter,
                registry: SessionRegistry::new(capacity)?,
            })),
        })
    }

    #[test]
    fn validate_session_accepts_live_token_and_rejects_unknown() -> Result<(), SessionError> {
        let service = service_with_registry(4)?;
        service
            .state
            .lock()
            .map_err(|_| SessionError::InvalidToken)?
            .registry
            .insert(session([1; 16], u64::MAX))?;
        let accepted = service.validate_session(Some(caly_domain::to_hex([1; 16])));
        assert!(accepted.is_ok());
        assert!(
            service
                .validate_session(Some(caly_domain::to_hex([2; 16])))
                .is_err()
        );
        Ok(())
    }

    #[test]
    fn validate_session_rejects_missing_token() {
        let service = service_with_registry(4).unwrap_or_else(|_| std::process::abort());
        assert!(service.validate_session(None).is_err());
    }

    #[test]
    fn validate_session_rejects_expired_token() -> Result<(), SessionError> {
        let service = service_with_registry(4)?;
        service
            .state
            .lock()
            .map_err(|_| SessionError::InvalidToken)?
            .registry
            .insert(session([3; 16], 5))?; // expires at t=5
        // Wall clock is past 5ms since Unix epoch; the token must be expired.
        assert!(
            service
                .validate_session(Some(caly_domain::to_hex([3; 16])))
                .is_err()
        );
        Ok(())
    }
}

#[cfg(test)]
mod live_watch_tests;
