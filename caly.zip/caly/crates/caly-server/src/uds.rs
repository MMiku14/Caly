//! Linux owner-only Unix-domain-socket transport.

use std::{
    future::Future,
    io,
    path::{Path, PathBuf},
};

use caly_application::service::ApplicationServicePort;
use tokio::net::UnixListener;

use crate::json::JsonService;

/// Binds an owner-only Linux UDS, removing only an existing socket node.
///
/// The daemon entry point validates the existing path (type, owner, symlink)
/// via `caly_platform::uds::validate_uds_path` before this bind is reached, so
/// the bind only ever replaces a stale socket the current user owns.
pub fn bind_owner_only(path: &Path) -> io::Result<UnixListener> {
    if path.exists() {
        std::fs::remove_file(path)?;
    }
    let listener = UnixListener::bind(path)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600))?;
    }
    Ok(listener)
}

/// Serves the JSON-framed service over an owner-only UDS.
pub async fn serve_owner_only<A>(
    path: PathBuf,
    service: JsonService<A>,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>>
where
    A: ApplicationServicePort + Send + 'static,
{
    serve_owner_only_until_signal(path, service).await
}

pub(crate) async fn shutdown_signal() {
    #[cfg(unix)]
    {
        use tokio::signal::unix::{SignalKind, signal};
        let mut terminate = signal(SignalKind::terminate()).ok();
        tokio::select! {
            _ = tokio::signal::ctrl_c() => {},
            () = async { if let Some(signal) = terminate.as_mut() { signal.recv().await; } } => {},
        }
    }
    #[cfg(not(unix))]
    {
        let _ = tokio::signal::ctrl_c().await;
    }
}

/// Serves until SIGINT/SIGTERM-compatible Ctrl-C shutdown is received.
pub async fn serve_owner_only_until_signal<A>(
    path: PathBuf,
    service: JsonService<A>,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>>
where
    A: ApplicationServicePort + Send + 'static,
{
    serve_owner_only_until(path, service, std::future::pending()).await
}

/// Serves until either an OS shutdown signal or an application-owned fatal
/// shutdown future completes. Each accepted connection runs its own task; a
/// shutdown stops acceptance without waiting for long-lived watch streams,
/// mirroring the daemon's process-level cleanup contract.
pub async fn serve_owner_only_until<A, F>(
    path: PathBuf,
    service: JsonService<A>,
    application_shutdown: F,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>>
where
    A: ApplicationServicePort + Send + 'static,
    F: Future<Output = ()> + Send + 'static,
{
    let listener = bind_owner_only(&path)?;
    let shutdown = async move {
        tokio::select! {
            () = shutdown_signal() => {},
            () = application_shutdown => {},
        }
    };
    tokio::pin!(shutdown);
    loop {
        tokio::select! {
            () = &mut shutdown => return Ok(()),
            accepted = listener.accept() => {
                let (stream, _) = accepted?;
                let service = service.clone();
                tokio::spawn(async move {
                    service.handle_connection(stream).await;
                });
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    #[tokio::test]
    async fn bind_creates_owner_only_socket() -> io::Result<()> {
        let path = std::env::temp_dir().join(format!(
            "caly-uds-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map_or(0, |value| value.as_nanos())
        ));
        let listener = bind_owner_only(&path)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            assert_eq!(
                std::fs::metadata(&path)?.permissions().mode() & 0o777,
                0o600
            );
        }
        drop(listener);
        std::fs::remove_file(path)
    }
}
